# QA 報告：who-hid-the-seeds / zh-TW / round 2（復核輪）

```yaml
schema: piyo_text_qa_report/v0.9
slug: who-hid-the-seeds
locale: zh-TW
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-30"
step1_lint: {exit_code: 0, warnings: 6}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: zh-TW-teacher
    scores: {年齡適配度: 7, 朗讀口感: 9, 孩子抓得住度: 9}
  - id: zh-TW-parent
    scores: {睡前適讀性: 8, 零說教: 9}
  - id: zh-TW-editor
    scores: {母語自然度: 7, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

**復核輪性質說明**：round 1 全數 ✅ 均 ∈ {字串級, 句級}，符合復核輪資格。本輪＝STEP 1 機檢全量重跑＋修改逐筆落地驗證＋copy↔draft 同源檢＋E-lite（受修頁與鄰頁）。人設不重跑，分數沿用 round 1。

## STEP 1 機檢（全量重跑）

```
5-6.draft.json: exit 0, violations 0, warnings 2 (repeat_discount)
3-5.draft.json: exit 0, violations 0, warnings 2 (repeat_discount)
2-3.draft.json: exit 0, violations 0, warnings 2 (repeat_discount)
copy_check.py: exit 0, violations 0, warnings 22 (band)
```

三檔 locale_lint 全 exit 0。copy_check 全 exit 0，draft↔copy 同源零違規。

## 修改落地驗證（11 筆逐筆核銷）

| # | ID | 裁決指定 | draft 實際 | 核銷 |
|---|---|---|---|---|
| 1 | E-2 | 5-6/3-5 P08 疊句末行加「」 | 5-6 P08 `「不是這裡，不是這裡！」` / 3-5 P08 同 | ✅ |
| 2 | C-1 | 5-6 P09 耷拉→垂著 | `咚咚垂著尾巴` | ✅ |
| 3 | C-2/L-8/P-1 | 5-6 P07 黏呼呼→黏答答 | `黏答答的東西` | ✅ |
| 4 | C-3/P-3 | 5-6/3-5 P06 紮→扎 | 5-6 `扎進泥巴裡` / 3-5 同 | ✅ |
| 5 | C-4/P-2 | 5-6 P02 大大的→長長的 | `長長的懶腰` | ✅ |
| 6 | E-1→2C-① | 5-6 P03 白色→白白的 | `蒲公英白白的飛絮` | ✅ |
| 7 | L-1 | 3-5 P03 飛絮→毛毛 | `蒲公英的毛毛` | ✅ |
| 8 | L-2 | 3-5 P05 灌木叢→矮樹叢 | `矮樹叢裡翻找` | ✅ |
| 9 | L-3 | 3-5 P05 蒼耳子→小球球 | `刺刺的小球球` | ✅ |
| 10 | L-5 | 2-3 P06 嫩芽→小芽芽 | `小芽芽冒出來了` | ✅ |
| 11 | P-4 | 2-3 P07 沙沙沙補動作 | `沙沙沙，埋好了。` | ✅ |

11/11 全數核銷。

## STEP 2 checklist 自檢

（復核輪 E-lite：受修頁＋鄰頁複審）

**主題錨復述**：本書教「遺忘不代表白費——種子會自己記得」。

受修頁＋鄰頁範圍：
- 5-6：P01–P10（P02/P03/P06/P07/P08/P09 受修＋P01/P04/P05/P10 鄰頁）
- 3-5：P02–P09（P03/P05/P06/P08 受修＋P02/P04/P07/P09 鄰頁）
- 2-3：P05–P08（P06/P07 受修＋P05/P08 鄰頁）

### 母本語感獵手（E-lite 內嵌確認）

復核輪 E-lite 確認：round 1 2C 獵物①修正（P03 白白的）已落地，語感改善；鄰頁無新 R2-8 壓縮形。獵物②上呈項（P08/P09/P12）裁決維持。

### 結果

- Checklist 複核：受修頁全數通過（28/0），修改未引入新問題
- 對位複核：受修頁文案負載仍 ⊆ storyboard「文說什麼」欄，零違反
- Concept fidelity：三檔主題弧線完整，修改未偏離 original_concept
- 新發現：0 筆

## STEP 3 人設 blind QA

round 1 分數沿用，未重跑。

## STEP 4 三分法分診

本輪 ✅=0，收斂完成。round 1 ⏸️ 5 筆維持上呈（見 round 1 上呈批次）。
