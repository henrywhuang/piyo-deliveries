# Piyo Bitable 內容生產工作臺 Escalations

> 狀態：v0.1 支架已建成（2026-07-09）。
> Base URL：https://aiorzjhmll.sg.larksuite.com/base/RJkUboBp7aGxPns6b7alPkIAghb

## 本輪修正紀錄

| 日期 | Stacy 指示 | 修正 |
|---|---|---|
| 2026-07-09 | 從奧卡姆剃刀原則出發，只先打支架 | 從 4 表降為 2 表；Wave / QA / Assets 暫不成表 |
| 2026-07-09 | 從第一性原理出發 | 只保留兩個不可合併粒度：書本、版本 |
| 2026-07-09 | 從未來靈活性出發，能不寫死就不寫死 | 主題域、敘事結構、環節選配、公式/lookup/dashboard 全部延後 |
| 2026-07-09 | 欄位內容能放中文就放中文 | 欄位名保留英文；欄位值、狀態、視圖名改為繁中優先 |

## 建議拍板

| ID | 議題 | 建議裁定 |
|---|---|---|
| P1 | v0.1 是否只建兩張表 | 已按「只建 `Story Workbooks` 和 `Production Versions`」執行 |
| P2 | `Wave` 是否先作為 `Story Workbooks` 欄位 | 已執行；未拆 `Waves / Schedule` 表 |
| P3 | QA 是否先不建 issue table | 已執行；先用 `Blocker` / `Notes` |
| P4 | 欄位值是否用繁中 | 已執行；欄位名英文，欄位值與視圖名繁中 |
| P5 | 是否先不建公式/lookup/dashboard | 已執行；未建公式、lookup、dashboard |

## 明確延後

| 延後項 | 延後理由 | 觸發條件 |
|---|---|---|
| `Waves / Schedule` table | 目前 wave 沒有獨立生命週期 | 需要日期、owner、跨書排程或進度統計 |
| `QA Issue Log` table | v0.1 還不需要 issue workflow | active issue 多、需要附件/復驗/修復紀錄 |
| `Assets` table | audio/image/timestamp 先附屬於版本 | 素材有獨立 batch、挑選、重用、audit 需求 |
| 主題域/敘事結構/course modules enum | book_slate / course pipeline 尚未穩定 | 50 本書目與課程配置定稿 |
| formula / lookup / dashboard | 手動視圖足夠 | 需要自動統計或人工看不動 |

## 建表結果

| 項目 | 結果 |
|---|---|
| Base URL | https://aiorzjhmll.sg.larksuite.com/base/RJkUboBp7aGxPns6b7alPkIAghb |
| Base token | `RJkUboBp7aGxPns6b7alPkIAghb` |
| Tables | 3：`Story Workbooks`、`Production Versions`、`Product MVP Work` |
| Story rows | 3 |
| Version rows | 54 |
| Product MVP Work rows | 35 |
| Version status | 2026-07-09 重置後：`未開始` 54；`已上線` 0 |
| Product MVP Work status | 35 筆皆為 `P0` + `未開始` |
| 未做項 | 未建 QA / Wave / Assets 表；未建 formula / lookup / dashboard；未 seed P1/P2 backlog |

## Phase 4 檢查

- [x] Stacy 明確同意 `bitable_schema_proposal.md` v0.1。
- [x] 重讀 ELA Base schema，確認可沿用欄位/視圖慣例。
- [x] 只建兩張表與最小欄位。
- [x] 回讀 3 本 seed book rows、54 筆 seed version rows；2026-07-09 重置後 54 筆皆為 `未開始`。

## 2026-07-09 三本既有故事重置

| 故事 | 調整 |
|---|---|
| 三隻小豬 | 改為 `母本審核`；`Story Bible Status=需修改`；18 個版本全數 `未開始` |
| 龜兔賽跑 | 改為 `母本審核`；`Story Bible Status=需修改`；18 個版本全數 `未開始` |
| 金髮女孩與三隻熊 | 改為 `母本審核`；`Story Bible Status=需修改`；18 個版本全數 `未開始` |

理由：現有內容只剩舊流程的繁中母版可作參考，且只有兩個年齡段；新流程需要三個年齡段 story bible、6 locale、3 age tier、課程與素材全鏈路，因此不能保留 `已上線` 狀態。

## 2026-07-09 Product MVP Work 產品工作表

| 項目 | 結果 |
|---|---|
| Table id | `tbljijcGbVH8QhLP` |
| Primary field | `Work Item` |
| Rows | 35 |
| Views | `完整資料`、`P0 MVP`、`UI / Flow`、`題型與 JSON`、`帳號 / 付費 / 合規`、`開發中 / 測試中`、`卡住`、`按狀態` |
| 驗證 | 回讀 35 rows；原 `Story Workbooks` 3 rows、`Production Versions` 54 rows 未變 |

裁定與取捨：

- 只建一張產品側工作表，不把 UI / 題型 / 帳號付費工作混入內容生產兩表。
- 借鑑 ELA `共用產品功能` 的輕量欄位思路；不照搬 ELA 的 `Pen Input`、`Typing Input`、`Mini-Whiteboard`。
- P1/P2 僅保留 enum 支援，避免 MVP 工作臺膨脹。

## 2026-07-09 Product MVP Work 中文化與產品缺口補強

| 項目 | 結果 |
|---|---|
| `Work Item` | 原 26 筆已改為繁中主標題 |
| `Work Item EN` | 新增欄位，保留原英文名稱 |
| 新增 rows | `PMVP-027` 到 `PMVP-035`，共 9 筆 |
| 新增 row 預設 | 全部 `Priority=P0`、`Status=未開始`、`Owner` 空白 |
| 新增 Area options | `App Foundation`、`App Store & Launch`、`QA & Readiness`、`Data & Analytics` |
| 新增 Source options | `child_compliance.md`、`ios_tech_options.md`、`locale_specs/README.md`、`preview/CLAUDE.md` |

新增 P0 rows：

| Task ID | Work Item | 裁定理由 |
|---|---|---|
| `PMVP-027` | iOS 技術棧與 SDK 邊界拍板 | 不拍板會卡 app 架構、StoreKit、offline 與 SDK 邊界 |
| `PMVP-028` | 兒童資料與家長同意流程 Spec | Child Profile、訂閱、家長區都依賴此流程 |
| `PMVP-029` | App Privacy／Reviewer Note 合規包 | 送審阻塞項 |
| `PMVP-030` | IAP 商品與 Entitlement Matrix | Paywall 與 Access Control 的共同 source of truth |
| `PMVP-031` | 合規-safe Analytics／Event Allowlist | 防止誤接第三方 analytics 或收集不必要兒童資料 |
| `PMVP-032` | 360 Story Pack 上線完整性矩陣 | 內容包缺漏會直接破壞 reader/offline/course 體驗 |
| `PMVP-033` | 課程內容驗收 QA | 確認課程內容可播放、可驗收，不只追播放器功能 |
| `PMVP-034` | UI 文案／在地化矩陣 | 6 locale UI、parent gate、paywall、legal entry copy 要先對齊 |
| `PMVP-035` | TestFlight 裝置 QA 計畫 | 播放器、IAP、offline 是審核與留存高風險點 |
