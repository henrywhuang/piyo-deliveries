# 2026-07-09 三本既有故事重置紀錄

## 背景

Stacy 指示：`三隻小豬`、`龜兔賽跑`、`金髮女孩與三隻熊` 需要全部按新流程重做。

原因：

- Piyo 現在改為 3 個年齡版本。
- 語言矩陣改為 6 locale。
- 現有內容唯一可參考的是舊流程繁中母版故事，且只有 2 個年齡段。
- 因此 story bible 不能算完成，版本也不能保留 `已上線`。

## Bitable 調整

Base：https://aiorzjhmll.sg.larksuite.com/base/RJkUboBp7aGxPns6b7alPkIAghb

### Story Workbooks

三本均已改為：

- `Status=母本審核`
- `Story Bible Status=需修改`
- `Illustration Status=未開始`
- `Blocker=需補齊三個年齡段的繁中 story bible；現有僅舊流程繁中母版且只有兩個年齡段。`

### Production Versions

54 筆版本 row 全部改為：

- `Status=未開始`
- `Notes=2026-07-09 調整：舊版不再視為可沿用產線成果。需按新流程重做：三個年齡段 story bible、6 locale、3 age tier、課程與素材全鏈路。`

## 回讀驗證

| 項目 | 結果 |
|---|---|
| Story rows | 3 |
| Production Version rows | 54 |
| Version `已上線` | 0 |
| Version `未開始` | 54 |

