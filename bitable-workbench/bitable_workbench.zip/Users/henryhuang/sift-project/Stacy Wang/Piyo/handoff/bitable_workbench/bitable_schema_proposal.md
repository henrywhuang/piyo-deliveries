# Piyo Bitable 內容生產工作臺 Schema Proposal

> 狀態：v0.1 內容支架已建成；產品 MVP 工作表已加上（2026-07-09）。
> Base URL：https://aiorzjhmll.sg.larksuite.com/base/RJkUboBp7aGxPns6b7alPkIAghb
> Base token：`RJkUboBp7aGxPns6b7alPkIAghb`
> 參照範本：JOJO ELA Base `YSoZbDOKCadq3Ys4c9Gl0FkYgqe`，讀取日期 2026-07-09。

## 1. 設計原則

### 結論

上一版太完整，不符合「先打支架」。v0.1 應該只建能回答三個問題的最小工作臺：

1. 這本書排在哪一波？
2. 這個版本現在卡在哪個生產階段？
3. 下一步誰要處理、看哪個 repo 路徑或備註？

所以 v0.1 只建兩張表：

| 表 | 是否 v0.1 建立 | 原因 |
|---|---|---|
| `Story Workbooks` | 必建 | 一本書一次的事情住這裡：排程、母本、共用插畫、主題摘要 |
| `Production Versions` | 必建 | 每本 18 個版本的狀態住這裡；這是量產追蹤核心 |
| `Waves / Schedule` | 暫不建 | 目前 wave 只是 book 的欄位；沒有獨立排程、責任人、日期前不需要成表 |
| `QA Issue Log` | 暫不建 | 先用 `Blocker` / `Notes`；等真的有大量 QA issue、附件、返修紀錄時再拆表 |
| `Assets` | 不建 | audio / image / timestamp 先用版本狀態與 path 管；不要為未發生的素材治理複雜度建表 |

### 為什麼這是目前最簡潔、也最好的版本

| 原則 | 判斷 | v0.1 做法 |
|---|---|---|
| 奧卡姆剃刀 | 沒有獨立生命週期的東西不要先建表 | Wave、QA、Assets 先不成表 |
| 第一性原理 | Piyo 只有兩個不可合併的生產粒度：書本、版本 | 只保留 `Story Workbooks` 和 `Production Versions` |
| 未來靈活性 | 不確定的分類不要先寫死成 enum | 主題域、環節選配先用文字/備註，等 book slate / course pipeline 穩定後再結構化 |
| 人用優先 | 欄位名稱給 AI/腳本穩定讀，欄位內容給團隊好讀 | 欄位名稱保留英文；狀態值、備註、視圖名用繁體中文 |

## 2. Table A: `Story Workbooks`

用途：50 本書目總表。每列代表一本 story workbook。

### v0.1 欄位

| 欄位名稱 | 類型 | 選項 / 規則 | 為什麼需要 |
|---|---|---|---|
| `Book ID` | text, primary | `PYO-001` 起跳 | 穩定主鍵，不用書名當 key |
| `Title zh-TW` | text |  | 繁中母本書名 |
| `English Reference Title` | text |  | 對外/多語參考名 |
| `Slug` | text | kebab-case | 對應 repo `final/{slug}/` |
| `Priority` | single select | `P0` / `P1` / `P2` | 業務優先級 |
| `Wave` | single select | `首發 P0` / `第二波` / `第三波` / `第四波` / `待排程` | 排程分波；先是欄位，不是表 |
| `Status` | single select | `未開始` / `母本審核` / `版本生產中` / `素材就緒` / `測試中` / `已上線` / `暫停` | book-level aggregate 狀態 |
| `Story Bible Status` | single select | `未開始` / `草稿中` / `Stacy 審核` / `需修改` / `已定稿` | 每本一次，且 Stacy 親審，是 book-level 關鍵 gate |
| `Illustration Status` | single select | `未開始` / `生成中` / `待挑選` / `已定稿` / `缺漏` | 插畫每本共用一套，適合放 book 層 |
| `Book Notes` | text | 繁中自由填寫 | 主題域、子主題、敘事結構、角色設定、跨文化風險先放這裡，不先硬拆欄位 |
| `Repo Link` | text | repo path / doc link | 指向 source of truth，不搬規格全文 |
| `Owner` | user |  | 主要負責人 |
| `Blocker` | text | 繁中自由填寫 | 先取代 QA issue table |

### v0.1 不先放的欄位

| 不先放 | 原因 | 何時再加 |
|---|---|---|
| `Theme Domain` enum | book_slate 50 本尚未定稿，不要先寫死 | 50 本書目拍板後 |
| `Narrative Pattern` enum | 目前只是書目提案卡內容，不是生產狀態必要欄位 | 若要做內容分佈 dashboard |
| `Course Modules` multi-select | course pipeline 尚未跑起來，先用 notes/link | 課程配置開始批量生產時 |
| `QA-1` / `QA-2` | v0.1 先不排正式審校人力 | QA 節點開始運作時 |
| 公式/lookup 進度欄 | 支架階段手動視圖已足夠 | 表內資料量大到人工看不動時 |

### v0.1 視圖

| 視圖 | 用途 |
|---|---|
| `完整資料` | 全部書目 |
| `首發 P0` | P0 MVP 清單 |
| `按波次` | 依 `Wave` 分組 |
| `母本待審` | `Story Bible Status` 為 `Stacy 審核` 或 `需修改` |
| `有卡點` | `Blocker` 不為空 |

## 3. Table B: `Production Versions`

用途：版本生產任務表。每列代表一本書的一個 locale + age tier 版本。

### 主鍵與 row 生成規則

`Version ID = {slug}/{locale}/{ageTier}`

每本書派生 18 rows：

```text
6 locale: zh-TW, ja, en-US, en-GB, es-MX, pt-BR
3 age tier: 2-3, 3-5, 5-6
```

### v0.1 欄位

| 欄位名稱 | 類型 | 選項 / 規則 | 為什麼需要 |
|---|---|---|---|
| `Version ID` | text, primary | `{slug}/{locale}/{ageTier}` | 穩定主鍵 |
| `Book` | link | link to `Story Workbooks` | 所屬書 |
| `Locale` | single select | `zh-TW` / `ja` / `en-US` / `en-GB` / `es-MX` / `pt-BR` | canonical code，維持 repo 規格 |
| `Age Tier` | single select | `2-3` / `3-5` / `5-6` | 三段制 |
| `Status` | single select | `未開始` / `腳本設計` / `課程設計` / `素材製作` / `素材就緒` / `測試中` / `已上線` / `卡住` | 版本主狀態；拆出 Piyo content design 的兩個必要節點 |
| `Asset Path` | text | `pipeline/preview/final/{slug}/{FINAL_LOCALE}/{ageTier}/` | 找得到最終素材 |
| `Owner` | user |  | 主要負責人 |
| `Blocker` | text | 繁中自由填寫 | 先取代 QA issue table |
| `Notes` | text | 繁中自由填寫 | QA、TTS、timestamp、課程備註先放這裡 |

### 主狀態語義

| Status | 定義 |
|---|---|
| `未開始` | 尚未進入該版本生產 |
| `腳本設計` | locale + age tier 文本改寫/審查中 |
| `課程設計` | 環節出題、互動題、course config 設計中 |
| `素材製作` | TTS、timestamps、必要素材處理中 |
| `素材就緒` | 對該版本已可進 preview/app 接線 |
| `測試中` | linter、人工審查、preview/app QA 中 |
| `已上線` | 已進 final asset，可作為上線版本 |
| `卡住` | 需要處理 blocker |

### v0.1 不先放的欄位

| 不先放 | 原因 | 何時再加 |
|---|---|---|
| `Script Status` | 主狀態已有 `腳本設計`，v0.1 不需要雙層追蹤 | 腳本審查流程變複雜時 |
| `Course Design Status` | 主狀態已有 `課程設計` | course pipeline 批量運作時 |
| `TTS Status` / `Timestamp Status` | v0.1 只需要知道版本是否到 `素材就緒` | 音檔或 timestamp 成為主要瓶頸時 |
| `QA Status` | 先用 `測試中` + `Blocker` | QA issue 需要附件、返修紀錄、二次驗收時 |
| `Pages Count` / `Audio File Count` | 屬於 audit 結果，不是支架必要欄位 | 需要 dashboard 或自動驗證時 |
| `Final Folder Locale` | 可由 `Locale` deterministic 推導 | 若腳本寫入很常出錯再加 |

### v0.1 視圖

| 視圖 | 用途 |
|---|---|
| `完整資料` | 全部版本 |
| `按狀態` | 依 `Status` 分組 |
| `按語言` | 依 `Locale` 分組 |
| `按年齡` | 依 `Age Tier` 分組 |
| `Content Design` | `Status` 為 `腳本設計` 或 `課程設計` |
| `素材與測試` | `Status` 為 `素材製作`、`素材就緒`、`測試中` |
| `有卡點` | `Status == 卡住` 或 `Blocker` 不為空 |

## 4. 延後但保留的擴充點

| 擴充 | 觸發條件 | 到時怎麼加 |
|---|---|---|
| `Waves / Schedule` table | Wave 有獨立日期、負責人、進度、跨書排程 | 從 `Story Workbooks.Wave` 拆成 link table |
| `QA Issue Log` table | QA issue 需要附件、復驗、修復紀錄，或 active issues 超過 20 條 | 從 `Blocker` / `Notes` 拆出 issue rows |
| `Assets` table | audio/image/timestamp 有獨立重用、批次、挑選、hash/audit 需求 | 從 `Production Versions.Asset Path` 拆出素材任務 |
| formula / lookup / dashboard | 需要自動統計進度 | 先讀 lark-base formula/lookup guide，再補，不在 v0.1 建 |
| 結構化主題/敘事/環節欄位 | 50 本書目與 course pipeline 穩定後 | 把 `Book Notes` 裡高頻固定內容拆欄 |

## 5. Phase 4 seed 規則

### Story Workbooks seed

| Book ID | Slug | Title zh-TW | English Reference Title | 目前狀態 |
|---|---|---|---|---|
| `PYO-001` | `three-little-pigs` | 三隻小豬 | The Three Little Pigs | `母本審核` / `Story Bible Status=需修改` |
| `PYO-002` | `the-tortoise-and-the-hare` | 龜兔賽跑 | The Tortoise and the Hare | `母本審核` / `Story Bible Status=需修改` |
| `PYO-003` | `goldilocks-and-the-three-bears` | 金髮女孩與三隻熊 | Goldilocks and the Three Bears | `母本審核` / `Story Bible Status=需修改` |

### Production Versions seed

建 54 rows：

| 類型 | 筆數 | 初始狀態 |
|---|---:|---|
| 三本故事 x 6 locale x 3 age tier | 54 | `未開始` |

註：原本現有 `zh-TW` / `ja` / `en-US` x `2-3` / `3-5` 的 18 筆，已於 2026-07-09 依 Stacy 指示重置為 `未開始`；舊流程內容只可作參考，不再代表新流程完成。

## 6. 與 repo 的分工邊界

| Repo source of truth | Bitable v0.1 只放 |
|---|---|
| `DIRECTION.md` | 排程/狀態摘要，不放方向決策全文 |
| `knowledge_base/locale_specs/README.md` | `Locale` enum 依 canonical code |
| `knowledge_base/course_design/course_structure.md` | 只放連結或 notes；不先硬建 10 個 course module enum |
| `handoff/book_slate_50/` | 書目提案卡摘要等拍板後再灌 |
| `pipeline/preview/final/` | `Asset Path` 與是否已上線 |

## 7. 建表前拍板項

| ID | 要拍板的事 | 建議 |
|---|---|---|
| P1 | 是否接受 v0.1 只建兩張表 | 接受。先用兩張表驗證工作流，不先建 QA / Wave / Asset 表 |
| P2 | 狀態值是否採繁中 | 接受。欄位名保留英文，欄位值與視圖名用繁中，團隊使用成本最低 |
| P3 | 是否先不建公式/lookup/dashboard | 接受。支架階段手動視圖足夠，避免 Base 結構過早複雜化 |

## 8. 驗收清單

- [x] Stacy 拍板 v0.1 兩表支架。
- [x] 建成 `Story Workbooks`、`Production Versions`。
- [x] seed 3 本書與 54 個版本。
- [x] 2026-07-09 依 Stacy 指示重置：54 個版本全部為 `未開始`。
- [x] 視圖可用：完整資料、按波次/狀態/語言/年齡、有卡點。
- [x] Base URL 回寫本檔頂部。
- [x] 未 `git commit` / `git push`。

## 9. Phase 4 建表結果

| 項目 | 結果 |
|---|---|
| Base | [Piyo 內容生產工作臺 v0.1](https://aiorzjhmll.sg.larksuite.com/base/RJkUboBp7aGxPns6b7alPkIAghb) |
| `Story Workbooks` table id | `tbl4FLf1ANIe8oag` |
| `Production Versions` table id | `tblg68DN7PccdnII` |
| Story rows | 3 |
| Version rows | 54 |
| `已上線` versions | 0 |
| `未開始` versions | 54 |
| Story status | 三本皆為 `母本審核`；`Story Bible Status=需修改`；`Illustration Status=未開始` |
| 額外說明 | 2026-07-09 依 Stacy 指示，三本舊版內容不再視為可沿用產線成果，需按新流程重做。Lark 會自動建立 `Grid View` 預設視圖；目前保留，未做不可逆刪除。 |

## 10. 2026-07-09 三本既有故事重置

Stacy 裁定：`三隻小豬`、`龜兔賽跑`、`金髮女孩與三隻熊` 要全部按新流程重做。原因是 Piyo 已改為 3 個年齡版本與 6 locale 矩陣；現有素材唯一可參考的是舊流程的繁中母版故事，而且只有 2 個年齡段，因此 story bible 不能算完成。

已執行調整：

- `Story Workbooks` 三本：`Status=母本審核`、`Story Bible Status=需修改`、`Illustration Status=未開始`。
- `Production Versions` 54 筆：全部改為 `Status=未開始`。
- `Book Notes` / `Blocker` 已標明需補齊三個年齡段的繁中 story bible，並按新流程重跑 6 locale x 3 age tier。

## 11. 2026-07-09 Product MVP Work 產品工作表

Stacy 裁定：Piyo Bitable 不只追繪本內容，也要追 MVP 開發過程中的產品側工作；新增一張輕量表，不混進內容生產兩表。

| 項目 | 結果 |
|---|---|
| Table | `Product MVP Work` |
| Table id | `tbljijcGbVH8QhLP` |
| Primary field | `Work Item` |
| Current rows | 35 |
| Current status | 全部 `Priority=P0`、`Status=未開始` |
| 原內容表 | `Story Workbooks` 仍為 3 rows；`Production Versions` 仍為 54 rows |

### 欄位

| Field | Type | 備註 |
|---|---|---|
| `Work Item` | text, primary | 產品功能或工作項名稱；繁中主標題 |
| `Work Item EN` | text | 原英文名稱或英文備份 |
| `Task ID` | text | `PMVP-001` 到 `PMVP-035` |
| `Area` | select | `UI/UX`、`Reading Player`、`Course & Question Types`、`Account & Compliance`、`Subscription & Access`、`Content/Data Pipeline`、`Engagement & Progress`、`Design System`、`App Foundation`、`App Store & Launch`、`QA & Readiness`、`Data & Analytics` |
| `Priority` | select | `P0` / `P1` / `P2` |
| `Status` | select | `未開始`、`需求拆解`、`設計中`、`Spec/JSON`、`開發中`、`測試中`、`完成`、`暫緩`、`卡住` |
| `Deliverable` | multi-select | `User Flow`、`UI Prototype`、`Design Spec`、`JSON Schema`、`App Contract`、`Content Spec`、`QA Checklist`、`Engineering Spike` |
| `Source` | multi-select | `DIRECTION.md`、`app_mvp_scope.md`、`course_structure.md`、`question_type_library.md`、`ELA 共用產品功能`、`Stacy 補充`、`child_compliance.md`、`ios_tech_options.md`、`locale_specs/README.md`、`preview/CLAUDE.md` |
| `Impact Scope` | text | 影響頁面、流程、內容或 Story Pack |
| `Owner` | user | seed 時先空白 |
| `Design Link` | text url | Figma 或設計稿 |
| `Spec Link` | text url | repo doc / JSON spec / prototype doc |
| `Notes` | text | 繁中備註、卡點、決策紀錄 |

### 視圖

| View | 設定 |
|---|---|
| `完整資料` | 全部 rows |
| `P0 MVP` | filter `Priority=P0` |
| `UI / Flow` | filter `Area=UI/UX` 或 `Area=Design System` |
| `題型與 JSON` | filter `Area=Course & Question Types` 或 `Deliverable` 含 `JSON Schema` / `App Contract` |
| `帳號 / 付費 / 合規` | filter `Area=Account & Compliance` 或 `Area=Subscription & Access` |
| `開發中 / 測試中` | filter `Status=開發中` 或 `Status=測試中` |
| `卡住` | filter `Status=卡住` |
| `按狀態` | kanban，group by `Status` |

註：Lark 仍會自動保留一個預設 `Grid View`；目前未刪除。

### Seed rows

| 範圍 | Task IDs |
|---|---|
| UI / Flow | `PMVP-001` 到 `PMVP-009` |
| Core Product / Engine | `PMVP-010` 到 `PMVP-014` |
| Account / Pay | `PMVP-015` 到 `PMVP-018` |
| Course / Question Types | `PMVP-019` 到 `PMVP-026` |
| Product Readiness / Launch Prep | `PMVP-027` 到 `PMVP-035` |

明確不放：Piyo App icon、ELA 專用的 `Pen Input`、`Typing Input`、`Mini-Whiteboard`。

2026-07-09 追加：依 Stacy 指示，`Work Item` 全部改為繁中主標題，英文改存 `Work Item EN`；並根據 gpt-5.5 product review 補入 9 筆 P0 launch/readiness rows。P1 候選如錯誤/空狀態、App Store metadata、家長客服 SOP 先不進表，等 P0 flow 定稿後再補。
