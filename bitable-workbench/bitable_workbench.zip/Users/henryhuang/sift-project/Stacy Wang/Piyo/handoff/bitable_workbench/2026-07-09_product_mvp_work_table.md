# 2026-07-09 Product MVP Work Table Execution Log

## Summary

已依 Stacy 拍板，在現有 Piyo Base 新增產品側 MVP 工作表。

| 項目 | 結果 |
|---|---|
| Base URL | https://aiorzjhmll.sg.larksuite.com/base/RJkUboBp7aGxPns6b7alPkIAghb |
| Base token | `RJkUboBp7aGxPns6b7alPkIAghb` |
| New table | `Product MVP Work` |
| New table id | `tbljijcGbVH8QhLP` |
| Primary field | `Work Item` |
| Current rows | 35 |
| Seed default | `Priority=P0`、`Status=未開始`、`Owner` 空白 |

## Fields

| Field | Type |
|---|---|
| `Work Item` | text, primary |
| `Work Item EN` | text |
| `Task ID` | text |
| `Area` | single select |
| `Priority` | single select |
| `Status` | single select |
| `Deliverable` | multi-select |
| `Source` | multi-select |
| `Impact Scope` | text |
| `Owner` | user |
| `Design Link` | url text |
| `Spec Link` | url text |
| `Notes` | text |

## Views

| View | View id | 設定 |
|---|---|---|
| `完整資料` | `vewFqeqD7s` | all rows |
| `P0 MVP` | `vewSyTJwNG` | `Priority=P0` |
| `UI / Flow` | `vewxFI1tqg` | `Area=UI/UX` or `Design System` |
| `題型與 JSON` | `vewfBHPMRU` | `Area=Course & Question Types` or `Deliverable` contains `JSON Schema` / `App Contract` |
| `帳號 / 付費 / 合規` | `vewySLxAQa` | `Area=Account & Compliance` or `Subscription & Access` |
| `開發中 / 測試中` | `vew1tSnlbd` | `Status=開發中` or `測試中` |
| `卡住` | `vewl2NbG4P` | `Status=卡住` |
| `按狀態` | `vewJfAPf0L` | kanban, group by `Status` |

Lark 自動保留預設 `Grid View`：`vewzqj6FfX`。

## Seed Rows

| Group | Task IDs |
|---|---|
| UI / Flow | `PMVP-001` to `PMVP-009` |
| Core Product / Engine | `PMVP-010` to `PMVP-014` |
| Account / Pay | `PMVP-015` to `PMVP-018` |
| Course / Question Types | `PMVP-019` to `PMVP-026` |
| Product Readiness / Launch Prep | `PMVP-027` to `PMVP-035` |

## 2026-07-09 中文化與產品缺口補強

依 Stacy 指示，`Work Item` 已改為繁中主標題，並新增 `Work Item EN` 保存原英文名稱。

### Field Updates

| Field | Change |
|---|---|
| `Work Item EN` | 新增 text 欄位；原 26 筆英文名稱已回填 |
| `Area` | 新增 `App Foundation`、`App Store & Launch`、`QA & Readiness`、`Data & Analytics` |
| `Source` | 新增 `child_compliance.md`、`ios_tech_options.md`、`locale_specs/README.md`、`preview/CLAUDE.md` |

### Added Rows

| Task ID | Work Item | Area |
|---|---|---|
| `PMVP-027` | iOS 技術棧與 SDK 邊界拍板 | `App Foundation` |
| `PMVP-028` | 兒童資料與家長同意流程 Spec | `Account & Compliance` |
| `PMVP-029` | App Privacy／Reviewer Note 合規包 | `App Store & Launch` |
| `PMVP-030` | IAP 商品與 Entitlement Matrix | `Subscription & Access` |
| `PMVP-031` | 合規-safe Analytics／Event Allowlist | `Data & Analytics` |
| `PMVP-032` | 360 Story Pack 上線完整性矩陣 | `QA & Readiness` |
| `PMVP-033` | 課程內容驗收 QA | `QA & Readiness` |
| `PMVP-034` | UI 文案／在地化矩陣 | `UI/UX` |
| `PMVP-035` | TestFlight 裝置 QA 計畫 | `QA & Readiness` |

P1 候選如錯誤/空狀態、App Store metadata、家長客服與資料權利 SOP 先不進表；等 P0 flow 定稿後再補。

## Verification

| Check | Result |
|---|---|
| Base table count | 3 tables: `Story Workbooks`, `Production Versions`, `Product MVP Work` |
| `Product MVP Work` rows | 35 |
| Missing Task IDs | none |
| Unique priority | `P0` only |
| Unique status | `未開始` only |
| Original 26 rows | `Work Item` 已中文化；`Work Item EN` 已保留英文 |
| Added 9 rows | 全部 `P0` + `未開始`；`Owner` 空白 |
| `UI / Flow` view rows | 7 |
| `帳號 / 付費 / 合規` view rows | 4 |
| `開發中 / 測試中` view rows | 0 |
| `卡住` view rows | 0 |
| `Story Workbooks` rows | 3 |
| `Production Versions` rows | 54 |

## Notes

- 本次未建 formula、lookup、dashboard、automations。
- P1/P2 只保留 enum 支援，未 seed backlog rows。
- Piyo App icon 已另行安排，不納入此表。
- ELA `Pen Input`、`Typing Input`、`Mini-Whiteboard` 不納入，因為它們是 ELA 練習冊特有互動，不是 Piyo MVP 必要互動。
