# 任務：Piyo Bitable 內容生產工作臺（架構規劃 → 拍板 → 建表）

## 環境與紀律（先讀）

- 工作目錄：Piyo repo 根目錄（`/Users/stacywang/Desktop/Code Project/Piyo`）。開工前先讀 `CLAUDE.md` 與 `DIRECTION.md`。
- 需要 Lark 存取：使用 **lark-base skill／lark-cli** 操作 Larksuite Bitable。
- Repo 一律唯讀；規劃文件寫在 `handoff/bitable_workbench/` 內。**建表動作必須等 Stacy 拍板 schema 之後**才執行。
- **禁止 `git commit`／`git push`**。

## 背景

Piyo 要比照 JOJO ELA 專案建一個 Bitable 內容生產工作臺，管理繪本 workbook 的排程與生產狀態。**參照範本（ELA 的 base，欄位命名與規範以它為準）**：
https://aiorzjhmll.sg.larksuite.com/base/YSoZbDOKCadq3Ys4c9Gl0FkYgqe

## 已拍板的業務事實（工作臺要能承載這些）

- **內容排程**：總清單容量 **50 本**；首發 P0＝**20 本** MVP；後續按優先級分波（每波約 10 本，節奏暫定）。
- **量產矩陣**：每本書 × **6 語言**（zh-TW／ja／en-US／en-GB／es-MX／pt-BR）× **3 年齡檔**（2-3／3-5／5-6）＝每本 18 個版本；MVP 20 本＝360 版本，總清單全做＝900 版本。
- **生產階段**（每個版本要走完）：story bible（每本一次，繁中母本，Stacy 親審）→ 各語腳本（文化適配改寫）→ 插畫（每本一套共用）→ TTS 音檔 → 課程配置（環節池選配，見 course_structure.md）→ timestamps → QA（linter＋審查）→ 上線。
- **書目資料欄位**（對齊 book_slate 任務的提案卡）：暫定書名（zh-TW＋英文參考名）、主題域／子主題、敘事結構類型、主角設定、公版/原創、優先級（P0/P1/P2）、波次、環節選配、跨文化風險備註。
- 決策與規格的單一權威在 repo（DIRECTION.md、locale_specs、course_structure.md）——**Bitable 是執行狀態的工作臺，不是規格的家**，欄位裡放連結不放規格內容。

## 交付物

1. **Phase 1-2 產出**：`bitable_schema_proposal.md` —— 架構提案文件（落在本資料夾），含：
   - 表清單與用途（建議至少：①書目總表 50 列 ②生產任務/版本表（書 × 語言 × 檔位粒度，狀態機欄位）③波次/排程表；是否需要 QA 記錄表、素材連結表由你依 ELA 範本判斷）
   - 每張表的欄位設計（名稱、類型、選項 enum、公式/查找引用），**命名與狀態 enum 比照 ELA base 的既有規範**
   - 視圖設計（按優先級、按生產階段、按語言、按負責人；進度 dashboard）
   - 表間關聯與自動化（如版本表由書目表派生 18 列的做法）
   - 與 repo 的分工邊界說明
2. **Phase 4 產出（拍板後）**：在 Larksuite 建好 base（或於既有空間新建），表結構＋視圖＋範例列（用既有 3 本書當種子資料：三隻小豬、龜兔賽跑、金髮女孩與三隻熊，含其已完成的 3 語 × 2 檔狀態）；50 本書目待 book_slate 任務定稿後再灌（不阻塞本任務）。
3. `escalations.md` —— 上呈清單。

## 工作流

### Phase 1 — 讀範本與需求
- 用 lark-cli 讀取參照 base（上方 URL）的表結構、欄位命名、狀態 enum、視圖配置——**這是規範來源**，Piyo 沿用其慣例、只在業務差異處偏離（偏離處要在提案中標注理由）。
- 讀 repo：`DIRECTION.md`（C 表＋E 表＋路線圖）、`knowledge_base/course_design/course_structure.md`（環節凍結清單＝課程配置欄位的 enum 來源）、`knowledge_base/locale_specs/README.md`（locale registry＝語言欄 enum 來源）、`CLAUDE.md`（4-stage pipeline＝生產階段 enum 參考）、`handoff/book_slate_50/book_slate_PROMPT.md`（書目欄位對齊）。

### Phase 2 — Schema 設計
產出 `bitable_schema_proposal.md`。設計原則：**狀態粒度夠用就好**（900 版本 × 8 階段的追蹤要可維護，不要過度設計）；枚舉值一律引用 repo 既有凍結清單，不自創代碼。

### Phase 3 — 上呈拍板
提案交 Stacy 確認（表清單、版本表粒度、狀態 enum 三項是必問）。**未拍板不建表。**

### Phase 4 — 建表與種子資料
按拍板結果建 base；灌 3 本種子書驗證欄位與視圖可用；把 base URL 寫回 `bitable_schema_proposal.md` 頂部。

## 完成定義（DoD）

- [ ] schema 提案文件完整（表／欄位／視圖／關聯／與 ELA 範本的偏離說明）
- [ ] Stacy 拍板紀錄在 escalations.md
- [ ] base 建成＋3 本種子資料＋視圖可用；URL 已回寫
- [ ] 未 commit/push；repo 未被修改
