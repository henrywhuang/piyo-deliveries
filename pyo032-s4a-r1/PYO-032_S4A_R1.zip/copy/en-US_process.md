# B1 折計預算表 — PYO-032 en-US

## 預算總覽

| 檔位 | max_total | raw_total | refrain_uses | refrain_words | discount_rate | folded_total | 餘裕 |
|---|---|---|---|---|---|---|---|
| 5-6 | 505 | 351 | 4× (5w) | 20 | 0.25 → 8.75 | ~345 | ~160 |
| 3-5 | 389 | 205 | 4× (5w) | 20 | 0.25 → 8.75 | ~199 | ~190 |
| 2-3 | 88 | 87 | 4× (3w) | 12 | 0.25 → 5.25 | ~80 | ~8 |

## 疊句出現位

| 頁 | 5-6 | 3-5 | 2-3 |
|---|---|---|---|
| P02 | ×3 "I'm NOT falling asleep first!" | ×3 "I'm NOT falling asleep first!" | ×3 "NOT falling asleep!" (shortened) |
| P05 | ×1 "I'm NOT falling asleep first!" | ×1 "I'm NOT falling asleep first!" | ×1 "NOT falling asleep!" (shortened) |
| P10 | ×1 variation "I'm not… falling… asleep…" | ×1 variation "I'm not… falling… asleep…" | ×1 variation "Not… falling… asleep…" |

P10 variation = 非精確匹配，不折計。

## 擬聲詞出現位

| 頁 | SNOOOOOORE! | SNOOOOOORE… | pff… pff… |
|---|---|---|---|
| P04 | ✓ (爆發) | | |
| P07 | | | ✓ (爆發) |
| P08 | | ✓ (5-6 ×2, 3-5 ×1) | ✓ (5-6 ×2, 3-5 ×1) |
| P10 | | ✓ | ✓ |
| P12 | | ✓ | ✓ |

## B3 待回填

- [ ] copy_check.py raw 終值
- [ ] locale_lint 正字法
- [ ] localize_readiness 對位
