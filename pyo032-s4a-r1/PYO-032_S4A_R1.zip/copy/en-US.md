# 圖文總表：誰先睡著？（who-falls-asleep-first / en-US）

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: who-falls-asleep-first
locale: en-US
mode: B
storyboard: content/PYO-032_who-falls-asleep-first/PYO-032_storyboard.md
design: content/PYO-032_who-falls-asleep-first/PYO-032_design.md
image_pool: 12
selection:
  "3-5": [P01, P02, P03, P04, P05, P06, P07, P08, P10, P11, P12]
  "2-3": [P01, P02, P04, P05, P07, P10, P11, P12]
commitments:
  refrain: "NOT falling asleep"
  ending:
    "5-6": "Their little cave was warm and cozy."
    "3-5": "Their cave was warm."
    "2-3": "Warm and cozy."
  onomatopoeia: ["SNOOOOOORE!", "pff… pff…"]
characters: [Cubby, Fuzzy, Papa Bear]
```

### B0 語感基建

**疊句**：
- 5-6/3-5：`I'm NOT falling asleep first!`（5 words；NOT 全大寫＝倔強爆發）
- 2-3 縮短：`NOT falling asleep!`（3 words；省主詞＋first 符合 max_sentence 8）
- P10 變奏（全檔位）：trailing off `I'm not… falling… asleep…`／2-3 `Not… falling… asleep…`

**擬聲詞**（凍結字串表）：
1. `SNOOOOOORE!` — Papa Bear 大鼾聲（O1 全大寫＋!；P04 爆發）
2. `SNOOOOOORE…` — 持續態（P08/P10/P12 背景鼾聲）
3. `pff… pff…` — Fuzzy 輕鼾（小寫柔氣音；P07 爆發、P08/P10/P12 交替）

**角色口癖卡**：
- **Cubby**（he）：柔聲回音型——學姊姊說話，句子短，常 trail off。藍色小被子。
- **Fuzzy**（she）：昂首不服型——"I'm not doing THAT." 倔強但可愛。數天花板裂紋睡著。
- **Papa Bear**（he）：誇張戲劇型——"I'll tell you my secret." 一臉得意，結果第一個睡。

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | One cozy night, moonlight spilled into a warm bear cave.<br>Papa Bear sat up with a big grin.<br>"I know!" he said. "Let's have a contest — who falls asleep first!" | 30✓ | 1 | One night, moonlight spilled into a warm bear cave.<br>Papa Bear grinned. "Let's have a contest — who falls asleep first!" | 20✓ | 1 | Moonlight in the bear cave.<br>Papa Bear grinned.<br>"Who falls asleep first?" | 12✓ | ✓ | 5-6「cozy」增感官＋「sat up with a big grin」動作鋪陳；3-5 精簡動作；2-3 電報式最短引出比賽 |
| P02 | 2 | Three bears lay on their soft, grassy beds.<br>"I'm NOT falling asleep first!" Papa Bear boomed.<br>"I'm NOT falling asleep first!" Fuzzy said, staring Papa down.<br>Cubby hugged his blue blanket.<br>"I'm NOT falling asleep first!" | 36✓ | 2 | "I'm NOT falling asleep first!" Papa boomed.<br>"I'm NOT falling asleep first!" Fuzzy said.<br>"I'm NOT falling asleep first!" Cubby squeaked. | 21✓ | 2 | "NOT falling asleep!" Papa Bear boomed.<br>"NOT falling asleep!" said Fuzzy.<br>"NOT falling asleep!" | 14✓ | ✓ | 疊句三拍：5-6 各角色個性化（boomed/staring down/blanket）；3-5 精簡 2-word attributions；2-3 縮短疊句 3 words |
| P03 | 3 | "I'll tell you my secret," Papa Bear whispered.<br>"Just close your eyes… and think really hard about staying awake."<br>He closed his eyes. His smile got bigger and bigger.<br>The cave went very, very quiet. | 35✓ | 3 | "Here's my secret," Papa whispered. "Close your eyes and think about staying awake."<br>He closed his eyes. The cave went quiet. | 21✓ | — | — | — | ✓ | 翻頁鉤子＝安靜蓄勢。5-6「think really hard」反諷＋重複 bigger；3-5 砍修飾；2-3 不選 |
| P04 | 4 | SNOOOOOORE!<br>Papa Bear flopped to one side, mouth wide open.<br>His big round belly went up… and down… and up… and down…<br>He'd just said, "stay awake" — and fell right asleep! | 31✓ | 4 | SNOOOOOORE!<br>Papa Bear flopped to one side, mouth wide open.<br>His big belly went up… and down… | 17✓ | 3 | SNOOOOOORE!<br>Papa Bear tipped right over.<br>His belly went up… and down… | 12✓ | ✓ | 擬聲爆發＋認知落差。5-6 呼吸四拍＋P03 反諷回扣（QA R1 補）；3-5 兩拍；2-3 簡化動作 |
| P05 | 5 | Fuzzy and Cubby looked at each other.<br>They slapped their paws over their mouths, trying SO hard not to laugh.<br>Fuzzy sat up straight. "Well, I'm not doing THAT," she whispered.<br>"I'm NOT falling asleep first!" | 36✓ | 5 | Fuzzy and Cubby slapped their paws over their mouths, trying not to laugh.<br>"I'm not doing THAT," Fuzzy whispered.<br>"I'm NOT falling asleep first!" | 24✓ | 4 | Fuzzy and Cubby tried not to laugh.<br>"NOT falling asleep!" said Fuzzy. | 12✓ | ✓ | 偷笑反應＋疊句。5-6「SO hard」「sat up straight」增態度；3-5 砍；2-3 只留偷笑＋縮短疊句 |
| P06 | 6 | Fuzzy tipped her chin up and started counting the cracks on the ceiling.<br>"One… two… three…"<br>She held up one little finger, her lips pressed tight together. | 27✓ | 6 | Fuzzy started counting cracks on the ceiling.<br>"One… two… three…"<br>She held up one finger, lips pressed tight. | 18✓ | — | — | — | ✓ | 數裂紋漸慢。5-6「tipped her chin up」鋪態度；3-5 砍態度保核心；2-3 不選 |
| P07 | 7 | "Three… f-four…"<br>Her voice got slower… and slower… Her mouth fell open. Her head tipped to the side.<br>pff… pff…<br>Fuzzy was fast asleep. | 24✓ | 7 | "Three… f-four…"<br>Slower… and slower… Her mouth fell open.<br>pff… pff…<br>Fuzzy was fast asleep. | 15✓ | 5 | Fuzzy tipped over.<br>pff… pff…<br>Asleep! | 6✓ | ✓ | 第二擬聲爆發。5-6 多層減速；3-5 砍描寫層；2-3 電報式（6/10 低帶＝入睡節奏骨幹合法） |
| P08 | 8 | Cubby reached over and poked Fuzzy's round back.<br>Nothing.<br>The cave was so quiet now. Just SNOOOOOORE… pff… pff… SNOOOOOORE… pff… pff… back and forth in the dark. | 28✓ | 8 | Cubby poked Fuzzy's round back. Nothing.<br>So quiet. Just SNOOOOOORE… pff… pff…<br>Back and forth in the dark. | 18✓ | — | — | — | ✓ | 靜場頁。5-6 交替鼾聲描繪聲景；3-5 單輪鼾聲＋黑暗；2-3 不選 |
| P09 | 9 | Cubby looked around.<br>Papa Bear was sprawled out like a big, furry mountain. Fuzzy was curled into a tiny ball.<br>The moonlight had gotten soft. | 25✓ | — | — | — | — | — | — | ✓ | 5-6 限定觀察頁：逐一觀察家人＋月光減速。3-5/2-3 不選 |
| P10 | 10 | Cubby leaned against Papa Bear's big, warm belly. It rose and fell, slow and gentle.<br>SNOOOOOORE… pff… pff…<br>Everyone was right here.<br>"I'm not… falling… asleep…" | 26✓ | 9 | Cubby leaned against Papa Bear's warm belly.<br>"I'm not… falling… asleep…"<br>His eyes closed, slow… slow… | 16✓ | 6 | Cubby leaned on Papa's warm belly.<br>SNOOOOOORE… pff… pff…<br>"Not… falling… asleep…" | 12✓ | ✓ | 高潮＋疊句變奏：trailing off＝放棄比賽。5-6「rose and fell, slow and gentle」呼吸描寫；3-5 保疊句變奏＋閉眼減速（對標 zh-TW 3-5）；2-3 電報式 |
| P11 | 11 | Cubby smiled. "Tomorrow night…" he whispered, "…let's do it again."<br>His eyes closed, slow… slow… slow.<br>Three bears, all piled together. Their shadows melted into one under the soft moonlight. | 30✓ | 10 | "Tomorrow night…" Cubby whispered, "…let's do it again."<br>His eyes closed. Three bears, all snuggled together. | 16✓ | 7 | Cubby's eyes closed.<br>Three bears, all snuggled up. | 8✓ | ✓ | 前瞻意願句＋閉眼。5-6「slow… slow… slow」減速＋「shadows melted」詩意；3-5 保核心；2-3 省前瞻句（style_guide F10 toddler：同框＋收束） |
| P12 | 12 | And from that day on… three bears snuggled up together every single night.<br>SNOOOOOORE… pff… pff…<br>Their little cave was warm and cozy. | 23✓ | 11 | And from that day on… three bears snuggled up together every night.<br>SNOOOOOORE… pff… pff…<br>Their cave was warm. | 19✓ | 8 | And from that day on…<br>SNOOOOOORE… pff… pff…<br>Warm and cozy. | 11✓ | ✓ | 收束式。5-6 完整形＋「every single night」「little cave」；3-5 省修飾；2-3 省主語（圖示同框）。結尾四件套：①同框 P11 ②N/A ③前瞻 P11（2-3 省略） ④收束 P12 |
