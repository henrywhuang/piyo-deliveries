# QA 報告：who-falls-asleep-first / en-US / round 2

```yaml
schema: piyo_text_qa_report/v0.9
slug: who-falls-asleep-first
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-30"
step1_lint: {exit_code: 0, warnings: 6}
step2_checklist: {pass: 28, fail: 0}
step3_mode: consolidated
step3_personas: []
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

**復核輪聲明**：R1 全部 ✅ ∈ {句級}（1 筆：P04 5-6 反諷回扣），依 v0.14 擴權規則執行復核輪＝STEP 1 機檢全量＋修改逐筆落地驗證＋受修頁與鄰頁合併審查。

## STEP 1 機檢

locale_lint ×3 tier 全量重跑：exit 0，違規 0。

| 檔位 | 違規 | 警告 | 說明 |
|---|---|---|---|
| 5-6 | 0 | 3 | repeat_discount ×2（refrain 5w P02/P05、onomatopoeia 3w P10/P12）；折計 351→345 |
| 3-5 | 0 | 0 | — |
| 2-3 | 0 | 3 | repeat_discount ×2（refrain 3w P02/P04、onomatopoeia 3w P06/P08）；折計 87→81 |

copy_check：exit 0，警告 2 筆（2-3 P05/P07 帶底，R1 已判合法）。

### 修改逐筆落地驗證

| R1# | 裁決 | 修改內容 | 落地驗證 |
|---|---|---|---|
| 1 | ✅ 句級 | P04 5-6 末增「He'd just said, "stay awake" — and fell right asleep!」 | ✓ draft.json P04 已含該句；copy 表 P04 更新為 31✓＋提純說明已加註；process.md 5-6 raw_total 更新 351 |

copy↔draft 同源：P04 5-6 copy 表文案 = draft.json text 逐字一致 ✓。

## STEP 2 checklist 自檢

**主題錨**：這個故事教孩子——睡覺比賽不是為了「贏」，真正的安心來自一家人相依入眠。

### E-lite：受修頁 P04 與鄰頁 P03、P05 複審

**P03（5-6）**：Papa 的秘訣台詞「think really hard about staying awake」——反諷種子完好，與 P04 新增回扣形成因果閉環。✓

**P04（5-6，受修頁）**：
- 新增句「He'd just said, "stay awake" — and fell right asleep!」
- 語義：回扣 P03 秘訣，反諷兌現（storyboard 要求「回扣P03台詞增反諷」）✓
- 語言：原生英語節奏，無 ESL 痕跡。"fell right asleep" 為口語慣用，非直譯 ✓
- 字數：31w，帶(20,40)內 ✓
- 句長：最長句 = "He'd just said, 'stay awake' — and fell right asleep!" = 9w ＜ 24w ✓
- 與鄰頁連貫：P03 蓄勢→P04 爆發＋反諷，P04→P05 偷笑——邏輯通暢 ✓

**P05（5-6）**：偷笑反應＋refrain，未受 P04 修改影響，維持不變。✓

### 對位：受修頁覆驗

P04 5-6：storyboard「擬聲爆發＋呼嚕聲形容＋回扣P03台詞增反諷」→ 文字現含 SNOOOOOORE!（爆發）＋belly up/down（形容）＋"just said, stay awake"（回扣）。全到位 ✓

### 新發現

無。

## STEP 3 人設 blind QA

S4A v0.15：見 STEP 2。復核輪不重跑人設，分數沿用（本書 S4A 無人設分數）。

## STEP 4 三分法分診

S4A v0.15：見 STEP 2。復核輪新增 real = 0。
