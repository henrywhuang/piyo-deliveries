# QA 報告：who-falls-asleep-first / en-US / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: who-falls-asleep-first
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-30"
step1_lint: {exit_code: 0, warnings: 6}
step2_checklist: {pass: 28, fail: 0}
step3_mode: consolidated
step3_personas: []
step4_triage: {real: 1, rejected: 0, escalated: 0}
verdict: fix_required
```

## STEP 1 機檢

locale_lint ×3 tier：exit 0，違規 0。

| 檔位 | 違規 | 警告 | 說明 |
|---|---|---|---|
| 5-6 | 0 | 3 | repeat_discount ×2（refrain 5w P02/P05、onomatopoeia 3w P10/P12）；折計 342→~336 |
| 3-5 | 0 | 0 | — |
| 2-3 | 0 | 3 | repeat_discount ×2（refrain 3w P02/P04、onomatopoeia 3w P06/P08）；折計 87→~81 |

copy_check：exit 0，警告 2 筆——2-3 P05（6w）、P07（8w）低於帶底 10。判讀：P05＝Fuzzy 入睡的電報式骨幹（"Fuzzy tipped over. / pff… pff… / Asleep!"）、P07＝Cubby 閉眼（"Cubby's eyes closed. / Three bears, all snuggled up."），均為入睡節奏頁，合法。

## STEP 2 checklist 自檢

**主題錨**：這個故事教孩子——睡覺比賽不是為了「贏」，真正的安心來自一家人相依入眠；比賽只是溫暖的遊戲，重要的是「每個人都在這裡」。

### Checklist A-E

| 項 | 判定 | 證據 |
|---|---|---|
| A1 故事弧 | ✓ | 完整三幕：比賽宣告(P01-02)→爸爸先睡(P03-04)→姊姊先睡(P05-07)→Cubby獨處放棄(P08-10)→同框收束(P11-12) |
| A2 翻頁鉤子 | ✓ | P03→P04（安靜蓄勢→鼾聲爆發）、P06→P07（數裂紋→入睡）、P10→P11（refrain 斷句→閉眼）均含翻頁驅動 |
| A3 結尾四件套 | ✓ | ①同框 P11 ②N/A ③前瞻 P11（2-3 省略合法）④收束 P12 |
| B1 角色一致 | ✓ | Papa＝誇張戲劇型（boomed/secret/grin）、Fuzzy＝倔強不服（THAT/staring down/chin up）、Cubby＝柔聲回音（hugged blanket/whispered/leaned） |
| B2 角色區分 | ✓ | 三者語氣、動作、入睡方式皆不同（大鼾/輕鼾/自然閉眼） |
| C1 5-6 適齡 | ✓ | 複句＋形容詞豐富（sprawled/furry mountain/shadows melted）、abstract observation（P09/P11）合理 |
| C2 3-5 適齡 | ✓ | 句型簡化、描寫縮減、刪去 P09 觀察頁 |
| C3 2-3 適齡 | ✓ | 具象短句、refrain 縮短（3w）、全頁 ≤14w、無抽象描寫 |
| D1 正字法 | ✓ | 省略號＝U+2026、破折號＝U+2014、直角雙引號＝ASCII straight、無 CJK 標點 |
| D2 句長上限 | ✓ | 5-6 max observed 17w（P02 attribution line）＜24w 上限；3-5 max 15w＜18w；2-3 max 11w P08 但 "And from that day on…" 前綴匹配 brand_frozen_unit 豁免 |
| D3 頁字數上限 | ✓ | 5-6 max 36w（P02/P05）＜60w；3-5 max 24w（P05）＜46w；2-3 max 14w（P02）≤14w |
| D4 總字數上限 | ✓ | 5-6 342w＜505w；3-5 205w＜389w；2-3 87w＜88w |
| E1 疊句兌現 | ✓ | P02×3＋P05×1＋P10 variation，三檔位一致結構 |
| E2 擬聲詞兌現 | ✓ | SNOOOOOORE!（P04）→SNOOOOOORE…＋pff…pff…（P08/P10/P12）持續態交替 |
| E3 收束式兌現 | ✓ | 5-6「Their little cave was warm and cozy.」/ 3-5「Their cave was warm.」/ 2-3「Warm and cozy.」匹配 commitments |
| E4 趣味設計兌現 | ✓ | design 宣告＝睡覺比賽反諷（最自信者先睡）＋聲音分軌（大鼾 vs 輕鼾）＋倒數入睡。P03-04 反諷兌現、P04/P07 聲音分軌兌現、P06-07 倒數入睡兌現 |
| E5 concept fidelity | ✓ | 見下方逐檔判定 |
| 快速掃描 ×9 | 9/9 ✓ | 角色名 registry 一致、onomatopoeia 凍結字串精確匹配、brand_frozen_unit 前綴匹配、tier selection 匹配 copy 表 |

### 對位逐頁比對

| 頁 | storyboard「文說什麼」 | 5-6 判定 | 3-5 判定 | 2-3 判定 |
|---|---|---|---|---|
| P01 | 熊爸爸提出比賽（主台詞＋規則）。晚安引出，不描寫月光外觀（交圖） | ✓ "moonlight spilled"＝大氣渲染非外觀描寫 | ✓ | ✓ |
| P02 | 疊句×3。角色辨識交圖，文字只需台詞 | ✓ attribution＝敘事歸屬非視覺描寫 | ✓ | ✓ |
| P03 | 秘訣台詞＝反諷種子。安靜蓄勢 | ✓ | ✓ | — |
| P04 | 擬聲爆發＋呼嚕聲形容＋**回扣P03台詞增反諷** | **❌ 缺反諷回扣** | ✓ 3-5 無此要求 | ✓ 2-3 無此要求 |
| P05 | 偷笑→摀嘴→毛毛反擊台詞。疊句第二拍 | ✓ | ✓ | ✓ |
| P06 | 數裂紋台詞＋漸慢暗示 | ✓ | ✓ | — |
| P07 | 第二擬聲＋入睡對比（大vs小）。毛毛睡了 | ✓ 對比由 onomatopoeia 音量傳達 | ✓ | ✓ |
| P08 | 推毛毛→沒回應。安靜中迴盪打呼聲。純環境渲染 | ✓ | ✓ | — |
| P09 | 逐一觀察家人：爸爸→大山、毛毛→小球。月光柔化。減速 | ✓ | — | — |
| P10 | 靠在大肚子上＋雙聲交替＋安心句＋疊句變奏切斷。翻頁鉤子＝放棄比賽 | ✓ | ✓ 3-5 省安心句（對標 zh-TW 3-5） | ✓ |
| P11 | 前瞻意願句＋閉眼 | ✓ | ✓ | ✓ 2-3 省前瞻（F10 toddler 規則） |
| P12 | 收束式＝「每天晚上」＋雙聲呼嚕＋暖暖的 | ✓ | ✓ | ✓ |

**對位違反 1 筆**：P04 5-6 缺 storyboard 要求的反諷回扣。

### ESL 獵手

逐頁掃描 en-US spec 雷區＋style_guide §3.4 四型：

| 頁 | 檔位 | 掃描結果 |
|---|---|---|
| P01 | 全 | ✓ 無 ESL 痕跡。"moonlight spilled" 為原生隱喻 |
| P02 | 全 | ✓ "staring Papa down"（5-6）原生 phrasal verb |
| P03 | 5-6/3-5 | ✓ "think really hard about staying awake" 自然語序 |
| P04 | 全 | ✓ "flopped to one side" 原生 |
| P05 | 全 | ✓ "SO hard"（5-6）口語強調合理；"I'm not doing THAT" 原生態度句 |
| P06 | 5-6/3-5 | ✓ "tipped her chin up" 原生 |
| P07 | 全 | ✓ "f-four" stuttering 標記自然 |
| P08 | 5-6/3-5 | ✓ "back and forth in the dark" 原生節奏 |
| P09 | 5-6 | ✓ "sprawled out like a big, furry mountain" 原生 simile |
| P10 | 全 | ✓ "Everyone was right here" 原生安心句 |
| P11 | 全 | ✓ "Their shadows melted into one"（5-6）原生詩意 |
| P12 | 全 | ✓ "every single night" 原生強調 |

**AI 機械句掃描**（§3.4 四型）：

1. 電報式裸動詞堆疊：2-3 P05「Fuzzy tipped over. / pff… pff… / Asleep!」——合法，§3.4 明定 2-3 檔電報式邊界。✓
2. 成分懸空：未發現。✓
3. 超規律平行：未發現。疊句三拍為設計構造，非機械重複。✓
4. 無語氣詞乾句：未發現。✓

ESL 獵手：零發現。

### 原生語感三視角

**Teacher**：朗讀流暢度好。SNOOOOOORE! 和 pff… pff… 的音量對比在教室裡可以引導孩子用大聲/小聲參與。refrain 三拍結構（P02）天然適合 chant-along。P10 trailing off "I'm not… falling… asleep…" 可以讓孩子越念越慢，體驗入睡。全三檔適齡。✓

**Parent**：作為睡前故事，節奏設計精準——前半活潑（比賽、偷笑）、後半漸慢（數裂紋→入睡→安靜→閉眼）。P10「Everyone was right here.」是家長會被觸動的安心句。2-3 檔位極簡但不空洞。✓

**Editor**：語言乾淨，無贅詞、無被動句堆疊。P11 5-6「slow… slow… slow.」三拍遞減收尾好。P09「The moonlight had gotten soft.」past perfect 合理（漸進變化）。唯一微疑：P08 5-6「Just SNOOOOOORE… pff… pff… SNOOOOOORE… pff… pff… back and forth in the dark.」—— 雙輪交替略長，但作為聲景描繪合法。✓

### Concept fidelity

| 檔位 | 判定 | 說明 |
|---|---|---|
| 5-6 | ✓ | 孩子帶走＝比賽不重要，一家人在一起才是真正的安心。P10「Everyone was right here.」＋P11「let's do it again」＋P12「warm and cozy」三層兌現 |
| 3-5 | ✓ | 同核心，簡化但完整。P09 refrain 變奏＋閉眼遞減傳達放棄比賽的安心 |
| 2-3 | ✓ | 具象核心：三隻熊靠在一起 → warm and cozy。比賽元素保留但不佔語義重心 |

### Inline 分診

| # | 頁 | 檔位 | 來源 | 發現 | 裁決 | 修改級別 | 依據 |
|---|---|---|---|---|---|---|---|
| 1 | P04 | 5-6 | 對位比對 | storyboard「文說什麼」要求「回扣P03台詞增反諷」，5-6 文字無反諷回扣。zh-TW 5-6 P04 有「才剛說完『什麼都不想』——就睡著了」| ✅ | 句級 | storyboard 明確負載要求；3-5/2-3 無此要求（zh-TW 同檔位亦無） |

建議修正：P04 5-6 末尾增「He'd just said, "stay awake" — and fell right asleep!」（+9w，P04 22→31w，帶內合規）。

**⏸️ 上呈批次**：無。

## STEP 3 人設 blind QA

S4A v0.15：見 STEP 2 合併審查。

## STEP 4 三分法分診

S4A v0.15：見 STEP 2 合併審查。
