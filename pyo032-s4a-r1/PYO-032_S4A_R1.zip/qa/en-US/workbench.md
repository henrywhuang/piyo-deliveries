# 關卡WB整合審閱：誰先睡著？（E 對位底稿／en-US）

- 生成時間：2026-07-30 18:21:15 +0800
- 書目錄：`content/PYO-032_who-falls-asleep-first`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate WB`（決定性腳本，純解析＋排版）
- locale：en-US
- 用途：E 主審與裁決 agent 的單檔輸入 bundle——文字＝QA 對象本體逐字轉錄；可疑頁保留開原檔抽驗權

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-032_storyboard.md` | 2026-07-30 12:23:14 |
| copy | `copy/en-US.md` | 2026-07-30 18:19:04 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-30 16:12:37 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-30 18:16:53 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-30 16:16:01 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-30 18:16:55 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-30 16:16:17 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-30 18:11:22 |
| qa/en-US/backtranslation.md | （缺） | — |

## 檔頭 commitments 逐字轉錄（兌現比對用）

```yaml
schema: piyo_copy/v0.9
slug: who-falls-asleep-first
locale: en-US
mode: B
storyboard: content/PYO-032_who-falls-asleep-first/PYO-032_storyboard.md
design: content/PYO-032_who-falls-asleep-first/PYO-032_design.md
image_pool: 12
selection:
  "3-5": [P01, P02, P03, P04, P05, P06, P07, P08, P10, P11, P12]
  "2-3": [P01, P02, P04, P05, P07, P10, P11, P12]
commitments:
  refrain: "NOT falling asleep"
  ending:
    "5-6": "Their little cave was warm and cozy."
    "3-5": "Their cave was warm."
    "2-3": "Warm and cozy."
  onomatopoeia: ["SNOOOOOORE!", "pff… pff…"]
characters: [Cubby, Fuzzy, Papa Bear]
```

## 檔位 5-6（12 頁）

### 5-6｜P01（母版 P01）

- 圖說什麼：月光從洞口灑進溫暖的山洞，乾草軟墊鋪滿地面。一大兩小三隻熊窩在一起，大熊舉起手比著什麼，兩隻小熊仰頭看。洞口矮枝上一隻小鳥歪頭張望。
- 文說什麼：介紹場景和角色，熊爸爸提出比賽誰先睡著的遊戲。
- 鉤子：懸念型：比賽要開始了，誰會先睡著？
- 選圖與提純說明：5-6「cozy」增感官＋「sat up with a big grin」動作鋪陳；3-5 精簡動作；2-3 電報式最短引出比賽
- 匹配欄：✓

【zh-TW】
晚安的時間到了。
熊爸爸躺好了，突然說：「嘿！今天晚上，我們來比賽——誰先睡著，誰就輸了！」

【en-US】
One cozy night, moonlight spilled into a warm bear cave.
Papa Bear sat up with a big grin.
"I know!" he said. "Let's have a contest — who falls asleep first!"

### 5-6｜P02（母版 P02）

- 圖說什麼：三隻熊並排躺在乾草軟墊上。熊爸爸鼓著胸膛張大嘴巴最神氣，毛毛握拳盯著爸爸不服輸，小寶抱著藍色小毯子學姐姐瞪大眼睛。
- 文說什麼：三隻熊輪流喊出疊句「我才不會先睡著！」，建立競爭氣氛。
- 鉤子：懸念型：大家都說不會先睡，越有自信的是不是越快倒？
- 選圖與提純說明：疊句三拍：5-6 各角色個性化（boomed/staring down/blanket）；3-5 精簡 2-word attributions；2-3 縮短疊句 3 words
- 匹配欄：✓

【zh-TW】
「我才不會先睡著！」熊爸爸最大聲。
「我才不會先睡著！」毛毛不服輸。
小寶學著喊：「我……我才不會先睡著！」

【en-US】
Three bears lay on their soft, grassy beds.
"I'm NOT falling asleep first!" Papa Bear boomed.
"I'm NOT falling asleep first!" Fuzzy said, staring Papa down.
Cubby hugged his blue blanket.
"I'm NOT falling asleep first!"

### 5-6｜P03（母版 P03）

- 圖說什麼：熊爸爸的大臉佔滿畫面，眼睛慢慢閉上，嘴角微微上揚帶著得意。月光柔柔地照在他毛茸茸的大臉上，四周一片安靜。
- 文說什麼：爸爸分享撐住秘訣然後閉眼示範，敘述蓄勢到安靜斷點，不揭示下一秒。
- 鉤子：動作中斷型：眼睛閉上了，山洞安靜下來——只是在示範，對嗎？
- 選圖與提純說明：翻頁鉤子＝安靜蓄勢。5-6「think really hard」反諷＋重複 bigger；3-5 砍修飾；2-3 不選
- 匹配欄：✓

【zh-TW】
熊爸爸得意地說：「撐住不睡的秘訣，就是——閉上眼睛，什麼都不想。」
熊爸爸閉上眼睛。
山洞安安靜靜的……

【en-US】
"I'll tell you my secret," Papa Bear whispered.
"Just close your eyes… and think really hard about staying awake."
He closed his eyes. His smile got bigger and bigger.
The cave went very, very quiet.

### 5-6｜P04（母版 P04）

- 圖說什麼：熊爸爸往旁邊一歪倒下去，嘴巴大張，圓鼓鼓的肚子隨著呼嚕一起一伏。毛毛和小寶被嚇得眼睛瞪圓，小寶的藍毯子彈到半空。旁邊的乾草被呼出的氣吹得滾開。
- 文說什麼：呼嚕嚕嚕嚕！擬聲詞爆發，敘述爸爸打呼倒下。
- 鉤子：懸念型：最有自信的爸爸先倒了！毛毛能撐住嗎？
- 選圖與提純說明：擬聲爆發＋認知落差。5-6 呼吸四拍＋呼吸四拍；3-5 兩拍；2-3 簡化動作
- 匹配欄：✓

【zh-TW】
呼嚕嚕嚕嚕！
好大好大的呼嚕聲！
才剛說完「什麼都不想」——熊爸爸就睡著了。

【en-US】
SNOOOOOORE!
Papa Bear flopped to one side, mouth wide open.
His big round belly went up… and down… and up… and down…

### 5-6｜P05（母版 P05）

- 圖說什麼：毛毛和小寶面對面，雙手摀住嘴巴憋著笑，眼睛笑成兩條線。旁邊熊爸爸已經歪倒攤平，嘴巴半張著打呼，渾然不覺。
- 文說什麼：兩隻小熊的偷笑反應，毛毛宣告自己絕不會像爸爸那樣。
- 鉤子：問句型：毛毛有自己的撐住秘訣——是什麼？
- 選圖與提純說明：偷笑反應＋疊句。5-6「SO hard」「sat up straight」增態度；3-5 砍；2-3 只留偷笑＋縮短疊句
- 匹配欄：✓

【zh-TW】
毛毛和小寶偷偷看了一眼，趕快摀住嘴巴。
毛毛小小聲地說：「我才不會像爸爸那樣！我才不會先睡著！」

【en-US】
Fuzzy and Cubby looked at each other.
They slapped their paws over their mouths, trying SO hard not to laugh.
Fuzzy sat up straight. "Well, I'm not doing THAT," she whispered.
"I'm NOT falling asleep first!"

### 5-6｜P06（母版 P06）

- 圖說什麼：毛毛仰著頭數天花板的裂紋，右手舉起一根手指，表情認真得嘴唇翹起來。她圓滾滾的下巴仰得高高的，像一顆下定決心的小毛球。
- 文說什麼：毛毛用數天花板裂紋保持清醒，敘述越數越慢的過程。
- 鉤子：動作中斷型：數到四……聲音越來越慢……
- 選圖與提純說明：數裂紋漸慢。5-6「tipped her chin up」鋪態度；3-5 砍態度保核心；2-3 不選
- 匹配欄：✓

【zh-TW】
毛毛有自己的辦法。
她仰起頭，開始數天花板上的裂紋。
「一條……兩條……三條……」
聲音越來越小，越來越慢……
「四……」

【en-US】
Fuzzy tipped her chin up and started counting the cracks on the ceiling.
"One… two… three…"
She held up one little finger, her lips pressed tight together.

### 5-6｜P07（母版 P07）

- 圖說什麼：毛毛的臉佔滿畫面，嘴巴張開一半，頭往旁邊一歪，眼睛已經閉上了。粉色蝴蝶結歪到右耳下面，表情安詳又有點傻。
- 文說什麼：噗嚕嚕——毛毛也睡著了，敘述她數到一半嘴巴張開的樣子。
- 鉤子：懸念型：只剩小寶一個人醒著了
- 選圖與提純說明：第二擬聲爆發。5-6 多層減速；3-5 砍描寫層；2-3 電報式（6/10 低帶＝入睡節奏骨幹合法）
- 匹配欄：✓

【zh-TW】
噗嚕嚕……
毛毛數到一半，也睡著了。
小小的噗嚕嚕，跟爸爸大大的呼嚕完全不一樣。

【en-US】
"Three… f-four…"
Her voice got slower… and slower… Her mouth fell open. Her head tipped to the side.
pff… pff…
Fuzzy was fast asleep.

### 5-6｜P08（母版 P08）

- 圖說什麼：小寶伸出小手推推毛毛圓圓的背，毛毛完全沒反應。小寶歪著頭看著她，眼睛大大的，手裡還捏著藍色小毯子的一角。
- 文說什麼：小寶推毛毛沒反應，山洞裡只剩兩種呼嚕聲交替取代嬉鬧的安靜描述。
- 鉤子：視覺引導型：小寶的目光從毛毛移向整個安靜的洞穴
- 選圖與提純說明：靜場頁。5-6 交替鼾聲描繪聲景；3-5 單輪鼾聲＋黑暗；2-3 不選
- 匹配欄：✓

【zh-TW】
小寶伸出手，推了推毛毛。
沒有人回答。
山洞裡安安靜靜的，只剩下——
兩種打呼聲，一大一小，輪流響著……

【en-US】
Cubby reached over and poked Fuzzy's round back.
Nothing.
The cave was so quiet now. Just SNOOOOOORE… pff… pff… SNOOOOOORE… pff… pff… back and forth in the dark.

### 5-6｜P09（母版 P09）

- 圖說什麼：整個熊窩一覽無遺。熊爸爸攤成一大坨佔了大半地方，毛毛蜷成一顆小球。小寶坐在中間小小的，被柔柔的月光籠著。洞口小鳥已把頭埋進翅膀裡。
- 文說什麼：安靜的節奏描述小寶看著家人——從比賽的興奮慢慢轉為觀察的溫暖。
- 鉤子：視覺引導型：月光漸柔，小寶的感受正在改變
- 選圖與提純說明：5-6 限定觀察頁：逐一觀察家人＋月光減速。3-5/2-3 不選
- 匹配欄：✓

【zh-TW】
小寶看看爸爸——好大好大一坨。
再看看毛毛——蜷成小小的一顆球。
月光好柔好柔的。

【en-US】
Cubby looked around.
Papa Bear was sprawled out like a big, furry mountain. Fuzzy was curled into a tiny ball.
The moonlight had gotten soft.

### 5-6｜P10（母版 P10）

- 圖說什麼：小寶整個身體靠在熊爸爸暖暖的大肚子上，藍色小毯子鬆鬆地蓋著。眼睛慢慢瞇起來，嘴角微微上揚。爸爸的肚子隨呼吸輕輕起伏，像搖籃一樣。
- 文說什麼：感受體溫和呼吸聲——不想比了。疊句最後一次，變奏為放棄比賽的安心。
- 鉤子：動作中斷型：眼睛慢慢……慢慢……
- 選圖與提純說明：高潮＋疊句變奏：trailing off＝放棄比賽。5-6「rose and fell, slow and gentle」呼吸描寫；3-5 保疊句變奏＋閉眼減速（對標 zh-TW 3-5）；2-3 電報式
- 匹配欄：✓

【zh-TW】
小寶靠在爸爸暖暖的大肚子上。
呼嚕嚕……噗嚕嚕……
好溫暖。大家都在。
「我才不會先……」
眼睛慢慢……慢慢……

【en-US】
Cubby leaned against Papa Bear's big, warm belly. It rose and fell, slow and gentle.
SNOOOOOORE… pff… pff…
Everyone was right here.
"I'm not… falling… asleep…"

### 5-6｜P11（母版 P11）

- 圖說什麼：三隻熊擠在一起。小寶靠在爸爸背上微微笑著，眼睛快要閉上。毛毛蜷在另一邊，蝴蝶結歪歪的。月光從洞口照進來，三團毛茸茸的影子疊在一起。
- 文說什麼：小寶輕輕說出前瞻意願句然後閉眼。三隻熊擠在一起的溫暖畫面。
- 鉤子：視覺引導型：呼吸聲越來越遠，三個影子融在一起
- 選圖與提純說明：前瞻意願句＋閉眼。5-6「slow… slow… slow」減速＋「shadows melted」詩意；3-5 保核心；2-3 省前瞻句（style_guide F10 toddler：同框＋收束）
- 匹配欄：✓

【zh-TW】
小寶笑了笑，輕輕地說：
「明天晚上……再比一次。」
然後，眼睛閉起來了。

【en-US】
Cubby smiled. "Tomorrow night…" he whispered, "…let's do it again."
His eyes closed, slow… slow… slow.
Three bears, all piled together. Their shadows melted into one under the soft moonlight.

### 5-6｜P12（母版 P12）

- 圖說什麼：三隻熊擠成一團，毛茸茸的身體交疊在一起分不清邊界了。月光淡淡地照著三個圓圓的輪廓，一切安安靜靜。
- 文說什麼：固定收束語加呼嚕嚕噗嚕嚕的擬聲詞做聽覺收束。
- 鉤子：—
- 選圖與提純說明：收束式。5-6 完整形＋「every single night」「little cave」；3-5 省修飾；2-3 省主語（圖示同框）。結尾四件套：①同框 P11 ②N/A ③前瞻 P11（2-3 省略） ④收束 P12
- 匹配欄：✓

【zh-TW】
後來呀……
三隻熊每天晚上都擠在一起。
呼嚕嚕，噗嚕嚕，山洞裡暖暖的。

【en-US】
And from that day on… three bears snuggled up together every single night.
SNOOOOOORE… pff… pff…
Their little cave was warm and cozy.

## 檔位 3-5（11 頁）

### 3-5｜P01（母版 P01）

- 圖說什麼：月光從洞口灑進溫暖的山洞，乾草軟墊鋪滿地面。一大兩小三隻熊窩在一起，大熊舉起手比著什麼，兩隻小熊仰頭看。洞口矮枝上一隻小鳥歪頭張望。
- 文說什麼：介紹場景和角色，熊爸爸提出比賽誰先睡著的遊戲。
- 鉤子：懸念型：比賽要開始了，誰會先睡著？
- 選圖與提純說明：5-6「cozy」增感官＋「sat up with a big grin」動作鋪陳；3-5 精簡動作；2-3 電報式最短引出比賽
- 匹配欄：✓

【zh-TW】
晚安的時間到了。
熊爸爸說：「來比賽！誰先睡著，誰就輸了！」

【en-US】
One night, moonlight spilled into a warm bear cave.
Papa Bear grinned. "Let's have a contest — who falls asleep first!"

### 3-5｜P02（母版 P02）

- 圖說什麼：三隻熊並排躺在乾草軟墊上。熊爸爸鼓著胸膛張大嘴巴最神氣，毛毛握拳盯著爸爸不服輸，小寶抱著藍色小毯子學姐姐瞪大眼睛。
- 文說什麼：三隻熊輪流喊出疊句「我才不會先睡著！」，建立競爭氣氛。
- 鉤子：懸念型：大家都說不會先睡，越有自信的是不是越快倒？
- 選圖與提純說明：疊句三拍：5-6 各角色個性化（boomed/staring down/blanket）；3-5 精簡 2-word attributions；2-3 縮短疊句 3 words
- 匹配欄：✓

【zh-TW】
「我才不會先睡著！」
「我才不會先睡著！」
「我才不會先睡著！」
大家都喊。

【en-US】
"I'm NOT falling asleep first!" Papa boomed.
"I'm NOT falling asleep first!" Fuzzy said.
"I'm NOT falling asleep first!" Cubby squeaked.

### 3-5｜P03（母版 P03）

- 圖說什麼：熊爸爸的大臉佔滿畫面，眼睛慢慢閉上，嘴角微微上揚帶著得意。月光柔柔地照在他毛茸茸的大臉上，四周一片安靜。
- 文說什麼：爸爸分享撐住秘訣然後閉眼示範，敘述蓄勢到安靜斷點，不揭示下一秒。
- 鉤子：動作中斷型：眼睛閉上了，山洞安靜下來——只是在示範，對嗎？
- 選圖與提純說明：翻頁鉤子＝安靜蓄勢。5-6「think really hard」反諷＋重複 bigger；3-5 砍修飾；2-3 不選
- 匹配欄：✓

【zh-TW】
熊爸爸說：「撐住的秘訣，就是——閉上眼睛。」
山洞安安靜靜的……

【en-US】
"Here's my secret," Papa whispered. "Close your eyes and think about staying awake."
He closed his eyes. The cave went quiet.

### 3-5｜P04（母版 P04）

- 圖說什麼：熊爸爸往旁邊一歪倒下去，嘴巴大張，圓鼓鼓的肚子隨著呼嚕一起一伏。毛毛和小寶被嚇得眼睛瞪圓，小寶的藍毯子彈到半空。旁邊的乾草被呼出的氣吹得滾開。
- 文說什麼：呼嚕嚕嚕嚕！擬聲詞爆發，敘述爸爸打呼倒下。
- 鉤子：懸念型：最有自信的爸爸先倒了！毛毛能撐住嗎？
- 選圖與提純說明：擬聲爆發＋認知落差。5-6 呼吸四拍＋呼吸四拍；3-5 兩拍；2-3 簡化動作
- 匹配欄：✓

【zh-TW】
呼嚕嚕嚕嚕！
好大好大的呼嚕聲！
熊爸爸先睡著了。

【en-US】
SNOOOOOORE!
Papa Bear flopped to one side, mouth wide open.
His big belly went up… and down…

### 3-5｜P05（母版 P05）

- 圖說什麼：毛毛和小寶面對面，雙手摀住嘴巴憋著笑，眼睛笑成兩條線。旁邊熊爸爸已經歪倒攤平，嘴巴半張著打呼，渾然不覺。
- 文說什麼：兩隻小熊的偷笑反應，毛毛宣告自己絕不會像爸爸那樣。
- 鉤子：問句型：毛毛有自己的撐住秘訣——是什麼？
- 選圖與提純說明：偷笑反應＋疊句。5-6「SO hard」「sat up straight」增態度；3-5 砍；2-3 只留偷笑＋縮短疊句
- 匹配欄：✓

【zh-TW】
毛毛偷偷笑：「我才不會像爸爸那樣！我才不會先睡著！」

【en-US】
Fuzzy and Cubby slapped their paws over their mouths, trying not to laugh.
"I'm not doing THAT," Fuzzy whispered.
"I'm NOT falling asleep first!"

### 3-5｜P06（母版 P06）

- 圖說什麼：毛毛仰著頭數天花板的裂紋，右手舉起一根手指，表情認真得嘴唇翹起來。她圓滾滾的下巴仰得高高的，像一顆下定決心的小毛球。
- 文說什麼：毛毛用數天花板裂紋保持清醒，敘述越數越慢的過程。
- 鉤子：動作中斷型：數到四……聲音越來越慢……
- 選圖與提純說明：數裂紋漸慢。5-6「tipped her chin up」鋪態度；3-5 砍態度保核心；2-3 不選
- 匹配欄：✓

【zh-TW】
毛毛開始數天花板上的裂紋。
「一條……兩條……三條……四……」
聲音越來越小……

【en-US】
Fuzzy started counting cracks on the ceiling.
"One… two… three…"
She held up one finger, lips pressed tight.

### 3-5｜P07（母版 P07）

- 圖說什麼：毛毛的臉佔滿畫面，嘴巴張開一半，頭往旁邊一歪，眼睛已經閉上了。粉色蝴蝶結歪到右耳下面，表情安詳又有點傻。
- 文說什麼：噗嚕嚕——毛毛也睡著了，敘述她數到一半嘴巴張開的樣子。
- 鉤子：懸念型：只剩小寶一個人醒著了
- 選圖與提純說明：第二擬聲爆發。5-6 多層減速；3-5 砍描寫層；2-3 電報式（6/10 低帶＝入睡節奏骨幹合法）
- 匹配欄：✓

【zh-TW】
噗嚕嚕……
毛毛也睡著了。
小小的噗嚕嚕，跟大大的呼嚕不一樣。

【en-US】
"Three… f-four…"
Slower… and slower… Her mouth fell open.
pff… pff…
Fuzzy was fast asleep.

### 3-5｜P08（母版 P08）

- 圖說什麼：小寶伸出小手推推毛毛圓圓的背，毛毛完全沒反應。小寶歪著頭看著她，眼睛大大的，手裡還捏著藍色小毯子的一角。
- 文說什麼：小寶推毛毛沒反應，山洞裡只剩兩種呼嚕聲交替取代嬉鬧的安靜描述。
- 鉤子：視覺引導型：小寶的目光從毛毛移向整個安靜的洞穴
- 選圖與提純說明：靜場頁。5-6 交替鼾聲描繪聲景；3-5 單輪鼾聲＋黑暗；2-3 不選
- 匹配欄：✓

【zh-TW】
小寶推了推毛毛——沒有人回答。
山洞裡只剩下呼嚕嚕……噗嚕嚕……

【en-US】
Cubby poked Fuzzy's round back. Nothing.
So quiet. Just SNOOOOOORE… pff… pff…
Back and forth in the dark.

### 3-5｜P09（母版 P10）

- 圖說什麼：小寶整個身體靠在熊爸爸暖暖的大肚子上，藍色小毯子鬆鬆地蓋著。眼睛慢慢瞇起來，嘴角微微上揚。爸爸的肚子隨呼吸輕輕起伏，像搖籃一樣。
- 文說什麼：感受體溫和呼吸聲——不想比了。疊句最後一次，變奏為放棄比賽的安心。
- 鉤子：動作中斷型：眼睛慢慢……慢慢……
- 選圖與提純說明：高潮＋疊句變奏：trailing off＝放棄比賽。5-6「rose and fell, slow and gentle」呼吸描寫；3-5 保疊句變奏＋閉眼減速（對標 zh-TW 3-5）；2-3 電報式
- 匹配欄：✓

【zh-TW】
小寶靠在爸爸暖暖的大肚子上。
「我才不會先……」
眼睛慢慢……慢慢……

【en-US】
Cubby leaned against Papa Bear's warm belly.
"I'm not… falling… asleep…"
His eyes closed, slow… slow…

### 3-5｜P10（母版 P11）

- 圖說什麼：三隻熊擠在一起。小寶靠在爸爸背上微微笑著，眼睛快要閉上。毛毛蜷在另一邊，蝴蝶結歪歪的。月光從洞口照進來，三團毛茸茸的影子疊在一起。
- 文說什麼：小寶輕輕說出前瞻意願句然後閉眼。三隻熊擠在一起的溫暖畫面。
- 鉤子：視覺引導型：呼吸聲越來越遠，三個影子融在一起
- 選圖與提純說明：前瞻意願句＋閉眼。5-6「slow… slow… slow」減速＋「shadows melted」詩意；3-5 保核心；2-3 省前瞻句（style_guide F10 toddler：同框＋收束）
- 匹配欄：✓

【zh-TW】
小寶輕輕說：
「明天晚上……再比一次。」
眼睛閉起來了。

【en-US】
"Tomorrow night…" Cubby whispered, "…let's do it again."
His eyes closed. Three bears, all snuggled together.

### 3-5｜P11（母版 P12）

- 圖說什麼：三隻熊擠成一團，毛茸茸的身體交疊在一起分不清邊界了。月光淡淡地照著三個圓圓的輪廓，一切安安靜靜。
- 文說什麼：固定收束語加呼嚕嚕噗嚕嚕的擬聲詞做聽覺收束。
- 鉤子：—
- 選圖與提純說明：收束式。5-6 完整形＋「every single night」「little cave」；3-5 省修飾；2-3 省主語（圖示同框）。結尾四件套：①同框 P11 ②N/A ③前瞻 P11（2-3 省略） ④收束 P12
- 匹配欄：✓

【zh-TW】
後來呀……
三隻熊每天晚上都擠在一起。
呼嚕嚕，噗嚕嚕，暖暖的。

【en-US】
And from that day on… three bears snuggled up together every night.
SNOOOOOORE… pff… pff…
Their cave was warm.

## 檔位 2-3（8 頁）

### 2-3｜P01（母版 P01）

- 圖說什麼：月光從洞口灑進溫暖的山洞，乾草軟墊鋪滿地面。一大兩小三隻熊窩在一起，大熊舉起手比著什麼，兩隻小熊仰頭看。洞口矮枝上一隻小鳥歪頭張望。
- 文說什麼：介紹場景和角色，熊爸爸提出比賽誰先睡著的遊戲。
- 鉤子：懸念型：比賽要開始了，誰會先睡著？
- 選圖與提純說明：5-6「cozy」增感官＋「sat up with a big grin」動作鋪陳；3-5 精簡動作；2-3 電報式最短引出比賽
- 匹配欄：✓

【zh-TW】
晚安囉！
熊爸爸說：「來比賽！誰先睡著？」

【en-US】
Moonlight in the bear cave.
Papa Bear grinned.
"Who falls asleep first?"

### 2-3｜P02（母版 P02）

- 圖說什麼：三隻熊並排躺在乾草軟墊上。熊爸爸鼓著胸膛張大嘴巴最神氣，毛毛握拳盯著爸爸不服輸，小寶抱著藍色小毯子學姐姐瞪大眼睛。
- 文說什麼：三隻熊輪流喊出疊句「我才不會先睡著！」，建立競爭氣氛。
- 鉤子：懸念型：大家都說不會先睡，越有自信的是不是越快倒？
- 選圖與提純說明：疊句三拍：5-6 各角色個性化（boomed/staring down/blanket）；3-5 精簡 2-word attributions；2-3 縮短疊句 3 words
- 匹配欄：✓

【zh-TW】
「我才不會先睡著！」
「我才不會先睡著！」
「我才不會先睡著！」

【en-US】
"NOT falling asleep!" Papa Bear boomed.
"NOT falling asleep!" said Fuzzy.
"NOT falling asleep!"

### 2-3｜P03（母版 P04）

- 圖說什麼：熊爸爸往旁邊一歪倒下去，嘴巴大張，圓鼓鼓的肚子隨著呼嚕一起一伏。毛毛和小寶被嚇得眼睛瞪圓，小寶的藍毯子彈到半空。旁邊的乾草被呼出的氣吹得滾開。
- 文說什麼：呼嚕嚕嚕嚕！擬聲詞爆發，敘述爸爸打呼倒下。
- 鉤子：懸念型：最有自信的爸爸先倒了！毛毛能撐住嗎？
- 選圖與提純說明：擬聲爆發＋認知落差。5-6 呼吸四拍＋呼吸四拍；3-5 兩拍；2-3 簡化動作
- 匹配欄：✓

【zh-TW】
呼嚕嚕嚕嚕！
爸爸睡著了！

【en-US】
SNOOOOOORE!
Papa Bear tipped right over.
His belly went up… and down…

### 2-3｜P04（母版 P05）

- 圖說什麼：毛毛和小寶面對面，雙手摀住嘴巴憋著笑，眼睛笑成兩條線。旁邊熊爸爸已經歪倒攤平，嘴巴半張著打呼，渾然不覺。
- 文說什麼：兩隻小熊的偷笑反應，毛毛宣告自己絕不會像爸爸那樣。
- 鉤子：問句型：毛毛有自己的撐住秘訣——是什麼？
- 選圖與提純說明：偷笑反應＋疊句。5-6「SO hard」「sat up straight」增態度；3-5 砍；2-3 只留偷笑＋縮短疊句
- 匹配欄：✓

【zh-TW】
毛毛和小寶偷偷笑。
「我才不會先睡著！」

【en-US】
Fuzzy and Cubby tried not to laugh.
"NOT falling asleep!" said Fuzzy.

### 2-3｜P05（母版 P07）

- 圖說什麼：毛毛的臉佔滿畫面，嘴巴張開一半，頭往旁邊一歪，眼睛已經閉上了。粉色蝴蝶結歪到右耳下面，表情安詳又有點傻。
- 文說什麼：噗嚕嚕——毛毛也睡著了，敘述她數到一半嘴巴張開的樣子。
- 鉤子：懸念型：只剩小寶一個人醒著了
- 選圖與提純說明：第二擬聲爆發。5-6 多層減速；3-5 砍描寫層；2-3 電報式（6/10 低帶＝入睡節奏骨幹合法）
- 匹配欄：✓

【zh-TW】
噗嚕嚕……
毛毛也睡著了。

【en-US】
Fuzzy tipped over.
pff… pff…
Asleep!

### 2-3｜P06（母版 P10）

- 圖說什麼：小寶整個身體靠在熊爸爸暖暖的大肚子上，藍色小毯子鬆鬆地蓋著。眼睛慢慢瞇起來，嘴角微微上揚。爸爸的肚子隨呼吸輕輕起伏，像搖籃一樣。
- 文說什麼：感受體溫和呼吸聲——不想比了。疊句最後一次，變奏為放棄比賽的安心。
- 鉤子：動作中斷型：眼睛慢慢……慢慢……
- 選圖與提純說明：高潮＋疊句變奏：trailing off＝放棄比賽。5-6「rose and fell, slow and gentle」呼吸描寫；3-5 保疊句變奏＋閉眼減速（對標 zh-TW 3-5）；2-3 電報式
- 匹配欄：✓

【zh-TW】
呼嚕嚕……噗嚕嚕……
大家都在。暖暖的。
「我才不會先……」

【en-US】
Cubby leaned on Papa's warm belly.
SNOOOOOORE… pff… pff…
"Not… falling… asleep…"

### 2-3｜P07（母版 P11）

- 圖說什麼：三隻熊擠在一起。小寶靠在爸爸背上微微笑著，眼睛快要閉上。毛毛蜷在另一邊，蝴蝶結歪歪的。月光從洞口照進來，三團毛茸茸的影子疊在一起。
- 文說什麼：小寶輕輕說出前瞻意願句然後閉眼。三隻熊擠在一起的溫暖畫面。
- 鉤子：視覺引導型：呼吸聲越來越遠，三個影子融在一起
- 選圖與提純說明：前瞻意願句＋閉眼。5-6「slow… slow… slow」減速＋「shadows melted」詩意；3-5 保核心；2-3 省前瞻句（style_guide F10 toddler：同框＋收束）
- 匹配欄：✓

【zh-TW】
小寶笑了。
「明天……再比一次。」

【en-US】
Cubby's eyes closed.
Three bears, all snuggled up.

### 2-3｜P08（母版 P12）

- 圖說什麼：三隻熊擠成一團，毛茸茸的身體交疊在一起分不清邊界了。月光淡淡地照著三個圓圓的輪廓，一切安安靜靜。
- 文說什麼：固定收束語加呼嚕嚕噗嚕嚕的擬聲詞做聽覺收束。
- 鉤子：—
- 選圖與提純說明：收束式。5-6 完整形＋「every single night」「little cave」；3-5 省修飾；2-3 省主語（圖示同框）。結尾四件套：①同框 P11 ②N/A ③前瞻 P11（2-3 省略） ④收束 P12
- 匹配欄：✓

【zh-TW】
後來呀……
每天晚上，呼嚕嚕，噗嚕嚕，暖暖的。

【en-US】
And from that day on…
SNOOOOOORE… pff… pff…
Warm and cozy.

