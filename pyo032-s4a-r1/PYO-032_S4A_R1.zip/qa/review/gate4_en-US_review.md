# 關卡4整合審閱：誰先睡著？（S4 證據包／en-US）

- 生成時間：2026-07-30 20:51:03 +0800
- 書目錄：`content/PYO-032_who-falls-asleep-first`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：en-US
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-032_storyboard.md` | 2026-07-30 12:23:14 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-30 16:12:37 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-30 18:23:46 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-30 16:16:01 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-30 18:16:55 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-30 16:16:17 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-30 18:11:22 |
| qa/en-US/backtranslation.md | `qa/en-US/backtranslation.md` | 2026-07-30 20:50:46 |
| qa/en-US round | `qa/en-US/round1.md` | 2026-07-30 20:44:21 |
| qa/en-US round | `qa/en-US/round2.md` | 2026-07-30 20:45:23 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | en-US 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 12 | 12 頁有文 | 12 頁有文 | 12/12 | 7 |
| 3-5 | 11 | 11 頁有文 | 11 頁有文 | 11/11 | 3 |
| 2-3 | 8 | 8 頁有文 | 8 頁有文 | 8/8 | 4 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 晚安的時間到了。／熊爸爸躺好了，突然說：「嘿！今天晚上，我們來比賽——誰先睡著，誰就輸了！」 | One cozy night, moonlight spilled into a warm bear cave.／Papa Bear sat up with a big grin.／"I know!" he said. "Let's have a contest — who falls asleep first!" | 一個溫馨的夜晚，月光灑進溫暖的熊洞裡。<br>熊爸爸坐起身，咧嘴笑了。<br>「我知道了！」他說。「我們來比賽——看誰先睡著！」 | 輕微：開場氛圍句改寫（月光灑進 vs 晚安的時間到了）＋姿態差（坐起 vs 躺好）＋省略「輸了」——「比賽」已含競爭語義 |
| P02 | P02 | 「我才不會先睡著！」熊爸爸最大聲。／「我才不會先睡著！」毛毛不服輸。／小寶學著喊：「我……我才不會先睡著！」 | Three bears lay on their soft, grassy beds.／"I'm NOT falling asleep first!" Papa Bear boomed.／"I'm NOT falling asleep first!" Fuzzy said, staring Papa down.／Cubby hugged his blue blanket.／"I'm NOT falling asleep first!" | 三隻熊躺在柔軟的草床上。<br>「我才不會先睡著！」熊爸爸大聲說。<br>「我才不會先睡著！」毛毛說，瞪著爸爸。<br>小熊抱著他的藍色毯子。<br>「我才不會先睡著！」 | 輕微：角色態度表達改編（staring down vs 不服輸）；Cubby 行為差（抱毯子 vs 學著喊結巴版） |
| P03 | P03 | 熊爸爸得意地說：「撐住不睡的秘訣，就是——閉上眼睛，什麼都不想。」／熊爸爸閉上眼睛。／山洞安安靜靜的…… | "I'll tell you my secret," Papa Bear whispered.／"Just close your eyes… and think really hard about staying awake."／He closed his eyes. His smile got bigger and bigger.／The cave went very, very quiet. | 「我告訴你們我的祕訣，」熊爸爸小聲說。<br>「只要閉上眼睛……然後拼命想著不要睡著。」<br>他閉上了眼睛。他的笑容越來越大。<br>洞裡變得好安靜、好安靜。 | 輕微：秘訣內容改編（「想著不要睡著」vs「什麼都不想」——兩者皆為反諷種子，語義功能等價）；表演方式差（whispered vs 得意地說） |
| P04 | P04 | 呼嚕嚕嚕嚕！／好大好大的呼嚕聲！／才剛說完「什麼都不想」——熊爸爸就睡著了。 | SNOOOOOORE!／Papa Bear flopped to one side, mouth wide open.／His big round belly went up… and down… and up… and down…／He'd just said, "stay awake" — and fell right asleep! | 呼——嚕嚕嚕！<br>熊爸爸往旁邊一倒，嘴巴張得大大的。<br>他圓滾滾的大肚子一起……一伏……一起……一伏……<br>他才剛說「不要睡著」——自己就睡著了！ | 輕微：身體描寫增加（肚子起伏——storyboard「呼嚕聲形容」的不同兌現方式）；回扣內容與 P03 改編一致 |
| P05 | P05 | 毛毛和小寶偷偷看了一眼，趕快摀住嘴巴。／毛毛小小聲地說：「我才不會像爸爸那樣！我才不會先睡著！」 | Fuzzy and Cubby looked at each other.／They slapped their paws over their mouths, trying SO hard not to laugh.／Fuzzy sat up straight. "Well, I'm not doing THAT," she whispered.／"I'm NOT falling asleep first!" | 毛毛和小熊互看了一眼。<br>他們用爪子摀住嘴巴，拼命忍住不笑出來。<br>毛毛坐直了身子。「哼，我才不會像那樣，」她小聲說。<br>「我才不會先睡著！」 | 無 |
| P06 | P06 | 毛毛有自己的辦法。／她仰起頭，開始數天花板上的裂紋。／「一條……兩條……三條……」／聲音越來越小，越來越慢……／「四……」 | Fuzzy tipped her chin up and started counting the cracks on the ceiling.／"One… two… three…"／She held up one little finger, her lips pressed tight together. | 毛毛抬起下巴，開始數天花板上的裂縫。<br>「一……二……三……」<br>她舉起一根小指頭，嘴唇緊緊抿著。 | 無 |
| P07 | P07 | 噗嚕嚕……／毛毛數到一半，也睡著了。／小小的噗嚕嚕，跟爸爸大大的呼嚕完全不一樣。 | "Three… f-four…"／Her voice got slower… and slower… Her mouth fell open. Her head tipped to the side.／pff… pff…／Fuzzy was fast asleep. | 「三……四、四……」<br>她的聲音越來越慢……越來越慢……嘴巴張開了。頭歪到了一邊。<br>噗呼……噗呼……<br>毛毛睡得好沉好沉。 | 輕微：zh-TW 有明確大小鼾聲對比句（「小小的噗嚕嚕，跟爸爸大大的呼嚕完全不一樣」），en-US 以擬聲詞音量差隱含傳達——表達策略不同 |
| P08 | P08 | 小寶伸出手，推了推毛毛。／沒有人回答。／山洞裡安安靜靜的，只剩下——／兩種打呼聲，一大一小，輪流響著…… | Cubby reached over and poked Fuzzy's round back.／Nothing.／The cave was so quiet now. Just SNOOOOOORE… pff… pff… SNOOOOOORE… pff… pff… back and forth in the dark. | 小熊伸手戳了戳毛毛圓圓的背。<br>沒有反應。<br>洞裡現在好安靜。只有呼——嚕嚕嚕……噗呼……噗呼……呼——嚕嚕嚕……噗呼……噗呼……在黑暗中此起彼落。 | 無 |
| P09 | P09 | 小寶看看爸爸——好大好大一坨。／再看看毛毛——蜷成小小的一顆球。／月光好柔好柔的。 | Cubby looked around.／Papa Bear was sprawled out like a big, furry mountain. Fuzzy was curled into a tiny ball.／The moonlight had gotten soft. | 小熊環顧四周。<br>熊爸爸攤開四肢，像一座毛茸茸的大山。毛毛蜷成小小一團。<br>月光變得柔柔的。 | 無 |
| P10 | P10 | 小寶靠在爸爸暖暖的大肚子上。／呼嚕嚕……噗嚕嚕……／好溫暖。大家都在。／「我才不會先……」／眼睛慢慢……慢慢…… | Cubby leaned against Papa Bear's big, warm belly. It rose and fell, slow and gentle.／SNOOOOOORE… pff… pff…／Everyone was right here.／"I'm not… falling… asleep…" | 小熊靠在熊爸爸大大的、暖暖的肚子上。肚子慢慢地、輕輕地一起一伏。<br>呼——嚕嚕嚕……噗呼……噗呼……<br>大家都在這裡。<br>「我……才……沒有……睡著……」 | 輕微：疊句變奏措辭差（「不會睡著」vs「不會先……」——功能等價的 trailing off）；呼吸描寫增筆 |
| P11 | P11 | 小寶笑了笑，輕輕地說：／「明天晚上……再比一次。」／然後，眼睛閉起來了。 | Cubby smiled. "Tomorrow night…" he whispered, "…let's do it again."／His eyes closed, slow… slow… slow.／Three bears, all piled together. Their shadows melted into one under the soft moonlight. | 小熊笑了。「明天晚上……」他小聲說，「……我們再比一次。」<br>他的眼睛慢慢……慢慢……慢慢闔上了。<br>三隻熊，全擠在一起。他們的影子在柔柔的月光下融成了一個。 | 輕微：en-US 增詩意收束（影子融合＋slow 三拍遞減）——5-6 限定加筆，語義服務同框主題 |
| P12 | P12 | 後來呀……／三隻熊每天晚上都擠在一起。／呼嚕嚕，噗嚕嚕，山洞裡暖暖的。 | And from that day on… three bears snuggled up together every single night.／SNOOOOOORE… pff… pff…／Their little cave was warm and cozy. | 從那天起……三隻熊每天晚上都窩在一起。<br>呼——嚕嚕嚕……噗呼……噗呼……<br>他們的小洞穴又溫暖又舒服。 | 無 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 晚安的時間到了。／熊爸爸說：「來比賽！誰先睡著，誰就輸了！」 | One night, moonlight spilled into a warm bear cave.／Papa Bear grinned. "Let's have a contest — who falls asleep first!" | 一天晚上，月光灑進溫暖的熊洞裡。<br>熊爸爸咧嘴笑了。「我們來比賽——看誰先睡著！」 | 輕微：同 5-6 P01（開場改寫＋省略「輸了」） |
| P02 | P02 | 「我才不會先睡著！」／「我才不會先睡著！」／「我才不會先睡著！」／大家都喊。 | "I'm NOT falling asleep first!" Papa boomed.／"I'm NOT falling asleep first!" Fuzzy said.／"I'm NOT falling asleep first!" Cubby squeaked. | 「我才不會先睡著！」爸爸大聲說。<br>「我才不會先睡著！」毛毛說。<br>「我才不會先睡著！」小熊尖聲說。 | 無 |
| P03 | P03 | 熊爸爸說：「撐住的秘訣，就是——閉上眼睛。」／山洞安安靜靜的…… | "Here's my secret," Papa whispered. "Close your eyes and think about staying awake."／He closed his eyes. The cave went quiet. | 「告訴你們我的祕訣，」爸爸小聲說。「閉上眼睛，然後想著不要睡著。」<br>他閉上了眼睛。洞裡安靜下來了。 | 輕微：秘訣內容擴充（en-US 加「想著不要睡著」，zh-TW 3-5 只說「閉上眼睛」） |
| P04 | P04 | 呼嚕嚕嚕嚕！／好大好大的呼嚕聲！／熊爸爸先睡著了。 | SNOOOOOORE!／Papa Bear flopped to one side, mouth wide open.／His big belly went up… and down… | 呼——嚕嚕嚕！<br>熊爸爸往旁邊一倒，嘴巴張得大大的。<br>他的大肚子一起……一伏…… | 無 |
| P05 | P05 | 毛毛偷偷笑：「我才不會像爸爸那樣！我才不會先睡著！」 | Fuzzy and Cubby slapped their paws over their mouths, trying not to laugh.／"I'm not doing THAT," Fuzzy whispered.／"I'm NOT falling asleep first!" | 毛毛和小熊用爪子摀住嘴巴，忍住不笑出來。<br>「我才不會像那樣，」毛毛小聲說。<br>「我才不會先睡著！」 | 無 |
| P06 | P06 | 毛毛開始數天花板上的裂紋。／「一條……兩條……三條……四……」／聲音越來越小…… | Fuzzy started counting cracks on the ceiling.／"One… two… three…"／She held up one finger, lips pressed tight. | 毛毛開始數天花板上的裂縫。<br>「一……二……三……」<br>她舉起一根指頭，嘴唇緊緊抿著。 | 無 |
| P07 | P07 | 噗嚕嚕……／毛毛也睡著了。／小小的噗嚕嚕，跟大大的呼嚕不一樣。 | "Three… f-four…"／Slower… and slower… Her mouth fell open.／pff… pff…／Fuzzy was fast asleep. | 「三……四、四……」<br>越來越慢……越來越慢……嘴巴張開了。<br>噗呼……噗呼……<br>毛毛睡得好沉好沉。 | 輕微：同 5-6 P07（en-US 減速描寫 vs zh-TW 大小對比——表達策略不同） |
| P08 | P08 | 小寶推了推毛毛——沒有人回答。／山洞裡只剩下呼嚕嚕……噗嚕嚕…… | Cubby poked Fuzzy's round back. Nothing.／So quiet. Just SNOOOOOORE… pff… pff…／Back and forth in the dark. | 小熊戳了戳毛毛圓圓的背。沒有反應。<br>好安靜。只有呼——嚕嚕嚕……噗呼……噗呼……<br>在黑暗中此起彼落。 | 無 |
| P09 | P10 | 小寶靠在爸爸暖暖的大肚子上。／「我才不會先……」／眼睛慢慢……慢慢…… | Cubby leaned against Papa Bear's warm belly.／"I'm not… falling… asleep…"／His eyes closed, slow… slow… | 「明天晚上……」小熊小聲說，「……我們再比一次。」<br>他的眼睛闔上了。三隻熊，全窩在一起。 | 無 |
| P10 | P11 | 小寶輕輕說：／「明天晚上……再比一次。」／眼睛閉起來了。 | "Tomorrow night…" Cubby whispered, "…let's do it again."／His eyes closed. Three bears, all snuggled together. | 從那天起……三隻熊每天晚上都窩在一起。<br>呼——嚕嚕嚕……噗呼……噗呼……<br>他們的洞穴好溫暖。 | 無 |
| P11 | P12 | 後來呀……／三隻熊每天晚上都擠在一起。／呼嚕嚕，噗嚕嚕，暖暖的。 | And from that day on… three bears snuggled up together every night.／SNOOOOOORE… pff… pff…／Their cave was warm. | （缺） | — |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 晚安囉！／熊爸爸說：「來比賽！誰先睡著？」 | Moonlight in the bear cave.／Papa Bear grinned.／"Who falls asleep first?" | 月光照進熊洞裡。<br>熊爸爸咧嘴笑了。<br>「看誰先睡著？」 | 輕微：開場句改寫（月光照進 vs 晚安囉） |
| P02 | P02 | 「我才不會先睡著！」／「我才不會先睡著！」／「我才不會先睡著！」 | "NOT falling asleep!" Papa Bear boomed.／"NOT falling asleep!" said Fuzzy.／"NOT falling asleep!" | 「才不會睡著！」熊爸爸大聲說。<br>「才不會睡著！」毛毛說。<br>「才不會睡著！」 | 輕微：疊句縮短（en-US 2-3 省主詞＋first——word limit 下的年齡適配改編，功能等價） |
| P03 | P04 | 呼嚕嚕嚕嚕！／爸爸睡著了！ | SNOOOOOORE!／Papa Bear tipped right over.／His belly went up… and down… | 毛毛和小熊忍住不笑出來。<br>「才不會睡著！」毛毛說。 | 無 |
| P04 | P05 | 毛毛和小寶偷偷笑。／「我才不會先睡著！」 | Fuzzy and Cubby tried not to laugh.／"NOT falling asleep!" said Fuzzy. | 毛毛倒下去了。<br>噗呼……噗呼……<br>睡著了！ | 無 |
| P05 | P07 | 噗嚕嚕……／毛毛也睡著了。 | Fuzzy tipped over.／pff… pff…／Asleep! | 小熊的眼睛闔上了。<br>三隻熊，全窩在一起。 | 輕微：en-US 省略前瞻句「明天再比一次」（style_guide F10 toddler 規則——2-3 只保同框＋收束；zh-TW 2-3 保留） |
| P06 | P10 | 呼嚕嚕……噗嚕嚕……／大家都在。暖暖的。／「我才不會先……」 | Cubby leaned on Papa's warm belly.／SNOOOOOORE… pff… pff…／"Not… falling… asleep…" | （缺） | — |
| P07 | P11 | 小寶笑了。／「明天……再比一次。」 | Cubby's eyes closed.／Three bears, all snuggled up. | （缺） | — |
| P08 | P12 | 後來呀……／每天晚上，呼嚕嚕，噗嚕嚕，暖暖的。 | And from that day on…／SNOOOOOORE… pff… pff…／Warm and cozy. | （缺） | — |

## 三、QA 摘要（qa/en-US）

- `qa/en-US/round1.md`：round 1／verdict fix_required
- `qa/en-US/round2.md`：round 2／verdict pass

最新 round：`qa/en-US/round2.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: who-falls-asleep-first
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-30"
step1_lint: {exit_code: 0, warnings: 6}
step2_checklist: {pass: 28, fail: 0}
step3_mode: consolidated
step3_personas: []
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

### ESL 獵手發現（原文引用）

（缺）最新 round 無「ESL」標題節——確認漏斗是否執行 ESL 獵手維度。

## 四、⏸️ 上呈批次

- （`qa/en-US/round1.md`）**⏸️ 上呈批次**：無。

