# Gate 4 Evidence Summary: PYO-006 ja

## QA Overview

| Field | Value |
|---|---|
| Book | PYO-006 whats-in-the-worry-pocket |
| Locale | ja |
| QA round | R1 |
| Date | 2026-07-21 |
| Mode | B (S4B locale adaptation) |
| Tiers reviewed | 2-3, 3-5, 5-6 |
| Verdict | **escalated** (2 items for Stacy) |

## Machine Check (STEP 1)

All 3 tiers pass (exit 0, 0 violations). 9 warnings total, all repeat_discount related (design-intent refrain repetition).

## Editor E (STEP 2)

- Checklist: 19/19 PASS (text-stage applicable items)
- Alignment: 0 violations across all pages x 3 tiers
- Concept fidelity: PASS all tiers
- Fun design commitments: all delivered (refrain, hooks, onomatopoeia, gravity contrast)

## Back-translation (STEP 2A)

- Coverage: S4B structural pages + triggered (28 page-translations across 3 tiers)
- Result: 0 moderate-or-above drift markers; 5 minor markers (all storyboard payload fulfillment or legitimate structural adaptation)

## Translation-Tone Hunter (STEP 2B)

12 findings (8 translation tone, 4 AI mechanical). 4 triaged as real issues (all fixed); 8 rejected with lock-in references.

## Personas (STEP 3)

| Persona | Dim 1 | Dim 2 | Dim 3 |
|---|---|---|---|
| ja-hoikushi | 年齡適配度: 8 | 音読口感: 8 | 孩子抓得住度: 9 |
| ja-hahaoya | 睡前適讀性: 8 | 零說教: 9 | — |
| ja-henshusha | 母語自然度: 7 | 文字工藝: 8 | — |

## Triage (STEP 4)

| Category | Count |
|---|---|
| ✅ Real issues (fixed) | 4 |
| ❌ Rejected (false positives) | 5 |
| ⏸️ Escalated | 2 |

### Fixes Applied (all string-level)

1. **5-6 P05**: `しぼられました` -> `ぺちゃんこ。` (unnatural passive; 3-way convergence)
2. **5-6 P07**: `バイバイを して` -> `バイバイ して` (unnatural particle; 2-way convergence)
3. **5-6/3-5 P05**: `むきなおしました` -> `むきました` (overly literary; 2-way convergence)
4. **2-3 P11**: `おしまい。` -> `おみず、おしまい。` (semantic ambiguity; 3-way convergence)

Post-fix re-lint: all 3 tiers exit 0.

### Escalated Items (for Stacy)

1. **2-3 P08 "かえってこない" assertive fear**: The 2-3 tier uses `こわい…… かえってこない。` (scared... won't come back) as a flat assertion, whereas 5-6 uses the softer `かえってこないかも……って おもっちゃった` (I accidentally thought maybe she won't come back). The 2-3 form is more direct for very young children. However, zh-TW source 2-3 uses the same blunt form. Agent recommendation: retain (consistent with source design intent), but Stacy to confirm.

2. **2-3 missing stone-weight-recovery narration**: The 5-6 and 3-5 tiers include `いしは いつもの おもさに もどりました` (the stone returned to normal weight) after each refrain cycle. The 2-3 tier completely omits this, relying on illustrations. Since Piyo is audio-self-sufficient, a listener-only 2-3 child has no auditory signal that the stone normalized. zh-TW source 2-3 also omits this line. Agent recommendation: retain (consistent with source), but Stacy may wish to add a minimal version (e.g., `かるくなった。`) across all locales' 2-3 tiers.

## File References

- QA report: `content/PYO-006_whats-in-the-worry-pocket/qa/ja/round1.md`
- Back-translation: `content/PYO-006_whats-in-the-worry-pocket/qa/ja/backtranslation.md`
- Workbench: `content/PYO-006_whats-in-the-worry-pocket/qa/ja/workbench.md`
- Draft texts: `content/PYO-006_whats-in-the-worry-pocket/text/ja/{2-3,3-5,5-6}.draft.json`
- Copy table: `content/PYO-006_whats-in-the-worry-pocket/copy/ja.md`
