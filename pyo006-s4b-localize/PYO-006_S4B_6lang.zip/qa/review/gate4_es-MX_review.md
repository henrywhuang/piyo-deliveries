# 關卡4整合審閱：擔心口袋裡有什麼？（S4 證據包／es-MX）

- 生成時間：2026-07-21 18:01:49 +0800
- 書目錄：`content/PYO-006_whats-in-the-worry-pocket`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：es-MX
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-006_storyboard.md` | 2026-07-21 17:08:45 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-21 17:08:45 |
| text/es-MX/5-6 | `text/es-MX/5-6.draft.json` | 2026-07-21 17:57:44 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-21 17:08:45 |
| text/es-MX/3-5 | `text/es-MX/3-5.draft.json` | 2026-07-21 17:57:43 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-21 17:08:45 |
| text/es-MX/2-3 | `text/es-MX/2-3.draft.json` | 2026-07-21 17:38:25 |
| qa/es-MX/backtranslation.md | `qa/es-MX/backtranslation.md` | 2026-07-21 17:54:09 |
| qa/es-MX round | `qa/es-MX/round1.md` | 2026-07-21 17:57:10 |
| qa/es-MX round | `qa/es-MX/round2.md` | 2026-07-21 18:01:41 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | es-MX 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 12 | 12 頁有文 | 12 頁有文 | 12/12 | 6 |
| 3-5 | 10 | 10 頁有文 | 10 頁有文 | 10/10 | 3 |
| 2-3 | 8 | 8 頁有文 | 8 頁有文 | 8/8 | 1 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | es-MX 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 牽牽抱著小黃鴨，準備去玩水。／媽媽慢慢鬆開手——／咚！／口袋突然多了一顆小石頭，好重好重。 | Mimí llegó a chapotear con su patito de hule. Mamá Nutria soltó despacito la mano de Mimí.／¡TUN!／Una piedra cayó en el bolsillo de Mimí y lo jaló hacia abajo. ¡Qué pesada! | 咪咪帶著她的橡皮鴨來玩水。水獺媽媽慢慢地鬆開了咪咪的手。\n咚！\n一顆石頭掉進了咪咪的口袋，把她往下拉。好重啊！ | 輕微：es-MX 加了「de hule（橡皮的）」，zh-TW 僅稱「小黃鴨」；es-MX「lo jalo hacia abajo（把她往下拉）」比 zh-TW「好重好重」更側重動態描述 |
| P02 | P02 | 媽媽蹲下來，打開手掌，安靜等著。／「等一下，我要說！」／「我怕…… 手放開。」／「再握一下，好不好？」 | Mamá Nutria se agachó, abrió las manos y esperó.／—¡Espera, te quiero decir!／Me da miedo… me da miedo soltar la mano.／¿Un abrazo más antes de decir adiós? —dijo Mimí.／Mimí se paró derechita. | 水獺媽媽蹲下來，張開雙手，等著。\n——等一下，我想跟你說！\n我害怕……我害怕放開手。\n再抱一下再說再見好嗎？——咪咪說。\n咪咪挺直了身子站好。 | 輕微：es-MX「abrazo（擁抱）」vs zh-TW「再握一下」——請求動作從握手變成擁抱；es-MX 多了「dijo Mimi」引語動詞和「se paro derechita（站直）」結尾句（zh-TW 無此行） |
| P03 | P03 | 媽媽小聲說：「小黃鴨玩完水，我就回來。」／再握一下，放開。／牽牽抱著小黃鴨，往前走了一小步。 | Mamá Nutria le dio un abrazo más. —Voy a regresar cuando tu patito termine de chapotear.／Después soltó la mano, y Mimí dio un pasito con su patito. | 水獺媽媽又抱了她一下。——等你的小鴨子玩完水我就回來。\n然後她鬆開了手，咪咪帶著她的小鴨子踏出了一小步。 | 無 |
| P04 | P04 | 媽媽往門邊走了一步。／牽牽也往前走——／咚！／口袋用力往後一甩。 | Mamá Nutria dio un paso hacia la puerta. Mimí siguió caminando.／¡TUN!／Otra piedra cayó en su bolsillo. La jaló hacia atrás, dándole la vuelta… | 水獺媽媽朝門口走了一步。咪咪繼續往前走。\n咚！\n又一顆石頭掉進了她的口袋。把她往後拉，讓她轉了過去…… | 無 |
| P05 | P05 | 嘎！小黃鴨被擠了一下。／「等一下，我要說！」／「我怕…… 看不到媽媽。」／「在門口揮揮手，好嗎？」 | ¡CUAC!／Mimí quedó volteada hacia Mamá Nutria.／—¡Espera, te quiero decir!／Me da miedo… no te voy a ver desde adentro.／¿Me dices adiós con la mano desde la puerta?／Mimí volteó hacia el salón de juegos. | 嘎！\n咪咪被轉向面對水獺媽媽。\n——等一下，我想跟你說！\n我害怕……從裡面看不到你。\n你可以在門口跟我揮手說再見嗎？\n咪咪轉向了遊戲室。 | 輕微：es-MX 多了「Mimi quedo volteada（被轉回面對）」旁白和「volteo hacia el salon de juegos（轉向遊戲室）」收尾句，zh-TW 無此兩行 |
| P06 | P06 | 媽媽在門口，輕輕揮了揮手。／牽牽走到門檻邊——裡面有人在等，還有那個水盆。 | Mamá Nutria le dijo adiós con la mano. Mimí caminó hasta la puerta.／Adentro, una señora conocida esperaba junto a la tina de agua. | 水獺媽媽向她揮手道別。咪咪走到了門口。\n裡面，一位認識的阿姨在水盆旁邊等著。 | 輕微：es-MX「senora conocida（認識的女士）」比 zh-TW「有人在等」更具體指稱照顧者 |
| P07 | P07 | 媽媽說完再見，轉身要走了。／牽牽剛抬起腳——／咚！／最重的一顆石頭掉進口袋。 | Mamá Nutria se despidió y se dio la vuelta para irse. Mimí levantó un pie hacia la puerta.／¡TUN!／La tercera piedra, la más pesada de todas, cayó en su bolsillo y la jaló derecho hacia abajo… | 水獺媽媽道了別，轉身準備離開。咪咪抬起一隻腳朝門口跨去。\n咚！\n第三顆石頭，所有石頭裡最重的，掉進了她的口袋，把她直直往下拉…… | 無 |
| P08 | P08 | 噗通！／嘎！小黃鴨彈了起來。／「等一下，我要說！」／「我怕…… 媽媽不回來。」／「玩完水，你會來嗎？」／媽媽點點頭：「會的。」 | ¡PUM!／¡CUAC!／Mimí habló primero.／—¡Espera, te quiero decir!／Me da miedo… que no regreses.／¿Vas a regresar cuando mi patito termine de chapotear?／—Sí. Voy a regresar —dijo Mamá Nutria.／El bolsillo de Mimí se levantó del tapete. | 砰！\n嘎！\n咪咪先開口了。\n——等一下，我想跟你說！\n我害怕……你不會回來了。\n等我的小鴨子玩完水你會回來嗎？\n——會的。我會回來——水獺媽媽說。\n咪咪的口袋從地墊上浮了起來。 | 輕微：es-MX「Mimi hablo primero（咪咪先開口了）」為 en-US 同源行（zh-TW 無）；es-MX 末句「bolsillo se levanto del tapete」亦為 en-US 同源（zh-TW 無） |
| P09 | P09 | 牽牽自己站了起來。／她對媽媽揮揮手，抱著小黃鴨，抬起腳—— | Mimí se levantó solita. Le dijo adiós a Mamá Nutria con la mano y abrazó a su patito.／Levantó un pie para cruzar la puerta… | 咪咪自己站了起來。她向水獺媽媽揮手道別，抱緊了她的小鴨子。\n她抬起一隻腳準備跨過門口…… | 無 |
| P10 | P10 | 牽牽跨過門檻，把小黃鴨輕輕放進水盆。／啵！／小黃鴨浮了起來。 | Mimí cruzó la puerta con las tres piedras en su bolsillo.／Bajó a su patito de hule hasta el agua.／¡PLAS!／Se quedó flotando. | 咪咪帶著口袋裡的三顆石頭跨過了門口。\n她把橡皮鴨放進水裡。\n嘩！\n小鴨子浮了起來。 | 輕微：es-MX「patito de hule（橡皮鴨）」再現（zh-TW 無 hule 修飾） |
| P11 | P11 | 小黃鴨在水盆裡玩夠了。／啪嗒，啪嗒。／門外傳來好熟悉的腳步聲。 | Se acabó la hora de chapotear. Mimí sacó a su patito mojado.／Entonces se oyeron unos pasos que Mimí conocía bien:／toc, toc, toc!／Miró hacia la puerta… y esperó… | 玩水的時間結束了。咪咪撈起了她濕漉漉的小鴨子。\n然後她聽到了她很熟悉的腳步聲：\n嗒，嗒，嗒！\n她望向門口……等著…… | 無 |
| P12 | P12 | 媽媽回來了！／「你看，小石頭還在，小黃鴨濕濕的！」／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | Mamá Nutria regresó, tal como lo prometió.／Mimí le enseñó a su patito mojado. —¡Mis piedritas siguen aquí… y tú también!／De la mano, se fueron caminando a casa.／Y desde ese día… se tomaron de la mano en cada adiós y en cada hola. | 水獺媽媽回來了，就像她答應的那樣。\n咪咪舉起她濕漉漉的小鴨子給她看。——我的小石頭還在……你也是！\n手牽手，她們走路回家了。\n從那天起……每一次再見和每一次你好，她們都牽著手。 | 無 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | es-MX 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 媽媽鬆開手——／咚！／口袋多了一顆小石頭，好重好重。 | Mimí llegó a chapotear con su patito. Mamá Nutria soltó su mano.／¡TUN!／Una piedra pesada cayó en el bolsillo de Mimí. | 咪咪帶著她的小鴨子來玩水。水獺媽媽鬆開了她的手。\n咚！\n一顆沉重的石頭掉進了咪咪的口袋。 | 無 |
| P02 | P02 | 「等一下，我要說！」／「我怕…… 手放開。」／「再握一下，好不好？」 | Mamá Nutria se agachó y esperó.／—¡Espera, te quiero decir!／Me da miedo… soltar la mano.／¿Un abrazo más antes de decir adiós?／Mimí se paró derechita. | 水獺媽媽蹲下來，等著。\n——等一下，我想跟你說！\n我害怕……放開手。\n再抱一下再說再見好嗎？\n咪咪挺直了身子站好。 | 輕微：同 5-6，abrazo vs 握手；derechita 行 zh-TW 無 |
| P03 | P04 | 媽媽說了會回來，牽牽往前走。／咚！／口袋用力往後一甩。 | Mamá Nutria le dio un abrazo más. —Voy a regresar cuando tu patito termine de chapotear. Mimí dio un paso.／¡TUN!／Otra piedra cayó en su bolsillo y la jaló hacia atrás… | （缺） | — |
| P04 | P05 | 嘎！／「等一下，我要說！」／「我怕…… 看不到媽媽。」／「揮揮手，好嗎？」 | Mamá Nutria le dio un abrazo más. —Voy a regresar cuando tu patito termine de chapotear. Mimí dio un paso.／¡TUN!／Otra piedra cayó en su bolsillo y la jaló hacia atrás… | 水獺媽媽又抱了她一下。——等你的小鴨子玩完水我就回來。咪咪踏出了一步。\n咚！\n又一顆石頭掉進了她的口袋，把她往後拉…… | 無 |
| P05 | P07 | 媽媽揮了揮手。／牽牽走到門口——／咚！／最重的石頭掉進口袋。 | ¡CUAC!／—¡Espera, te quiero decir!／Me da miedo… no te veo.／¿Me dices adiós desde la puerta?／Mimí volteó hacia el salón. | 嘎！\n——等一下，我想跟你說！\n我害怕……看不到你。\n你在門口跟我說再見好嗎？\n咪咪轉向了遊戲室。 | 無 |
| P06 | P08 | 噗通！嘎！／「等一下，我要說！」／「我怕…… 媽媽不回來。」／「玩完水，你會來嗎？」／「會的。」 | ¡PUM!／¡CUAC!／—¡Espera, te quiero decir!／Me da miedo… que no regreses.／¿Vas a regresar después de chapotear?／—Sí —dijo Mamá Nutria. | （缺） | — |
| P07 | P09 | 牽牽站起來，對媽媽揮揮手。／抱著小黃鴨，抬起腳—— | Mamá Nutria le dijo adiós con la mano y se fue despacito.／Mimí levantó un pie hacia la puerta…／¡TUN!／La tercera piedra, la más pesada, la jaló hacia abajo… | 水獺媽媽向她揮手道別。\n她道了別就走了。\n咪咪抬起一隻腳朝門口跨去……\n咚！\n第三顆石頭，最重的那顆，把她往下拉…… | 輕微：es-MX 3-5 P07 前兩行（揮手+告別走了）語義重疊 |
| P08 | P10 | 牽牽跨過門檻，把小黃鴨放進水盆。／啵！小黃鴨浮起來了。 | ¡PUM!／¡CUAC!／—¡Espera, te quiero decir!／Me da miedo… que no regreses.／¿Vas a regresar después de chapotear?／—Sí —dijo Mamá Nutria. | 砰！\n嘎！\n——等一下，我想跟你說！\n我害怕……你不會回來了。\n玩完水你會回來嗎？\n——會的——水獺媽媽說。 | 無 |
| P09 | P11 | 小黃鴨玩夠了。／啪嗒，啪嗒。／門外傳來腳步聲——好像是媽媽！ | Mimí se paró solita y dijo adiós primero. Mamá Nutria le contestó con la mano.／Mimí abrazó a su patito y levantó un pie… | 咪咪站了起來，她第一個說再見。水獺媽媽向她揮手回應。\n咪咪抱緊了她的小鴨子，抬起了一隻腳…… | 輕微：es-MX「fue la primera en decir adios」偏書面句構，zh-TW 只說「對媽媽揮揮手」 |
| P10 | P12 | 媽媽回來了！／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | Mimí cruzó la puerta con las tres piedras en su bolsillo.／Bajó a su patito hasta el agua.／¡PLAS!／Se quedó flotando. | 咪咪帶著口袋裡的三顆石頭跨過了門口。\n她把小鴨子放進水裡。\n嘩！\n小鴨子浮了起來。 | 無 |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | es-MX 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 媽媽放手了。／咚！／口袋好重好重。 | Mamá soltó la mano.／¡TUN!／Una piedra cayó en el bolsillo de Mimí.／¡Qué pesada! | 媽媽放開了手。\n咚！\n一顆石頭掉進了咪咪的口袋。\n好重啊！ | 無 |
| P02 | P02 | 「等一下，我要說！」／「怕…… 手放開。」／「再握一下。」 | —¡Espera, te quiero decir!／Me da miedo soltar la mano.／¿Un abrazo más? | ——等一下，我想跟你說！\n我害怕放開手。\n再抱一下好嗎？ | 輕微：abrazo vs 握手（同 5-6） |
| P03 | P05 | 咚！又一顆石頭。／嘎！／「等一下，我要說！」／「怕…… 看不到媽媽。」 | ¡TUN! Otra piedra.／¡CUAC!／—¡Espera, te quiero decir!／¡No te veo! | （缺） | — |
| P04 | P08 | 咚！最重的。／噗通！嘎！／「等一下，我要說！」／「怕…… 媽媽不回來。」／媽媽點點頭。 | ¡TUN!／¡PUM! ¡CUAC!／—¡Espera, te quiero decir!／¿Vas a regresar?／Mamá dijo que sí. | （缺） | — |
| P05 | P09 | 牽牽站起來了。／揮揮手——抬起腳—— | ¡TUN! Otra piedra.／¡CUAC!／—¡Espera, te quiero decir!／¡No te veo! | 咚！又一顆石頭。\n嘎！\n——等一下，我想跟你說！\n看不到你了！ | 無 |
| P06 | P10 | 跨過去了！／小黃鴨——啵！／浮起來了。 | ¡Mimí entró!／¡Tres piedras en su bolsillo!／¡PLAS!／Su patito se quedó flotando. | （缺） | — |
| P07 | P11 | 小黃鴨玩完水了。／啪嗒，啪嗒。／門外有腳步聲。 | Su patito ya chapoteó.／toc, toc, toc!／¡Pasos en la puerta! | （缺） | — |
| P08 | P12 | 媽媽回來了！／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | ¡TUN!／¡PUM! ¡CUAC!／—¡Espera, te quiero decir!／¿Vas a regresar?／Mamá dijo que sí. | 咚！\n砰！嘎！\n——等一下，我想跟你說！\n你會回來嗎？\n媽媽說會。 | 無 |

## 三、QA 摘要（qa/es-MX）

- `qa/es-MX/round1.md`：round 1／verdict fix_required
- `qa/es-MX/round2.md`：round 2／verdict escalated

最新 round：`qa/es-MX/round2.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: whats-in-the-worry-pocket
locale: es-MX
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-21"
step1_lint: {exit_code: 0, warnings: 11}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: es-MX-educadora
    scores: {年齡適配度: 7, 墨西哥語感: 8, 孩子抓得住度: 8}
  - id: es-MX-mama
    scores: {睡前適讀性: 7, 零說教: 6}
  - id: es-MX-editora
    scores: {母語自然度: 7, 文字工藝: 7}
step4_triage: {real: 0, rejected: 0, escalated: 1}
verdict: escalated
```

### ESL 獵手發現（原文引用）

（缺）最新 round 無「ESL」標題節——確認漏斗是否執行 ESL 獵手維度。

## 四、⏸️ 上呈批次

- （`qa/es-MX/round1.md`）| T9 | F1+F5 | 全檔 P12 | 收束式「Y desde ese dia...」格言感 | ⏸️ | 2 路收斂（媽媽人設 5-6+2-3 P12）。收束式「Y desde ese dia...」是 copy commitments 鎖定、style_guide F10 2-3 必備、en-US「And from that day on...」跨語同形——lock-in 明確。但 F5 指出 2-3 檔位「desde ese dia」對兩歲語境偏重。裁決傾向保留（lock-in），上呈 2-3 收束式措辭微調是否屬 piyo-localize 權限。 | — | 2 路 |
- （`qa/es-MX/round1.md`）### ⏸️ 上呈批次
- （`qa/es-MX/round2.md`）本輪新增 ✅ = 0、❌ = 0。R1 ⏸️ T9（2-3 P12 收束式）carry-over 上呈（escalated = 1）。
- （`qa/es-MX/round2.md`）文本品質收斂、三筆回修落地驗證通過。verdict 為 `escalated`，原因：R1 T9 ⏸️ 未裁決（2-3 P12 收束式措辭是否微調屬跨語決策層，需 Stacy / piyo-localize 裁量）。保留此 escalated verdict；gate4 證據包供 Stacy 選閱。

