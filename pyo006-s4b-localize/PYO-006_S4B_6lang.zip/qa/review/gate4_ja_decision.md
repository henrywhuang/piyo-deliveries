decision: Green Light
date: 2026-07-21
preserved AI verdict: escalated
accepted scope: 2-3 P08 断定形「かえってこない」保留（設計核心＝直述擔心）；2-3 石頭恢復敘事省略保留（2-3 合法簡化，用身體動作替代）
constraints: 不修改文案；兩項設計層問題記錄為已知 tradeoff，不回寫 text
