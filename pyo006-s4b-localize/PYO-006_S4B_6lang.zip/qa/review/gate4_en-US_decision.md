# Gate 4 Decision — PYO-006 What's in the Worry Pocket? (en-US)

- decision: Green Light
- date: 2026-07-21
- reviewer: Stacy Wang
- preserved AI verdict: escalated
- accepted scope: PYO-006 en-US Mode B 三檔文本（5-6／3-5／2-3）與 SHA-256 `52cf1d116a4c7dc4f5d345fd54927dde8f0b8d40ffccf289f67afcab0ef115e2` 的 Gate 4 證據包；接受 Human S4 R4 指令回修與獨立 R5 五維度 PASS 後現稿、display title `What's in the Worry Pocket?`、角色名 `Cuddles`／`Mama Otter`、五組 en-US SFX，以及現有 target-band advisory set。
- constraints: 歷史 Round 1–3、`verdict: escalated`、triage、偏移標記與上呈理由原樣保留；Green Light 是人工授權，不追溯改寫 AI QA。五組 SFX 依 locale registry 規則只升為已核准提案，須完成 TTS round-trip 才能升定案；不改 frozen design、storyboard、zh-TW 定稿、slug、selection 或 shared locale thresholds。

## Human authorization

- Stacy 於 2026-07-21 明確指示「S4 Greenlight：《擔心口袋裡有什麼？》安排後續所有動作」，授權本次 Gate 4 收尾與 S4B handoff。
- R3 的歷史 Greenlight 已被 R4 明文推翻；本次授權採用由未參與 R4 回修的獨立 reviewer 產出的 R5 PASS，不恢復 R3 的現行效力，也不另造 AI QA round4。
- 接受現有 display title、R4 指定的朗讀語域與指涉修正、三檔 fixed refrain／ending、2-3 tier 的既定提純，以及 Gate 4 證據包中的 current advisory set。
- `What's in the Worry Pocket?`、`Cuddles` 與 `Mama Otter` 升為 en-US 定案；`THUNK!`、`SQUEAK!`、`PLOP!`、`SPLISH!`、`tap, tap, tap!` 為已核准且同書鎖定的 SFX 提案，待 TTS round-trip 後再決定 registry 定案。

## Freeze boundary

- 凍結三檔頁數與 frozen storyboard selection：5-6＝12 頁、3-5＝10 頁、2-3＝8 頁。
- 三檔 `.draft.json` 轉為同名 `.json` 定稿；舊 draft 檔名必須不存在。
- copy 只更新 Green Light／registry 簿記；逐頁文本、backtranslation、歷史 QA rounds、Human S4 review 與 Gate 4 審包不因 decision 被重寫。
- 本次只完成 S4A 收尾與 `Stage = S4B 多語放量` handoff；不啟動 piyo-localize 泳道、TTS、S5 或其他下游工作。
