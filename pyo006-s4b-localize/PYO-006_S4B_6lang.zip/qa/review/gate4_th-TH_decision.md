decision: Green Light
date: 2026-07-21
preserved AI verdict: escalated
accepted scope: P04 5-6/3-5「ดึงตัวกลับไปข้างหลัง」保留（ดึงตัวกลับ 在泰語有用例 attested，triage 傾向保留）
constraints: 不修改文案；Chinese calque 疑義記錄為已知 tradeoff
