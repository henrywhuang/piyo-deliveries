# 關卡4整合審閱：擔心口袋裡有什麼？（S4 證據包／en-US）

- 生成時間：2026-07-21 11:47:24 +0800
- 書目錄：`content/PYO-006_whats-in-the-worry-pocket`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：en-US
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審
- 證據狀態：決定性三欄對照已同步至 Human S4 R4 回修後 raw JSON；R4 明文推翻 R3，最新獨立 formal R5 判定為 `copywriting review passed; awaiting Stacy Gate 4 Green Light`。歷史 text-QA Round 1–3 的 `verdict: escalated` 原樣保留。

## 來源檔案

| 來源 | 檔案 | mtime／狀態 |
|---|---|---|
| storyboard.md | `PYO-006_storyboard.md` | 2026-07-21 11:16:50 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-21 11:16:50 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-21 11:24:51 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-21 11:16:50 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-21 11:22:16 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-21 11:16:50 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-21 11:22:16 |
| qa/en-US/backtranslation.md | `qa/en-US/backtranslation.md` | 2026-07-21 11:30:36 |
| qa/en-US round | `qa/en-US/round1.md` | 2026-07-21 11:16:50 |
| qa/en-US round | `qa/en-US/round2.md` | 2026-07-21 11:16:50 |
| qa/en-US round | `qa/en-US/round3.md` | 2026-07-21 11:16:50 |
| Human S4 R1 revision evidence | `qa/en-US/revision_R1.md` | 正式 R1 退回後的 normalized 落地證據 |
| Human S4 R2 | `qa/review/whats-in-the-worry-pocket_s4_review_R2_revisions.md` | 不通過；三個 2-3 blocker |
| Human S4 R2 revision evidence | `qa/en-US/revision_R2.md` | R2 blocker 回修證據 |
| Human S4 R3 | `qa/review/whats-in-the-worry-pocket_s4_review_R3_greenlight.md` | 歷史 Greenlight；已被 R4 明文推翻，不具 current 放行效力 |
| Human S4 R4 | `qa/review/whats-in-the-worry-pocket_s4_review_R4_revisions.md` | 不通過；本包 current 回修指令來源 |
| Human S4 R4 revision evidence | `qa/en-US/revision_R4.md` | writer 回修與 W0–W9；不是正式 verdict |
| Human S4 R5 | `qa/review/whats-in-the-worry-pocket_s4_review_R5_greenlight.md` | 全新獨立 reviewer；60/60 raw pages PASS |
| character registry | `knowledge_base/locale_specs/character_names.md` | PYO-006 書名／角色雙語 proposal 逐字核對 |
| SFX registry | `knowledge_base/locale_specs/onomatopoeia_map.md` | PYO-006 五組雙語 proposal 逐字核對 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | en-US 改編 | 回譯覆蓋 | 修訂前 R3 偏移數（歷史） |
|---|---|---|---|---|---|
| 5-6 | 12 | 12 頁有文 | 12 頁有文 | 12/12 | 0 |
| 3-5 | 10 | 10 頁有文 | 10 頁有文 | 10/10 | 0 |
| 2-3 | 8 | 8 頁有文 | 8 頁有文 | 8/8 | 8 |

上述 8 筆只保存修訂前 text-QA R3 的歷史標記，不能拿來覆蓋 current R5 verdict；current raw 的兩語一致性與純聽覺可理解性以獨立 R5 60/60 全掃為準。

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 修訂前偏移標記（歷史） |
|---|---|---|---|---|---|
| P01 | P01 | 牽牽抱著小黃鴨，準備去玩水。／媽媽慢慢鬆開手——／咚！／口袋突然多了一顆小石頭，好重好重。 | Cuddles came to splash with her toy duck. Mama Otter slowly let go of Cuddles's hand.／THUNK!／A stone dropped into Cuddles's pocket—down it sagged. So heavy! | Cuddles 帶著她的玩具鴨來玩水。水獺媽媽慢慢放開 Cuddles 的手。<br>咚！<br>一顆石頭掉進 Cuddles 的口袋——口袋向下垂。好重！ | 無 |
| P02 | P02 | 媽媽蹲下來，打開手掌，安靜等著。／「等一下，我要說！」／「我怕…… 手放開。」／「再握一下，好不好？」 | Mama Otter knelt, opened her hands, and waited.／"Wait—I need to tell you!／I'm scared… scared to let go.／One more squeeze before goodbye?" Cuddles said.／Cuddles stood tall. | 水獺媽媽跪下來，張開雙手，等著。<br>「等等——我需要告訴你！<br>我害怕……害怕放手。<br>說再見前，可以再抱緊一下嗎？」Cuddles 說。<br>Cuddles 直挺挺地站著。 | 無 |
| P03 | P03 | 媽媽小聲說：「小黃鴨玩完水，我就回來。」／再握一下，放開。／牽牽抱著小黃鴨，往前走了一小步。 | Mama Otter gave Cuddles one more squeeze. "I'll be back when your duck is done splashing."／Then Mama Otter let go, and Cuddles took one small step with her duck. | 水獺媽媽又抱緊 Cuddles 一次。「你的小鴨玩完水時，我就會回來。」<br>接著，水獺媽媽放開手，Cuddles 帶著她的小鴨往前跨了一小步。 | 無 |
| P04 | P04 | 媽媽往門邊走了一步。／牽牽也往前走——／咚！／口袋用力往後一甩。 | Mama Otter took a step toward the doorway. Cuddles kept going.／THUNK!／A second stone dropped into her pocket. It pulled her backward, turning her around— | 水獺媽媽朝門口跨了一步。Cuddles 繼續往前走。<br>咚！<br>第二顆石頭掉進她的口袋。它把她往後拉，讓她轉過身—— | 無 |
| P05 | P05 | 嘎！小黃鴨被擠了一下。／「等一下，我要說！」／「我怕…… 看不到媽媽。」／「在門口揮揮手，好嗎？」 | SQUEAK!／Cuddles turned all the way back.／"Wait—I need to tell you!／I'm scared… I can't see you from in there.／Will you wave from the doorway?"／Cuddles turned toward the playroom. | 吱！<br>Cuddles 完全轉了回去。<br>「等等——我需要告訴你！<br>我害怕……我從裡面看不到你。<br>你會在門口向我揮手嗎？」<br>Cuddles 轉向遊戲室。 | 無 |
| P06 | P06 | 媽媽在門口，輕輕揮了揮手。／牽牽走到門檻邊——裡面有人在等，還有那個水盆。 | Mama Otter gave one small wave. Cuddles walked to the doorway.／A familiar grown-up waited inside by the little tub of water. | 水獺媽媽輕輕揮了一下手。Cuddles 走到門口。<br>一位熟悉的大人在裡面的小水盆旁等著。 | 無 |
| P07 | P07 | 媽媽說完再見，轉身要走了。／牽牽剛抬起腳——／咚！／最重的一顆石頭掉進口袋。 | Mama Otter said goodbye and turned to go. Cuddles lifted one foot toward the doorway.／THUNK!／The third—and heaviest—stone dropped into her pocket and pulled her straight down— | 水獺媽媽說了再見，轉身準備離開。Cuddles 朝門口抬起一隻腳。<br>咚！<br>第三顆——也是最重的一顆——石頭掉進她的口袋，把她直直往下拉—— | 無 |
| P08 | P08 | 噗通！／嘎！小黃鴨彈了起來。／「等一下，我要說！」／「我怕…… 媽媽不回來。」／「玩完水，你會來嗎？」／媽媽點點頭：「會的。」 | PLOP!／SQUEAK!／Cuddles spoke first.／"Wait—I need to tell you!／I'm scared… you won't come back.／Will you come back when my duck is done splashing?"／"Yes. I'll come back," Mama Otter said.／Cuddles's pocket lifted off the mat. | 撲通！<br>吱！<br>Cuddles 先開了口。<br>「等等——我需要告訴你！<br>我害怕……你不會回來。<br>我的小鴨玩完水時，你會回來嗎？」<br>「會。我會回來。」水獺媽媽說。<br>Cuddles 的口袋從墊子上抬了起來。 | 無 |
| P09 | P09 | 牽牽自己站了起來。／她對媽媽揮揮手，抱著小黃鴨，抬起腳—— | Cuddles stood up all by herself. She gave Mama Otter one small wave, then hugged her toy duck close.／She lifted one foot over the threshold— | Cuddles 完全靠自己站了起來。她向水獺媽媽輕輕揮了一下手，接著把玩具鴨緊緊抱住。<br>她抬起一隻腳跨過門檻—— | 無 |
| P10 | P10 | 牽牽跨過門檻，把小黃鴨輕輕放進水盆。／啵！／小黃鴨浮了起來。 | Cuddles stepped through the doorway with all three stones in her pocket.／She lowered her toy duck into the water.／SPLISH!／It floated. | Cuddles 口袋裡裝著三顆石頭，跨過門口走了進去。<br>她把玩具鴨放進水裡。<br>嘩啦！<br>它浮了起來。 | 無 |
| P11 | P11 | 小黃鴨在水盆裡玩夠了。／啪嗒，啪嗒。／門外傳來好熟悉的腳步聲。 | Splash time was over. Cuddles lifted her wet toy duck.／Then came footsteps Cuddles knew—／tap, tap, tap!／She looked toward the doorway—and waited— | 玩水時間結束了。Cuddles 拿起濕答答的玩具鴨。<br>接著，Cuddles 熟悉的腳步聲傳來——<br>踏、踏、踏！<br>她看向門口——等著—— | 無 |
| P12 | P12 | 媽媽回來了！／「你看，小石頭還在，小黃鴨濕濕的！」／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | Mama Otter came back, just as promised.／Cuddles held up her wet toy duck. "My little stones are still here—and so are you!"／Hand in hand, they headed home.／And from that day on… they held hands at every goodbye and hello. | 水獺媽媽回來了，就像她答應的那樣。<br>Cuddles 舉起濕答答的玩具鴨。「我的小石頭還在——你也還在！」<br>她們手牽著手回家。<br>從那天起……每次說再見和打招呼時，她們都會牽著手。 | 無 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 修訂前偏移標記（歷史） |
|---|---|---|---|---|---|
| P01 | P01 | 媽媽鬆開手——／咚！／口袋多了一顆小石頭，好重好重。 | Cuddles came to splash with her toy duck. Mama Otter let go of her hand.／THUNK!／A heavy stone dropped into Cuddles's pocket. | Cuddles 帶著她的玩具鴨來玩水。水獺媽媽放開了她的手。<br>咚！<br>一顆沉重的石頭掉進 Cuddles 的口袋。 | 無 |
| P02 | P02 | 「等一下，我要說！」／「我怕…… 手放開。」／「再握一下，好不好？」 | Mama Otter knelt and waited.／"Wait—I need to tell you!／I'm scared… scared to let go.／One more squeeze before goodbye?"／Cuddles stood tall. | 水獺媽媽跪下來，等著。<br>「等等——我需要告訴你！<br>我害怕……害怕放手。<br>說再見前，可以再抱緊一下嗎？」<br>Cuddles 直挺挺地站著。 | 無 |
| P03 | P04 | 媽媽說了會回來，牽牽往前走。／咚！／口袋用力往後一甩。 | Mama Otter gave one more squeeze. "I'll be back when your duck is done splashing." Cuddles stepped forward.／THUNK!／A second stone dropped into her pocket and pulled her backward— | 水獺媽媽又抱緊她一次。「你的小鴨玩完水時，我就會回來。」Cuddles 往前跨了一步。<br>咚！<br>第二顆石頭掉進她的口袋，把她往後拉—— | 無 |
| P04 | P05 | 嘎！／「等一下，我要說！」／「我怕…… 看不到媽媽。」／「揮揮手，好嗎？」 | SQUEAK!／"Wait—I need to tell you!／I'm scared… I can't see you.／Will you wave from the doorway?"／Cuddles turned toward the playroom. | 吱！<br>「等等——我需要告訴你！<br>我害怕……我看不到你。<br>你會在門口向我揮手嗎？」<br>Cuddles 轉向遊戲室。 | 無 |
| P05 | P07 | 媽媽揮了揮手。／牽牽走到門口——／咚！／最重的石頭掉進口袋。 | Mama Otter waved.／She said goodbye and stepped away.／Cuddles lifted one foot toward the doorway—／THUNK!／The third—and heaviest—stone pulled her down— | 水獺媽媽揮了揮手。<br>她說了再見，往外走開。<br>Cuddles 朝門口抬起一隻腳——<br>咚！<br>第三顆——也是最重的一顆——石頭把她往下拉—— | 無 |
| P06 | P08 | 噗通！嘎！／「等一下，我要說！」／「我怕…… 媽媽不回來。」／「玩完水，你會來嗎？」／「會的。」 | PLOP!／SQUEAK!／"Wait—I need to tell you!／I'm scared… you won't come back.／Will you come back after splashing?"／"Yes," Mama Otter said. | 撲通！<br>吱！<br>「等等——我需要告訴你！<br>我害怕……你不會回來。<br>玩完水後，你會回來嗎？」<br>「會。」水獺媽媽說。 | 無 |
| P07 | P09 | 牽牽站起來，對媽媽揮揮手。／抱著小黃鴨，抬起腳—— | Cuddles stood and waved first. Mama Otter waved back.／Cuddles hugged her toy duck and lifted one foot— | Cuddles 站起來，先揮了揮手。水獺媽媽也向她揮手。<br>Cuddles 抱住玩具鴨，抬起一隻腳—— | 無 |
| P08 | P10 | 牽牽跨過門檻，把小黃鴨放進水盆。／啵！小黃鴨浮起來了。 | Cuddles stepped through the doorway with all three stones in her pocket.／She lowered her toy duck into the water.／SPLISH!／It floated. | Cuddles 口袋裡裝著三顆石頭，跨過門口走了進去。<br>她把玩具鴨放進水裡。<br>嘩啦！<br>它浮了起來。 | 無 |
| P09 | P11 | 小黃鴨玩夠了。／啪嗒，啪嗒。／門外傳來腳步聲——好像是媽媽！ | Splash time was over. Cuddles lifted her wet toy duck.／Then came footsteps Cuddles knew—／tap, tap, tap!／She looked toward the doorway—and waited— | 玩水時間結束了。Cuddles 拿起濕答答的玩具鴨。<br>接著，Cuddles 熟悉的腳步聲傳來——<br>踏、踏、踏！<br>她看向門口——等著—— | 無 |
| P10 | P12 | 媽媽回來了！／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | Mama Otter came back.／"You came back!"／Hand in hand, they headed home.／And from that day on… they held hands at every goodbye and hello. | 水獺媽媽回來了。<br>「你回來了！」<br>她們手牽著手回家。<br>從那天起……每次說再見和打招呼時，她們都會牽著手。 | 無 |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 修訂前偏移標記（歷史） |
|---|---|---|---|---|---|
| P01 | P01 | 媽媽放手了。／咚！／口袋好重好重。 | Mama let go.／THUNK!／A stone fell into Cuddles's pocket.／So heavy! | 媽媽放開手。<br>咚！<br>一顆石頭掉進 Cuddles 的口袋。<br>好重！ | 輕微：口袋所有者指涉含糊，聽覺上可能暫時誤連到媽媽 |
| P02 | P02 | 「等一下，我要說！」／「怕…… 手放開。」／「再握一下。」 | "Wait—I need to tell you!／I'm scared to let go.／One more squeeze?" | 「等一下——我得告訴你！<br>我害怕放手。<br>再抱緊一下？」 | 中度：第一石結果弱化為「變輕」而非恢復普通重量，且提前跨步 |
| P03 | P05 | 咚！又一顆石頭。／嘎！／「等一下，我要說！」／「怕…… 看不到媽媽。」 | THUNK!／"Wait—I need to tell you!／I can't see you!／Wave, Mama?" | 咚！<br>「等等——我需要告訴你！<br>我看不到你！<br>媽媽，揮揮手？」 | 中度：未明示第二顆石、媽媽回應與第二石恢復普通重量 |
| P04 | P08 | 咚！最重的。／噗通！嘎！／「等一下，我要說！」／「怕…… 媽媽不回來。」／媽媽點點頭。 | THUNK!／"Wait—I need to tell you!／I'm scared… will you come back?"／Mama nodded. | 咚！<br>「等一下——我得告訴你！<br>我很害怕……你會回來嗎？」<br>媽媽點了點頭。 | 中度：第三個具體擔心壓縮成含糊的「回來？」，媽媽回應移至下頁 |
| P05 | P09 | 牽牽站起來了。／揮揮手——抬起腳—— | Cuddles stood up.／She waved.／She lifted one foot— | Cuddles 站了起來。<br>她揮了揮手。<br>她抬起一隻腳—— | 中度：只寫拉力變小，未交付第三石恢復普通重量；承接前頁回應 |
| P06 | P10 | 跨過去了！／小黃鴨——啵！／浮起來了。 | In she went!／Three stones in her pocket!／SPLISH!／Her toy duck floated. | 她走進去了！<br>口袋裡有三顆石頭！<br>嘩啦！<br>她的玩具鴨浮了起來。 | 輕微：未先建立玩具鴨，聽覺上可能被理解為活鴨 |
| P07 | P11 | 小黃鴨玩完水了。／啪嗒，啪嗒。／門外有腳步聲。 | Footsteps at the door!／tap, tap, tap!／Cuddles waited— | 門口傳來腳步聲！<br>踏、踏、踏！<br>Cuddles 等著—— | 輕微：熟悉腳步聲的門外位置線索被省略 |
| P08 | P12 | 媽媽回來了！／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | Mama came back!／And from that day on… they held hands. | 媽媽回來了！<br>從那天起……她們都會牽著手。 | 中度：省略媽媽如約回來與重逢展示，只剩收束式 |

## 三、Human S4 正式輪次現況

| 正式輪次 | 判定 | 現況證據 |
|---|---|---|
| R1 | 不通過 | Stacy 正式修改指令；normalized 落地證據見 `qa/en-US/revision_R1.md`。 |
| R2 | 不通過 | `whats-in-the-worry-pocket_s4_review_R2_revisions.md` 新增 2-3 P02／P04／P05 blockers。 |
| R3 | 歷史 Greenlight，**已被 R4 推翻** | 報告留存作歷史；依 v0.10 回修／判定分權規則，不具 current 放行效力。 |
| R4 | 不通過 | 朗讀語域與指涉退回；11 個明文修改點均已在 current raw 落地。 |
| R5 | **PASS** | 全新獨立 `gpt-5.6-sol` reviewer 未參與回修；六份 raw JSON 60/60 全掃、R4 11/11、五維度全通過。 |

- Current deterministic checks：en-US `copy_check.py` exit 0，0 violations／5 target-band warnings；三檔 `locale_lint.py` 3/3 exit 0，0 violations／11 repeat-discount warnings；六份 raw JSON parse 6/6；registry check exit 0；三份歷史 text-QA report 均通過 `qa_report_check.py`。
- Current backtranslation：5-6 12/12、3-5 10/10、2-3 8/8，共 30/30；R4 變更頁均由獨立 blind back-translator 同步。
- Current registry：`Cuddles`／`Mama Otter` 與 `THUNK!`／`SQUEAK!`／`PLOP!`／`SPLISH!`／`tap, tap, tap!` 均與 proposal 逐字一致；仍保持 proposal，不升定案。
- Gate 邊界：R5 editorial PASS 不等於 Stacy Gate 4 Green Light；本包仍保持 `.draft.json`、不建立 decision、不改 `book.yaml`／Stage、不啟動 S4B／TTS。

## 四、歷史 text-QA 摘要（qa/en-US）

- `qa/en-US/round1.md`：round 1／verdict escalated
- `qa/en-US/round2.md`：round 2／verdict escalated
- `qa/en-US/round3.md`：round 3／verdict escalated

最新 round：`qa/en-US/round3.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: whats-in-the-worry-pocket
locale: en-US
tiers: ["5-6", "3-5", "2-3"]
round: 3
date: "2026-07-20"
step1_lint: {exit_code: 0, warnings: 20}
step2_checklist: {pass: 23, fail: 2}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 4, 朗讀口感: 4, 孩子抓得住度: 4}
  - id: en-US-parent
    scores: {睡前適讀性: 4, 零說教: 8}
  - id: en-US-editor
    scores: {母語自然度: 4, 文字工藝: 4}
step4_triage: {real: 32, rejected: 13, escalated: 11}
verdict: escalated
escalation_summary: "Three-round ceiling reached. Unresolved: 2-3 P03 engine/cap conflict, 2-3 P08 return/closing/cap conflict, brand-prefix versus one-time closing timeline, and dialogue-ratio authority conflict; remaining true findings are not passed."
```

### ESL 獵手發現（原文引用）

### ESL 獵手

Fresh hunter 全掃 30/30；無 en-GB、美式拼寫、標點、文化紅線或 SFX registry 形式問題。

| ID | finding |
|---|---|
| ESL3-01 | 高檔 P01 `pocket sagged under its weight` pronoun ambiguity |
| ESL3-02 | 2-3 P01 `pulled pocket way over` collocation 不自然 |
| ESL3-03 | 高檔六次 `weight felt normal` 抽象／機械 |
| ESL3-04 | 三檔高潮 `crossed` 缺 threshold 受詞或方向 |
| ESL3-05 | 結束 splashing 語塊偏生硬（品味級） |
| ESL3-06 | familiar footsteps 語序偏書面；2-3 缺名詞錨 |
| ESL3-07 | 2-3 `Back?`／`After splashing` 不清楚 |
| ESL3-08 | exact prefix 與永久 handholding／單次回家時間軸張力 |

B1 結構分歧仍具中等文本可信度；只說明現稿不是逐句鏡像，不作存取證明。Registry proposals 位於同一 worktree 且待本次交付，不構成缺失。

## 五、歷史 text-QA ⏸️ 上呈批次

- （`qa/en-US/round3.md`）### ⏸️ 最終上呈批次
- （`qa/en-US/round3.md`）- ⏸️ 2-3 P03：兩個 SFX＋exact 7-word refrain＋具體看不見擔心／揮手需求已占滿 14 words，無空間加入第二石、Mama response 與 ordinary-result。
- （`qa/en-US/round3.md`）- ⏸️ 2-3 P08：缺 Mama 如約回來；14-word cap、exact brand prefix 與 frozen 牽手／帶鴨回家收束負載互相衝突。
- （`qa/en-US/round3.md`）- ⏸️ Brand ending：`And from that day on…` 的永久時間軸與 frozen 單次重逢後牽手回家語義存在未裁定張力。
- （`qa/en-US/round3.md`）- ⏸️ 高檔對話比例：quality criterion 與 frozen storyboard／style guide「旁白搭台、對話收拍」contract 衝突。
- （`qa/en-US/round3.md`）- ⏸️ 其餘 32 個真問題仍未通過；三輪上限已滿，不建立 Round 4。
