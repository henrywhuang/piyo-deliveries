# 關卡4整合審閱：擔心口袋裡有什麼？（S4 證據包／vi-VN）

- 生成時間：2026-07-21 17:53:48 +0800
- 書目錄：`content/PYO-006_whats-in-the-worry-pocket`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：vi-VN
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-006_storyboard.md` | 2026-07-21 17:08:45 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-21 17:08:45 |
| text/vi-VN/5-6 | `text/vi-VN/5-6.draft.json` | 2026-07-21 17:47:45 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-21 17:08:45 |
| text/vi-VN/3-5 | `text/vi-VN/3-5.draft.json` | 2026-07-21 17:40:22 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-21 17:08:45 |
| text/vi-VN/2-3 | `text/vi-VN/2-3.draft.json` | 2026-07-21 17:40:22 |
| qa/vi-VN/backtranslation.md | `qa/vi-VN/backtranslation.md` | 2026-07-21 17:49:00 |
| qa/vi-VN round | `qa/vi-VN/round1.md` | 2026-07-21 17:52:55 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | vi-VN 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 12 | 12 頁有文 | 12 頁有文 | 12/12 | 2 |
| 3-5 | 10 | 10 頁有文 | 10 頁有文 | 10/10 | 2 |
| 2-3 | 8 | 8 頁有文 | 8 頁有文 | 8/8 | 0 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | vi-VN 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 牽牽抱著小黃鴨，準備去玩水。／媽媽慢慢鬆開手——／咚！／口袋突然多了一顆小石頭，好重好重。 | Bống ôm vịt con, chuẩn bị đi chơi nước.／Mẹ từ từ buông tay ra —／Bịch!／Túi áo bỗng nặng trĩu. Nặng quá, nặng quá! | 小圓抱著小鴨，準備去玩水。\n媽媽慢慢鬆開手——\n咚！\n口袋突然變得好沉。好重好重！ | 無 |
| P02 | P02 | 媽媽蹲下來，打開手掌，安靜等著。／「等一下，我要說！」／「我怕…… 手放開。」／「再握一下，好不好？」 | Mẹ Rái ngồi xuống, xòe hai bàn tay ra, lặng lặng chờ.／"Khoan đã — con muốn nói!"／"Con sợ… buông tay ra."／"Nắm thêm một cái nhé?" | 水獺媽媽坐下來，攤開兩隻手，靜靜地等。\n「等一下——我想說！」\n「我害怕……鬆開手。」\n「再握一下好嗎？」 | 無 |
| P03 | P03 | 媽媽小聲說：「小黃鴨玩完水，我就回來。」／再握一下，放開。／牽牽抱著小黃鴨，往前走了一小步。 | Mẹ nói khẽ: "Khi vịt con chơi nước xong, mẹ sẽ về."／Nắm thêm một cái, rồi buông.／Bống ôm vịt con, bước một bước nhỏ về phía trước. | （非結構頁，免譯） | — |
| P04 | P04 | 媽媽往門邊走了一步。／牽牽也往前走——／咚！／口袋用力往後一甩。 | Mẹ bước một bước về phía cửa.／Bống cũng bước tới —／Bịch!／Túi áo giật mạnh về phía sau. | 媽媽往門口走了一步。\n小圓也跟著走——\n咚！\n口袋用力往後拉。 | 無 |
| P05 | P05 | 嘎！小黃鴨被擠了一下。／「等一下，我要說！」／「我怕…… 看不到媽媽。」／「在門口揮揮手，好嗎？」 | Kẹt! Vịt con bị bóp một cái.／"Khoan đã — con muốn nói!"／"Con sợ… không nhìn thấy mẹ."／"Mẹ vẫy tay ở cửa nhé?" | 卡住了！小鴨被擠了一下。\n「等一下——我想說！」\n「我害怕……看不到媽媽。」\n「媽媽在門口揮揮手好嗎？」 | 無 |
| P06 | P06 | 媽媽在門口，輕輕揮了揮手。／牽牽走到門檻邊——裡面有人在等，還有那個水盆。 | Mẹ đứng ở cửa, nhẹ nhàng vẫy tay.／Bống bước đến bậc cửa — bên trong có người chờ, và cả cái chậu nước nữa. | （非結構頁，免譯） | — |
| P07 | P07 | 媽媽說完再見，轉身要走了。／牽牽剛抬起腳——／咚！／最重的一顆石頭掉進口袋。 | Mẹ nói lời tạm biệt, quay người bước đi.／Bống vừa nhấc chân lên —／Bịch!／Viên sỏi nặng nhất rơi xuống túi áo. | 媽媽說了再見，轉身走了。\n小圓剛抬起腳——\n咚！\n最重的石頭掉進了口袋。 | 輕微：vi 用「viên sỏi」（小石子/鵝卵石），zh-TW 母本用「石頭」——語義等值，vi 用法更符合設計（普通小石）的質感 |
| P08 | P08 | 噗通！／嘎！小黃鴨彈了起來。／「等一下，我要說！」／「我怕…… 媽媽不回來。」／「玩完水，你會來嗎？」／媽媽點點頭：「會的。」 | Bộp!／Kẹt! Vịt con bật lên.／"Khoan đã — con muốn nói!"／"Con sợ… mẹ không về nữa."／"Chơi nước xong, mẹ có về không?"／Mẹ gật đầu: "Có, mẹ sẽ về." | 啪！\n卡住了！小鴨彈起來了。\n「等一下——我想說！」\n「我害怕……媽媽不回來了。」\n「玩完水，媽媽會回來嗎？」\n媽媽點頭：「會，媽媽會回來。」 | 無 |
| P09 | P09 | 牽牽自己站了起來。／她對媽媽揮揮手，抱著小黃鴨，抬起腳—— | Bống tự đứng dậy.／Bống vẫy tay chào mẹ, ôm vịt con, nhấc chân lên — | 小圓自己站了起來。\n小圓跟媽媽揮手再見，抱著小鴨，抬起腳—— | 無 |
| P10 | P10 | 牽牽跨過門檻，把小黃鴨輕輕放進水盆。／啵！／小黃鴨浮了起來。 | Bống bước qua bậc cửa, nhẹ nhàng đặt vịt con vào chậu nước.／Tõm!／Vịt con nổi lên. | 小圓跨過門檻，輕輕把小鴨放進水盆。\n撲通！\n小鴨浮起來了。 | 無 |
| P11 | P11 | 小黃鴨在水盆裡玩夠了。／啪嗒，啪嗒。／門外傳來好熟悉的腳步聲。 | Vịt con chơi nước xong rồi.／lộp bộp, lộp bộp.／Ngoài cửa vọng lại tiếng bước chân quen thuộc. | 小鴨玩完水了。\n啪嗒、啪嗒。\n門外傳來熟悉的腳步聲。 | 無 |
| P12 | P12 | 媽媽回來了！／「你看，小石頭還在，小黃鴨濕濕的！」／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | Mẹ về rồi!／"Mẹ nhìn này, mấy viên sỏi vẫn còn đây, vịt con ướt hết rồi!"／Từ ngày đó… Bống nắm tay mẹ, còn vịt con cũng theo về nhà rồi. | 媽媽回來了！\n「媽媽你看，那些小石頭還在這裡，小鴨全身都濕了！」\n從那天起……小圓牽著媽媽的手，小鴨也跟著回家了。 | 無（已修正 nè→này） |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | vi-VN 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 媽媽鬆開手——／咚！／口袋多了一顆小石頭，好重好重。 | Mẹ buông tay ra —／Bịch!／Túi áo thêm một viên sỏi, nặng quá, nặng quá! | 媽媽鬆開手——\n咚！\n口袋又多了一顆石頭，好重好重！ | 輕微：vi「thêm một viên sỏi」（又多了一顆小石子）vs zh「多了一顆小石頭」——vi 版明確化「又多一顆」，zh 版僅說「多了」；語義更精準不偏移 |
| P02 | P02 | 「等一下，我要說！」／「我怕…… 手放開。」／「再握一下，好不好？」 | "Khoan đã — con muốn nói!"／"Con sợ… buông tay ra."／"Nắm thêm một cái nhé?" | 「等一下——我想說！」\n「我害怕……鬆開手。」\n「再握一下好嗎？」 | 無 |
| P03 | P04 | 媽媽說了會回來，牽牽往前走。／咚！／口袋用力往後一甩。 | Mẹ đã hẹn sẽ về. Bống bước tới.／Bịch!／Túi áo giật mạnh về phía sau. | （缺） | — |
| P04 | P05 | 嘎！／「等一下，我要說！」／「我怕…… 看不到媽媽。」／「揮揮手，好嗎？」 | Mẹ đã hẹn sẽ về. Bống bước tới.／Bịch!／Túi áo giật mạnh về phía sau. | 媽媽已經約好會回來。小圓往前走。\n咚！\n口袋用力往後拉。 | 無 |
| P05 | P07 | 媽媽揮了揮手。／牽牽走到門口——／咚！／最重的石頭掉進口袋。 | Kẹt!／"Khoan đã — con muốn nói!"／"Con sợ… không nhìn thấy mẹ."／"Vẫy tay nhé?" | 卡住了！\n「等一下——我想說！」\n「我害怕……看不到媽媽。」\n「揮揮手好嗎？」 | 無 |
| P06 | P08 | 噗通！嘎！／「等一下，我要說！」／「我怕…… 媽媽不回來。」／「玩完水，你會來嗎？」／「會的。」 | Bộp! Kẹt!／"Khoan đã — con muốn nói!"／"Con sợ… mẹ không về nữa."／"Chơi nước xong, mẹ về nhé?"／"Có." | （缺） | — |
| P07 | P09 | 牽牽站起來，對媽媽揮揮手。／抱著小黃鴨，抬起腳—— | Mẹ vẫy tay. Bống bước đến cửa —／Bịch!／Viên sỏi nặng nhất rơi xuống túi áo. | 媽媽揮揮手。小圓走到門口——\n咚！\n最重的石頭掉進了口袋。 | 無 |
| P08 | P10 | 牽牽跨過門檻，把小黃鴨放進水盆。／啵！小黃鴨浮起來了。 | Bộp! Kẹt!／"Khoan đã — con muốn nói!"／"Con sợ… mẹ không về nữa."／"Chơi nước xong, mẹ về nhé?"／"Có." | 啪！卡住了！\n「等一下——我想說！」\n「我害怕……媽媽不回來了。」\n「玩完水，媽媽回來好嗎？」\n「好。」 | 輕微：vi「Chơi nước xong, mẹ về nhé?」＋「Có.」vs zh-TW「玩完水，你會來嗎？」＋「會的。」——vi 用「nhé」語氣詞柔化請求，語氣更溫柔；回答「Có」（有/會）比「會的」更短，符合 3-5 節制語域 |
| P09 | P11 | 小黃鴨玩夠了。／啪嗒，啪嗒。／門外傳來腳步聲——好像是媽媽！ | Bống đứng dậy, vẫy tay chào mẹ.／Ôm vịt con, nhấc chân lên — | 小圓站起來，跟媽媽揮手再見。\n抱著小鴨，抬起腳—— | 無 |
| P10 | P12 | 媽媽回來了！／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | Bống bước qua bậc cửa, đặt vịt con vào chậu nước.／Tõm! Vịt con nổi lên rồi. | 小圓跨過門檻，把小鴨放進水盆。\n撲通！小鴨浮起來了。 | 無 |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | vi-VN 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 媽媽放手了。／咚！／口袋好重好重。 | Mẹ buông tay rồi.／Bịch!／Túi áo nặng quá! | 媽媽鬆手了。\n咚！\n口袋好重！ | 無 |
| P02 | P02 | 「等一下，我要說！」／「怕…… 手放開。」／「再握一下。」 | "Khoan đã — con muốn nói!"／"Sợ… buông tay."／"Nắm một cái." | 「等一下——我想說！」\n「怕……鬆手。」\n「握一下。」 | 無 |
| P03 | P05 | 咚！又一顆石頭。／嘎！／「等一下，我要說！」／「怕…… 看不到媽媽。」 | Bịch! Thêm một viên nữa.／Kẹt!／"Khoan đã — con muốn nói!"／"Sợ… không thấy mẹ." | （缺） | — |
| P04 | P08 | 咚！最重的。／噗通！嘎！／「等一下，我要說！」／「怕…… 媽媽不回來。」／媽媽點點頭。 | Bịch! Viên nặng nhất.／Bộp! Kẹt!／"Khoan đã — con muốn nói!"／"Sợ… mẹ không về."／Mẹ gật đầu. | （缺） | — |
| P05 | P09 | 牽牽站起來了。／揮揮手——抬起腳—— | Bịch! Thêm một viên nữa.／Kẹt!／"Khoan đã — con muốn nói!"／"Sợ… không thấy mẹ." | 咚！又多一顆。\n卡住了！\n「等一下——我想說！」\n「怕……看不到媽媽。」 | 無 |
| P06 | P10 | 跨過去了！／小黃鴨——啵！／浮起來了。 | Bước qua rồi!／Vịt con — Tõm!／Nổi lên rồi. | （缺） | — |
| P07 | P11 | 小黃鴨玩完水了。／啪嗒，啪嗒。／門外有腳步聲。 | Vịt con chơi xong rồi.／lộp bộp, lộp bộp.／Ngoài cửa có tiếng bước chân. | （缺） | — |
| P08 | P12 | 媽媽回來了！／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | Bịch! Viên nặng nhất.／Bộp! Kẹt!／"Khoan đã — con muốn nói!"／"Sợ… mẹ không về."／Mẹ gật đầu. | 咚！最重的那顆。\n啪！卡住了！\n「等一下——我想說！」\n「怕……媽媽不回來。」\n媽媽點頭。 | 無 |

## 三、QA 摘要（qa/vi-VN）

- `qa/vi-VN/round1.md`：round 1／verdict escalated

最新 round：`qa/vi-VN/round1.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: whats-in-the-worry-pocket
locale: vi-VN
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-21"
step1_lint: {exit_code: 0, warnings: 6}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: vi-VN-teacher
    scores: {年齡適配度: 9, 朗讀口感: 9, 孩子抓得住度: 9}
  - id: vi-VN-parent
    scores: {睡前適讀性: 9, 零說教: 10}
  - id: vi-VN-editor
    scores: {母語自然度: 9, 文字工藝: 9}
step4_triage: {real: 1, rejected: 3, escalated: 1}
verdict: escalated
```

### ESL 獵手發現（原文引用）

### ESL 獵手（翻譯腔獵手 vi-VN：北方標準錨定＋AI 機械句）

**主題錨復述句**：同 STEP 2。

**靶區（vi-VN spec 雷區）**：
- 獵物① 翻譯腔：北部標準 R5 錨定（南方詞形滲漏）、中文母本句序殘留、「của」所有格連串、「bị/được」被動濫用、漢越詞過度
- 獵物② AI 機械句（style_guide §3.4）：電報式裸動詞堆疊、成分懸空、超規律平行、無語氣詞乾句

**輸入**：vi-VN 三檔 × zh-TW 三檔對讀 × en-US 三檔對讀

**訊源計量**：vi-VN 三檔文本 + zh-TW 定稿三檔 + en-US 定稿三檔 = 9 檔對讀

**逐頁掃瞄結果**：

| 檔位 | 頁 | 獵物 | 原句 | 問題 | 建議 |
|---|---|---|---|---|---|
| 5-6 | P12 | ① 南方詞 | 「Mẹ nhìn **nè**」 | 「nè」是南方語氣詞（giọng Nam），北方標準用「này」。R5 違反。 | **已修正**：改為「Mẹ nhìn này」 |

**盲稿讀序聲明真偽抽驗**：copy 檔頭宣告「B0/B1 completed without opening any zh-TW or en-US text files」。結構分歧檢查——vi-VN 三檔的句法結構與 zh-TW/en-US 存在明顯差異（如 P05 2-3 tier 合併 Bịch＋Kẹt 兩 SFX 是獨立設計、非句句對譯），支持盲稿宣告。

**獵手結論**：
- 獵物① 1 筆（P12 nè），**已修正**
- 獵物② 0 筆。2-3 檔電報式語體在 W7 合法邊界內——有拍點設計（SFX＋疊句＋感受收束），非機械裸列。三檔語氣詞分佈正常（nhé/nhá/rồi/ơi 各檔均有適度出現）
- 漢越詞比例：2-3/3-5 零進階漢越詞，5-6 無堆疊。合規
- 中文句序殘留：未檢出。vi 語序自然
- 「của」所有格連串：未檢出
- 「bị/được」被動濫用：P05 5-6「Vịt con bị bóp một cái」合法被動（被擠＝非自願），非濫用
- en-US 二手錨定檢查：未發現 vi 版句句對位 en-US 的跡象，句法保持越南語自然結構

---

## 四、⏸️ 上呈批次

- （`qa/vi-VN/round1.md`）**2-3 P12 句長違規**：15 tiếng > max 10。此為收束式設計承諾（「Từ ngày đó… Bống nắm tay mẹ, còn vịt con cũng theo về nhà rồi.」＝「從那天起……小圓牽著媽媽的手，小鴨也跟著回家了。」），三檔共用、zh-TW 母本同樣超線（句長 12 > max_sentence_len=10），seed 值 low confidence。**結構性 ⏸️ 上呈項**（同 zh-TW 共用議題，非 vi-VN 獨有）。
- （`qa/vi-VN/round1.md`）exit_code = 0（5-6、3-5 通過）；2-3 有 1 筆已知結構性違規（收束式），不擋後續步驟（轉 STEP 4 分診 ⏸️）。總警告 9 筆（3×3 tiers），全為設計承諾折計。
- （`qa/vi-VN/round1.md`）| F4 | 機檢 | 2-3 | P12 | 收束式句長 15 > max_sentence_len 10 | ⏸️ | — | — | 設計承諾＝三檔共用收束式「Từ ngày đó… Bống nắm tay mẹ, còn vịt con cũng theo về nhà rồi.」；zh-TW 母本同樣超線（12>10）。vi-VN seed 值 max_sentence_len=10 信心 low。vi 的收束式比 zh-TW 母本長（15 vs 12 tiếng），因越南語多音節詞拆分天然膨脹。改短收束式＝動品牌簽名（style_guide 收束式＝招牌級），超越本站權限 | ⏸️ 上呈。傾向：保留收束式不動，seed 校準時調整 max_sentence_len 門檻（vi-VN 2-3 首批內容，門檻待實測） |
- （`qa/vi-VN/round1.md`）- ⏸️ = 1（F4 收束式句長，結構性共用議題）
- （`qa/vi-VN/round1.md`）理由：STEP 4 ✅=1 已全數修正落地。⏸️=1（F4 收束式句長）為結構性共用議題——同 zh-TW 母本同類問題，非 vi-VN 獨有，需 Stacy 裁定 seed 門檻或收束式處置。

