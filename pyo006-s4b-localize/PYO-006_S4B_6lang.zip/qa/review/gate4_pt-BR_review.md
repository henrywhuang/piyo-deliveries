# 關卡4整合審閱：擔心口袋裡有什麼？（S4 證據包／pt-BR）

- 生成時間：2026-07-21 22:29:34 +0800
- 書目錄：`content/PYO-006_whats-in-the-worry-pocket`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：pt-BR
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-006_storyboard.md` | 2026-07-21 17:08:45 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-21 17:08:45 |
| text/pt-BR/5-6 | `text/pt-BR/5-6.draft.json` | 2026-07-21 17:46:47 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-21 17:08:45 |
| text/pt-BR/3-5 | `text/pt-BR/3-5.draft.json` | 2026-07-21 18:05:08 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-21 17:08:45 |
| text/pt-BR/2-3 | `text/pt-BR/2-3.draft.json` | 2026-07-21 17:46:44 |
| qa/pt-BR/backtranslation.md | `qa/pt-BR/backtranslation.md` | 2026-07-21 22:25:16 |
| qa/pt-BR round | `qa/pt-BR/round1.md` | 2026-07-21 22:29:09 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | pt-BR 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 12 | 12 頁有文 | 12 頁有文 | 10/12 | 0 |
| 3-5 | 10 | 10 頁有文 | 10 頁有文 | 10/10 | 0 |
| 2-3 | 8 | 8 頁有文 | 8 頁有文 | 8/8 | 0 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | pt-BR 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 牽牽抱著小黃鴨，準備去玩水。／媽媽慢慢鬆開手——／咚！／口袋突然多了一顆小石頭，好重好重。 | Dedinha trouxe o patinho para brincar na água. Mamãe Lontra foi soltando a mão dela, devagarzinho.／TUM!／Uma pedrinha caiu dentro do bolso — ficou pesado, pesado. | 小指獺帶了小鴨子去玩水。水獺媽媽慢慢地鬆開她的手。TUM！一顆小石頭掉進口袋裡——變得好重好重。 | 無 |
| P02 | P02 | 媽媽蹲下來，打開手掌，安靜等著。／「等一下，我要說！」／「我怕…… 手放開。」／「再握一下，好不好？」 | Mamãe Lontra abaixou, abriu as mãos e ficou esperando, quietinha.／— Espera — eu preciso falar!／— Eu tenho medo… de soltar a mão.／— Mais um aperto antes do tchau? | 水獺媽媽蹲下來，打開雙手，安靜等著。「等一下——我需要說！」「我害怕……放開手。」「道別之前再握一下？」 | 無 |
| P03 | P03 | 媽媽小聲說：「小黃鴨玩完水，我就回來。」／再握一下，放開。／牽牽抱著小黃鴨，往前走了一小步。 | Mamãe Lontra deu mais um aperto. — Eu volto quando o patinho acabar de brincar na água.／Soltou a mão, e Dedinha deu um passinho com o patinho debaixo do braço. | （缺） | — |
| P04 | P04 | 媽媽往門邊走了一步。／牽牽也往前走——／咚！／口袋用力往後一甩。 | Mamãe Lontra deu um passo pro lado da porta. Dedinha continuou andando.／TUM!／Outra pedrinha caiu no bolso e puxou tudo pra trás — | 水獺媽媽往門邊走了一步。小指獺繼續往前走。TUM！另一顆小石頭掉進口袋，把一切往後拉—— | 無 |
| P05 | P05 | 嘎！小黃鴨被擠了一下。／「等一下，我要說！」／「我怕…… 看不到媽媽。」／「在門口揮揮手，好嗎？」 | QUEC!／Dedinha virou inteirinha de volta pra mamãe.／— Espera — eu preciso falar!／— Eu tenho medo… de não enxergar você lá dentro.／— Tchau com a mão lá na porta, mamãe? | QUEC！小指獺整個轉回了媽媽那邊。「等一下——我需要說！」「我害怕……在裡面看不到你。」「在門口揮揮手，好嗎，媽媽？」 | 無 |
| P06 | P06 | 媽媽在門口，輕輕揮了揮手。／牽牽走到門檻邊——裡面有人在等，還有那個水盆。 | Mamãe Lontra fez um tchauzinho com a mão. Dedinha chegou pertinho da porta.／Lá dentro, alguém conhecido esperava, e a bacia de água estava lá. | （缺） | — |
| P07 | P07 | 媽媽說完再見，轉身要走了。／牽牽剛抬起腳——／咚！／最重的一顆石頭掉進口袋。 | Mamãe Lontra disse tchau e virou pra ir embora. Dedinha levantou um pé pra entrar.／TUM!／A pedrinha mais pesada de todas caiu no bolso e puxou ela direto pro chão — | 水獺媽媽說了再見，轉身要走了。小指獺抬起一隻腳要進去。TUM！最重的一顆小石頭掉進口袋，把她直直拉向地面—— | 無 |
| P08 | P08 | 噗通！／嘎！小黃鴨彈了起來。／「等一下，我要說！」／「我怕…… 媽媽不回來。」／「玩完水，你會來嗎？」／媽媽點點頭：「會的。」 | PLOFT!／QUEC!／Dedinha falou primeiro.／— Espera — eu preciso falar!／— Eu tenho medo… de você não voltar.／— Você volta quando o patinho acabar de brincar?／— Volto, sim — disse Mamãe Lontra.／O bolso saiu do chão. | PLOFT！QUEC！小指獺先開口說了。「等一下——我需要說！」「我害怕……你不回來。」「你會在小鴨子玩完水的時候回來嗎？」「會的——」水獺媽媽說。口袋離開了地面。 | 無 |
| P09 | P09 | 牽牽自己站了起來。／她對媽媽揮揮手，抱著小黃鴨，抬起腳—— | Dedinha levantou sozinha. Fez tchauzinho pra mamãe, e mamãe fez de volta.／Abraçou o patinho bem pertinho e levantou um pé — | 小指獺自己站了起來。對媽媽做了一個小小的揮手，媽媽也揮了回來。她把小鴨子緊緊抱在懷裡，抬起一隻腳—— | 無 |
| P10 | P10 | 牽牽跨過門檻，把小黃鴨輕輕放進水盆。／啵！／小黃鴨浮了起來。 | Dedinha entrou com as três pedrinhas no bolso.／Colocou o patinho na água, devagarinho.／TCHIBUM!／Ele boiou. | 小指獺帶著口袋裡三顆小石頭進去了。她慢慢地把小鴨子放進水裡。TCHIBUM！牠浮起來了。 | 無 |
| P11 | P11 | 小黃鴨在水盆裡玩夠了。／啪嗒，啪嗒。／門外傳來好熟悉的腳步聲。 | O patinho já tinha brincado bastante. Dedinha tirou ele da água, todo molhadinho.／Aí veio um barulho que ela conhecia —／tec, tec, tec!／Dedinha olhou pra porta — e esperou — | 小鴨子已經玩夠了。小指獺把牠從水裡撈出來，全身濕漉漉的。然後傳來一個她認識的聲音——tec, tec, tec！小指獺看向門口——等著—— | 無 |
| P12 | P12 | 媽媽回來了！／「你看，小石頭還在，小黃鴨濕濕的！」／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | Mamãe Lontra voltou, igualzinho prometeu.／— Olha, mamãe! As pedrinhas ainda estão aqui — e o patinho tá todo molhado!／De mão dada, foram pra casa.／E desde aquele dia… elas davam as mãos em todo tchau e em todo oi. | 水獺媽媽回來了，跟她答應的一模一樣。「你看，媽媽！小石頭還在這裡——小鴨子全身都濕了！」手牽手，一起回家了。從那天起……她們每次道別和問好都會牽手。 | 無 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | pt-BR 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 媽媽鬆開手——／咚！／口袋多了一顆小石頭，好重好重。 | Mamãe Lontra soltou a mão.／TUM!／Uma pedrinha caiu no bolso de Dedinha. Pesado, pesado! | 水獺媽媽鬆開手。TUM！一顆小石頭掉進小指獺的口袋。好重好重！ | 無 |
| P02 | P02 | 「等一下，我要說！」／「我怕…… 手放開。」／「再握一下，好不好？」 | Mamãe Lontra abaixou e esperou.／— Espera — eu preciso falar!／— Eu tenho medo… de soltar a mão.／— Mais um aperto? | 水獺媽媽蹲下來等著。「等一下——我需要說！」「我害怕……放開手。」「再握一下？」 | 無 |
| P03 | P04 | 媽媽說了會回來，牽牽往前走。／咚！／口袋用力往後一甩。 | Mamãe Lontra disse que voltava. Dedinha apertou mais uma vez e deu um passo.／TUM!／Outra pedrinha caiu no bolso e puxou tudo pra trás — | （缺） | — |
| P04 | P05 | 嘎！／「等一下，我要說！」／「我怕…… 看不到媽媽。」／「揮揮手，好嗎？」 | Mamãe Lontra disse que voltava. Dedinha apertou mais uma vez e deu um passo.／TUM!／Outra pedrinha caiu no bolso e puxou tudo pra trás — | 水獺媽媽說會回來。小指獺再握了一下，走了一步。TUM！另一顆小石頭掉進口袋，把一切往後拉—— | 無 |
| P05 | P07 | 媽媽揮了揮手。／牽牽走到門口——／咚！／最重的石頭掉進口袋。 | QUEC!／— Espera — eu preciso falar!／— Eu tenho medo… de não enxergar você.／— Tchau com a mão, mamãe? | QUEC！「等一下——我需要說！」「我害怕……看不到你。」「揮揮手，好嗎，媽媽？」 | 無 |
| P06 | P08 | 噗通！嘎！／「等一下，我要說！」／「我怕…… 媽媽不回來。」／「玩完水，你會來嗎？」／「會的。」 | PLOFT!／QUEC!／— Espera — eu preciso falar!／— Eu tenho medo… de você não voltar.／— Você volta depois do patinho brincar?／— Volto, sim. | （缺） | — |
| P07 | P09 | 牽牽站起來，對媽媽揮揮手。／抱著小黃鴨，抬起腳—— | Mamãe Lontra fez tchauzinho. Virou e foi embora.／Dedinha levantou um pé —／TUM!／A pedrinha mais pesada de todas puxou ela pra baixo — | 水獺媽媽做了一個小小的揮手。轉身走了。小指獺抬起一隻腳——TUM！最重的一顆小石頭把她往下拉—— | 無 |
| P08 | P10 | 牽牽跨過門檻，把小黃鴨放進水盆。／啵！小黃鴨浮起來了。 | PLOFT!／QUEC!／— Espera — eu preciso falar!／— Eu tenho medo… de você não voltar.／— Você volta depois do patinho brincar?／— Volto, sim. | PLOFT！QUEC！「等一下——我需要說！」「我害怕……你不回來。」「小鴨子玩完水以後你會回來嗎？」「會的。」 | 無 |
| P09 | P11 | 小黃鴨玩夠了。／啪嗒，啪嗒。／門外傳來腳步聲——好像是媽媽！ | Dedinha levantou e fez tchauzinho primeiro. Mamãe Lontra fez de volta.／Abraçou o patinho e levantou um pé — | 小指獺站起來，先做了一個小小的揮手。水獺媽媽也揮了回來。抱著小鴨子，抬起一隻腳—— | 無 |
| P10 | P12 | 媽媽回來了！／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | Dedinha entrou com as três pedrinhas no bolso.／Colocou o patinho na água.／TCHIBUM!／Ele boiou. | 小指獺帶著口袋裡三顆小石頭進去了。把小鴨子放進水裡。TCHIBUM！牠浮起來了。 | 無 |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | pt-BR 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 媽媽放手了。／咚！／口袋好重好重。 | Mamãe soltou a mão.／TUM!／O bolso ficou pesado, pesado! | 媽媽放手了。TUM！口袋變得好重好重！ | 無 |
| P02 | P02 | 「等一下，我要說！」／「怕…… 手放開。」／「再握一下。」 | — Espera — eu preciso falar!／— Medo… de soltar a mão.／— Mais um aperto? | 「等一下——我需要說！」「怕……放開手。」「再握一下？」 | 無 |
| P03 | P05 | 咚！又一顆石頭。／嘎！／「等一下，我要說！」／「怕…… 看不到媽媽。」 | TUM!／— Espera — eu preciso falar!／— Medo… não vejo mamãe.／— Tchau com a mão? | （缺） | — |
| P04 | P08 | 咚！最重的。／噗通！嘎！／「等一下，我要說！」／「怕…… 媽媽不回來。」／媽媽點點頭。 | TUM!／— Espera — eu preciso falar!／— Medo… mamãe não volta.／— Você volta?／Mamãe fez que sim. | （缺） | — |
| P05 | P09 | 牽牽站起來了。／揮揮手——抬起腳—— | TUM!／— Espera — eu preciso falar!／— Medo… não vejo mamãe.／— Tchau com a mão? | TUM！「等一下——我需要說！」「怕……看不到媽媽。」「揮揮手？」 | 無 |
| P06 | P10 | 跨過去了！／小黃鴨——啵！／浮起來了。 | Entrou!／Três pedrinhas no bolso!／TCHIBUM!／O patinho boiou. | （缺） | — |
| P07 | P11 | 小黃鴨玩完水了。／啪嗒，啪嗒。／門外有腳步聲。 | O patinho brincou bastante.／tec, tec, tec!／Dedinha esperou — | （缺） | — |
| P08 | P12 | 媽媽回來了！／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | TUM!／— Espera — eu preciso falar!／— Medo… mamãe não volta.／— Você volta?／Mamãe fez que sim. | TUM！「等一下——我需要說！」「怕……媽媽不回來。」「你會回來嗎？」媽媽點了點頭。 | 無 |

## 三、QA 摘要（qa/pt-BR）

- `qa/pt-BR/round1.md`：round 1／verdict pass

最新 round：`qa/pt-BR/round1.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: whats-in-the-worry-pocket
locale: pt-BR
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-21"
step1_lint: {exit_code: 0, warnings: 11}
step2_checklist: {pass: 19, fail: 0}
step3_personas:
  - id: pt-BR-professora
    scores: {年齡適配度: 8, 巴西語感: 9, 孩子抓得住度: 8}
  - id: pt-BR-mae
    scores: {睡前適讀性: 9, 零說教: 10}
  - id: pt-BR-editora
    scores: {母語自然度: 9, 文字工藝: 8}
step4_triage: {real: 0, rejected: 3, escalated: 0}
verdict: pass
```

### ESL 獵手發現（原文引用）

### ESL 獵手（pt-BR 翻譯腔獵手）

**主題錨復述句**：本書讓小水獺在三輪分離距離增加時，從身體線索察覺擔心、用疊句停一下再說出具體怕什麼、提出可完成的需求，才能走下一步；石頭不消失只變輕。

**獵物① 翻譯腔靶區**（pt-BR spec 雷區）：
- 被動語態 calque：全書掃描，無 en-US/zh-TW 式被動滲漏。所有句子均為主動態。✓
- 英語語序：全書語序為自然巴西式。代詞位置正確——對話用 proclisis（「— Me ajuda」模式不出現，但所有代詞位置均合法 BR 口語）。✓
- 形式語域混入幼兒文本：2-3 檔電報式「Medo…」碎句，語域自然偏低幼。3-5/5-6 旁白略正式但在 BR 童書 norma culta 輕量版範圍。✓
- diminutivos 使用：devagarzinho(P01), pedrinha(P01/P04/P07), passinho(P03), quietinha(P02), tchauzinho(P06/P09), pertinho(P06/P09), molhadinho(P11/P12), devagarinho(P10) — 自然分佈，無堆疊（同句不超過 1 個 diminutivo）。✓
- tu/voce 混用：全書統一 voce/vocês，零 tu 出現。✓
- 歐葡滲漏：無 estar a + infinitivo、無 PT-PT 詞彙、無 mamã（全用 mamãe 短形或 Mamãe Lontra）。✓

**獵物② AI 機械句**（style_guide 3.4）：
- 電報式裸動詞堆疊：2-3 檔 P09「Dedinha levantou. / Tchauzinho! / Levantou um pé —」為三拍片段句，有收束有拍點設計（tchauzinho! 為情緒拍點），屬 W7 合法電報式，非機械裸列。✓
- 成分懸空：全書無動詞著力點缺失。✓
- 超規律平行：三次疊句「— Espera — eu preciso falar!」逐字一致為刻意設計（B0 rulings 凍結），非無設計性機械重複。三次擔心句「Eu tenho medo… de X」為刻意平行結構（design.md theme_cycles 規格），有變奏（每輪內容不同）。✓
- 無語氣詞乾句：BR 口語語氣自然——P08 diminutivo、P12「igualzinho prometeu」「tá todo molhado」（口語縮合 está→tá），對話不乾。✓

**盲稿讀序結構分歧抽驗**：pt-BR 文本的改編痕跡與 B0 語感基建一致——角色名 Dedinha/Mamãe Lontra、擬聲 TUM!/QUEC!/PLOFT!/TCHIBUM!/tec,tec,tec!、疊句 travessão 制——均為 B0 提案凍結項，非 zh-TW/en-US 直譯痕跡。P05 5-6「de não enxergar você lá dentro」（看不到你在裡面）與 zh-TW「看不到媽媽」和 en-US「won't see you inside」均為各自自然表達，無句句對位跡象。讀序聲明可信。

**ESL 獵手結論**：零發現。pt-BR 文本語感自然，無翻譯腔或 AI 機械句。

## 四、⏸️ 上呈批次

- （`qa/pt-BR/round1.md`）### ⏸️ 上呈批次
- （`qa/pt-BR/round1.md`）✅ real = 0, ❌ rejected = 3, ⏸️ escalated = 0。**一輪 ✅=0，QA 收斂。**
- （`qa/pt-BR/round1.md`）Round 1 STEP 4 ✅=0，⏸️=0。pt-BR 泳道已收斂。

