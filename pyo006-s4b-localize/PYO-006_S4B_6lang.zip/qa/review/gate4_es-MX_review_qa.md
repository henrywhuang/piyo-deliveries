# Gate 4 Evidence Summary: PYO-006 es-MX

## QA Overview

| Field | Value |
|---|---|
| Book | PYO-006 whats-in-the-worry-pocket |
| Locale | es-MX |
| QA rounds | R1 (full) + R2 (review round) |
| Date | 2026-07-21 |
| Mode | B (S4B locale adaptation) |
| Tiers reviewed | 2-3, 3-5, 5-6 |
| Verdict | **escalated** (1 item for Stacy) |

## Machine Check (STEP 1)

All 3 tiers pass (exit 0, 0 violations). 11 warnings total, all repeat_discount related (design-intent refrain repetition).

## Editor E (STEP 2)

- Checklist: 28/28 PASS (text-stage applicable items)
- Alignment: 0 violations across all pages x 3 tiers
- Concept fidelity: PASS all tiers (three worry rounds preserved, stone-weight mechanism intact)
- Fun design commitments: all delivered (refrain, hooks, onomatopoeia, gravity contrast)

## Back-translation (STEP 2A)

- Coverage: S4B structural pages + triggered (30 page-translations across 3 tiers)
- Result: 0 moderate-or-above drift markers; 8 minor markers (all legitimate adaptation choices: MX diminutives, spatial phrasing, dynamic descriptions)

## Translation-Tone Hunter (STEP 2B)

10 findings (6 translation tone, 4 AI mechanical). 3 triaged as real issues (all fixed); 7 rejected with lock-in or spec references.

## Personas (STEP 3)

| Persona | Dim 1 | Dim 2 | Dim 3 |
|---|---|---|---|
| es-MX-educadora (Maestra Lupita) | 年齡適配度: 7 | 墨西哥語感: 8 | 孩子抓得住度: 8 |
| es-MX-mama (Fernanda) | 睡前適讀性: 7 | 零說教: 6 | -- |
| es-MX-editora (Editora Valeria) | 母語自然度: 7 | 文字工藝: 7 | -- |

## Triage (STEP 4)

| Category | Count |
|---|---|
| ✅ Real issues (fixed) | 3 |
| ❌ Rejected (false positives) | 10 |
| ⏸️ Escalated | 1 |

### Fixes Applied (R1, verified in R2 review round)

1. **T1: 3-5 P09** (句級): `"Mimí se paró y fue la primera en decir adiós."` -> `"Mimí se paró solita y dijo adiós primero."` -- "fue la primera en decir adiós" was overly bookish for 3-5 tier, flagged by 3 independent sources (hunter H5, educadora L5, editora V4). Fix adds MX diminutive warmth ("solita") and shifts to oral register.

2. **T2: 3-5 P07** (句級): `"Mamá Nutria le dijo adiós con la mano.\nSe despidió y se fue."` -> `"Mamá Nutria le dijo adiós con la mano y se fue despacito."` -- Semantic redundancy (waving goodbye + said goodbye). Merged into single sentence; "despacito" adds MX diminutive warmth and matches spec recommendation.

3. **T3: 5-6 P05** (字串級): `"desde allá adentro"` -> `"desde adentro"` -- Stacked spatial markers ("allá" + "adentro") suspected English calque of "from in there". Reduced to single spatial marker per natural MX usage.

Post-fix re-lint (R2): all 3 tiers exit 0. Copy table synced. E-lite on modified + adjacent pages: all PASS.

### Escalated Item (for Stacy)

1. **T9: All tiers P12 -- closing formula "Y desde ese dia..."** has moraleja/proverb feel per 2 personas (Fernanda scored 2-3 零說教 at 6). However:
   - It is a copy commitment lock-in (commitments.ending in copy table)
   - style_guide F10 mandates closing formula for 2-3 tier
   - Cross-language consistent (same structure in zh-TW, en-US, ja, en-GB, vi-VN)
   - Agent recommendation: retain as-is; micro-adjusting the 2-3 wording (e.g., shortening to "Y desde ese dia... se tomaron de la mano.") would need piyo-localize cross-language consistency review. Escalated for Stacy's discretion.

## File References

- Full evidence bundle: `content/PYO-006_whats-in-the-worry-pocket/qa/review/gate4_es-MX_review.md`
- QA reports: `content/PYO-006_whats-in-the-worry-pocket/qa/es-MX/round1.md`, `round2.md`
- Back-translation: `content/PYO-006_whats-in-the-worry-pocket/qa/es-MX/backtranslation.md`
- Workbench: `content/PYO-006_whats-in-the-worry-pocket/qa/es-MX/workbench.md`
- Draft texts: `content/PYO-006_whats-in-the-worry-pocket/text/es-MX/{2-3,3-5,5-6}.draft.json`
- Copy table: `content/PYO-006_whats-in-the-worry-pocket/copy/es-MX.md`
