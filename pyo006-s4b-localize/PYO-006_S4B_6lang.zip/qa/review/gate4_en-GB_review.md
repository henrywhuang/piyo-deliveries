# 關卡4整合審閱：擔心口袋裡有什麼？（S4 證據包／en-GB）

- 生成時間：2026-07-21 22:31:52 +0800
- 書目錄：`content/PYO-006_whats-in-the-worry-pocket`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：en-GB
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-006_storyboard.md` | 2026-07-21 17:08:45 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-21 17:08:45 |
| text/en-GB/5-6 | `text/en-GB/5-6.draft.json` | 2026-07-21 17:20:44 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-21 17:08:45 |
| text/en-GB/3-5 | `text/en-GB/3-5.draft.json` | 2026-07-21 17:20:50 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-21 17:08:45 |
| text/en-GB/2-3 | `text/en-GB/2-3.draft.json` | 2026-07-21 17:20:53 |
| qa/en-GB/backtranslation.md | （缺） | — |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | en-GB 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 12 | 12 頁有文 | 12 頁有文 | 0/12 | 0 |
| 3-5 | 10 | 10 頁有文 | 10 頁有文 | 0/10 | 0 |
| 2-3 | 8 | 8 頁有文 | 8 頁有文 | 0/8 | 0 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | en-GB 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 牽牽抱著小黃鴨，準備去玩水。／媽媽慢慢鬆開手——／咚！／口袋突然多了一顆小石頭，好重好重。 | Cuddles came to splash with her toy duck. Mama Otter slowly let go of Cuddles's hand.／THUNK!／A stone dropped into Cuddles's pocket—down it sagged. So heavy! | （缺） | — |
| P02 | P02 | 媽媽蹲下來，打開手掌，安靜等著。／「等一下，我要說！」／「我怕…… 手放開。」／「再握一下，好不好？」 | Mama Otter knelt, opened her hands and waited.／"Wait—I need to tell you!／I'm scared… scared to let go.／One more squeeze before goodbye?" Cuddles said.／Cuddles stood tall. | （缺） | — |
| P03 | P03 | 媽媽小聲說：「小黃鴨玩完水，我就回來。」／再握一下，放開。／牽牽抱著小黃鴨，往前走了一小步。 | Mama Otter gave Cuddles one more squeeze. "I'll be back when your duck is done splashing."／Then Mama Otter let go, and Cuddles took one small step with her duck. | （缺） | — |
| P04 | P04 | 媽媽往門邊走了一步。／牽牽也往前走——／咚！／口袋用力往後一甩。 | Mama Otter took a step toward the doorway. Cuddles kept going.／THUNK!／A second stone dropped into her pocket. It pulled her backward, turning her around— | （缺） | — |
| P05 | P05 | 嘎！小黃鴨被擠了一下。／「等一下，我要說！」／「我怕…… 看不到媽媽。」／「在門口揮揮手，好嗎？」 | SQUEAK!／Cuddles turned all the way back.／"Wait—I need to tell you!／I'm scared… I can't see you from in there.／Will you wave from the doorway?"／Cuddles turned toward the playroom. | （缺） | — |
| P06 | P06 | 媽媽在門口，輕輕揮了揮手。／牽牽走到門檻邊——裡面有人在等，還有那個水盆。 | Mama Otter gave one small wave. Cuddles walked to the doorway.／A familiar grown-up waited inside by the little tub of water. | （缺） | — |
| P07 | P07 | 媽媽說完再見，轉身要走了。／牽牽剛抬起腳——／咚！／最重的一顆石頭掉進口袋。 | Mama Otter said goodbye and turned to go. Cuddles lifted one foot toward the doorway.／THUNK!／The third—and heaviest—stone dropped into her pocket and pulled her straight down— | （缺） | — |
| P08 | P08 | 噗通！／嘎！小黃鴨彈了起來。／「等一下，我要說！」／「我怕…… 媽媽不回來。」／「玩完水，你會來嗎？」／媽媽點點頭：「會的。」 | PLOP!／SQUEAK!／Cuddles spoke first.／"Wait—I need to tell you!／I'm scared… you won't come back.／Will you come back when my duck is done splashing?"／"Yes. I'll come back," Mama Otter said.／Cuddles's pocket lifted off the mat. | （缺） | — |
| P09 | P09 | 牽牽自己站了起來。／她對媽媽揮揮手，抱著小黃鴨，抬起腳—— | Cuddles stood up all by herself. She gave Mama Otter one small wave, then hugged her toy duck close.／She lifted one foot over the threshold— | （缺） | — |
| P10 | P10 | 牽牽跨過門檻，把小黃鴨輕輕放進水盆。／啵！／小黃鴨浮了起來。 | Cuddles stepped through the doorway with all three stones in her pocket.／She lowered her toy duck into the water.／SPLISH!／It floated. | （缺） | — |
| P11 | P11 | 小黃鴨在水盆裡玩夠了。／啪嗒，啪嗒。／門外傳來好熟悉的腳步聲。 | Splash time was over. Cuddles lifted her wet toy duck.／Then came footsteps Cuddles knew—／tap, tap, tap!／She looked toward the doorway—and waited— | （缺） | — |
| P12 | P12 | 媽媽回來了！／「你看，小石頭還在，小黃鴨濕濕的！」／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | Mama Otter came back, just as promised.／Cuddles held up her wet toy duck. "My little stones are still here—and so are you!"／Hand in hand, they headed home.／And from that day on… they held hands at every goodbye and hello. | （缺） | — |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | en-GB 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 媽媽鬆開手——／咚！／口袋多了一顆小石頭，好重好重。 | Cuddles came to splash with her toy duck. Mama Otter let go of her hand.／THUNK!／A heavy stone dropped into Cuddles's pocket. | （缺） | — |
| P02 | P02 | 「等一下，我要說！」／「我怕…… 手放開。」／「再握一下，好不好？」 | Mama Otter knelt and waited.／"Wait—I need to tell you!／I'm scared… scared to let go.／One more squeeze before goodbye?"／Cuddles stood tall. | （缺） | — |
| P03 | P04 | 媽媽說了會回來，牽牽往前走。／咚！／口袋用力往後一甩。 | Mama Otter gave one more squeeze. "I'll be back when your duck is done splashing." Cuddles stepped forward.／THUNK!／A second stone dropped into her pocket and pulled her backward— | （缺） | — |
| P04 | P05 | 嘎！／「等一下，我要說！」／「我怕…… 看不到媽媽。」／「揮揮手，好嗎？」 | SQUEAK!／"Wait—I need to tell you!／I'm scared… I can't see you.／Will you wave from the doorway?"／Cuddles turned toward the playroom. | （缺） | — |
| P05 | P07 | 媽媽揮了揮手。／牽牽走到門口——／咚！／最重的石頭掉進口袋。 | Mama Otter waved.／She said goodbye and stepped away.／Cuddles lifted one foot toward the doorway—／THUNK!／The third—and heaviest—stone pulled her down— | （缺） | — |
| P06 | P08 | 噗通！嘎！／「等一下，我要說！」／「我怕…… 媽媽不回來。」／「玩完水，你會來嗎？」／「會的。」 | PLOP!／SQUEAK!／"Wait—I need to tell you!／I'm scared… you won't come back.／Will you come back after splashing?"／"Yes," Mama Otter said. | （缺） | — |
| P07 | P09 | 牽牽站起來，對媽媽揮揮手。／抱著小黃鴨，抬起腳—— | Cuddles stood and waved first. Mama Otter waved back.／Cuddles hugged her toy duck and lifted one foot— | （缺） | — |
| P08 | P10 | 牽牽跨過門檻，把小黃鴨放進水盆。／啵！小黃鴨浮起來了。 | Cuddles stepped through the doorway with all three stones in her pocket.／She lowered her toy duck into the water.／SPLISH!／It floated. | （缺） | — |
| P09 | P11 | 小黃鴨玩夠了。／啪嗒，啪嗒。／門外傳來腳步聲——好像是媽媽！ | Splash time was over. Cuddles lifted her wet toy duck.／Then came footsteps Cuddles knew—／tap, tap, tap!／She looked toward the doorway—and waited— | （缺） | — |
| P10 | P12 | 媽媽回來了！／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | Mama Otter came back.／"You came back!"／Hand in hand, they headed home.／And from that day on… they held hands at every goodbye and hello. | （缺） | — |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | en-GB 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 媽媽放手了。／咚！／口袋好重好重。 | Mama let go.／THUNK!／A stone fell into Cuddles's pocket.／So heavy! | （缺） | — |
| P02 | P02 | 「等一下，我要說！」／「怕…… 手放開。」／「再握一下。」 | "Wait—I need to tell you!／I'm scared to let go.／One more squeeze?" | （缺） | — |
| P03 | P05 | 咚！又一顆石頭。／嘎！／「等一下，我要說！」／「怕…… 看不到媽媽。」 | THUNK!／"Wait—I need to tell you!／I can't see you!／Wave, Mama?" | （缺） | — |
| P04 | P08 | 咚！最重的。／噗通！嘎！／「等一下，我要說！」／「怕…… 媽媽不回來。」／媽媽點點頭。 | THUNK!／"Wait—I need to tell you!／I'm scared… will you come back?"／Mama nodded. | （缺） | — |
| P05 | P09 | 牽牽站起來了。／揮揮手——抬起腳—— | Cuddles stood up.／She waved.／She lifted one foot— | （缺） | — |
| P06 | P10 | 跨過去了！／小黃鴨——啵！／浮起來了。 | In she went!／Three stones in her pocket!／SPLISH!／Her toy duck floated. | （缺） | — |
| P07 | P11 | 小黃鴨玩完水了。／啪嗒，啪嗒。／門外有腳步聲。 | Footsteps at the door!／tap, tap, tap!／Cuddles waited— | （缺） | — |
| P08 | P12 | 媽媽回來了！／後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。 | Mama came back!／And from that day on… they held hands. | （缺） | — |

（缺）回譯檔：找不到 `content/PYO-006_whats-in-the-worry-pocket/qa/en-GB/backtranslation.md`

## 三、QA 摘要（qa/en-GB）

（缺）qa/en-GB round 檔：找不到 `content/PYO-006_whats-in-the-worry-pocket/qa/en-GB/round*.md`

## 四、⏸️ 上呈批次

無——各輪未見 ⏸️ 標記行。

