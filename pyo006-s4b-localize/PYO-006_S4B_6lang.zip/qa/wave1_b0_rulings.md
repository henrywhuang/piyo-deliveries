---
schema: piyo_b0_rulings/v1
book_id: PYO-006
slug: whats-in-the-worry-pocket
wave: 1
lanes: [ja, en-GB, es-MX, pt-BR]
status: frozen
---

# Wave 1 B0 Rulings — PYO-006 What's in the Worry Pocket?

## Frozen String Table

All values below are the unique source of truth for downstream QA and registry write-back.
Prose sections reference entries by `[R1]`…`[R4]` only — never repeat the string body.

### Refrains

| # | Locale | Frozen Value |
|---|--------|-------------|
| R1 | ja | `「まって、いいたいの！」` |
| R2 | en-GB | `Wait—I need to tell you!` |
| R3 | es-MX | `¡Espera, te quiero decir!` |
| R4 | pt-BR | `— Espera — eu preciso falar!` |

### Endings (common prefix)

| # | Locale | Frozen Value |
|---|--------|-------------|
| E1 | ja | `それからね……` |
| E2 | en-GB | `And from that day on…` |
| E3 | es-MX | `Y desde ese día…` |
| E4 | pt-BR | `E desde aquele dia…` |

### Onomatopoeia (5 SFX per locale)

| # | Function | ja | en-GB | es-MX | pt-BR |
|---|----------|-----|-------|-------|-------|
| S1 | stone drop | `ズシン` | `THUNK!` | `¡TUN!` | `TUM!` |
| S2 | duck squeeze | `キュッ` | `SQUEAK!` | `¡CUAC!` | `QUEC!` |
| S3 | sit plop | `どすん` | `PLOP!` | `¡PUM!` | `PLOFT!` |
| S4 | splash | `ぽちゃん` | `SPLISH!` | `¡PLAS!` | `TCHIBUM!` |
| S5 | footsteps | `ぱたぱた` | `tap, tap, tap!` | `toc, toc, toc!` | `tec, tec, tec!` |

### Character Names

| # | Role | ja | en-GB | es-MX | pt-BR |
|---|------|-----|-------|-------|-------|
| C1 | cuddles | `ぎゅっちゃん` | `Cuddles` | `Mimí` | `Dedinha` |
| C2 | mama_otter | `カワウソのおかあさん` | `Mama Otter` | `Mamá Nutria` | `Mamãe Lontra` |

## Rulings

- [R1]–[R4]: All refrains approved as B0 proposals; three-tier three-round consistency required.
- [E1]–[E4]: All ending prefixes approved; per-tier expansions follow copy table commitments.
- [S1]–[S5]: All SFX approved as B0 proposals; TTS round-trip pending (S6).
- [C1]–[C2]: All character names approved as B0 proposals.
- en-GB ([R2],[E2],[S1]–[S5],[C1]–[C2]): Derived variant — identical to en-US Gate 4 Green Light values.
- ja [C2]: Full form `カワウソのおかあさん` for registry; text uses short form `おかあさん` (copy_check acknowledges visual-only presence).
