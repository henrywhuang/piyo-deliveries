# QA 報告：whats-in-the-worry-pocket / pt-BR / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: whats-in-the-worry-pocket
locale: pt-BR
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-21"
step1_lint: {exit_code: 0, warnings: 11}
step2_checklist: {pass: 19, fail: 0}
step3_personas:
  - id: pt-BR-professora
    scores: {年齡適配度: 8, 巴西語感: 9, 孩子抓得住度: 8}
  - id: pt-BR-mae
    scores: {睡前適讀性: 9, 零說教: 10}
  - id: pt-BR-editora
    scores: {母語自然度: 9, 文字工藝: 8}
step4_triage: {real: 0, rejected: 3, escalated: 0}
verdict: pass
```

## STEP 1 機檢

### locale_lint（三檔逐檔）

**5-6.draft.json**：
```
exit 0, 警告 4 筆（均為 repeat_discount 正常折計）
⚠ 逐字重複 x3 TUM!（P01,P04,P07）
⚠ 逐字重複 x3 疊句（P02,P05,P08）
⚠ 逐字重複 x2 QUEC!（P05,P08）
⚠ 折計後總量 331 → 322.75
```
判讀：疊句與擬聲重複為設計意圖（B0 rulings），折計不影響門檻。通過。

**3-5.draft.json**：
```
exit 0, 警告 4 筆（同上 repeat_discount）
⚠ 逐字重複 x3 TUM!（P01,P04,P07）
⚠ 逐字重複 x3 疊句（P02,P05,P08）
⚠ 逐字重複 x2 QUEC!（P05,P08）
⚠ 折計後總量 201 → 192.75
```
判讀：同 5-6。通過。

**2-3.draft.json**：
```
exit 0, 警告 3 筆
⚠ 逐字重複 x3 TUM!（P01,P05,P08）
⚠ 逐字重複 x3 疊句（P02,P05,P08）
⚠ 折計後總量 90 → 82.5
```
判讀：通過。

### copy_check

```
exit 0, 警告 5 筆
⚠ [band] 低於帶下緣：2-3 P09(6w)、P10(9w)、P11(9w) — deliberate hook-breath/climax/suspense pages
⚠ [band] 超帶上緣：3-5 P12(26w) — brand ending formula
```
判讀：P09/P10/P11 低於下緣均為刻意設計頁（copy 表已附說明「deliberate hook-breath page」「below band floor -- climax page is action-dense + SFX」「deliberate suspense-breath page」）。P12 超上緣因收束式公式句。均為 copy 表明確標記的合法偏差。通過。

### 機檢結論

三檔 locale_lint exit 0 + copy_check exit 0，**STEP 1 通過**。

---

## STEP 2 checklist 自檢

**主題錨復述句**：本書的核心教訓是「小水獺在三次分離距離增加時，從身體線索察覺到自己正在擔心，把一個具體的分離擔心說給媽媽聽（每次用疊句停一下再說），然後提出一個可完成的告別或重逢需求，再走下一小步」——擔心是具體的石頭隱喻（說出後不消失、只恢復普通重量），不被勇敢/獨立/完成任務取代。

### A）故事結構（5 項）

| 項 | 5-6 | 3-5 | 2-3 | 證據 |
|---|---|---|---|---|
| A-1 完整弧線 | ✓ | ✓ | ✓ | 觸發＝P01 石頭出現；上升＝三輪遞增；高潮＝P10 跨門放鴨；收束＝P12 重逢＋收束式 |
| A-2 衝突有份量 | ✓ | ✓ | ✓ | 衝突跨 P01→P10（三輪累積），主角以三次開口行動解決，非外力 |
| A-3 情緒有起伏 | ✓ | ✓ | ✓ | 期待→驚訝（P01）→鬆動（P02）→失衡（P04-05）→最大擔心（P07-08）→跨門釋放（P10）→重逢安心（P12） |
| A-4 結尾有回響 | ✓ | ✓ | ✓ | P12 圓滿式：呼應 P01 分離場景，收束式「E desde aquele dia…」，旁白無教訓宣言 |
| A-5 開場有鉤子 | ✓ | ✓ | ✓ | P01 反常型：空口袋突然 TUM! 變重，身體被帶歪 |

### B）語言文字（5 項）

| 項 | 5-6 | 3-5 | 2-3 | 證據 |
|---|---|---|---|---|
| B-1 每頁字數 | N/A(量化) | N/A(量化) | N/A(量化) | STEP 1 機檢已判 |
| B-2 句長配情緒 | ✓ | ✓ | ✓ | 短句：P08「PLOFT!」「QUEC!」（緊張爆發）；長句：P12 收束式（回暖減速）；句長非均一 |
| B-3 聲音裝置 | ✓ | ✓ | ✓ | 5 種擬聲（TUM/QUEC/PLOFT/TCHIBUM/tec,tec,tec），TUM x3、QUEC x2、其餘 x1，配額合規；疊句「— Espera — eu preciso falar!」x3 |
| B-4 對話比例 | ✓ | ✓ | tier-N/A | 5-6/3-5 對話行占比>50%（疊句＋擔心＋需求每輪 3-4 行）；2-3 旁白為主符合規格 |
| B-5 無百科腔 | ✓ | ✓ | ✓ | 全書無知識灌輸句 |

### C）角色塑造（4 項）

| 項 | 5-6 | 3-5 | 2-3 | 證據 |
|---|---|---|---|---|
| C-1 主角辨識度 | ✓ | ✓ | ✓ | Dedinha 的區分特質「一擔心就黏回、口袋變重」透過行為呈現（P01 身體歪、P05 轉回、P08 被拉坐） |
| C-2 成長弧線 | ✓ | ✓ | ✓ | 缺陷＝擔心時抓緊/後退；觸發＝三輪距離增加；轉變＝P08 主動先說「Dedinha falou primeiro」→P09 自己站起→P10 跨門 |
| C-3 障礙有阻力 | ✓ | ✓ | ✓ | 三輪阻擋：P01/P04/P07 三顆石分別拉歪/後甩/坐下，非一次解決 |
| C-4 配角有功能 | ✓ | ✓ | ✓ | Mamãe Lontra＝引導者（蹲下等待、約定重逢），功能清楚 |

### D）圖文配合（4 項）

| 項 | 5-6 | 3-5 | 2-3 | 證據 |
|---|---|---|---|---|
| D-1 圖文關係多元 | stage-N/A | stage-N/A | stage-N/A | 待媒體線補檢 |
| D-2 圖畫承載資訊 | stage-N/A | stage-N/A | stage-N/A | 待媒體線補檢 |
| D-3 視覺風格一致 | stage-N/A | stage-N/A | stage-N/A | 待媒體線補檢 |
| D-4 翻頁有牽引（限文字三型） | ✓ | ✓ | ✓ | 5-6: P04 動作中斷（puxou tudo pra tras —）、P07 動作中斷（puxou ela direto pro chao —）、P09 動作中斷（levantou um pe —）、P11 懸念（tec,tec,tec! esperou —）；3-5/2-3 同等佈點 |

### E）主題思想（4 項）

| 項 | 5-6 | 3-5 | 2-3 | 證據 |
|---|---|---|---|---|
| E-1 主題由行動呈現 | ✓ | ✓ | ✓ | 核心教訓由 Dedinha 的三次行動呈現（說出擔心→提需求→前進），旁白零教訓句 |
| E-2 情感共鳴可達 | ✓ | ✓ | ✓ | P01 身體被帶歪＝間接呈現驚慌；P08 PLOFT! 被拉坐＝間接呈現最大擔心；P12 重逢＝安心 |
| E-3 末頁無教訓宣言 | ✓ | ✓ | ✓ | P12 只有收束式「E desde aquele dia…」，無「從此學會了」句式 |
| E-4 抽象度匹配 | ✓ | ✓ | ✓ | 2-3 無抽象概念詞；5-6 的「medo」由具體場景支撐（每次後面跟具體擔心） |

### 快速掃描（9 項文本階段適用）

| # | 判定 | 證據 |
|---|---|---|
| 1 無說教 | ✓ | 零旁白道德宣言 |
| 2 衝突跨頁 | ✓ | 三輪跨 P01-P10 |
| 3 情緒轉折 | ✓ | ≥3 轉折點 |
| 4 每頁字數 | N/A(量化) | STEP 1 已判 |
| 5 開場鉤子 | ✓ | P01 反常 |
| 6 主角特質行為呈現 | ✓ | P01/P05/P08 三輪失衡 |
| 7 圖文關係 | stage-N/A | 待媒體線 |
| 8 翻頁 hook | ✓ | P04/P07/P09 動作中斷＋P11 懸念 |
| 9 聲音裝置 | ✓ | 5 種 SFX＋疊句 |
| 10 末頁無教訓 | ✓ | 確認 |

### 趣味設計兌現比對

| 宣告（design.md） | 兌現 | 判定 |
|---|---|---|
| 開場鉤子：反常 P01 | P01「TUM! Uma pedrinha caiu dentro do bolso — ficou pesado, pesado.」＝空口袋突然變重 | ✓ |
| 疊句「等一下，我要說！」→P02/P05/P08，末次變奏 | P02/P05/P08 三次「— Espera — eu preciso falar!」逐字一致；P08 變奏＝Dedinha falou primeiro（主動先說） | ✓ |
| 翻頁 hook P04 動作中斷 | P04「puxou tudo pra trás —」破折號懸停 | ✓ |
| 翻頁 hook P07 動作中斷 | P07「puxou ela direto pro chão —」破折號懸停 | ✓ |
| 翻頁 hook P09 動作中斷 | P09「levantou um pé —」破折號懸停 | ✓ |
| 翻頁 hook P11 懸念 | P11「tec, tec, tec! Dedinha olhou pra porta — e esperou —」懸念 | ✓ |
| 擬聲 motif：咚 x3 | TUM! P01/P04/P07 = 3 次 | ✓ |
| 擬聲 motif：嘎 x2 | QUEC! P05/P08 = 2 次 | ✓ |
| 擬聲 motif：噗通 x1 | PLOFT! P08 = 1 次 | ✓ |
| 擬聲 motif：啵 x1 | TCHIBUM! P10 = 1 次 | ✓ |
| 擬聲 motif：啪嗒 x1 | tec, tec, tec! P11 = 1 次 | ✓ |
| 高潮 P10 | P10「Dedinha entrou com as três pedrinhas no bolso. / Colocou o patinho na água, devagarinho. / TCHIBUM! / Ele boiou.」＝跨門＋三石同在＋鴨入水 | ✓ |
| 幽默 P01 重力反差 | P01 口袋突然下垂身體帶歪 | ✓ |
| 幽默 P05 方向反轉 | P05「virou inteirinha de volta pra mamãe」整隻轉回 | ✓ |
| 幽默 P08 無害噗通 | P08「PLOFT!」被拉坐柔軟墊 | ✓ |
| 收束式 | P12「E desde aquele dia… elas davam as mãos em todo tchau e em todo oi.」 | ✓ |

設計外新增：無。

### 對位逐頁比對

逐頁核對 storyboard「文說什麼」負載欄 vs pt-BR 文本：

| 頁 | 判定 | 說明 |
|---|---|---|
| P01 | ✓ | 負載＝旁白告別情境＋擬聲咚。文本：旁白建立情境＋TUM!。不重述圖的視覺屬性。 |
| P02 | ✓ | 負載＝台詞疊句＋擔心＋需求＋旁白媽媽動作。文本：四行台詞＋一行旁白。不描述特寫畫面外觀。 |
| P03 | ✓ | 負載＝旁白約定＋放手＋第一步。文本：約定句＋放手＋passinho。聽覺自足。 |
| P04 | ✓ | 負載＝旁白移動＋擬聲咚＋動態。文本：移動＋TUM!＋puxou pra tras。 |
| P05 | ✓ | 負載＝擬聲嘎＋台詞疊句＋擔心＋需求。文本：QUEC!＋轉回敘述＋疊句＋擔心＋揮手請求。 |
| P06 | ✓ | 負載＝旁白揮手＋安全線索。文本：tchauzinho＋porta＋照顧者＋水盆。 |
| P07 | ✓ | 負載＝旁白告別＋擬聲咚＋最大重量。文本：disse tchau＋TUM!＋mais pesada＋pro chao。 |
| P08 | ✓ | 負載＝擬聲噗通/嘎＋台詞疊句＋擔心＋重逢＋旁白確認。文本：PLOFT!/QUEC!＋falou primeiro＋疊句＋擔心＋重逢確認＋Volto sim＋bolso saiu do chao。 |
| P09 | ✓ | 負載＝旁白站起＋揮手＋抬腳。文本：levantou sozinha＋tchauzinho＋levantou um pe。 |
| P10 | ✓ | 負載＝旁白跨門放鴨＋擬聲啵。文本：entrou com tres pedrinhas＋colocou na agua＋TCHIBUM!＋boiou。 |
| P11 | ✓ | 負載＝旁白玩完＋擬聲啪嗒。文本：brincado bastante＋tirou da agua＋tec tec tec＋esperou。 |
| P12 | ✓ | 負載＝旁白重逢＋台詞交流＋收束式。文本：voltou igualzinho prometeu＋展示台詞＋de mao dada＋E desde aquele dia。 |

**對位結論**：12 頁零違反。文字均承擔聲音/台詞/內心/時間等負載，無重述圖已明示的視覺屬性。Piyo 聽覺自足原則遵守——事件推進句（如 P05「virou inteirinha de volta」）為旁白直述畫面事件，合法（刪掉這句閉眼聽會漏掉情節）。

### concept fidelity 逐檔判定

| 檔位 | 判定 | 說明 |
|---|---|---|
| 5-6 | ✓ | 三輪完整：每輪先出現身體線索（被帶歪/轉回/被拉坐）→Dedinha 說出具體擔心（手放開/看不到/不回來）→提出需求（再握/揮手/確認重逢）→走下一步。核心教訓＝察覺線索→說出具體分離擔心→提出需求→走下一步。未被勇敢/獨立/完成任務取代。P08「Dedinha falou primeiro」＝第三輪主動性升級。石頭不消失只恢復普通重量。結局非「從此不焦慮」。 |
| 3-5 | ✓ | 砍 P03/P06 過渡頁，三輪因果完整保留。bridge 頁承接被跳內容（P04 bridge 承接 P03 的約定與第一步）。concept fidelity 無偏離。 |
| 2-3 | ✓ | 三次 TUM! 遞進 + 三次疊句 + 電報式擔心（Medo... de soltar a mao / nao vejo mamae / mamae nao volta）+ 三次需求。核心引擎完整。2-3 P08 bridge 第三輪簡化為「Mamae fez que sim」，保留確認不喪失因果。 |

**concept fidelity 結論**：三檔全通過。主題錨「說出具體分離擔心使石頭恢復普通重量」在三檔均完整保留，未被 forbidden substitutes 取代。

### ESL 獵手（pt-BR 翻譯腔獵手）

**主題錨復述句**：本書讓小水獺在三輪分離距離增加時，從身體線索察覺擔心、用疊句停一下再說出具體怕什麼、提出可完成的需求，才能走下一步；石頭不消失只變輕。

**獵物① 翻譯腔靶區**（pt-BR spec 雷區）：
- 被動語態 calque：全書掃描，無 en-US/zh-TW 式被動滲漏。所有句子均為主動態。✓
- 英語語序：全書語序為自然巴西式。代詞位置正確——對話用 proclisis（「— Me ajuda」模式不出現，但所有代詞位置均合法 BR 口語）。✓
- 形式語域混入幼兒文本：2-3 檔電報式「Medo…」碎句，語域自然偏低幼。3-5/5-6 旁白略正式但在 BR 童書 norma culta 輕量版範圍。✓
- diminutivos 使用：devagarzinho(P01), pedrinha(P01/P04/P07), passinho(P03), quietinha(P02), tchauzinho(P06/P09), pertinho(P06/P09), molhadinho(P11/P12), devagarinho(P10) — 自然分佈，無堆疊（同句不超過 1 個 diminutivo）。✓
- tu/voce 混用：全書統一 voce/vocês，零 tu 出現。✓
- 歐葡滲漏：無 estar a + infinitivo、無 PT-PT 詞彙、無 mamã（全用 mamãe 短形或 Mamãe Lontra）。✓

**獵物② AI 機械句**（style_guide 3.4）：
- 電報式裸動詞堆疊：2-3 檔 P09「Dedinha levantou. / Tchauzinho! / Levantou um pé —」為三拍片段句，有收束有拍點設計（tchauzinho! 為情緒拍點），屬 W7 合法電報式，非機械裸列。✓
- 成分懸空：全書無動詞著力點缺失。✓
- 超規律平行：三次疊句「— Espera — eu preciso falar!」逐字一致為刻意設計（B0 rulings 凍結），非無設計性機械重複。三次擔心句「Eu tenho medo… de X」為刻意平行結構（design.md theme_cycles 規格），有變奏（每輪內容不同）。✓
- 無語氣詞乾句：BR 口語語氣自然——P08 diminutivo、P12「igualzinho prometeu」「tá todo molhado」（口語縮合 está→tá），對話不乾。✓

**盲稿讀序結構分歧抽驗**：pt-BR 文本的改編痕跡與 B0 語感基建一致——角色名 Dedinha/Mamãe Lontra、擬聲 TUM!/QUEC!/PLOFT!/TCHIBUM!/tec,tec,tec!、疊句 travessão 制——均為 B0 提案凍結項，非 zh-TW/en-US 直譯痕跡。P05 5-6「de não enxergar você lá dentro」（看不到你在裡面）與 zh-TW「看不到媽媽」和 en-US「won't see you inside」均為各自自然表達，無句句對位跡象。讀序聲明可信。

**ESL 獵手結論**：零發現。pt-BR 文本語感自然，無翻譯腔或 AI 機械句。

### 回譯偏移標記（E 比對結果）

比對回譯 zh-TW vs 原始 zh-TW 母本：

| 檔位 | 頁 | 偏移 | 說明 |
|---|---|---|---|
| 5-6 | P01-P12 | 全部「無」 | 語義完整保留。P05 pt-BR 加了「lá dentro」（在裡面）為 B0 語感自建，不構成偏離。P08「Dedinha falou primeiro」＝主動先說，對應 zh-TW 設計意圖。P12 收束式語義完整。 |
| 3-5 | P01-P12 | 全部「無」 | bridge 頁語義承接正確。P04 bridge 承接 P03 的約定＋第一步。 |
| 2-3 | P01-P12 | 全部「無」 | 電報式壓縮保留核心語義。「Medo…」碎句對應 zh-TW「怕……」。 |

**回譯偏移結論**：全檔位零中度偏移。

### STEP 2 結論

文本階段適用項 19 項 + 快速掃描 9 項 = 28 項全通過（含 N/A 各類如實列出）。對位 12 頁零違反。concept fidelity 三檔全通。趣味設計兌現比對全項成立。ESL 獵手零發現。回譯零偏移。**STEP 2 通過**。

---

## STEP 3 人設 blind QA

### Persona 1: Professora Ana Clara (pt-BR-professora)

**身分**：聖保羅 educação infantil 教師十一年，roda de leitura 日常直覺。

**逐句挑錯**：

| 檔位 | 頁 | 原句（節錄） | 問題描述 | 嚴重度 | 建議改法 |
|---|---|---|---|---|---|
| 5-6 | P05 | de não enxergar você lá dentro | 「lá dentro」對 5-6 的 educação infantil 孩子稍長但可接受 | 低 | 可縮為「de não ver você」但原文也合理 |
| 2-3 | P09 | Dedinha levantou. / Tchauzinho! / Levantou um pé — | 三拍節奏很好唸，孩子可以跟拍手，但「Tchauzinho!」獨立一行感嘆效果強 | 低 | 品味級——保持原樣也完全可以 |
| 3-5 | P12 | elas davam as mãos em todo tchau e em todo oi | 「em todo tchau e em todo oi」節奏感很棒，roda de leitura 孩子會跟著拍 | — | 不是問題，是肯定 |

**分檔評分**：

年齡適配度：
- 5-6 = 8（每頁資訊量適中，三輪遞進清楚，P05「enxergar」可教但偏進階）
- 3-5 = 9（bridge 頁承接流暢，字數配比精準）
- 2-3 = 8（電報式節奏對 toddler 友好，但 P08 五行稍密）
- **摘要分＝8**（最弱 5-6/2-3）

巴西語感：
- 5-6 = 9（devagarzinho、pertinho、molhadinho 自然；travessão 制正確）
- 3-5 = 9（同上）
- 2-3 = 9（Mamãe 短稱、碎句「Medo…」像巴西 toddler 會說的話）
- **摘要分＝9**

孩子抓得住度：
- 5-6 = 8（三輪擬聲＋疊句是強力抓手；P06 過渡頁「alguém conhecido esperava」稍平但有安全感功能）
- 3-5 = 9（跳 P03/P06 後節奏更緊湊）
- 2-3 = 8（三次 TUM! + 三次疊句＝極強重複抓力；P09 六字頁是呼吸拍，roda de leitura 孩子會屏氣等翻頁）
- **摘要分＝8**（最弱 5-6/2-3）

### Persona 2: Camila (pt-BR-mae)

**身分**：BH 雙寶媽，hora de dormir 唸書，對翻譯腔極度敏感。

**逐句挑錯**：

| 檔位 | 頁 | 原句（節錄） | 問題描述 | 嚴重度 | 建議改法 |
|---|---|---|---|---|---|
| 5-6 | P08 | — Volto, sim — disse Mamãe Lontra. | 完全像我在家會說的話，零翻譯感 | — | 不是問題，是肯定 |
| 5-6 | P12 | o patinho tá todo molhado | 「tá」口語收束很舒服，hora de dormir 的溫度剛好 | — | 不是問題，是肯定 |
| 3-5 | P08 | — Volto, sim. | 比 5-6 更短更乾脆，雙寶媽模式下的回答就是這樣 | — | 肯定 |

**分檔評分**：

睡前適讀性：
- 5-6 = 9（情緒弧清楚，緊張段有擬聲緩衝（PLOFT! 好笑不嚇人），P12 收束溫暖）
- 3-5 = 9（更緊湊但依然回暖完整）
- 2-3 = 8（三次 TUM! 的密度對 hora de dormir 稍緊張，但每次後面立刻有疊句和安撫——整體適讀）
- **摘要分＝8**（最弱 2-3）

零說教：
- 5-6 = 10（旁白零教訓，Dedinha 的成長完全透過行動——P08 主動先說、P09 自己站起、P10 跨門放鴨）
- 3-5 = 10
- 2-3 = 10
- **摘要分＝10**

### Persona 3: Editora Beatriz (pt-BR-editora)

**身分**：里約童書出版社編輯十五年，專抓歐葡/英語直譯/中性葡語塑膠感。

**逐句挑錯**：

| 檔位 | 頁 | 原句（節錄） | 問題描述 | 嚴重度 | 建議改法 |
|---|---|---|---|---|---|
| 5-6 | P03 | Mamãe Lontra deu mais um aperto. — Eu volto quando o patinho acabar de brincar na água. | 旁白直接接 travessão 對話在同一行，排版稍擁擠，但不構成語法錯誤 | 低 | 品味級——分行更優但不影響正確性 |
| 3-5 | P12 | elas davam as mãos em todo tchau e em todo oi | 26w 稍超帶頂但收束式不可砍；「em todo tchau e em todo oi」韻律完美 | 低 | 品味級（收束式公式句合法超帶） |
| 5-6 | P01 | ficou pesado, pesado | 重複形容詞是 BR 兒語經典手法——「grande, grande」「forte, forte」——完全母語 | — | 肯定 |

**分檔評分**：

母語自然度：
- 5-6 = 9（devagarzinho/pertinho/molhadinho diminutivo 分佈自然；代詞位置正確；travessão 制完美；「tá」口語收束；零歐葡滲漏）
- 3-5 = 9（同上）
- 2-3 = 9（「Medo…」碎句＋「Mamãe fez que sim」像巴西幼兒對話）
- **摘要分＝9**

文字工藝：
- 5-6 = 8（三輪結構嚴密，疊句節奏感強，擬聲選字精準——TUM 比 BUM 更有「沉入」感；P12 收束式「em todo tchau e em todo oi」是本書最好的一句）
- 3-5 = 8（bridge 頁工藝到位——P04 承接兩頁資訊不臃腫）
- 2-3 = 8（電報式工藝——「Entrou! / Três pedrinhas no bolso! / TCHIBUM!」三拍高潮乾脆有力）
- **摘要分＝8**

---

## STEP 4 三分法分診

**主題錨復述句**：本書讓小水獺在三次分離距離增加時，從身體線索察覺到自己正在擔心，用疊句「等一下，我要說！」停一下再說出具體怕什麼（手放開/看不到/不回來），然後提出一個可完成的告別或重逢需求，再走下一小步。擔心是具體的石頭隱喻——說出後不消失、只恢復普通重量。勇敢/獨立/完成任務不取代核心引擎。

### 裁決表

| # | 來源 | 發現描述 | 裁決 | 修改級別 | 收斂計數 | 依據 |
|---|---|---|---|---|---|---|
| F1 | pt-BR-professora | 5-6 P05「enxergar」偏進階 | ❌ | — | 1路 | 5-6 檔允許進階詞（spec R2 建議「書面動詞留給 5-6 檔」）；enxergar（看見）在 BR 日常高頻，非進階詞。且 zh-TW 母本 P05 無此限制。拒絕。 |
| F2 | pt-BR-professora | 2-3 P09「Tchauzinho!」獨立行感嘆強 | ❌ | — | 1路 | 品味級。P09 為動作中斷 hook 頁（設計意圖），三拍節奏「Dedinha levantou. / Tchauzinho! / Levantou um pe —」為刻意設計。拒絕。 |
| F3 | pt-BR-editora | 5-6 P03 旁白與 travessao 對話同行排版擁擠 | ❌ | — | 1路 | 品味級。旁白接 travessao 在 BR 出版慣例中合法（A2 語料有同類排版）。且拆行會增加一行、不影響語義。拒絕。 |

**訊源計量行**：獨有訊源分佈：獵手獨有 real 0 | 回譯獨有 real 0 | 人設獨有 real 0 | 多路收斂 real 0

### ⏸️ 上呈批次

無。

### STEP 4 結論

✅ real = 0, ❌ rejected = 3, ⏸️ escalated = 0。**一輪 ✅=0，QA 收斂。**

---

## 收斂判定

Round 1 STEP 4 ✅=0，⏸️=0。pt-BR 泳道已收斂。

**verdict: pass**

三檔文本品質確認：
- 機檢全通過（零違規）
- E checklist 19+9 項全通過
- 對位零違反
- concept fidelity 三檔全通
- 翻譯腔獵手零發現
- 回譯零偏移
- 三人設均分 >=8（最低 8 分均附證據）
- 分診零 real、零 escalated
