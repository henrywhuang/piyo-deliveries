# QA 報告：whats-in-the-worry-pocket / es-MX / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: whats-in-the-worry-pocket
locale: es-MX
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-21"
step1_lint: {exit_code: 0, warnings: 11}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: es-MX-educadora
    scores: {年齡適配度: 7, 墨西哥語感: 8, 孩子抓得住度: 8}
  - id: es-MX-mama
    scores: {睡前適讀性: 7, 零說教: 6}
  - id: es-MX-editora
    scores: {母語自然度: 7, 文字工藝: 7}
step4_triage: {real: 3, rejected: 10, escalated: 1}
verdict: fix_required
```

## STEP 1 機檢

```bash
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-006_whats-in-the-worry-pocket/text/es-MX/5-6.draft.json --locale es-MX --band 5-6
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-006_whats-in-the-worry-pocket/text/es-MX/3-5.draft.json --locale es-MX --band 3-5
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-006_whats-in-the-worry-pocket/text/es-MX/2-3.draft.json --locale es-MX --band 2-3
```

三檔均 exit 0、零違規。警告 11 筆全為疊句折計通知（¡TUN! ×3、¡Espera, te quiero decir! ×3、¡CUAC! ×2），屬設計預期疊句，已依第 8 段折計規則正確折算。

- 5-6：折計後 374.75w ≤ 761（max_total_len），通過
- 3-5：折計後 250.75w ≤ 585，通過
- 2-3：折計後 92.25w ≤ 101，通過

¡¿ 開頭標點人工掃描：三檔全數感嘆句與問句均有完整 ¡¿ 配對，零漏。raya（U+2014）對話排版正確。重音符號完整（Mimi, Mama 等均帶 tilde）。刪節號均為 U+2026 單碼。

## STEP 2 checklist 自檢

**主題錨復述**：牽牽獺每次與媽媽的分離距離增加，口袋便咚地多一顆異常沉重的普通小石；只有她自己察覺身體線索、開口說出當下那一個具體的分離擔心並提出告別或重逢需求，石頭才恢復普通重量，讓她走下一步。勇敢、聽話、媽媽安撫皆不得替代此核心引擎；故事結果不得寫成牽牽從此不焦慮。

### A）故事結構（5/5 通過，三檔一致）

| 項目 | 判定 | 證據 |
|---|---|---|
| A-1 完整弧線 | PASS | 觸發=P01 石落袋；上升=P02-P08 三輪嘗試；高潮=P10 跨門；收束=P12 重逢。三檔均具備。 |
| A-2 衝突有份量 | PASS | 分離擔心讓口袋沉重，跨 P01-P10 方解決；Mimi 每輪付出「說出具體擔心＋提出需求」。 |
| A-3 情緒有起伏 | PASS | 期待→驚訝(P01)→被承接鬆動(P02)→再度失衡(P04-05)→最大低谷(P07-08)→踏實跨門(P10)→重逢(P12)。 |
| A-4 結尾有回響 | PASS | 三檔均以「Y desde ese dia...」圓滿呼應式收束，無旁白直陳教訓。 |
| A-5 開場有鉤子 | PASS | P01 反常型：媽媽才鬆手，口袋便咚地冒出石頭。 |

### B）語言文字（5/5 通過）

| 項目 | 判定 | 證據 |
|---|---|---|
| B-1 每頁字數 | N/A(量化) | STEP 1 機檢已判。 |
| B-2 句長配合情緒 | PASS | 緊張短句：¡TUN! 1w、¡PUM! 1w；溫馨長句：P03 約定句 9w、P12 收束句 15w。2-3 全短句符合低幼。 |
| B-3 聲音裝置 | PASS | 5 種擬聲詞（¡TUN!×3, ¡CUAC!×2, ¡PUM!×1, ¡PLAS!×1, toc,toc,toc!×1），均≤3 次。 |
| B-4 對話比例 | PASS | 5-6/3-5 旁白與台詞均衡；2-3 以台詞＋擬聲為主，符合各檔規格。 |
| B-5 無百科腔 | PASS | 全書無知識灌輸句式。 |

### C）角色塑造（4/4 通過）

| 項目 | 判定 | 證據 |
|---|---|---|
| C-1 主角有辨識度 | PASS | Mimi 透過三輪行動（先身體反應→開口說出）展現區分特質。 |
| C-2 成長弧線 | PASS | P02 被承接→P05 自行察覺→P08 主動先說（Mimi hablo primero）。 |
| C-3 障礙有阻力 | PASS | 口袋重量三次阻擋（P01 橫向帶歪、P04 向後轉、P07 垂直拉坐），每次更強。 |
| C-4 配角有功能 | PASS | Mama Nutria = 引導者（蹲下等待、確認重逢），不替 Mimi 命名擔心。 |

### D）圖文配合

| 項目 | 判定 | 證據 |
|---|---|---|
| D-1 圖文關係 | stage-N/A | 需插圖。 |
| D-2 圖畫承載 | stage-N/A | 需插圖。 |
| D-3 視覺風格 | stage-N/A | 需插圖。 |
| D-4 翻頁有牽引 | PASS | 5-6: P04/P07/P09 動作中斷＋P11 懸念 = 4 處。3-5: 同 4 處。2-3: P09/P11 = 2 處。 |

### E）主題思想（4/4 通過）

| 項目 | 判定 | 證據 |
|---|---|---|
| E-1 主題由行動呈現 | PASS | 「說出擔心讓石頭恢復普通重量」透過三輪行動自然浮現，無旁白總結。 |
| E-2 情感共鳴可達 | PASS | P08 Mimi 被拉坐、主動開口 = 行為間接呈現情緒。P12 piedritas 台詞。 |
| E-3 末頁無教訓宣言 | PASS | 三檔均無「Mimi aprendio que...」句式。 |
| E-4 抽象度匹配 | PASS | 2-3 無抽象概念詞；5-6「me da miedo que no regreses」有具體場景。 |

### 快速掃描（9 PASS + 1 stage-N/A）

| # | 判定 |
|---|---|
| 1-6, 8-10 | PASS |
| 7 (圖文關係) | stage-N/A |

### 趣味設計兌現比對

| 宣告 | 兌現 | 判定 |
|---|---|---|
| 開場鉤子（反常, P01） | P01 石頭突然出現 | PASS |
| 疊句（等一下我要說, P02/P05/P08, 變奏 P08） | 三檔三頁「¡Espera, te quiero decir!」逐字一致；P08 變奏 = Mimi 主動先說 | PASS |
| 翻頁 hook（動作中斷 P04/P07/P09, 懸念 P11） | P04 向後轉中途…、P07 最大重力…、P09 抬腳…、P11 腳步未揭 | PASS |
| 擬聲詞 motif（5 組） | ¡TUN!×3(石落袋)、¡CUAC!×2(鴨叫)、¡PUM!×1(拉坐)、¡PLAS!×1(入水)、toc,toc,toc!×1(腳步) | PASS |
| 高潮 P10 | P10 = 跨門＋放鴨入水 = 全書張力頂點 | PASS |
| 幽默（重力反差 P01, 方向反轉 P05, 無害噗通 P08） | P01 被帶歪、P05 被轉回、P08 被拉坐 + CUAC | PASS |
| 收束式 | 三檔均有「Y desde ese dia...」 | PASS |

設計外新增：無。

### 對位逐頁比對

三檔共 30 頁，逐頁檢查文字是否複述插圖已展示的視覺屬性。判準：「刪掉此句，閉眼聽的人會不會漏掉情節」（Piyo 聽覺自足）。

**結果：三檔零違反。** 文字嚴守事件敘述與台詞負載，未出現顏色、外觀、位置等視覺屬性複述。

### Concept Fidelity 逐檔判定

| 檔位 | 判定 | 說明 |
|---|---|---|
| 5-6 | PASS | 三輪完整展開；forbidden_substitutes 零觸：Mama Nutria 從未說「se valiente」或「no te preocupes」；P12 石頭仍在但不再阻止。 |
| 3-5 | PASS | 三輪因果鏈完整；P03 重逢約定移到 P04 橋接。 |
| 2-3 | PASS | 三次疊句＋三個不同擔心＋跨門＋重逢。P05 省略請求句但核心擔心保留。 |

### 回譯偏移標記摘要

全量覆蓋（三檔 30 頁）。偏移統計：
- 中度偏移：0 筆
- 輕微偏移：8 筆（5-6: P01/P02/P05/P06/P08/P10, 3-5: P02/P07/P09, 2-3: P02）
- 無偏移：22 筆

輕微偏移均屬改編合理範圍（如 es-MX 加 diminutive「de hule」、abrazo vs 握手的動作替換、en-US 同源行保留等），無語義漂移。中度以上偏移為零。

### ESL 獵手（es-MX）

**獵手人設**：母語資深 MX 編輯，雙獵物（翻譯腔 + AI 機械句）。

| # | 檔位 | 頁 | 原句 | 獵物類型 | 問題描述 |
|---|---|---|---|---|---|
| H1 | 5-6 | P04 | "dandole la vuelta..." | 英語句法 | gerundio 伴隨動作；MX 口語更傾向用 y 連接 |
| H2 | 5-6 | P06 | "una senora conocida" | 二手錨定(en-US) | 與 en-US "familiar grown-up" 語義對齊，zh-TW 僅「有人在等」 |
| H3 | 5-6 | P08 | "bolsillo se levanto del tapete" | 二手錨定(en-US) | en-US "pocket lifted off the mat" 同源，zh-TW 無此行 |
| H4 | 3-5 | P07 | "le dijo adios con la mano. Se despidio y se fue." | AI機械句 | 揮手道別 + 告別了 = 語義重疊 |
| H5 | 3-5 | P09 | "fue la primera en decir adios" | 翻譯腔 | 偏書面句構，MX 幼兒口語不自然 |

盲稿聲明交叉驗證結論：大致可信。B1 獨立寫作有結構歧異支持（patito de hule、derechita、te quiero decir），B2 校準時 en-US 二手錨定痕跡存在但可控。

## STEP 3 人設 blind QA

### es-MX-educadora (Maestra Lupita)

**發現：**

| # | 檔位 | 頁 | 原句（節錄） | 問題描述 | 嚴重度 |
|---|---|---|---|---|---|
| L1 | 5-6 | P06 | "una senora conocida" | 偏書面，MX 幼兒語境不夠口語 | 低 |
| L2 | 5-6 | P12 | "Mimi le enseno a su patito mojado" | ensenar 歧義（教 vs 展示） | 低 |
| L3 | 3-5 | P04 | 擁抱→TUN 轉折 | 節奏偏趕，溫暖感未留住就被打斷 | 中 |
| L4 | 3-5 | P05 | "no te veo" | 現在式 vs 未來式（5-6 用 no te voy a ver），簡化過頭 | 中 |
| L5 | 3-5 | P09 | "fue la primera en decir adios" | 句構偏複雜，3-5 歲不適配 | 低 |
| L6 | 2-3 | P05 | 頁內密度高（TUN+石頭+CUAC+疊句+恐懼） | 2-3 注意力一頁只能抓一事件 | 中 |
| L7 | 2-3 | P11 | "Su patito ya chapoteo" | pretérito 偏書面，2-3 少聽 | 低 |

**分數：**

| 維度 | 5-6 | 3-5 | 2-3 |
|---|---|---|---|
| 年齡適配度 | 8 | 7 | 8 |
| 墨西哥語感 | 9 | 8 | 8 |
| 孩子抓得住度 | 8 | 8 | 9 |

### es-MX-mama (Fernanda)

**發現：**

| # | 檔位 | 頁 | 原句（節錄） | 問題描述 | 嚴重度 |
|---|---|---|---|---|---|
| F1 | 5-6 | P12 | "en cada adios y en cada hola" | 格言感，睡前收尾偏「總結人生道理」 | 中 |
| F2 | 3-5 | P07 | "Se despidio y se fue" | 媽媽「走了」太乾，3-5 歲聽到會緊張 | 中 |
| F3 | 3-5 | P12 | 缺觸覺重逢動作 | ¡Regresaste! 後直接跳收束，少身體動作 | 低 |
| F4 | 2-3 | P05 | "¡No te veo!" 缺即時安撫 | 2-3 需即時安心，不能等三頁 | 中 |
| F5 | 2-3 | P12 | "Y desde ese dia..." | 兩歲檔位格言佔比過重 | 高 |

**分數：**

| 維度 | 5-6 | 3-5 | 2-3 |
|---|---|---|---|
| 睡前適讀性 | 7 | 7 | 7 |
| 零說教 | 7 | 7 | 6 |

### es-MX-editora (Editora Valeria)

**發現：**

| # | 檔位 | 頁 | 原句（節錄） | 問題描述 | 嚴重度 |
|---|---|---|---|---|---|
| V1 | 5-6 | P05 | "desde alla adentro" | 兩個方位詞疊加偏 forzado，疑 en-US "from in there" 映射 | 中 |
| V2 | 5-6 | P07 | "la jalo derecho hacia abajo" | "derecho hacia abajo" 疑 "straight down" calque | 中 |
| V3 | 5-6 | P12 | "tal como lo prometio" | 偏 literario，MX 口語不自然 | 低 |
| V4 | 3-5 | P09 | "fue la primera en decir adios" | 翻譯味句構 | 中 |
| V5 | 5-6 | P01 | "lo jalo" pronoun → "¡Que pesada!" gender switch | 微 tropiezo 指代跳躍 | 低 |
| V6 | 2-3 | P11 | "Su patito ya chapoteo" | pretérito 偏 puntual，語境需完成義 | 中 |

**分數：**

| 維度 | 5-6 | 3-5 | 2-3 |
|---|---|---|---|
| 母語自然度 | 7 | 8 | 8 |
| 文字工藝 | 8 | 8 | 7 |

## STEP 4 三分法分診

**裁決主題錨復述**：本書核心引擎是「每輪分離距離增加→口袋多石→Mimi 察覺身體線索→開口說出具體分離擔心＋提出告別/重逢需求→石頭恢復普通重量→走下一步」。勇敢、聽話、媽媽安撫不得替代；結局不得寫成不再焦慮。

裁決 lock-in 上下文已讀：es-MX spec 全文、design.md concept_contract、storyboard 圖文分工欄、style_guide、character_names.md、onomatopoeia_map.md。

### 裁決表

| # | 訊源 | 頁 | 發現摘要 | 裁決 | 依據 | 修改級別 | 收斂計數 |
|---|---|---|---|---|---|---|---|
| T1 | H4+L5+V4 | 3-5 P09 | "fue la primera en decir adios" 偏書面翻譯味 | ✅ | 3 路收斂（獵手＋教育者＋編輯）；spec R2.4「旁白簡潔敘事書面體」但此為角色行動旁白，應貼幼兒口語；style_guide「旁白有戲不上課」 | 句級 | 3 路 |
| T2 | H4 | 3-5 P07 | "le dijo adios con la mano. Se despidio y se fue." 語義重疊 | ✅ | 獵手獨有但 F2 也指向同頁不同面向（太乾），2 路指向 P07；合併為一個揮手+離開動作即可 | 句級 | 2 路 |
| T3 | V1 | 5-6 P05 | "desde alla adentro" 雙方位詞疊加 | ✅ | 編輯獨有；spec 無明文禁，但 R2.4 旁白簡潔原則＋calque 風險 | 字串級 | 1 路 |
| T4 | L2 | 5-6 P12 | "enseno" 歧義（教 vs 展示） | ❌ | MX 口語 ensenar=mostrar 合法（DAMER 有案）；非歧義而是雙義共存，不致誤解 | — | 1 路 |
| T5 | L1+V2 | 5-6 P06/P07 | "senora conocida" 偏書面 / "derecho hacia abajo" calque | ❌ | P06 señora conocida 服務聽覺自足（storyboard 指定安全線索）；P07 derecho = MX 口語副詞，非 calque（DAMER：derecho adv. = directamente）。品味級。 | — | 2 路 |
| T6 | L3 | 3-5 P04 | 擁抱→TUN 節奏偏趕 | ❌ | 3-5 取捨方向 = 砍過渡頁、壓縮，節奏加速是設計意圖（design 6 三檔取捨方向）；P04 橋接 P03+P04 的結構已確認合法 | — | 1 路 |
| T7 | L4 | 3-5 P05 | "no te veo" vs "no te voy a ver" | ❌ | 3-5 的簡化為合理取捨；「no te veo」語法正確且 3-5 歲理解力足（現在式表將來為西語口語常見）；5-6 版保留完整未來式，檔位差異合理 | — | 1 路 |
| T8 | L6 | 2-3 P05 | 頁內密度高 | ❌ | 2-3 P05 為 11w ≤ 16w 門檻；橋接 P04/P05 兩 beat 是 2-3 選用表（跳 P03/P04）的必然結果；聲音詞本身不加認知負載，是節奏裝置 | — | 1 路 |
| T9 | F1+F5 | 全檔 P12 | 收束式「Y desde ese dia...」格言感 | ⏸️ | 2 路收斂（媽媽人設 5-6+2-3 P12）。收束式「Y desde ese dia...」是 copy commitments 鎖定、style_guide F10 2-3 必備、en-US「And from that day on...」跨語同形——lock-in 明確。但 F5 指出 2-3 檔位「desde ese dia」對兩歲語境偏重。裁決傾向保留（lock-in），上呈 2-3 收束式措辭微調是否屬 piyo-localize 權限。 | — | 2 路 |
| T10 | V3 | 5-6 P12 | "tal como lo prometio" 偏 literario | ❌ | 品味級；3-5/2-3 已無此句（自然砍掉），5-6 作為最高檔位允許輕微書面色彩 | — | 1 路 |
| T11 | H2+H3 | 5-6 P06/P08 | en-US 二手錨定行 | ❌ | P06 señora conocida 服務安全線索（storyboard 指定）；P08 bolsillo se levanto = 核心隱喻裝置（口袋變輕），design metaphor_rules 明確支持。兩行均有功能理由，非無意識照搬。 | — | 2 路 |
| T12 | V5 | 5-6 P01 | "lo jalo"→"¡Que pesada!" 指代跳躍 | ❌ | lo 指 bolsillo、pesada 指 piedra，語法正確；前後文語境清楚，不致幼兒誤解 | — | 1 路 |
| T13 | V6+L7 | 2-3 P11 | "Su patito ya chapoteo" pretérito | ❌ | 西語 pretérito 用於表達已完成事件（ya chapoteo = 已經玩完了），語法正確。「ya」作完成標記 + pretérito 是 MX 口語常見組合。zh-TW 亦用完成式「玩完水了」。品味級。 | — | 2 路 |
| T14 | F4 | 2-3 P05 | "¡No te veo!" 缺即時安撫 | ❌ | 2-3 選用表跳 P03/P06（過渡安撫頁），此為設計意圖。2-3 聽覺加上圖畫的安全線索足夠；加安撫句會超門檻或削弱疊句的情緒密度 | — | 1 路 |

**訊源計量行**：獵手獨有 real 0 | 回譯獨有 real 0 | 人設獨有 real 0 | 多路收斂 real 3

### ✅ 回修清單

| # | 檔位 | 頁 | 當前文字 | 修改 | 級別 |
|---|---|---|---|---|---|
| T1 | 3-5 | P09 | "Mimi se paro y fue la primera en decir adios." | → "Mimi se paro solita y dijo adios primero." | 句級 |
| T2 | 3-5 | P07 | "Mama Nutria le dijo adios con la mano.\nSe despidio y se fue." | → "Mama Nutria le dijo adios con la mano y se fue despacito." | 句級 |
| T3 | 5-6 | P05 | "no te voy a ver desde alla adentro" | → "no te voy a ver desde adentro" | 字串級 |

三筆均 ∈ {字串級, 句級} → round 2 具復核輪資格。

### ⏸️ 上呈批次

| # | 涉及頁 | 為什麼裁決不了 | 裁決傾向 |
|---|---|---|---|
| T9 | 全檔 P12 | 收束式「Y desde ese dia...」是 copy commitments lock-in 且 style_guide F10 必備；但 2-3 檔位「desde ese dia」對兩歲語境是否需要微調措辭（如改為「Y se tomaron de la mano...」去掉時間抽象），涉及跨語收束式一致性，屬 piyo-localize 權限 | 傾向保留原文（lock-in 明確、zh-TW 同樣 20 字收束式已記為 spec/design 衝突 escalation），但 Stacy 若指示可微調 2-3 |
