# QA 報告：whats-in-the-worry-pocket / es-MX / round 2（復核輪）

```yaml
schema: piyo_text_qa_report/v0.9
slug: whats-in-the-worry-pocket
locale: es-MX
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-21"
step1_lint: {exit_code: 0, warnings: 11}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: es-MX-educadora
    scores: {年齡適配度: 7, 墨西哥語感: 8, 孩子抓得住度: 8}
  - id: es-MX-mama
    scores: {睡前適讀性: 7, 零說教: 6}
  - id: es-MX-editora
    scores: {母語自然度: 7, 文字工藝: 7}
step4_triage: {real: 0, rejected: 0, escalated: 1}
verdict: escalated
```

> **復核輪聲明**：R1 三筆 ✅ 全數 ∈ {字串級, 句級}，符合復核輪資格（SKILL.md v0.14）。本輪執行：STEP 1 機檢全量重跑 + 修改逐筆落地驗證 + copy↔draft 同源檢 + E-lite（受修頁及相鄰頁）+ 受修頁回譯同步。人設不重跑，分數沿用 R1。

## STEP 1 機檢

### 全量重跑

三檔 locale_lint 均 exit 0：
- 5-6：折計後 373.75w ≤ 761，通過
- 3-5：折計後 247.75w ≤ 585，通過
- 2-3：未修改，92.25w ≤ 101，通過

### 修改逐筆落地驗證（diff 對裁決內容核銷）

| T# | 裁決指定內容 | 實際落地 | 核銷 |
|---|---|---|---|
| T1 | 3-5 P09「Mimi se paro y fue la primera en decir adios」→「Mimi se paro solita y dijo adios primero.」 | 3-5.draft.json P09: "Mimí se paró solita y dijo adiós primero." ✓ | ✓ |
| T2 | 3-5 P07 前兩行合併「Mama Nutria le dijo adios con la mano y se fue despacito.」 | 3-5.draft.json P07: "Mamá Nutria le dijo adiós con la mano y se fue despacito." ✓ | ✓ |
| T3 | 5-6 P05「desde alla adentro」→「desde adentro」 | 5-6.draft.json P05: "no te voy a ver desde adentro" ✓ | ✓ |

三筆全部逐字核銷通過。

## copy↔draft 同源檢

copy/es-MX.md P05（5-6 欄）、P07（3-5 欄）、P09（3-5 欄）均已同步更新，與 draft json 一致。

## STEP 2 checklist 自檢

> 復核輪：E-lite 取代完整 STEP 2。checklist pass/fail 沿用 R1（28/0）。

## STEP 3 人設 blind QA

> 復核輪：人設不重跑，分數沿用 R1。

### E-lite（受修頁及相鄰頁）

**主題錨復述**：牽牽獺每次分離距離增加，口袋多石；只有她開口說出具體分離擔心、提出告別/重逢需求，石頭才恢復普通重量讓她走下一步。

受修頁：5-6 P05、3-5 P07、3-5 P09。相鄰頁：5-6 P04/P06、3-5 P05/P08、3-5 P08/P10。

| 頁 | 判定 | 說明 |
|---|---|---|
| 5-6 P04 | PASS | 未修改，與受修 P05 銜接正常。 |
| 5-6 P05 | PASS | 「desde adentro」語義完整，聽覺自足。負載不變（第二個擔心＋請求揮手）。 |
| 5-6 P06 | PASS | 未修改，接收 P05 不受影響。 |
| 3-5 P05 | PASS | 未修改，與受修 P07 之間為正常 beat 銜接。 |
| 3-5 P07 | PASS | 合併後「le dijo adios con la mano y se fue despacito」語義完整，消除重疊。「despacito」添加溫度暗示（媽媽慢慢走），與 spec diminutives 建議一致。 |
| 3-5 P08 | PASS | 未修改，接收 P07 不受影響。 |
| 3-5 P09 | PASS | 「se paro solita y dijo adios primero」更貼幼兒口語，「solita」增 MX diminutive 溫度，「primero」保留主動性標記。與 5-6 P09「se levanto solita」呼應一致。 |
| 3-5 P10 | PASS | 未修改，接收 P09 不受影響。 |

Alignment、concept fidelity 不受影響（三筆修改均不動 beat 語義、不觸主題錨）。

## 受修頁回譯同步

3-5 P07 回譯更新：「水獺媽媽向她揮手道別，慢慢走了。」偏移標記：無（語義與 zh-TW 3-5 P05「媽媽揮了揮手」對齊、動作合併合理）。

3-5 P09 回譯更新：「咪咪自己站了起來，先說了再見。」偏移標記：無（「solita＋先說再見」與 zh-TW 3-5 P07「牽牽站起來，對媽媽揮揮手」語義一致）。

5-6 P05 回譯更新：「我害怕……從裡面看不到你。」偏移標記：無（刪「alla」不改語義）。

## STEP 4 三分法分診

本輪新增 ✅ = 0、❌ = 0。R1 ⏸️ T9（2-3 P12 收束式）carry-over 上呈（escalated = 1）。

**收斂判定**：✅ = 0 且無新發現 → es-MX QA 收斂。

## verdict 說明

文本品質收斂、三筆回修落地驗證通過。verdict 為 `escalated`，原因：R1 T9 ⏸️ 未裁決（2-3 P12 收束式措辭是否微調屬跨語決策層，需 Stacy / piyo-localize 裁量）。保留此 escalated verdict；gate4 證據包供 Stacy 選閱。
