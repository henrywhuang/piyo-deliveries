# 關卡WB整合審閱：擔心口袋裡有什麼？（E 對位底稿／es-MX）

- 生成時間：2026-07-21 17:44:45 +0800
- 書目錄：`content/PYO-006_whats-in-the-worry-pocket`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate WB`（決定性腳本，純解析＋排版）
- locale：es-MX
- 用途：E 主審與裁決 agent 的單檔輸入 bundle——文字＝QA 對象本體逐字轉錄；可疑頁保留開原檔抽驗權

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-006_storyboard.md` | 2026-07-21 17:08:45 |
| copy | `copy/es-MX.md` | 2026-07-21 17:31:50 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-21 17:08:45 |
| text/es-MX/5-6 | `text/es-MX/5-6.draft.json` | 2026-07-21 17:21:02 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-21 17:08:45 |
| text/es-MX/3-5 | `text/es-MX/3-5.draft.json` | 2026-07-21 17:38:25 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-21 17:08:45 |
| text/es-MX/2-3 | `text/es-MX/2-3.draft.json` | 2026-07-21 17:38:25 |
| qa/es-MX/backtranslation.md | （缺） | — |

## 檔頭 commitments 逐字轉錄（兌現比對用）

```yaml
schema: piyo_copy/v0.9
slug: whats-in-the-worry-pocket
locale: es-MX
mode: B
storyboard: content/PYO-006_whats-in-the-worry-pocket/PYO-006_storyboard.md
design: content/PYO-006_whats-in-the-worry-pocket/PYO-006_design.md
image_pool: 12
selection:
  "3-5": [P01, P02, P04, P05, P07, P08, P09, P10, P11, P12]
  "2-3": [P01, P02, P05, P08, P09, P10, P11, P12]
commitments:
  refrain: "¡Espera, te quiero decir!"
  ending: "Y desde ese día…"
  onomatopoeia: ["¡TUN!", "¡CUAC!", "¡PUM!", "¡PLAS!", "toc, toc, toc!"]
characters: [Mimí, Mamá Nutria]
```

## 檔位 5-6（12 頁）

### 5-6｜P01（母版 P01）

- 圖說什麼：日間柔光遊戲室門口全景。低矮門檻左側，幼年水獺牽牽（淺棕絨毛、深棕尾尖、海藍吊帶褲含超大前口袋）右手抱一隻小黃鴨，左手朝水獺媽媽（深棕水獺、米色上衣、湖綠長褲、寬厚尾巴，約 1.3 倍高）伸出；媽媽的手正從牽牽左手鬆開。鬆開瞬間口袋裡新出現一顆圓潤小石，口袋因異常重量向下垂墜，整隻牽牽的身體被帶歪——右肩往口袋側沉、左腳微離地，表情從期待變驚訝（嘴微張、眼圓）。門內隱約可見低水盆一角與熟悉照顧者模糊身影。<br>構圖裝置：人物偏左＋右向留白<br>
- 文說什麼：旁白：告別情境建立（媽媽鬆手、口袋突然變重）<br>擬聲：咚（第一顆石落袋）
- 鉤子：—
- 選圖與提純說明：5-6 completa: llegada, suelta, piedra, peso. 3-5 abrevia: sin hule ni despacito. 2-3 telegráfico: suelta, piedra, exclamación.
- 匹配欄：✓

【zh-TW】
牽牽抱著小黃鴨，準備去玩水。
媽媽慢慢鬆開手——
咚！
口袋突然多了一顆小石頭，好重好重。

【es-MX】
Mimí llegó a chapotear con su patito de hule. Mamá Nutria soltó despacito la mano de Mimí.
¡TUN!
Una piedra cayó en el bolsillo de Mimí y lo jaló hacia abajo. ¡Qué pesada!

### 5-6｜P02（母版 P02）

- 圖說什麼：牽牽與媽媽臉部至胸部特寫。媽媽蹲到牽牽同高，雙手打開向前、掌心朝上，表情溫暖安靜地等待。牽牽看見自己仍抓緊的左手，表情從緊張轉為認真——眉頭稍擠、嘴巴打開正在說話。口袋裡一顆小石清晰可見但口袋已不下垂（石頭恢復普通重量、身體重新站直）。小黃鴨安穩地夾在牽牽右臂與身體之間。<br>構圖裝置：雙人同高對視<br>
- 文說什麼：台詞：疊句「等一下，我要說！」＋第一個擔心（怕手放開）＋請求再握一下後告別<br>旁白：媽媽蹲下、打開手掌、安靜等待
- 鉤子：—
- 選圖與提純說明：Ronda 1: miedo a soltar + pedido de abrazo. 2-3 solo台詞, sin旁白.
- 匹配欄：✓

【zh-TW】
媽媽蹲下來，打開手掌，安靜等著。
「等一下，我要說！」
「我怕…… 手放開。」
「再握一下，好不好？」

【es-MX】
Mamá Nutria se agachó, abrió las manos y esperó.
—¡Espera, te quiero decir!
Me da miedo… me da miedo soltar la mano.
¿Un abrazo más antes de decir adiós? —dijo Mimí.
Mimí se paró derechita.

### 5-6｜P03（母版 P03）

- 圖說什麼：大量留白中，牽牽獨自帶著小黃鴨朝畫面右側邁出一小步，表情略帶認真的小小自信（嘴角微揚但眼神專注前方）。口袋含一顆石但不再下垂。身後遠處媽媽的輪廓清楚可見（站著、面向牽牽）。<br>背景細節層：柔軟入口墊上有一個淺淺的小腳印——先前有孩子從這裡走進去過。<br>構圖裝置：前方留白引導<br>
- 文說什麼：旁白：媽媽用一句話約定水盆遊戲結束後回來<br>旁白：再握一下放手，牽牽帶鴨前進第一步
- 鉤子：—
- 選圖與提純說明：Solo 5-6: pacto concreto de regreso + primer paso.
- 匹配欄：✓

【zh-TW】
媽媽小聲說：「小黃鴨玩完水，我就回來。」
再握一下，放開。
牽牽抱著小黃鴨，往前走了一小步。

【es-MX】
Mamá Nutria le dio un abrazo más. —Voy a regresar cuando tu patito termine de chapotear.
Después soltó la mano, y Mimí dio un pasito con su patito.

### 5-6｜P04（母版 P04）

- 圖說什麼：牽牽帶著小黃鴨往門檻方向走，身體重心向前——但口袋突然多出第二顆石，重量把口袋往身後甩，整隻小水獺正在被向後旋轉：前腳腳尖仍朝前但身體已開始轉，表情驚慌（眼圓睜、嘴微張）。小黃鴨被擠在臂彎裡即將發聲。畫面左後方可見媽媽站在門側（與牽牽距離比 P01 更遠）。動作凍結在旋轉中途。<br>構圖裝置：對角動線<br>
- 文說什麼：旁白：媽媽往門側移動一步<br>擬聲：咚（第二顆石落袋）<br>旁白：前進中被口袋往後甩的動態
- 鉤子：動作中斷型：牽牽往前走卻被第二顆石的重量猛地往後甩，身體正在旋轉中途——翻頁才見她轉回媽媽。
- 選圖與提純說明：5-6 hook: segunda piedra jala hacia atrás. 3-5 bridge P03+P04: pacto + paso + segunda piedra.
- 匹配欄：✓

【zh-TW】
媽媽往門邊走了一步。
牽牽也往前走——
咚！
口袋用力往後一甩。

【es-MX】
Mamá Nutria dio un paso hacia la puerta. Mimí siguió caminando.
¡TUN!
Otra piedra cayó en su bolsillo. La jaló hacia atrás, dándole la vuelta…

### 5-6｜P05（母版 P05）

- 圖說什麼：牽牽已完全轉回面向媽媽（背部朝門檻方向），表情先狼狽再認真——正在開口說話。小黃鴨被擠到微變形、嘴微張。口袋含兩顆石但不再向後甩（兩顆石恢復普通重量）。媽媽蹲到同高、雙手打開掌心朝上，表情與 P02 同樣溫暖等待。背景可見門檻線位置。<br>構圖裝置：雙人同高對視<br>
- 文說什麼：擬聲：嘎（小黃鴨被擠）<br>台詞：疊句「等一下，我要說！」＋第二個擔心（怕看不到媽媽）＋請媽媽在門口揮手
- 鉤子：—
- 選圖與提純說明：Ronda 2: miedo a no ver a Mamá + pedido de adiós con la mano. 2-3 bridge: integra segunda piedra + pato + refrain + miedo.
- 匹配欄：✓

【zh-TW】
嘎！小黃鴨被擠了一下。
「等一下，我要說！」
「我怕…… 看不到媽媽。」
「在門口揮揮手，好嗎？」

【es-MX】
¡CUAC!
Mimí quedó volteada hacia Mamá Nutria.
—¡Espera, te quiero decir!
Me da miedo… no te voy a ver desde allá adentro.
¿Me dices adiós con la mano desde la puerta?
Mimí volteó hacia el salón de juegos.

### 5-6｜P06（母版 P06）

- 圖說什麼：門框自然將畫面分為左右兩區。右側（門內）：唯一低水盆、熟悉照顧者安靜坐在旁邊，暖色室內光。左側（門外）：牽牽站在門檻線上，抱著小黃鴨望向門內水盆，表情踏實（小微笑、肩膀放鬆）。口袋含兩顆石但垂度正常。遠處左後方媽媽站立做一個短揮手（手勢不誇張）。<br>背景細節層：門框邊貼了一張小小的手印畫——遊戲室裡有其他孩子留下的溫暖痕跡。<br>構圖裝置：門框分割<br>
- 文說什麼：旁白：媽媽沿用同一短揮手<br>旁白：牽牽走到門檻線，看見安全線索
- 鉤子：—
- 選圖與提純說明：Solo 5-6: respuesta de Mamá + línea de seguridad (cuidadora conocida + tina).
- 匹配欄：✓

【zh-TW】
媽媽在門口，輕輕揮了揮手。
牽牽走到門檻邊——裡面有人在等，還有那個水盆。

【es-MX】
Mamá Nutria le dijo adiós con la mano. Mimí caminó hasta la puerta.
Adentro, una señora conocida esperaba junto a la tina de agua.

### 5-6｜P07（母版 P07）

- 圖說什麼：俯角望下。牽牽剛抬起一腳要跨過門檻，第三顆也是最大的一顆石墜入口袋——口袋垂直落向柔軟入口墊，把牽牽整個身體往下拉。抬起的腳懸在半空、另一腳開始打滑。表情從堅定瞬間變為驚恐（眼睛最圓、嘴巴張到最大）。小黃鴨在臂彎裡即將脫手。口袋裡三顆石的重量讓布料繃緊下墜。畫面上方門檻線橫跨。動作凍結在最大重量爆發的瞬間。<br>構圖裝置：垂直壓迫<br>
- 文說什麼：旁白：媽媽完成約定的短告別、準備走出視線<br>擬聲：咚（第三顆最沉的石）<br>旁白：抬腳越門時最大重量墜下
- 鉤子：動作中斷型：第三顆最沉的石在牽牽抬腳越門時墜下，口袋垂直落向柔軟入口墊——翻頁才見最大重力後果。
- 選圖與提純說明：5-6 hook: tercera piedra (más pesada) jala hacia abajo. 3-5 bridge P06+P07: adiós con mano + despedida + tercera piedra.
- 匹配欄：✓

【zh-TW】
媽媽說完再見，轉身要走了。
牽牽剛抬起腳——
咚！
最重的一顆石頭掉進口袋。

【es-MX】
Mamá Nutria se despidió y se dio la vuelta para irse. Mimí levantó un pie hacia la puerta.
¡TUN!
La tercera piedra, la más pesada de todas, cayó en su bolsillo y la jaló derecho hacia abajo…

### 5-6｜P08（母版 P08）

- 圖說什麼：牽牽坐在柔軟入口墊上（被垂直拉坐的結果），表情從短暫驚嚇轉為主動認真——嘴巴張開正在說話、眼神直視媽媽不再閃避。小黃鴨剛從彈起落回牽牽腿邊（稍歪）。口袋攤在墊面上，三顆石可見但布料開始鬆弛（不再繃緊——三顆石逐一恢復普通重量）。媽媽蹲到比 P02、P05 更低（配合牽牽坐姿高度），雙手打開掌心朝上，表情一致的溫暖等待。牽牽肩膀已從縮緊開始抬起。<br>構圖裝置：雙人同高對視<br>
- 文說什麼：擬聲：噗通（被拉坐）＋嘎（小黃鴨彈起）<br>台詞：疊句「等一下，我要說！」＋第三個擔心（怕媽媽不回來）＋確認玩完水後重逢<br>旁白：媽媽一句話確認並安靜等待
- 鉤子：—
- 選圖與提純說明：Ronda 3: Mimí habla primero, miedo a que Mamá no regrese + confirma reencuentro. 2-3 bridge: integra tercera piedra + plop + pato + pregunta directa.
- 匹配欄：✓

【zh-TW】
噗通！
嘎！小黃鴨彈了起來。
「等一下，我要說！」
「我怕…… 媽媽不回來。」
「玩完水，你會來嗎？」
媽媽點點頭：「會的。」

【es-MX】
¡PUM!
¡CUAC!
Mimí habló primero.
—¡Espera, te quiero decir!
Me da miedo… que no regreses.
¿Vas a regresar cuando mi patito termine de chapotear?
—Sí. Voy a regresar —dijo Mamá Nutria.
El bolsillo de Mimí se levantó del tapete.

### 5-6｜P09（母版 P09）

- 圖說什麼：仰角特寫。牽牽的臉與上半身填滿畫面，表情堅定而平靜（嘴唇抿住、眼神前望不回頭）。一隻手抱著小黃鴨貼在胸前，另一隻手向畫面左上方（身後媽媽方向）做出一個小揮手。畫面下緣可見牽牽的一隻腳正抬起跨過門檻邊緣——腳在仰角中顯得大而有力。口袋含三顆石但垂度正常、不拉扯。門檻線在牽牽身後形成一道水平分割。<br>構圖裝置：低角仰望<br>
- 文說什麼：旁白：牽牽自己站起來，先揮手短告別<br>旁白：抱著小黃鴨抬腳越過門檻
- 鉤子：動作中斷型：牽牽主動揮手告別後抬腳越門——翻頁才完成跨門與放鴨。
- 選圖與提純說明：Hook: adiós voluntario + pie en el aire. 2-3 fragmentos telegráficos.
- 匹配欄：✓

【zh-TW】
牽牽自己站了起來。
她對媽媽揮揮手，抱著小黃鴨，抬起腳——

【es-MX】
Mimí se levantó solita. Le dijo adiós a Mamá Nutria con la mano y abrazó a su patito.
Levantó un pie para cruzar la puerta…

### 5-6｜P10（母版 P10）

- 圖說什麼：滿版。水盆遊戲角全景：普通低水盆居畫面中央偏右，水面柔和反射日間光線。牽牽站在水盆旁，身體前傾，雙手正將小黃鴨放入水面——鴨子半入水、水花微微濺起。口袋含三顆石但垂度正常，不再拉扯身體。牽牽表情平靜滿足（微笑、眼睛溫柔望著鴨子）。背景：門口方向可見但媽媽已離開（門開著、光線從門口透入）；熟悉照顧者在畫面遠處安靜坐著。整個空間暖色調、安穩。<br>構圖裝置：中央聚焦<br>
- 文說什麼：旁白：跨過門檻，把小黃鴨放進水盆<br>擬聲：啵（小黃鴨落進水面）
- 鉤子：—
- 選圖與提純說明：Clímax: cruza, baja pato, splash, flota. 2-3 exclamaciones de logro.
- 匹配欄：✓

【zh-TW】
牽牽跨過門檻，把小黃鴨輕輕放進水盆。
啵！
小黃鴨浮了起來。

【es-MX】
Mimí cruzó la puerta con las tres piedras en su bolsillo.
Bajó a su patito de hule hasta el agua.
¡PLAS!
Se quedó flotando.

### 5-6｜P11（母版 P11）

- 圖說什麼：牽牽半身像，坐在水盆旁邊（水盆下方邊緣可見一角，小黃鴨濕漉漉地被撈出放在盆邊）。牽牽抬頭望向畫面左側（門口方向），表情驚喜而期待（眼睛亮、嘴巴微張）。一隻小圓耳微微豎起——正在聽。門口方向有柔和光線照入但來者尚未入畫。口袋安穩垂在身側，三顆石不顯眼。<br>構圖裝置：視線引導<br>
- 文說什麼：旁白：水盆遊戲結束<br>擬聲：啪嗒（門外熟悉的腳步聲）
- 鉤子：懸念型：水盆遊戲結束時門外傳來熟悉腳步，牽牽抬頭望向尚未揭示來者的門口——翻頁才揭示媽媽如約返回。
- 選圖與提純說明：Hook suspense: pasos familiares sin revelar quién. 2-3 invierte orden para rematar con exclamación.
- 匹配欄：✓

【zh-TW】
小黃鴨在水盆裡玩夠了。
啪嗒，啪嗒。
門外傳來好熟悉的腳步聲。

【es-MX】
Se acabó la hora de chapotear. Mimí sacó a su patito mojado.
Entonces se oyeron unos pasos que Mimí conocía bien:
toc, toc, toc!
Miró hacia la puerta… y esperó…

### 5-6｜P12（母版 P12）

- 圖說什麼：滿版暖色調。水盆遊戲角門口處，水獺媽媽（完整出現、與 P01 相同的深棕毛色米色上衣湖綠長褲寬厚尾巴）站在門口微蹲著張開雙臂。牽牽從水盆方向小跑迎向媽媽，一手提著濕漉漉的小黃鴨，另一手指著自己的口袋——口袋裡三顆小石微微露出一角。牽牽表情安心喜悅（最大的笑容、眼睛彎彎）。水盆在畫面右後方。<br>背景細節層：水盆裡多了一隻小塑膠魚——牽牽玩水時有人悄悄放進去的。<br>構圖裝置：前景後景對位
- 文說什麼：旁白：媽媽如約回到門口<br>台詞：重逢交流（牽牽展示小石和小黃鴨）<br>旁白：收束式（「後來呀……」）
- 鉤子：—
- 選圖與提純說明：Reencuentro: Mamá cumple promesa. 5-6 muestra piedras + pato mojado. 2-3 solo la emoción + cierre.
- 匹配欄：✓

【zh-TW】
媽媽回來了！
「你看，小石頭還在，小黃鴨濕濕的！」
後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。

【es-MX】
Mamá Nutria regresó, tal como lo prometió.
Mimí le enseñó a su patito mojado. —¡Mis piedritas siguen aquí… y tú también!
De la mano, se fueron caminando a casa.
Y desde ese día… se tomaron de la mano en cada adiós y en cada hola.

## 檔位 3-5（10 頁）

### 3-5｜P01（母版 P01）

- 圖說什麼：日間柔光遊戲室門口全景。低矮門檻左側，幼年水獺牽牽（淺棕絨毛、深棕尾尖、海藍吊帶褲含超大前口袋）右手抱一隻小黃鴨，左手朝水獺媽媽（深棕水獺、米色上衣、湖綠長褲、寬厚尾巴，約 1.3 倍高）伸出；媽媽的手正從牽牽左手鬆開。鬆開瞬間口袋裡新出現一顆圓潤小石，口袋因異常重量向下垂墜，整隻牽牽的身體被帶歪——右肩往口袋側沉、左腳微離地，表情從期待變驚訝（嘴微張、眼圓）。門內隱約可見低水盆一角與熟悉照顧者模糊身影。<br>構圖裝置：人物偏左＋右向留白<br>
- 文說什麼：旁白：告別情境建立（媽媽鬆手、口袋突然變重）<br>擬聲：咚（第一顆石落袋）
- 鉤子：—
- 選圖與提純說明：5-6 completa: llegada, suelta, piedra, peso. 3-5 abrevia: sin hule ni despacito. 2-3 telegráfico: suelta, piedra, exclamación.
- 匹配欄：✓

【zh-TW】
媽媽鬆開手——
咚！
口袋多了一顆小石頭，好重好重。

【es-MX】
Mimí llegó a chapotear con su patito. Mamá Nutria soltó su mano.
¡TUN!
Una piedra pesada cayó en el bolsillo de Mimí.

### 3-5｜P02（母版 P02）

- 圖說什麼：牽牽與媽媽臉部至胸部特寫。媽媽蹲到牽牽同高，雙手打開向前、掌心朝上，表情溫暖安靜地等待。牽牽看見自己仍抓緊的左手，表情從緊張轉為認真——眉頭稍擠、嘴巴打開正在說話。口袋裡一顆小石清晰可見但口袋已不下垂（石頭恢復普通重量、身體重新站直）。小黃鴨安穩地夾在牽牽右臂與身體之間。<br>構圖裝置：雙人同高對視<br>
- 文說什麼：台詞：疊句「等一下，我要說！」＋第一個擔心（怕手放開）＋請求再握一下後告別<br>旁白：媽媽蹲下、打開手掌、安靜等待
- 鉤子：—
- 選圖與提純說明：Ronda 1: miedo a soltar + pedido de abrazo. 2-3 solo台詞, sin旁白.
- 匹配欄：✓

【zh-TW】
「等一下，我要說！」
「我怕…… 手放開。」
「再握一下，好不好？」

【es-MX】
Mamá Nutria se agachó y esperó.
—¡Espera, te quiero decir!
Me da miedo… soltar la mano.
¿Un abrazo más antes de decir adiós?
Mimí se paró derechita.

### 3-5｜P03（母版 P04）

- 圖說什麼：牽牽帶著小黃鴨往門檻方向走，身體重心向前——但口袋突然多出第二顆石，重量把口袋往身後甩，整隻小水獺正在被向後旋轉：前腳腳尖仍朝前但身體已開始轉，表情驚慌（眼圓睜、嘴微張）。小黃鴨被擠在臂彎裡即將發聲。畫面左後方可見媽媽站在門側（與牽牽距離比 P01 更遠）。動作凍結在旋轉中途。<br>構圖裝置：對角動線<br>
- 文說什麼：旁白：媽媽往門側移動一步<br>擬聲：咚（第二顆石落袋）<br>旁白：前進中被口袋往後甩的動態
- 鉤子：動作中斷型：牽牽往前走卻被第二顆石的重量猛地往後甩，身體正在旋轉中途——翻頁才見她轉回媽媽。
- 選圖與提純說明：5-6 hook: segunda piedra jala hacia atrás. 3-5 bridge P03+P04: pacto + paso + segunda piedra.
- 匹配欄：✓

【zh-TW】
媽媽說了會回來，牽牽往前走。
咚！
口袋用力往後一甩。

【es-MX】
Mamá Nutria le dio un abrazo más. —Voy a regresar cuando tu patito termine de chapotear. Mimí dio un paso.
¡TUN!
Otra piedra cayó en su bolsillo y la jaló hacia atrás…

### 3-5｜P04（母版 P05）

- 圖說什麼：牽牽已完全轉回面向媽媽（背部朝門檻方向），表情先狼狽再認真——正在開口說話。小黃鴨被擠到微變形、嘴微張。口袋含兩顆石但不再向後甩（兩顆石恢復普通重量）。媽媽蹲到同高、雙手打開掌心朝上，表情與 P02 同樣溫暖等待。背景可見門檻線位置。<br>構圖裝置：雙人同高對視<br>
- 文說什麼：擬聲：嘎（小黃鴨被擠）<br>台詞：疊句「等一下，我要說！」＋第二個擔心（怕看不到媽媽）＋請媽媽在門口揮手
- 鉤子：—
- 選圖與提純說明：Ronda 2: miedo a no ver a Mamá + pedido de adiós con la mano. 2-3 bridge: integra segunda piedra + pato + refrain + miedo.
- 匹配欄：✓

【zh-TW】
嘎！
「等一下，我要說！」
「我怕…… 看不到媽媽。」
「揮揮手，好嗎？」

【es-MX】
Mamá Nutria le dio un abrazo más. —Voy a regresar cuando tu patito termine de chapotear. Mimí dio un paso.
¡TUN!
Otra piedra cayó en su bolsillo y la jaló hacia atrás…

### 3-5｜P05（母版 P07）

- 圖說什麼：俯角望下。牽牽剛抬起一腳要跨過門檻，第三顆也是最大的一顆石墜入口袋——口袋垂直落向柔軟入口墊，把牽牽整個身體往下拉。抬起的腳懸在半空、另一腳開始打滑。表情從堅定瞬間變為驚恐（眼睛最圓、嘴巴張到最大）。小黃鴨在臂彎裡即將脫手。口袋裡三顆石的重量讓布料繃緊下墜。畫面上方門檻線橫跨。動作凍結在最大重量爆發的瞬間。<br>構圖裝置：垂直壓迫<br>
- 文說什麼：旁白：媽媽完成約定的短告別、準備走出視線<br>擬聲：咚（第三顆最沉的石）<br>旁白：抬腳越門時最大重量墜下
- 鉤子：動作中斷型：第三顆最沉的石在牽牽抬腳越門時墜下，口袋垂直落向柔軟入口墊——翻頁才見最大重力後果。
- 選圖與提純說明：5-6 hook: tercera piedra (más pesada) jala hacia abajo. 3-5 bridge P06+P07: adiós con mano + despedida + tercera piedra.
- 匹配欄：✓

【zh-TW】
媽媽揮了揮手。
牽牽走到門口——
咚！
最重的石頭掉進口袋。

【es-MX】
¡CUAC!
—¡Espera, te quiero decir!
Me da miedo… no te veo.
¿Me dices adiós desde la puerta?
Mimí volteó hacia el salón.

### 3-5｜P06（母版 P08）

- 圖說什麼：牽牽坐在柔軟入口墊上（被垂直拉坐的結果），表情從短暫驚嚇轉為主動認真——嘴巴張開正在說話、眼神直視媽媽不再閃避。小黃鴨剛從彈起落回牽牽腿邊（稍歪）。口袋攤在墊面上，三顆石可見但布料開始鬆弛（不再繃緊——三顆石逐一恢復普通重量）。媽媽蹲到比 P02、P05 更低（配合牽牽坐姿高度），雙手打開掌心朝上，表情一致的溫暖等待。牽牽肩膀已從縮緊開始抬起。<br>構圖裝置：雙人同高對視<br>
- 文說什麼：擬聲：噗通（被拉坐）＋嘎（小黃鴨彈起）<br>台詞：疊句「等一下，我要說！」＋第三個擔心（怕媽媽不回來）＋確認玩完水後重逢<br>旁白：媽媽一句話確認並安靜等待
- 鉤子：—
- 選圖與提純說明：Ronda 3: Mimí habla primero, miedo a que Mamá no regrese + confirma reencuentro. 2-3 bridge: integra tercera piedra + plop + pato + pregunta directa.
- 匹配欄：✓

【zh-TW】
噗通！嘎！
「等一下，我要說！」
「我怕…… 媽媽不回來。」
「玩完水，你會來嗎？」
「會的。」

【es-MX】
¡PUM!
¡CUAC!
—¡Espera, te quiero decir!
Me da miedo… que no regreses.
¿Vas a regresar después de chapotear?
—Sí —dijo Mamá Nutria.

### 3-5｜P07（母版 P09）

- 圖說什麼：仰角特寫。牽牽的臉與上半身填滿畫面，表情堅定而平靜（嘴唇抿住、眼神前望不回頭）。一隻手抱著小黃鴨貼在胸前，另一隻手向畫面左上方（身後媽媽方向）做出一個小揮手。畫面下緣可見牽牽的一隻腳正抬起跨過門檻邊緣——腳在仰角中顯得大而有力。口袋含三顆石但垂度正常、不拉扯。門檻線在牽牽身後形成一道水平分割。<br>構圖裝置：低角仰望<br>
- 文說什麼：旁白：牽牽自己站起來，先揮手短告別<br>旁白：抱著小黃鴨抬腳越過門檻
- 鉤子：動作中斷型：牽牽主動揮手告別後抬腳越門——翻頁才完成跨門與放鴨。
- 選圖與提純說明：Hook: adiós voluntario + pie en el aire. 2-3 fragmentos telegráficos.
- 匹配欄：✓

【zh-TW】
牽牽站起來，對媽媽揮揮手。
抱著小黃鴨，抬起腳——

【es-MX】
Mamá Nutria le dijo adiós con la mano.
Se despidió y se fue.
Mimí levantó un pie hacia la puerta…
¡TUN!
La tercera piedra, la más pesada, la jaló hacia abajo…

### 3-5｜P08（母版 P10）

- 圖說什麼：滿版。水盆遊戲角全景：普通低水盆居畫面中央偏右，水面柔和反射日間光線。牽牽站在水盆旁，身體前傾，雙手正將小黃鴨放入水面——鴨子半入水、水花微微濺起。口袋含三顆石但垂度正常，不再拉扯身體。牽牽表情平靜滿足（微笑、眼睛溫柔望著鴨子）。背景：門口方向可見但媽媽已離開（門開著、光線從門口透入）；熟悉照顧者在畫面遠處安靜坐著。整個空間暖色調、安穩。<br>構圖裝置：中央聚焦<br>
- 文說什麼：旁白：跨過門檻，把小黃鴨放進水盆<br>擬聲：啵（小黃鴨落進水面）
- 鉤子：—
- 選圖與提純說明：Clímax: cruza, baja pato, splash, flota. 2-3 exclamaciones de logro.
- 匹配欄：✓

【zh-TW】
牽牽跨過門檻，把小黃鴨放進水盆。
啵！小黃鴨浮起來了。

【es-MX】
¡PUM!
¡CUAC!
—¡Espera, te quiero decir!
Me da miedo… que no regreses.
¿Vas a regresar después de chapotear?
—Sí —dijo Mamá Nutria.

### 3-5｜P09（母版 P11）

- 圖說什麼：牽牽半身像，坐在水盆旁邊（水盆下方邊緣可見一角，小黃鴨濕漉漉地被撈出放在盆邊）。牽牽抬頭望向畫面左側（門口方向），表情驚喜而期待（眼睛亮、嘴巴微張）。一隻小圓耳微微豎起——正在聽。門口方向有柔和光線照入但來者尚未入畫。口袋安穩垂在身側，三顆石不顯眼。<br>構圖裝置：視線引導<br>
- 文說什麼：旁白：水盆遊戲結束<br>擬聲：啪嗒（門外熟悉的腳步聲）
- 鉤子：懸念型：水盆遊戲結束時門外傳來熟悉腳步，牽牽抬頭望向尚未揭示來者的門口——翻頁才揭示媽媽如約返回。
- 選圖與提純說明：Hook suspense: pasos familiares sin revelar quién. 2-3 invierte orden para rematar con exclamación.
- 匹配欄：✓

【zh-TW】
小黃鴨玩夠了。
啪嗒，啪嗒。
門外傳來腳步聲——好像是媽媽！

【es-MX】
Mimí se paró y fue la primera en decir adiós. Mamá Nutria le contestó con la mano.
Mimí abrazó a su patito y levantó un pie…

### 3-5｜P10（母版 P12）

- 圖說什麼：滿版暖色調。水盆遊戲角門口處，水獺媽媽（完整出現、與 P01 相同的深棕毛色米色上衣湖綠長褲寬厚尾巴）站在門口微蹲著張開雙臂。牽牽從水盆方向小跑迎向媽媽，一手提著濕漉漉的小黃鴨，另一手指著自己的口袋——口袋裡三顆小石微微露出一角。牽牽表情安心喜悅（最大的笑容、眼睛彎彎）。水盆在畫面右後方。<br>背景細節層：水盆裡多了一隻小塑膠魚——牽牽玩水時有人悄悄放進去的。<br>構圖裝置：前景後景對位
- 文說什麼：旁白：媽媽如約回到門口<br>台詞：重逢交流（牽牽展示小石和小黃鴨）<br>旁白：收束式（「後來呀……」）
- 鉤子：—
- 選圖與提純說明：Reencuentro: Mamá cumple promesa. 5-6 muestra piedras + pato mojado. 2-3 solo la emoción + cierre.
- 匹配欄：✓

【zh-TW】
媽媽回來了！
後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。

【es-MX】
Mimí cruzó la puerta con las tres piedras en su bolsillo.
Bajó a su patito hasta el agua.
¡PLAS!
Se quedó flotando.

## 檔位 2-3（8 頁）

### 2-3｜P01（母版 P01）

- 圖說什麼：日間柔光遊戲室門口全景。低矮門檻左側，幼年水獺牽牽（淺棕絨毛、深棕尾尖、海藍吊帶褲含超大前口袋）右手抱一隻小黃鴨，左手朝水獺媽媽（深棕水獺、米色上衣、湖綠長褲、寬厚尾巴，約 1.3 倍高）伸出；媽媽的手正從牽牽左手鬆開。鬆開瞬間口袋裡新出現一顆圓潤小石，口袋因異常重量向下垂墜，整隻牽牽的身體被帶歪——右肩往口袋側沉、左腳微離地，表情從期待變驚訝（嘴微張、眼圓）。門內隱約可見低水盆一角與熟悉照顧者模糊身影。<br>構圖裝置：人物偏左＋右向留白<br>
- 文說什麼：旁白：告別情境建立（媽媽鬆手、口袋突然變重）<br>擬聲：咚（第一顆石落袋）
- 鉤子：—
- 選圖與提純說明：5-6 completa: llegada, suelta, piedra, peso. 3-5 abrevia: sin hule ni despacito. 2-3 telegráfico: suelta, piedra, exclamación.
- 匹配欄：✓

【zh-TW】
媽媽放手了。
咚！
口袋好重好重。

【es-MX】
Mamá soltó la mano.
¡TUN!
Una piedra cayó en el bolsillo de Mimí.
¡Qué pesada!

### 2-3｜P02（母版 P02）

- 圖說什麼：牽牽與媽媽臉部至胸部特寫。媽媽蹲到牽牽同高，雙手打開向前、掌心朝上，表情溫暖安靜地等待。牽牽看見自己仍抓緊的左手，表情從緊張轉為認真——眉頭稍擠、嘴巴打開正在說話。口袋裡一顆小石清晰可見但口袋已不下垂（石頭恢復普通重量、身體重新站直）。小黃鴨安穩地夾在牽牽右臂與身體之間。<br>構圖裝置：雙人同高對視<br>
- 文說什麼：台詞：疊句「等一下，我要說！」＋第一個擔心（怕手放開）＋請求再握一下後告別<br>旁白：媽媽蹲下、打開手掌、安靜等待
- 鉤子：—
- 選圖與提純說明：Ronda 1: miedo a soltar + pedido de abrazo. 2-3 solo台詞, sin旁白.
- 匹配欄：✓

【zh-TW】
「等一下，我要說！」
「怕…… 手放開。」
「再握一下。」

【es-MX】
—¡Espera, te quiero decir!
Me da miedo soltar la mano.
¿Un abrazo más?

### 2-3｜P03（母版 P05）

- 圖說什麼：牽牽已完全轉回面向媽媽（背部朝門檻方向），表情先狼狽再認真——正在開口說話。小黃鴨被擠到微變形、嘴微張。口袋含兩顆石但不再向後甩（兩顆石恢復普通重量）。媽媽蹲到同高、雙手打開掌心朝上，表情與 P02 同樣溫暖等待。背景可見門檻線位置。<br>構圖裝置：雙人同高對視<br>
- 文說什麼：擬聲：嘎（小黃鴨被擠）<br>台詞：疊句「等一下，我要說！」＋第二個擔心（怕看不到媽媽）＋請媽媽在門口揮手
- 鉤子：—
- 選圖與提純說明：Ronda 2: miedo a no ver a Mamá + pedido de adiós con la mano. 2-3 bridge: integra segunda piedra + pato + refrain + miedo.
- 匹配欄：✓

【zh-TW】
咚！又一顆石頭。
嘎！
「等一下，我要說！」
「怕…… 看不到媽媽。」

【es-MX】
¡TUN! Otra piedra.
¡CUAC!
—¡Espera, te quiero decir!
¡No te veo!

### 2-3｜P04（母版 P08）

- 圖說什麼：牽牽坐在柔軟入口墊上（被垂直拉坐的結果），表情從短暫驚嚇轉為主動認真——嘴巴張開正在說話、眼神直視媽媽不再閃避。小黃鴨剛從彈起落回牽牽腿邊（稍歪）。口袋攤在墊面上，三顆石可見但布料開始鬆弛（不再繃緊——三顆石逐一恢復普通重量）。媽媽蹲到比 P02、P05 更低（配合牽牽坐姿高度），雙手打開掌心朝上，表情一致的溫暖等待。牽牽肩膀已從縮緊開始抬起。<br>構圖裝置：雙人同高對視<br>
- 文說什麼：擬聲：噗通（被拉坐）＋嘎（小黃鴨彈起）<br>台詞：疊句「等一下，我要說！」＋第三個擔心（怕媽媽不回來）＋確認玩完水後重逢<br>旁白：媽媽一句話確認並安靜等待
- 鉤子：—
- 選圖與提純說明：Ronda 3: Mimí habla primero, miedo a que Mamá no regrese + confirma reencuentro. 2-3 bridge: integra tercera piedra + plop + pato + pregunta directa.
- 匹配欄：✓

【zh-TW】
咚！最重的。
噗通！嘎！
「等一下，我要說！」
「怕…… 媽媽不回來。」
媽媽點點頭。

【es-MX】
¡TUN!
¡PUM! ¡CUAC!
—¡Espera, te quiero decir!
¿Vas a regresar?
Mamá dijo que sí.

### 2-3｜P05（母版 P09）

- 圖說什麼：仰角特寫。牽牽的臉與上半身填滿畫面，表情堅定而平靜（嘴唇抿住、眼神前望不回頭）。一隻手抱著小黃鴨貼在胸前，另一隻手向畫面左上方（身後媽媽方向）做出一個小揮手。畫面下緣可見牽牽的一隻腳正抬起跨過門檻邊緣——腳在仰角中顯得大而有力。口袋含三顆石但垂度正常、不拉扯。門檻線在牽牽身後形成一道水平分割。<br>構圖裝置：低角仰望<br>
- 文說什麼：旁白：牽牽自己站起來，先揮手短告別<br>旁白：抱著小黃鴨抬腳越過門檻
- 鉤子：動作中斷型：牽牽主動揮手告別後抬腳越門——翻頁才完成跨門與放鴨。
- 選圖與提純說明：Hook: adiós voluntario + pie en el aire. 2-3 fragmentos telegráficos.
- 匹配欄：✓

【zh-TW】
牽牽站起來了。
揮揮手——抬起腳——

【es-MX】
¡TUN! Otra piedra.
¡CUAC!
—¡Espera, te quiero decir!
¡No te veo!

### 2-3｜P06（母版 P10）

- 圖說什麼：滿版。水盆遊戲角全景：普通低水盆居畫面中央偏右，水面柔和反射日間光線。牽牽站在水盆旁，身體前傾，雙手正將小黃鴨放入水面——鴨子半入水、水花微微濺起。口袋含三顆石但垂度正常，不再拉扯身體。牽牽表情平靜滿足（微笑、眼睛溫柔望著鴨子）。背景：門口方向可見但媽媽已離開（門開著、光線從門口透入）；熟悉照顧者在畫面遠處安靜坐著。整個空間暖色調、安穩。<br>構圖裝置：中央聚焦<br>
- 文說什麼：旁白：跨過門檻，把小黃鴨放進水盆<br>擬聲：啵（小黃鴨落進水面）
- 鉤子：—
- 選圖與提純說明：Clímax: cruza, baja pato, splash, flota. 2-3 exclamaciones de logro.
- 匹配欄：✓

【zh-TW】
跨過去了！
小黃鴨——啵！
浮起來了。

【es-MX】
¡Mimí entró!
¡Tres piedras en su bolsillo!
¡PLAS!
Su patito se quedó flotando.

### 2-3｜P07（母版 P11）

- 圖說什麼：牽牽半身像，坐在水盆旁邊（水盆下方邊緣可見一角，小黃鴨濕漉漉地被撈出放在盆邊）。牽牽抬頭望向畫面左側（門口方向），表情驚喜而期待（眼睛亮、嘴巴微張）。一隻小圓耳微微豎起——正在聽。門口方向有柔和光線照入但來者尚未入畫。口袋安穩垂在身側，三顆石不顯眼。<br>構圖裝置：視線引導<br>
- 文說什麼：旁白：水盆遊戲結束<br>擬聲：啪嗒（門外熟悉的腳步聲）
- 鉤子：懸念型：水盆遊戲結束時門外傳來熟悉腳步，牽牽抬頭望向尚未揭示來者的門口——翻頁才揭示媽媽如約返回。
- 選圖與提純說明：Hook suspense: pasos familiares sin revelar quién. 2-3 invierte orden para rematar con exclamación.
- 匹配欄：✓

【zh-TW】
小黃鴨玩完水了。
啪嗒，啪嗒。
門外有腳步聲。

【es-MX】
Su patito ya chapoteó.
toc, toc, toc!
¡Pasos en la puerta!

### 2-3｜P08（母版 P12）

- 圖說什麼：滿版暖色調。水盆遊戲角門口處，水獺媽媽（完整出現、與 P01 相同的深棕毛色米色上衣湖綠長褲寬厚尾巴）站在門口微蹲著張開雙臂。牽牽從水盆方向小跑迎向媽媽，一手提著濕漉漉的小黃鴨，另一手指著自己的口袋——口袋裡三顆小石微微露出一角。牽牽表情安心喜悅（最大的笑容、眼睛彎彎）。水盆在畫面右後方。<br>背景細節層：水盆裡多了一隻小塑膠魚——牽牽玩水時有人悄悄放進去的。<br>構圖裝置：前景後景對位
- 文說什麼：旁白：媽媽如約回到門口<br>台詞：重逢交流（牽牽展示小石和小黃鴨）<br>旁白：收束式（「後來呀……」）
- 鉤子：—
- 選圖與提純說明：Reencuentro: Mamá cumple promesa. 5-6 muestra piedras + pato mojado. 2-3 solo la emoción + cierre.
- 匹配欄：✓

【zh-TW】
媽媽回來了！
後來呀，牽牽和媽媽牽著手，小黃鴨也跟著回家了。

【es-MX】
¡TUN!
¡PUM! ¡CUAC!
—¡Espera, te quiero decir!
¿Vas a regresar?
Mamá dijo que sí.

