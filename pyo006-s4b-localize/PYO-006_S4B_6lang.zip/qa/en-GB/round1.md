# QA 報告：whats-in-the-worry-pocket / en-GB / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: whats-in-the-worry-pocket
locale: en-GB
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-21"
step1_lint: {exit_code: 0, warnings: 31}
step2_checklist: {pass: 7, fail: 0}
step3_personas:
  - id: en-GB-teacher
    scores: {年齡適配度: 9, 英式語感: 9, 孩子抓得住度: 9}
  - id: en-GB-parent
    scores: {睡前適讀性: 9, 零說教: 10}
  - id: en-GB-editor
    scores: {母語自然度: 9, 文字工藝: 9}
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

> **Lite QA scope**: en-GB is a derived variant from en-US Gate 4 Green Light frozen text. Per piyo-localize STEP 2, derived variant QA uses a lightweight funnel: machine checks + E-lite (divergence spot-check + alignment) + BrE editor persona single review + triage. Persona scores below are from a single BrE-focused review pass (not full blind protocol) since the text is byte-identical to en-US which passed Gate 4 with full persona battery.

---

## STEP 1 機檢

All three tiers pass locale_lint with exit 0 and 0 violations.

### 5-6 tier
```
locale_lint.py --pages-file text/en-GB/5-6.draft.json --locale en-GB --band 5-6
Exit code: 0
Violations: 0
Warnings: 13
```

### 3-5 tier
```
locale_lint.py --pages-file text/en-GB/3-5.draft.json --locale en-GB --band 3-5
Exit code: 0
Violations: 0
Warnings: 11
```

### 2-3 tier
```
locale_lint.py --pages-file text/en-GB/2-3.draft.json --locale en-GB --band 2-3
Exit code: 0
Violations: 0
Warnings: 7
```

### Warning Adjudication

All warnings fall into two categories:

1. **`warn_term: mama`** (9 + 7 + 4 = 20 instances across tiers): "Mama" appears as part of the character name "Mama Otter" (and shortened "Mama" in 2-3). This is a character name registry decision (character_names.md: en-GB proposes "Mama Otter", same as en-US). The en-GB spec R2.1 bans US-system kinship terms (Mom/Mommy) but "Mama" is a cross-cultural term, not US-specific. Verdict: **acceptable, character name decision**.

2. **`repeat_discount`** (4 + 4 + 3 = 11 instances): Informational warnings showing refrain/SFX repeat discounting for total word count. THUNK! x3, refrain "Wait--I need to tell you!" x3, SQUEAK! x2 per tier variant. These are structural repeats by design (three-cycle story engine). Discounted totals: 5-6 = 338.25, 3-5 = 227.25, 2-3 = 84 -- all within spec limits. Verdict: **expected, by design**.

---

## STEP 2 checklist 自檢

**Theme anchor**: This book teaches that a young otter (Cuddles) can notice her own body signals of separation anxiety, name each specific worry aloud to a trusted adult, and take one more small step toward independence -- without the worry disappearing entirely.

### Divergence Verification (Byte-Level Diff)

Programmatic comparison of all en-GB draft text against en-US final text:

| Tier | Pages | Differences | Detail |
|---|---|---|---|
| 5-6 | 12 | 1 | P02: Oxford comma removed. en-US "knelt, opened her hands, and waited" -> en-GB "knelt, opened her hands and waited". Conforms to en-GB spec S5.6 (Oxford comma default omit). |
| 3-5 | 10 | 0 | All 10 pages byte-identical to en-US final. |
| 2-3 | 8 | 0 | All 8 pages byte-identical to en-US final. |

**Assessment**: The sole divergence is the documented 5-6 P02 Oxford comma removal. No undocumented changes exist. This matches the copy table (copy/en-GB.md) which explicitly records this as the only BrE adaptation.

### Structural Alignment Checks

| Check | Result |
|---|---|
| Page count per tier | 5-6: 12, 3-5: 10, 2-3: 8 -- matches en-US |
| Page keys sequential | P01-P12 / P01-P10 / P01-P08 -- correct |
| Refrain "Wait--I need to tell you!" | 5-6: P02/P05/P08, 3-5: P02/P04/P06, 2-3: P02/P03/P04 -- 3x per tier, consistent |
| Ending "And from that day on..." | 5-6: P12, 3-5: P10, 2-3: P08 -- last page of each tier |
| SFX THUNK! | 5-6: P01/P04/P07, 3-5: P01/P03/P05, 2-3: P01/P03/P04 -- 3x per tier |
| SFX SQUEAK! | 5-6: P05/P08, 3-5: P04/P06, 2-3: absent (expected -- 2-3 simplification) |
| SFX PLOP! | 5-6: P08, 3-5: P06, 2-3: absent (expected) |
| SFX SPLISH! | 5-6: P10, 3-5: P08, 2-3: P06 -- 1x per tier |
| SFX "tap, tap, tap!" | 5-6: P11, 3-5: P09, 2-3: P07 -- 1x per tier |
| Character "Cuddles" | Present in all tiers, consistent naming |
| Character "Mama Otter" | Present in 5-6 and 3-5; 2-3 uses shortened "Mama" -- consistent with en-US |

All structural elements are identical to en-US. No refrain drift, no SFX inconsistency, no character name discrepancy.

### BrE Vocabulary Scan

Systematic check for US-specific vocabulary that should have been adapted to BrE:

| Item | Finding |
|---|---|
| Spelling (-or/-er/-ize/gray/cozy/pajamas) | None present in text. No BrE adaptation needed. |
| US kinship terms (Mom/Mommy) | None present. "Mama Otter" is cross-cultural. |
| US vocabulary (cookie, candy, trash, sidewalk, closet, etc.) | None present. |
| "toward" (4x in 5-6, 3x in 3-5) | Both "toward" and "towards" are acceptable in BrE. Copy table notes: "en-US source form retained for minimal diff". Acceptable. |
| "gotten" | Not present. |
| Come/Go + bare infinitive (US pattern) | Not present. |
| US cultural objects (Thanksgiving, dollar, mailbox) | None present. |

**Assessment**: The en-US source text uses universally understood English vocabulary throughout. No words require BrE spelling or vocabulary adaptation. The text is culturally neutral (generic playroom doorway, toy duck, water basin) with no US-specific cultural objects.

### Copy Table (copy/en-GB.md) Verification

The copy table correctly:
- Declares schema `piyo_copy/v0.9`, locale `en-GB`, mode `B`
- Lists all commitments (refrain, ending, onomatopoeia, characters) matching the draft JSONs
- Records the sole BrE divergence at 5-6 P02 with explanation
- Notes "No BrE divergence" for all other pages
- Word counts match the draft JSON content

### Checklist Summary (E-lite scope for derived variant)

7 applicable checks for derived variant lite QA: (1) machine lint pass, (2) divergence verification, (3) structural alignment, (4) BrE vocabulary scan, (5) copy table consistency, (6) refrain/SFX/ending cross-tier identity, (7) character name consistency. All 7 pass, 0 fail.

### ESL 獵手 (BrE editor -- derived variant lite scope)

**Reviewer persona**: British English children's book editor, focusing on whether the text reads naturally in BrE for a UK parent reading aloud at bedtime.

The text reads entirely naturally in British English. Key observations:

1. **Vocabulary is universally English**: Words like "splash", "squeeze", "pocket", "stone", "doorway", "threshold", "floated" are common to both BrE and AmE. No word in any tier would sound foreign or marked to a UK reader/listener.

2. **Dialogue is natural**: The refrain "Wait--I need to tell you!" is idiomatic in both varieties. The emotional language ("I'm scared...", "Will you come back?") is universal.

3. **"Mama Otter" as character name**: While BrE typically uses "Mum/Mummy", "Mama" is a warm, slightly literary register that works in UK picture books (cf. "Mama Bear" in many UK editions of Goldilocks). It is not a US-marked term. The character_names.md registry confirms this as the en-GB proposal.

4. **"toward" vs "towards"**: The text uses "toward" (US default form) four times in 5-6 and three times in 3-5. Both forms are standard in BrE. Retaining "toward" minimises the diff and is linguistically acceptable. No change needed.

5. **Oxford comma removal on 5-6 P02**: The single adaptation ("knelt, opened her hands and waited") follows UK convention correctly. The serial comma is only omitted from the final conjunction in a three-item list, which is the standard BrE practice. The sentence remains clear without it.

6. **Tone and register**: The warm, understated narrative voice (third person past tense, simple vocabulary, gentle pacing) is perfectly aligned with UK picture book conventions. The text would sit comfortably alongside Walker Books or Macmillan Children's titles.

7. **No AI mechanical sentence patterns detected**: No telegram-style bare verb stacking, no dangling components, no hyper-regular parallelism beyond the intentional three-cycle structure. The deliberate structural repetition (three THUNK! cycles, three refrain instances) is a picture book craft choice, not mechanical writing.

**BrE Editor verdict**: The text is ready for a UK audience with no changes required beyond the already-applied Oxford comma removal. Zero US-specific vocabulary, zero spelling issues, zero cultural objects requiring localisation.

---

## STEP 3 人設 blind QA

> Derived variant lite QA: en-GB text is byte-identical to en-US (which passed Gate 4 with full persona battery) except for one Oxford comma on 5-6 P02. Persona review below is conducted as a single BrE-focused pass rather than full blind protocol, since the underlying text substance is unchanged from the en-US Gate 4 approved version.

### en-GB-teacher (Mrs. Whitfield) -- nursery school teacher, EYFS specialist

| 檔位 | 頁 | 原句（節錄） | 問題描述 | 嚴重度 | 建議改法 |
|---|---|---|---|---|---|
| (none) | -- | -- | No issues found | -- | -- |

**Scores (per tier minimum)**:
- 年齡適配度: **9** -- 5-6 and 3-5 vocabulary sits well within Reception/Y1 listening comprehension. 2-3 text uses short fragments and concrete vocabulary (stone, duck, pocket) appropriate for nursery-age children. The refrain "Wait--I need to tell you!" is phonics-friendly and memorable. Evidence: 2-3 P02/P03/P04 three-word rhythm; 5-6 P09 "threshold" is the most advanced word but acceptable in 5-6 read-aloud context.
- 英式語感: **9** -- No American vocabulary or spelling detected. "Mama Otter" is the only potential discussion point but reads as warm and literary rather than American. "toward" (not "towards") is acceptable in BrE. Evidence: full text scan, zero US markers.
- 孩子抓得住度: **9** -- The three-cycle THUNK! structure with escalating physical consequences (sideways tilt, backward turn, pulled down) keeps children engaged. The refrain invites participation. Evidence: P04/P05 SQUEAK! surprise; P08 PLOP!+SQUEAK! double; P11 "tap, tap, tap!" anticipation.

### en-GB-parent (Sophie) -- bedtime story reader, Julia Donaldson standard

| 檔位 | 頁 | 原句（節錄） | 問題描述 | 嚴重度 | 建議改法 |
|---|---|---|---|---|---|
| (none) | -- | -- | No issues found | -- | -- |

**Scores (per tier minimum)**:
- 睡前適讀性: **9** -- The emotional arc winds down beautifully from P10 onward. P12's "And from that day on... they held hands at every goodbye and hello" is a perfect sleep-ready closing. The three stones metaphor is gentle enough for bedtime without being frightening. Evidence: P10-P12 pacing; 2-3 P08 two-sentence close.
- 零說教: **10** -- No explicit moral, no narrator summarising lessons. Cuddles discovers her own coping mechanism through action. The story shows rather than tells. Evidence: P12 -- "My little stones are still here--and so are you!" is Cuddles's own voice, not a lesson. No "and she learned that..." anywhere.

### en-GB-editor (Eleanor) -- commissioning editor, Americanisation specialist

| 檔位 | 頁 | 原句（節錄） | 問題描述 | 嚴重度 | 建議改法 |
|---|---|---|---|---|---|
| (none) | -- | -- | No issues found | -- | -- |

**Scores (per tier minimum)**:
- 母語自然度: **9** -- This is a rare case where the US source text is so culturally neutral that the en-GB adaptation is essentially transparent. Universal vocabulary, no US cultural markers, no US spelling forms present. The single Oxford comma removal is the only visible edit, and it is correctly applied. Evidence: full text comparison, zero US residue.
- 文字工藝: **9** -- The three-cycle structure with escalating physical stakes (horizontal tilt -> backward turn -> vertical pull-down) is well-crafted. Page-turn hooks at P04, P07, P09, P11 are effective. The refrain builds naturally with each cycle adding a new specific worry. The 2-3 tier reduction is clean -- retains core emotional beats without feeling gutted. Evidence: P07/P08 climax construction; P11 footstep anticipation.

---

## STEP 4 三分法分診

**Theme anchor**: This book teaches that a young otter can notice body signals of separation anxiety, name each specific worry aloud to a trusted adult, and take one more step -- the worry does not disappear but becomes manageable.

No findings to triage. Zero issues from STEP 2 E-lite, BrE editor review, or persona reviews.

| Source | Findings | Real | Rejected | Escalated |
|---|---|---|---|---|
| E-lite divergence check | 0 | 0 | 0 | 0 |
| BrE editor / ESL 獵手 | 0 | 0 | 0 | 0 |
| en-GB-teacher | 0 | 0 | 0 | 0 |
| en-GB-parent | 0 | 0 | 0 | 0 |
| en-GB-editor | 0 | 0 | 0 | 0 |
| **Total** | **0** | **0** | **0** | **0** |

---

## Summary

en-GB derived variant for PYO-006 "What's in the Worry Pocket?" passes lite QA with verdict **pass**.

- Machine checks: exit 0 on all three tiers, 0 violations, all 31 warnings adjudicated as acceptable (20 character name, 11 repeat discount).
- Text identity: en-GB is byte-identical to en-US Gate 4 Green Light frozen text across all three tiers, with exactly one documented divergence (5-6 P02 Oxford comma removal per en-GB spec S5.6).
- BrE vocabulary: the en-US source text uses universally understood vocabulary; no BrE spelling or vocabulary adaptations are required beyond the Oxford comma.
- Structural integrity: refrain, ending, SFX, and character names are consistent across all tiers and identical to en-US.
- BrE naturalness: the text reads naturally for a UK audience with no changes needed.
