---
schema: piyo_b0_rulings/v1
book_id: PYO-006
slug: whats-in-the-worry-pocket
wave: 2
lanes: [th-TH, vi-VN]
status: frozen
---

# Wave 2 B0 Rulings — PYO-006 What's in the Worry Pocket?

## Frozen String Table

| # | Asset | th-TH | vi-VN |
|---|-------|-------|-------|
| R1 | refrain | `"เดี๋ยว หนูจะพูด!"` | `"Khoan đã — con muốn nói!"` |
| E1 | ending | `ตั้งแต่วันนั้นเป็นต้นมา…` | `Từ ngày đó…` |
| S1 | stone drop | `ตึง!` | `Bịch!` |
| S2 | duck squeeze | `เอี๊ยด!` | `Kẹt!` |
| S3 | sit plop | `ตุ๊บ!` | `Bộp!` |
| S4 | splash | `จ๋อม!` | `Tõm!` |
| S5 | footsteps | `แตะ แตะ แตะ` | `lộp bộp, lộp bộp` |
| C1 | cuddles | `น้องกอด` | `Bống`（別名：Rái Bống） |
| C2 | mama_otter | `คุณแม่`（別名：แม่） | `Mẹ Rái`（別名：Mẹ） |

## Rulings

- All values approved as B0 proposals; three-tier three-round consistency required.
- th-TH [C2]: Full form `คุณแม่` for registry; text uses short form `แม่` (copy_check acknowledges visual-only presence).
- vi-VN 2-3 P08: max_sentence_len violation (15 > 10) on ending formula — structural issue shared with zh-TW; vi-VN 2-3 max_sentence_len=10 is seed value with low confidence. Escalated to QA.
