# QA 報告：whats-in-the-worry-pocket / th-TH / round 2（復核輪）

```yaml
schema: piyo_text_qa_report/v0.9
slug: whats-in-the-worry-pocket
locale: th-TH
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-21"
step1_lint: {exit_code: 0, warnings: 9}
step2_checklist: {pass: 19, fail: 0}
step3_personas:
  - id: th-TH-teacher
    scores: {年齡適配度: 8, 朗讀口感: 8, 孩子抓得住度: 9}
  - id: th-TH-parent
    scores: {睡前適讀性: 9, 零說教: 10}
  - id: th-TH-editor
    scores: {母語自然度: 7, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 1}
verdict: escalated
```

> **復核輪聲明**：R1 七筆 ✅ 全數 ∈ 字串級，符合復核輪資格（SKILL.md v0.14）。本輪執行：STEP 1 機檢全量重跑 + 修改逐筆落地驗證 + copy↔draft 同源檢。人設不重跑，分數沿用 R1。

## STEP 1 機檢

三檔 locale_lint 均 exit 0：
- 5-6：0 violations（warnings: repeat_discount）
- 3-5：0 violations（warnings: repeat_discount）
- 2-3：0 violations（warnings: repeat_discount）

copy_check.py：✅ copy 機檢通過（warnings: band ⚠ = th-TH 帶未校準 + visual-only character）

### 修改逐筆落地驗證

| # | 裁決指定內容 | 實際落地 | 核銷 |
|---|---|---|---|
| 1 | P01 5-6 ทันที→เลย | ✅ verified | ✓ |
| 2 | P03 5-6 ทีหนึ่ง→ก้าวนึง | ✅ verified | ✓ |
| 3 | P05 5-6 ถูกบีบ→โดนบีบ | ✅ verified | ✓ |
| 4 | P07 5-6 เพิ่ง→พอจะ | ✅ verified | ✓ |
| 5 | P12 5-6 ดูสิคะ→ดูนะคะ | ✅ verified | ✓ |
| 6 | P04 3-5 บอกว่า→บอก | ✅ verified | ✓ |
| 7 | P12 2-3 added นะ + line break | ✅ verified | ✓ |

七筆全部逐字核銷通過。copy/th-TH.md 已同步更新。

## STEP 2 checklist 自檢

> 復核輪：checklist pass/fail 沿用 R1（19/0）。受修頁 alignment、concept fidelity 不受影響（七筆修改均為字串級詞彙替換，不動 beat 語義、不觸主題錨）。

## STEP 3 人設 blind QA

> 復核輪：人設不重跑，分數沿用 R1。

## STEP 4 三分法分診

本輪新增 ✅ = 0、❌ = 0。R1 ⏸️ T-ESC-1（P04 ดึงตัวกลับไปข้างหลัง calque 疑義）carry-over 上呈（escalated = 1）。

**收斂判定**：✅ = 0 且無新發現 → th-TH QA 收斂。

## verdict 說明

文本品質收斂、七筆回修落地驗證通過。verdict 為 `escalated`，原因：R1 T-ESC-1 ⏸️ 未裁決（P04 `ดึงตัวกลับไปข้างหลัง` 是否為中文 calque 屬語言判斷層，triage 傾向保留現用但 defer to native judgment）。保留此 escalated verdict；gate4 證據包供 Stacy 選閱。
