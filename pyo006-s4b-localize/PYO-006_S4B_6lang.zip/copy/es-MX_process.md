# es-MX Process Log — PYO-006 whats-in-the-worry-pocket

## B0 Language Foundation

### Refrain
- zh-TW source: 「等一下，我要說！」
- en-US adaptation: "Wait—I need to tell you!"
- **es-MX native**: `¡Espera, te quiero decir!`
- Rationale: "Espera" is the most natural Mexican toddler stop-word (not "para" which is too abrupt, not "momento" which is adult register). "Te quiero decir" = I want to tell you — captures the child's agency in naming the worry. Rhythmic 8-syllable pattern, tú form (R2.1), no vosotros/vos. A 3-year-old Mexican child can repeat this full phrase. Tested against MX parent read-aloud cadence.

### SFX (5 onomatopoeia)
| Action | zh-TW | en-US | **es-MX** | Rationale |
|---|---|---|---|---|
| Stone drop into pocket | 咚！ | THUNK! | **¡TUN!** | Heavy dull thud; MX children recognize "tun" for heavy impact. Follows R4.3 (dramatic SFX with ¡!). |
| Rubber duck squeezed/bounced | 嘎！ | SQUEAK! | **¡CUAC!** | Standard es-MX duck sound (cuac cuac = quack quack). R4.1 normal typesetting, not italics. |
| Pulled to sit on mat | 噗通！ | PLOP! | **¡PUM!** | MX standard impact/sit-down sound. Distinct from ¡TUN! (stone = deep thud vs body = sudden impact). |
| Duck into water | 啵！ | SPLISH! | **¡PLAS!** | MX splash onomatopoeia (plas = flat water impact). Follows R4.3. |
| Familiar footsteps | 啪嗒，啪嗒 | tap, tap, tap! | **toc, toc, toc!** | Already validated in registry for three-little-pigs (es-MX knocking/tapping). R4.2 comma-separated (house rule). Lowercase sentence-internal form per zh-TW/en-US parallel. |

### Character Names
| canonical key | zh-TW | en-US | **es-MX** | Rationale |
|---|---|---|---|---|
| cuddles | 牽牽（牽牽獺） | Cuddles | **Mimí** | Two-syllable, accent-final, sweet and toddler-friendly. Easy for 2-year-old Mexican children to say. MX diminutive feel without actual -ito suffix (keeps it short for word count). Does not carry cultural baggage or gender stereotype. |
| mama_otter | 水獺媽媽 | Mama Otter | **Mamá Nutria** | Standard MX construction: Mamá + species. "Nutria" = otter in standard Spanish. Matches naming pattern of other es-MX parent characters (e.g., Mamá + animal). |

### Ending
- zh-TW: 「後來呀，…」
- en-US: "And from that day on…"
- **es-MX**: `Y desde ese día…`
- Rationale: Direct MX narrative closure formula. "Y desde ese día" is the standard Spanish story-closing equivalent, natural in read-aloud cadence. The ellipsis (U+2026, R5.5) bridges into the final image of walking home hand in hand.

### Display Title (proposal)
- **¿Qué hay en el bolsillo de los miedos?** (What's in the worry pocket?)
- Rationale: "bolsillo de los miedos" = pocket of fears/worries — captures the metaphor naturally. MX parents would find this title intriguing and age-appropriate.

---

## B1 Blind Draft — Word Count Budget

### Read-order declaration
B0/B1 phase: Did NOT open, search, print, or indirectly read any `text/zh-TW/**` or `copy/zh-TW.md` content. Only read: frozen design, storyboard, en-US copy (structure reference only), es-MX locale spec, registries (character_names.md, onomatopoeia_map.md), and the B0 cards above.

### Per-tier word counts (B1 → B2 final)

**5-6** (12 pages, spec limits: page≤90, total≤761, sentence≤39)
| Page | Words | Max sentence |
|---|---|---|
| P01 | 33 | 13 |
| P02 | 35 | 9 |
| P03 | 28 | 12 |
| P04 | 25 | 8 |
| P05 | 38 | 11 |
| P06 | 24 | 11 |
| P07 | 37 | 18 |
| P08 | 39 | 9 |
| P09 | 25 | 14 |
| P10 | 24 | 11 |
| P11 | 30 | 12 |
| P12 | 45 | 16 |
| **TOTAL** | **383** | — |

**3-5** (10 pages, spec limits: page≤69, total≤585, sentence≤29)
| Page | Words | Max sentence |
|---|---|---|
| P01 | 22 | 9 |
| P02 | 27 | 7 |
| P03 | 32 | 11 |
| P04 | 22 | 6 |
| P05 | 31 | 10 |
| P06 | 22 | 6 |
| P07 | 26 | 10 |
| P08 | 22 | 11 |
| P09 | 28 | 10 |
| P10 | 27 | 16 |
| **TOTAL** | **259** | — |

**2-3** (8 pages, spec limits: page≤16, total≤101, sentence≤11)
| Page | Words | Max sentence |
|---|---|---|
| P01 | 15 | 8 |
| P02 | 13 | 6 |
| P03 | 11 | 4 |
| P04 | 14 | 4 |
| P05 | 11 | 5 |
| P06 | 13 | 5 |
| P07 | 11 | 4 |
| P08 | 11 | 9 |
| **TOTAL raw** | **99** | — |
| **Refrain discount** | -6 (4w × 2 repeats × 0.75) | — |
| **TOTAL adjusted** | **93** | — |

All pages, totals, and sentences within spec limits.

---

## B2 Source Calibration Notes

### Read-order declaration
B2 is the first and only time zh-TW source texts were opened: `text/zh-TW/5-6.json`, `text/zh-TW/3-5.json`, `text/zh-TW/2-3.json`.

### Page-by-page calibration

**5-6**: All 12 pages cross-checked. Semantic loads match: three rounds of stone-drop → refrain → specific worry → request → step forward. zh-TW P02/P05/P08 "等一下，我要說！" maps to es-MX "¡Espera, te quiero decir!" zh-TW P12 closure "後來呀" maps to "Y desde ese día…"

**3-5**: All 10 pages cross-checked. Bridges verified:
- 3-5 P03 (bridge of master P03+P04): zh-TW says "媽媽說了會回來，牽牽往前走。咚！口袋用力往後一甩。" — es-MX captures: Mamá's return promise + step forward + THUNK + pulled backward.
- 3-5 P05 (bridge of master P06+P07): zh-TW "媽媽揮了揮手。牽牽走到門口——咚！" — es-MX captures: wave + goodbye + approach door + THUNK + heaviest stone.

**2-3**: All 8 pages cross-checked. Key B2 adjustments:
- **P03** (master P05): Added "¡CUAC!" and "Otra piedra" to match zh-TW 2-3 P03 which includes duck squeak and "又一顆石頭" (another stone). Removed wave request (zh-TW 2-3 P03 does not include it; wave request only appears at 3-5/5-6 level).
- **P04** (master P08): Added "¡PUM! ¡CUAC!" to match zh-TW 2-3 P04 which includes "噗通！嘎！" (plop + squeak). Trimmed "La más pesada" and "Me da miedo…" to fit 16-word page limit; the fear is implied in the direct question "¿Vas a regresar?" which matches zh-TW's pattern where P04 goes straight to "怕……媽媽不回來" without "me da miedo" preamble.
- **P07**: Changed from "¡Pasos en la puerta!\ntoc, toc, toc!\nMimí esperó…" to "Su patito ya chapoteó.\ntoc, toc, toc!\n¡Pasos en la puerta!" to match zh-TW which starts with "小黃鴨玩完水了" (duck finished playing) before the footsteps.

### Locale-specific decisions
- **Diminutives** used naturally per es-MX spec advice: despacito, pasito, derechita, solita, piedritas, patito. One per sentence maximum to avoid telenovela stacking.
- **Dialogue** uses raya (—, U+2014) per R5.2, never quotation marks.
- **Past tense**: Simple past throughout narration (llegó, cayó, soltó) per MX convention, never compound past (ha llegado).
- **"chapotear"** chosen over "jugar con agua" for splash-play — natural MX verb for water play, confirmed in SEP vocabulary range.
- **"bolsillo"** for pocket, **"tina de agua"** for water basin/tub — standard MX vocabulary.
- **"señora conocida"** for familiar grown-up — warm, non-specific, MX-appropriate.

### Machine checks
- Zero banned terms detected across all three tiers.
- Zero warn terms detected.
- All orthographic rules verified: ¡¿ pairs, raya dialogue, U+2026 ellipsis, complete tildes.
- No CJK characters or full-width punctuation leaked.
- Required script: Latin only — confirmed.
