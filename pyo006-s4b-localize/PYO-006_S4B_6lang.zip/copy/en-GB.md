<!-- piyo-text-writer derived variant — copy/en-GB.md（派生變體＝S4B en-GB from en-US final）
     en-GB 為 en-US 派生變體，非盲稿改編。以 en-US Gate 4 Green Light 凍結稿為基底，
     依 en-GB locale spec 做 BrE 拼寫／詞彙／慣用法適配。
     本書 en-US 文本幾乎全為通用英語，唯一實質變更＝5-6 P02 移除 Oxford comma。 -->

# 圖文總表：What's in the Worry Pocket?（whats-in-the-worry-pocket / en-GB）

> 派生變體＝en-US Gate 4 Green Light 凍結稿（2026-07-21）→ en-GB BrE divergence check。
> 一頁一圖，文字只承擔聲音、台詞、內心與時間等分鏡指定負載。
> Character names `Cuddles`／`Mama Otter` 沿用 en-US 定案不改。
> Refrain `Wait—I need to tell you!`、ending `And from that day on…`、SFX 五組均逐字同 en-US。
> 唯一 BrE 適配＝5-6 P02 移除 Oxford comma（S5.6）；其餘全書無 US-specific 拼寫或詞彙。

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: whats-in-the-worry-pocket
locale: en-GB
mode: B
storyboard: content/PYO-006_whats-in-the-worry-pocket/PYO-006_storyboard.md
design: content/PYO-006_whats-in-the-worry-pocket/PYO-006_design.md
image_pool: 12
selection:
  "3-5": [P01, P02, P04, P05, P07, P08, P09, P10, P11, P12]
  "2-3": [P01, P02, P05, P08, P09, P10, P11, P12]
commitments:
  refrain: "Wait—I need to tell you!"
  ending: "And from that day on…"
  onomatopoeia: [THUNK!, SQUEAK!, PLOP!, SPLISH!, "tap, tap, tap!"]
characters: [Cuddles, Mama Otter]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Cuddles came to splash with her toy duck. Mama Otter slowly let go of Cuddles's hand.<br>THUNK!<br>A stone dropped into Cuddles's pocket—down it sagged. So heavy! | 27✓ | 1 | Cuddles came to splash with her toy duck. Mama Otter let go of her hand.<br>THUNK!<br>A heavy stone dropped into Cuddles's pocket. | 23✓ | 1 | Mama let go.<br>THUNK!<br>A stone fell into Cuddles's pocket.<br>So heavy! | 12✓ | ✓ | No BrE divergence. All vocabulary universal. |
| P02 | 2 | Mama Otter knelt, opened her hands and waited.<br>"Wait—I need to tell you!<br>I'm scared… scared to let go.<br>One more squeeze before goodbye?" Cuddles said.<br>Cuddles stood tall. | 29✓ | 2 | Mama Otter knelt and waited.<br>"Wait—I need to tell you!<br>I'm scared… scared to let go.<br>One more squeeze before goodbye?"<br>Cuddles stood tall. | 24✓ | 2 | "Wait—I need to tell you!<br>I'm scared to let go.<br>One more squeeze?" | 13✓ | ✓ | 【5-6 BrE S5.6】Oxford comma removed: "knelt, opened her hands, and waited" → "knelt, opened her hands and waited". Word count unchanged. 3-5 and 2-3: no divergence. |
| P03 | 3 | Mama Otter gave Cuddles one more squeeze. "I'll be back when your duck is done splashing."<br>Then Mama Otter let go, and Cuddles took one small step with her duck. | 30✓ | — | — | — | — | — | — | ✓ | No BrE divergence. |
| P04 | 4 | Mama Otter took a step toward the doorway. Cuddles kept going.<br>THUNK!<br>A second stone dropped into her pocket. It pulled her backward, turning her around— | 26✓ | 3 | Mama Otter gave one more squeeze. "I'll be back when your duck is done splashing." Cuddles stepped forward.<br>THUNK!<br>A second stone dropped into her pocket and pulled her backward— | 30⚠ | — | — | — | ✓ | No BrE divergence. "toward" is acceptable in BrE (both "toward" and "towards" are used; en-US source form retained for minimal diff). |
| P05 | 5 | SQUEAK!<br>Cuddles turned all the way back.<br>"Wait—I need to tell you!<br>I'm scared… I can't see you from in there.<br>Will you wave from the doorway?"<br>Cuddles turned toward the playroom. | 32✓ | 4 | SQUEAK!<br>"Wait—I need to tell you!<br>I'm scared… I can't see you.<br>Will you wave from the doorway?"<br>Cuddles turned toward the playroom. | 23✓ | 3 | THUNK!<br>"Wait—I need to tell you!<br>I can't see you!<br>Wave, Mama?" | 12✓ | ✓ | No BrE divergence. |
| P06 | 6 | Mama Otter gave one small wave. Cuddles walked to the doorway.<br>A familiar grown-up waited inside by the little tub of water. | 22✓ | — | — | — | — | — | — | ✓ | No BrE divergence. |
| P07 | 7 | Mama Otter said goodbye and turned to go. Cuddles lifted one foot toward the doorway.<br>THUNK!<br>The third—and heaviest—stone dropped into her pocket and pulled her straight down— | 28✓ | 5 | Mama Otter waved.<br>She said goodbye and stepped away.<br>Cuddles lifted one foot toward the doorway—<br>THUNK!<br>The third—and heaviest—stone pulled her down— | 23✓ | — | — | — | ✓ | No BrE divergence. |
| P08 | 8 | PLOP!<br>SQUEAK!<br>Cuddles spoke first.<br>"Wait—I need to tell you!<br>I'm scared… you won't come back.<br>Will you come back when my duck is done splashing?"<br>"Yes. I'll come back," Mama Otter said.<br>Cuddles's pocket lifted off the mat. | 39✓ | 6 | PLOP!<br>SQUEAK!<br>"Wait—I need to tell you!<br>I'm scared… you won't come back.<br>Will you come back after splashing?"<br>"Yes," Mama Otter said. | 23✓ | 4 | THUNK!<br>"Wait—I need to tell you!<br>I'm scared… will you come back?"<br>Mama nodded. | 14✓ | ✓ | No BrE divergence. |
| P09 | 9 | Cuddles stood up all by herself. She gave Mama Otter one small wave, then hugged her toy duck close.<br>She lifted one foot over the threshold— | 26✓ | 7 | Cuddles stood and waved first. Mama Otter waved back.<br>Cuddles hugged her toy duck and lifted one foot— | 18✓ | 5 | Cuddles stood up.<br>She waved.<br>She lifted one foot— | 9✓ | ✓ | No BrE divergence. |
| P10 | 10 | Cuddles stepped through the doorway with all three stones in her pocket.<br>She lowered her toy duck into the water.<br>SPLISH!<br>It floated. | 23✓ | 8 | Cuddles stepped through the doorway with all three stones in her pocket.<br>She lowered her toy duck into the water.<br>SPLISH!<br>It floated. | 23✓ | 6 | In she went!<br>Three stones in her pocket!<br>SPLISH!<br>Her toy duck floated. | 13✓ | ✓ | No BrE divergence. |
| P11 | 11 | Splash time was over. Cuddles lifted her wet toy duck.<br>Then came footsteps Cuddles knew—<br>tap, tap, tap!<br>She looked toward the doorway—and waited— | 24✓ | 9 | Splash time was over. Cuddles lifted her wet toy duck.<br>Then came footsteps Cuddles knew—<br>tap, tap, tap!<br>She looked toward the doorway—and waited— | 24✓ | 7 | Footsteps at the door!<br>tap, tap, tap!<br>Cuddles waited— | 9✓ | ✓ | No BrE divergence. |
| P12 | 12 | Mama Otter came back, just as promised.<br>Cuddles held up her wet toy duck. "My little stones are still here—and so are you!"<br>Hand in hand, they headed home.<br>And from that day on… they held hands at every goodbye and hello. | 42⚠ | 10 | Mama Otter came back.<br>"You came back!"<br>Hand in hand, they headed home.<br>And from that day on… they held hands at every goodbye and hello. | 26⚠ | 8 | Mama came back!<br>And from that day on… they held hands. | 11✓ | ✓ | No BrE divergence. |
