# PYO-006 ja Process Notes (Mode B: Blind Adaptation)

## B0: Language Foundation

### Refrain

| Candidate | Morae | Rhythm | Notes |
|---|---|---|---|
| 「まって、いいたいの！」 | ma-tte / i-i-ta-i-no (5+5) | Balanced 2-beat | **SELECTED**. Natural toddler Japanese: まって = casual imperative (stop/wait), いいたいの = "I want to say [something]" with の as soft assertion particle. A 3-year-old would naturally say this to halt a parent. Not a translation of 等一下，我要說 -- constructed from child-native speech patterns. |
| 「まって！いうね！」 | ma-tte / i-u-ne (3+3) | Very short | Too abrupt; lacks the "wanting to tell" quality. |
| 「ちょっとまって、いいたいの！」 | cho-tto-ma-tte / i-i-ta-i-no (5+5) | Longer | ちょっと adds politeness but breaks the urgency. |

### SFX (5 onomatopoeia)

| Action | zh-TW | ja proposal | Script | Rationale |
|---|---|---|---|---|
| Heavy stone dropping into pocket | 咚 | ズシン | Katakana | Heavy single impact (O1 rule: hard/impact = katakana). ズ carries weight/gravity feel; シン captures the sinking motion into pocket. Differentiated from どすん (body fall). |
| Rubber duck squeezed | 嘎 | キュッ | Katakana | Sharp short squeeze (O1: hard single-burst). キュ = squeeze onomatopoeia; ッ promotes = abrupt stop (O3). |
| Sitting down plop | 噗通 | どすん | Hiragana | Body-to-surface contact (O1: softer body). Distinguished from stone ズシン by hiragana + body-weight register. |
| Duck splashing into water | 啵 | ぽちゃん | Hiragana | Small splash into water (O1: soft/liquid). ぽ = light pop + ちゃん = water splatter. Classic Japanese water-entry sound. |
| Familiar footsteps | 啪嗒 | ぱたぱた | Hiragana | Repeated soft footfalls (O1: light repeated = hiragana). 2-mora repeating unit, natural for walking rhythm. |

### Character Names

| canonical key | ja name | Rationale |
|---|---|---|
| cuddles | ぎゅっちゃん | From design doc proposal. ぎゅっ = onomatopoeia for squeezing/hugging tight (matches clingy character); ちゃん = diminutive. Promotes = abrupt squeeze feel. Natural for toddler speech. |
| mama_otter | カワウソのおかあさん (narration); おかあさん (dialogue/short form) | From design doc proposal. カワウソ = otter (katakana for animal species per P8); おかあさん = mama (standard child-to-mother address). Matches golden pattern: おかあさんブタ for mama_pig. |

### Ending Phrase

| Candidate | Notes |
|---|---|
| 「それからね……」 | **SELECTED**. Intimate, story-closing particle ね invites child listener to imagine what comes next. Golden reference: それからずっと (three-little-pigs P14) uses same それから stem. The ね softens to match this intimate mother-child story. |
| 「それからずっと……」 | Golden-attested but implies long duration; this story's closure is warm and immediate, not epic. |

## Budget Table

### 5-6 (12 pages)

| Item | Value |
|---|---|
| max_page_len | 146 |
| max_total_len | 1089 |
| max_sentence_len | 44 |
| Actual total (raw) | 902 |
| Refrain discount | 「まって、いいたいの！」x3 = 8 chars x 2 repeats x 0.75 = 12 |
| SFX discount | ズシン x3 = 3 chars x 2 repeats x 0.75 = 4.5 -> 4 |
| Total discount | 16 |
| Adjusted total | 886 / 1089 |

### 3-5 (10 pages)

| Item | Value |
|---|---|
| max_page_len | 112 |
| max_total_len | 838 |
| max_sentence_len | 33 |
| Actual total (raw) | 527 |
| Refrain discount | 「まって、いいたいの！」x3 = 12 |
| SFX discount | ズシン x2 extra = ~2; いしは いつもの おもさに もどりました x3 = 26 |
| Total discount | 40 |
| Adjusted total | 487 / 838 |

### 2-3 (8 pages)

| Item | Value |
|---|---|
| max_page_len | 30 |
| max_total_len | 190 |
| max_sentence_len | 21 |
| Actual total (raw) | 166 |
| Refrain discount | 「まって、いいたいの！」x3 = 12 |
| Total discount | 12 |
| Adjusted total | 154 / 190 |

## B2: Source Calibration Notes

### Pages modified during calibration (vs B1 blind draft)

| Page | Tier(s) | Change | Reason |
|---|---|---|---|
| P01 | 5-6 | Trimmed opening sentence; added おもい、おもい repetition | zh-TW uses 好重好重 double emphasis; original draft had unnecessary day-context opening |
| P02 | 5-6 | Restructured: removed ぎゅっと にぎった じぶんの て description; cleaned worry/request structure | zh-TW P02 is much leaner -- worry + request only, no hand-seeing narration. Kept mama-squatting narration as it's a text load not in zh-TW but needed for 5-6 beat. |
| P02 | 3-5 | Absorbed P03 bridge (mama's promise) into P02 | 3-5 skips P03; zh-TW 3-5 P02 is bare refrain, but P03 bridge says 媽媽說了會回來 -- absorbed promise into P02 to maintain causal chain. |
| P05 | 5-6 | Restructured to start with キュッ SFX per zh-TW sequence | zh-TW P05 starts with 嘎！then refrain. Original draft had narration first. |
| P05 | 3-5 | Added P06 bridge (mama waved, Cuddles reached door) before P07's stone | 3-5 skips P06; needed to show Cuddles reached the threshold before the third stone drops. |
| P08 | 5-6 | Added おかあさん……「かならず、くるよ。」mama confirmation; trimmed shoulder/pocket description | zh-TW P08 has 媽媽點點頭：「會的。」-- mama's verbal confirmation is essential for the third cycle's resolution. |
| P12 | 5-6 | Added Cuddles' dialogue 「みてみて、いしは まだ あるよ。あひるちゃん、びしょびしょ！」 | zh-TW P12 has 「你看，小石頭還在，小黃鴨濕濕的！」-- key reunion interaction showing stones and wet duck. |
| P03 | 2-3 | Added ズシン！ at start to bridge skipped P04 (second stone) | zh-TW 2-3 P03 = 「咚！又一顆石頭。嘎！」bridges P04 stone into this page. |
| P04 | 2-3 | Added ズシン！ at start to bridge skipped P07 (third/heaviest stone) | zh-TW 2-3 P04 = 「咚！最重的。噗通！嘎！」bridges P07 stone. |
| P09 | 3-5 | Added おかあさんかも！ excitement | zh-TW 3-5 P09 adds 好像是媽媽！ -- suspense reveal matching the hook. |
| P05 | 2-3 | Added ぎゅっちゃん character name | zh-TW 2-3 P05 uses 牽牽 by name; telegraphic style benefits from one name anchor before the climax pages. |

### Semantic load verification (all tiers)

- Refrain 「まって、いいたいの！」 appears exactly 3x in all tiers (P02/P05/P08 for 5-6; P02/P04/P06 for 3-5; P02/P03/P04 for 2-3)
- SFX ズシン (stone) appears exactly 3x in all tiers
- SFX キュッ (duck squeeze) appears 2x in 5-6/3-5, 2x in 2-3
- SFX どすん (plop) appears 1x in all tiers
- SFX ぽちゃん (splash) appears 1x in all tiers
- SFX ぱたぱた (footsteps) appears 1x or 2x per tier (2-3: 1x, others: 2x for ぱたぱた、ぱたぱた)
- Ending それからね…… appears 1x in all tiers
- Three worries progressive: hand (て) -> invisible (みえなく) -> won't return (かえってこない) -- consistent across all tiers
- No visual descriptions added beyond text loads
- No added entities beyond what's in the storyboard illustrations
