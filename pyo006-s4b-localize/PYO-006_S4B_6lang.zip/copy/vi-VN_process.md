# vi-VN Process Log: PYO-006 What's in the Worry Pocket?

## B0 Language Foundation

### Refrain Variations

| # | Variation | Tiếng count | Notes |
|---|---|---|---|
| A | `"Khoan đã — con muốn nói!"` | 6 | Northern standard "khoan đã" = natural "wait a moment"; "con muốn nói" = child self-referent + want + say. Rhythmic, toddler can echo "muốn nói" half. |
| B | `"Đợi đã — con muốn nói!"` | 6 | "Đợi đã" more colloquial but slightly less rhythmic; "khoan đã" has stronger literary-oral rhythm in children's books. |
| C | `"Khoan — con có điều muốn nói!"` | 7 | Longer; "có điều" (have something) adds syllable weight, harder for 2-3 to echo. |

**Selection: Variation A** -- `"Khoan đã — con muốn nói!"` -- most rhythmically tight, Northern anchored, 6 tiếng fits all tiers, "muốn nói" half is a 2-syllable echo chunk a toddler can complete.

### Character Names

| canonical key | vi-VN name | Alias | Rationale |
|---|---|---|---|
| cuddles | Bống | Rái Bống | "Bống" is a beloved Vietnamese endearment for small children (warm, round sound, 1 syllable = easy for toddlers). "Rái Bống" = baby otter Bống for formal/first mention. Not in registry yet -- proposed for this book. |
| mama_otter | Mẹ Rái | Mẹ | "Mẹ" = mama (Northern, R5 anchor); "Rái" = otter. Natural Vietnamese parent reference. |

### Onomatopoeia Set (Frozen String Table)

| # | Action (design) | vi-VN SFX | Form | Rationale |
|---|---|---|---|---|
| S1 | Heavy stone drops into pocket (x3) | `Bịch!` | Independent effect line, caps first letter | Dull heavy thud; Northern onomatopoeia for something heavy dropping into soft material. Distinct from door knock (cốc cốc) and footsteps (lộp bộp). |
| S2 | Rubber duck squeezed/bounced (x2) | `Kẹt!` | Independent effect line, caps first letter | Rubber squeeze sound; short, sharp, distinct from stone thud. |
| S3 | Heavy pocket pulls Bống to sit on mat (x1) | `Bộp!` | Independent effect line, caps first letter | Soft plop/thud of sitting down; round vowel mirrors the soft mat landing. |
| S4 | Duck placed into water basin (x1) | `Tõm!` | Independent effect line, caps first letter | Classic Vietnamese water-entry splash; distinct from all other SFX in the set. |
| S5 | Familiar footsteps at door (x1) | `lộp bộp, lộp bộp` | Sentence-internal, lowercase | Từ láy (onomatopoeia doublet) for footsteps; warm familiar rhythm; lowercase per O2 mid-intensity. |

### Ending Formula

`"Từ ngày đó… Bống nắm tay mẹ, còn vịt con cũng theo về nhà rồi."` -- "From that day on... Bống held mama's hand, and little duck also followed home." Uses `rồi` sentence-final particle (R3: completion/reassurance warmth). 16 tiếng.

### Character Voice Cards

**Bống (cuddles)**:
- Short sentences, first person "con" (child-to-parent register)
- Says worry first with `con sợ…` (I'm scared...), then makes a completable request
- Core verbal habit = the refrain itself
- Does not say abstract bravery; growth = gradually speaking up first
- 2-3 telegraphic: drops "con" subject, uses bare `sợ…`

**Mẹ Rái (mama_otter)**:
- Warm, few words, predictable responses
- Kneels, opens hands, waits quietly
- Gives one concrete return promise: "Khi vịt con chơi nước xong, mẹ sẽ về." (When duck finishes splashing, mama will return)
- Does not name Bống's worry for her, does not say "Đừng lo" (Don't worry) or "Con giỏi lắm" (You're so brave)
- Third round confirmation: "Có, mẹ sẽ về." (Yes, mama will return)

### Pre-draft Budget Table

| Tier | max_total_len | Refrain raw (6 x 3) | repeat_discount net | SFX fixed | Remaining budget | Pages | Avg per page |
|---|---|---|---|---|---|---|---|
| 5-6 | 658 | 18 raw, 9 net (first full + 2 x 0.25) | 9 | ~15 | 634 | 12 | ~52.8 |
| 3-5 | 506 | 18 raw, 9 net | 9 | ~13 | 484 | 10 | ~48.4 |
| 2-3 | 114 | 18 raw, 9 net | 9 | ~12 | 93 | 8 | ~11.6 |

Note: 2-3 budget is tight at ~11.6 tiếng average per page. Telegraphic style essential. Refrain at 6 tiếng per instance is manageable but leaves little margin. P08 (19 tiếng) and P12 (20 tiếng) push the ceiling due to bridge loads and ending formula.

## B1 Blind Draft

**Read order declaration**: B0/B1 completed without opening any `text/zh-TW/**`, `copy/zh-TW.md`, `text/en-US/**`, or `copy/en-US.md` text content. Only read: design.md, storyboard.md, locale specs, registries, standards files, and this process log.

Draft sequence: 5-6 (master, 12 pages) -> 3-5 (10 pages, skip P03/P06) -> 2-3 (8 pages, skip P03/P04/P06/P07).

### Gap Bridge Inventory

**3-5 gaps**:
- P02->P04 (skipping P03): P03 carries mama's promise + first step. Bridge needed at P04: past-tense callback "Mẹ đã hẹn sẽ về" (Mama promised to return). Verdict: bridged.
- P05->P07 (skipping P06): P06 carries mama's wave + arrival at threshold. Bridge needed at P07: "Mẹ vẫy tay. Bống bước đến cửa" (Mama waved. Bống walked to the door). Verdict: bridged.

**2-3 gaps**:
- P02->P05 (skipping P03, P04): P03 carries promise + step; P04 carries second stone drop + backward pull. Bridge at P05: "Bịch! Thêm một viên nữa." (THUNK! One more stone.) to cover second stone. Verdict: bridged.
- P05->P08 (skipping P06, P07): P06 carries wave + threshold; P07 carries third stone + biggest weight. Bridge at P08: "Bịch! Viên nặng nhất." (THUNK! The heaviest.) to cover third stone. Verdict: bridged.
- P08->P09: Sequential (no gap). Self-sufficient.
- P09->P10: Sequential (no gap). Self-sufficient.
- P10->P11: Sequential (no gap). Self-sufficient.
- P11->P12: Sequential (no gap). Self-sufficient.

## B2 Source Alignment

B2 cross-check completed against zh-TW frozen text (3 tiers x all pages). Changes from B1 blind draft:

| Page | Tier | Change | Reason |
|---|---|---|---|
| P01 | 5-6 | Added "chuẩn bị đi chơi nước" (getting ready to play water) | zh-TW has scene-setting "準備去玩水"; B1 had started mid-action. Added native Vietnamese phrasing, not translated. |
| P03 | 5-6 | Refined mama's promise to match design covenant beat exactly | zh-TW explicitly voices the return promise as mama's dialogue. B1 already had this but phrasing aligned. |
| P05 | 2-3 | Bridge strategy confirmed: "Bịch! Thêm một viên nữa." | zh-TW 2-3 P03 uses same bridge strategy "咚！又一顆石頭。" Confirmed alignment. |
| P08 | 2-3 | Bridge strategy confirmed: "Bịch! Viên nặng nhất." | zh-TW 2-3 P04 uses same bridge "咚！最重的。" Confirmed alignment. |
| P08 | 2-3 | Added "Mẹ gật đầu." (Mama nodded.) | zh-TW 2-3 P04 includes "媽媽點點頭。" B1 already had this -- confirmed essential for emotional landing. |

No structural changes needed. B1 blind draft already captured all semantic loads correctly from design/storyboard specifications. Adjustments were minor phrasing alignment to ensure completeness.

## Machine Check Results (STEP 3)

1. **copy_check.py**: PASS (exit 0; 8 below-band warnings, all advisory -- short pages are telegram-style 2-3 or transition pages)
2. **locale_lint.py**: 5-6 PASS (0 violations); 3-5 PASS (0 violations); **2-3: 1 violation** (P08 max_sentence_len 15 > 10 -- ending formula structural issue, see escalation below)
3. **localize_readiness.py --contract**: PASS (green -- registries updated)

## Escalations

1. **2-3 P08 max_sentence_len violation (locale_lint)**: Ending formula sentence "Từ ngày đó… Bống nắm tay mẹ, còn vịt con cũng theo về nhà rồi." is 15 tiếng (after `…` split: "Từ ngày đó…" = 3 + remainder = 12), exceeding vi-VN 2-3 max_sentence_len=10 (seed value, low confidence). This is a **cross-locale structural issue**: zh-TW 2-3 P08 has the same violation (句長 20 > 上限 15) with the same root cause -- the ending formula is a design commitment that cannot be reduced below its current length. Recommend spec review for vi-VN 2-3 max_sentence_len or an ending formula exemption mechanism.

2. **Below-band pages (copy_check warnings)**: 8 pages fall below the target band floor across tiers. All are intentionally short: 2-3 telegram-style pages (P01=9, P05=9, P06=9, P09=9) and 5-6 transition/quiet pages (P04=19, P09=15, P10=18, P11=19). None represent missing beats; verified against storyboard semantic loads.

3. **Registry write-back**: character_names.md and onomatopoeia_map.md updated with vi-VN proposals (Bống/Mẹ Rái, 5 SFX). Pending TTS round-trip validation for all SFX.

## STEP 4 Self-Check (W0-W9)

| # | Criterion | Pass/Fail | Evidence |
|---|---|---|---|
| W0 | Concept fidelity | PASS | original_concept: "小水獺每次擔心，口袋就多一顆小石頭；說出名字後口袋變輕". 5-6: child reads = "when Bống worries, pocket gets heavy; when she speaks up, she can take the next step" (P01 stone + P02 speaks + P03 first step; repeated P04-P05, P07-P08; culmination P09-P10 crosses threshold). 3-5: same arc in 10 pages, bridges preserve causality. 2-3: telegram version preserves core loop (stone -> refrain -> move). Interest check: P02 "con sợ... buông tay ra" + hand-squeeze request (5-6) serves theme directly; P08 "con sợ... mẹ không về nữa" + "Chơi nước xong, mẹ có về không?" serves theme's peak escalation. |
| W1 | Framework fidelity | PASS | Spot-checked P01 (storyboard: narration of separation setup + SFX stone; text: setup + "Bịch!" + heavy pocket -- matches), P05 (storyboard: SFX duck squeeze + refrain + 2nd worry + wave request; text: "Kẹt!" + refrain + "Con sợ... không nhìn thấy mẹ." + "Mẹ vẫy tay ở cửa nhé?" -- matches), P12 (storyboard: mama returns + reunion exchange + closing formula; text: "Mẹ về rồi!" + show-and-tell dialogue + ending formula -- matches). No scene changes, no plot changes, selection table unchanged. |
| W2 | Alignment self-check | PASS | 5-6 P01: "Bống ôm vịt con, chuẩn bị đi chơi nước" = context setup (duck + water play) visible in image; "Mẹ từ từ buông tay ra" = action visible in image. No color/appearance/position restatement. "Nặng quá, nặng quá!" = inner sensation, not visual. 3-5 P06: "Bộp! Kẹt!" = sounds (not visual); refrain + worry + request = speech (not visual); "Chơi nước xong, mẹ về nhé?" = request (not visual); "Có." = response (not visual). All text loads are sound/speech/inner state. No visual restatement found. |
| W3 | Entity layer self-check | PASS | 5-6 P02: entities = Mẹ Rái (in storyboard image: mama crouches to same height), hands open (in image: palms up), Bống speaking (in image: mouth open). All present. 2-3 P04: entities = stone (image: three stones visible), Bống (image: sitting on mat), duck bouncing (image: duck just landed), Mama nodding (image: mama crouches with open hands, consistent). Bridge entity "Bịch! Viên nặng nhất" refers to stone falling = design P07 beat, acceptable bridge entity. All entities verified. |
| W4 | Read-aloud test | PASS | Refrain "Khoan đã — con muốn nói!" x3 read: natural Northern rhythm, no awkward clusters, em-dash gives breath pause. "Bịch!" "Kẹt!" "Bộp!" "Tõm!" -- all single-syllable, punchy, child-friendly. "lộp bộp, lộp bộp" -- natural từ láy, warm rhythm. No bookish vocabulary detected; all words are age-appropriate oral Vietnamese. Tense pages (P04, P07) use short staccato sentences; warm pages (P03, P12) use longer flowing ones. |
| W5 | Three-tier shared rules | PASS | Refrain: identical "Khoan đã — con muốn nói!" across all tiers at P02/P05/P08 (5-6) and mapped pages (3-5, 2-3). Character names: Bống, Mẹ Rái, Mẹ consistent across tiers. SFX strings: Bịch!/Kẹt!/Bộp!/Tõm!/lộp bộp identical. Registry entries match copy table commitments. |
| W6 | Design commitment fulfillment | PASS | Design selling_points = concept_contract (same text). Checked: (1) stone-per-worry = P01/P04/P07 in 5-6, bridges in lower tiers; (2) refrain 3 rounds = P02/P05/P08 all tiers; (3) speaking-up-makes-lighter = P02 (stands straight after speaking), P05 (turns back, stones normal weight), P08 (mama confirms); (4) three escalating worries (letting go / can't see / won't return) = P02/P05/P08 all tiers; (5) ending formula = P12 all tiers. All design commitments fulfilled. |
| W7 | Low-tier register | PASS | 2-3 uses telegram style throughout: P01 "Mẹ buông tay rồi. Bịch! Túi áo nặng quá!" (9 tiếng, 3 short sentences); P02 drops "con" subject -> "Sợ... buông tay." (bare worry); P05/P06/P09 all use rồi-terminated closure ("đứng dậy rồi", "Bước qua rồi!", "Nổi lên rồi.") per vi-VN spec R3 completion particle. Not "long sentences made shorter" but restructured as telegram bursts. Ending formula split into shorter sentences for 2-3. |
| W8 | Adaptation not translation (Mode B only) | PASS | Spot-checked 3 pages against zh-TW: P02 zh-TW "「等一下，我要說！」「怕⋯⋯ 手放開。」「再握一下。」" vs vi-VN "「Khoan đã — con muốn nói!」「Con sợ... buông tay ra.」「Nắm thêm một cái nhé?」" -- different syntax (vi-VN adds "nhé?" softener, uses "con sợ" instead of bare "sợ" at 5-6), not calque. P09 zh-TW "牽牽自己站起來了。" vs vi-VN "Bống tự đứng dậy." -- different word order, no 了 particle mapping. P12 vi-VN "Mẹ nhìn nè" uses Southern-neutral "nè" (acceptable, not in banned list) vs zh-TW "媽媽你看" -- different pragmatic markers. No banned Southern terms (má, trái, chén, muỗng, bắp, nầy) found. No CJK characters found. Reads as native Vietnamese children's book. |
| W9 | Gap bridging self-sufficiency | PASS | **3-5 gaps**: (1) P02->P04 skip P03: masking P03, reading P02+P04 -- P02 ends with squeeze request, P04 starts "Mẹ đã hẹn sẽ về. Bống bước tới." Bridge "Mẹ đã hẹn sẽ về" (Mama promised to return) provides causality for stepping forward without knowing P03's promise scene. Self-sufficient. (2) P05->P07 skip P06: P05 ends with wave request, P07 starts "Mẹ vẫy tay. Bống bước đến cửa —" Bridge covers wave + arrival at door. Self-sufficient. **2-3 gaps**: (1) P02->P05 skip P03,P04: P05 starts "Bịch! Thêm một viên nữa. Kẹt!" Bridge "Bịch! Thêm một viên nữa" accounts for missing second stone. Self-sufficient. (2) P05->P08 skip P06,P07: P08 starts "Bịch! Viên nặng nhất. Bộp! Kẹt!" Bridge "Bịch! Viên nặng nhất" accounts for heaviest third stone. Self-sufficient. All bridge decisions logged in copy table notes column. |
