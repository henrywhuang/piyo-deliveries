<!-- piyo-text-writer B1 blind draft — copy/vi-VN.md (Mode B = S4B vi-VN adaptation)
     Section headings, header YAML fields and table columns follow templates/copy_table_template.md contract.
     B0 language foundation, B1 three-tier blind draft, B2 source alignment completed.
     Read order: B0/B1 period did NOT open any text/zh-TW/**, copy/zh-TW.md, text/en-US/**, or copy/en-US.md.
     B2 opened zh-TW frozen text for cross-check only after B1 completion. -->

# Trong Túi Lo Có Gì? (whats-in-the-worry-pocket / vi-VN)

> Mode B = locale adaptation (S4B, **adaptation, not translation** — read design documents then retell the story natively in Vietnamese);
> Page selection **fully inherits** storyboard three-tier selection table (copied into header selection, no self-selection/addition/deletion);
> One page one image; text carries only sound, dialogue, inner state, and time — does not restate visually evident facts.
> Word count targets the band **midpoint**, not the ceiling.
>
> **B0 Language Foundation Notes**
>
> - Refrain (adopted): `"Khoan đã — con muốn nói!"` — Northern standard "khoan đã" (wait) + child self-referent "con muốn nói" (I want to say); 6 tiếng, rhythmic, toddler can echo the "muốn nói" half. Three rounds, identical wording, page positions P02/P05/P08 per design.
> - Refrain three-round functional contract: Round 1 -> letting-go worry + squeeze request; Round 2 -> can't-see-Mama worry + wave request; Round 3 -> Bống speaks first, asks if Mama will return. High-tier worry uses `…` hesitation beat; 2-3 uses complete toddler short sentences.
> - Bống voice card: Short sentences, first person "con", says worry with "con sợ…" (I'm scared…) then makes a completable request. Core habit = the refrain. Does not say abstract bravery; growth = gradually initiating speech.
> - Mẹ Rái voice card: Warm, few words, predictable. Kneels, opens hands, waits. One concrete return promise: "Khi vịt con chơi nước xong, mẹ sẽ về." Does not name Bống's worry, does not say "Đừng lo" or "Con giỏi lắm."
> - SFX set (proposed, pending registry write-back + TTS round-trip): `Bịch!` (stone drop), `Kẹt!` (duck squeeze), `Bộp!` (sit plop), `Tõm!` (duck into water), `lộp bộp, lộp bộp` (footsteps).
> - Read order declaration: B0/B1 completed without opening any zh-TW or en-US text files. B2 opened zh-TW frozen text for source alignment only.
> - B2 full coverage: Cross-checked all 12/10/8 pages against zh-TW frozen text. All semantic loads present; minor phrasing adjustments for completeness logged in table notes.

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: whats-in-the-worry-pocket
locale: vi-VN
mode: B
storyboard: content/PYO-006_whats-in-the-worry-pocket/PYO-006_storyboard.md
design: content/PYO-006_whats-in-the-worry-pocket/PYO-006_design.md
image_pool: 12
selection:
  "3-5": [P01, P02, P04, P05, P07, P08, P09, P10, P11, P12]
  "2-3": [P01, P02, P05, P08, P09, P10, P11, P12]
commitments:
  refrain: "Khoan đã — con muốn nói!"
  ending: "Từ ngày đó… Bống nắm tay mẹ, còn vịt con cũng theo về nhà rồi."
  onomatopoeia: ["Bịch!", "Kẹt!", "Bộp!", "Tõm!", "lộp bộp, lộp bộp"]
characters: [Bống, Mẹ Rái]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Bống ôm vịt con, chuẩn bị đi chơi nước.<br>Mẹ từ từ buông tay ra —<br>Bịch!<br>Túi áo bỗng nặng trĩu. Nặng quá, nặng quá! | 25✓ | 1 | Mẹ buông tay ra —<br>Bịch!<br>Túi áo thêm một viên sỏi, nặng quá, nặng quá! | 15✓ | 1 | Mẹ buông tay rồi.<br>Bịch!<br>Túi áo nặng quá! | 9✓ | ✓ | 3-5 cắt thiết lập cảnh (ôm vịt, chuẩn bị chơi nước), vào thẳng buông tay; 2-3 điện báo (buông tay + SFX + cảm nhận). B2: thêm "chuẩn bị đi chơi nước" vào 5-6 theo zh-TW. |
| P02 | 2 | Mẹ Rái ngồi xuống, xòe hai bàn tay ra, lặng lặng chờ.<br>"Khoan đã — con muốn nói!"<br>"Con sợ… buông tay ra."<br>"Nắm thêm một cái nhé?" | 27✓ | 2 | "Khoan đã — con muốn nói!"<br>"Con sợ… buông tay ra."<br>"Nắm thêm một cái nhé?" | 15✓ | 2 | "Khoan đã — con muốn nói!"<br>"Sợ… buông tay."<br>"Nắm một cái." | 11✓ | ✓ | 3-5 cắt hành động mẹ, giữ ba dòng thoại; 2-3 bỏ chủ ngữ "con" thành điện báo "sợ…", rút gọn yêu cầu. |
| P03 | 3 | Mẹ nói khẽ: "Khi vịt con chơi nước xong, mẹ sẽ về."<br>Nắm thêm một cái, rồi buông.<br>Bống ôm vịt con, bước một bước nhỏ về phía trước. | 29✓ | — | — | — | — | — | — | ✓ | 3-5/2-3 bỏ; beat chuyển sang 3-5 P04 (hồi chỉ quá khứ "Mẹ đã hẹn sẽ về") và 2-3 P05. |
| P04 | 4 | Mẹ bước một bước về phía cửa.<br>Bống cũng bước tới —<br>Bịch!<br>Túi áo giật mạnh về phía sau. | 19✓ | 3 | Mẹ đã hẹn sẽ về. Bống bước tới.<br>Bịch!<br>Túi áo giật mạnh về phía sau. | 16✓ | — | — | — | ✓ | 3-5 nối P03: "Mẹ đã hẹn sẽ về" hồi chỉ quá khứ (nhân quả tự túc: cần biết mẹ hứa thì mới hiểu tại sao bước tới); 2-3 bỏ, nối P05. |
| P05 | 5 | Kẹt! Vịt con bị bóp một cái.<br>"Khoan đã — con muốn nói!"<br>"Con sợ… không nhìn thấy mẹ."<br>"Mẹ vẫy tay ở cửa nhé?" | 24✓ | 4 | Kẹt!<br>"Khoan đã — con muốn nói!"<br>"Con sợ… không nhìn thấy mẹ."<br>"Vẫy tay nhé?" | 15✓ | 3 | Bịch! Thêm một viên nữa.<br>Kẹt!<br>"Khoan đã — con muốn nói!"<br>"Sợ… không thấy mẹ." | 15✓ | ✓ | 3-5 cắt câu miêu tả SFX, rút ngắn yêu cầu; 2-3 nối P03/P04: "Bịch! Thêm một viên nữa" bù viên sỏi thứ hai + vịt kêu, bỏ câu yêu cầu. |
| P06 | 6 | Mẹ đứng ở cửa, nhẹ nhàng vẫy tay.<br>Bống bước đến bậc cửa — bên trong có người chờ, và cả cái chậu nước nữa. | 24✓ | — | — | — | — | — | — | ✓ | 3-5/2-3 bỏ; beat chuyển sang 3-5 P07 (hồi chỉ vẫy tay + đến cửa) và 2-3 P08. |
| P07 | 7 | Mẹ nói lời tạm biệt, quay người bước đi.<br>Bống vừa nhấc chân lên —<br>Bịch!<br>Viên sỏi nặng nhất rơi xuống túi áo. | 23✓ | 5 | Mẹ vẫy tay. Bống bước đến cửa —<br>Bịch!<br>Viên sỏi nặng nhất rơi xuống túi áo. | 16✓ | — | — | — | ✓ | 3-5 nối P06: "Mẹ vẫy tay" + "bước đến cửa" hồi chỉ quá khứ (nhân quả: cần biết đã đến ngưỡng cửa mới hiểu bước qua); 2-3 bỏ, nối P08. |
| P08 | 8 | Bộp!<br>Kẹt! Vịt con bật lên.<br>"Khoan đã — con muốn nói!"<br>"Con sợ… mẹ không về nữa."<br>"Chơi nước xong, mẹ có về không?"<br>Mẹ gật đầu: "Có, mẹ sẽ về." | 31✓ | 6 | Bộp! Kẹt!<br>"Khoan đã — con muốn nói!"<br>"Con sợ… mẹ không về nữa."<br>"Chơi nước xong, mẹ về nhé?"<br>"Có." | 20✓ | 4 | Bịch! Viên nặng nhất.<br>Bộp! Kẹt!<br>"Khoan đã — con muốn nói!"<br>"Sợ… mẹ không về."<br>Mẹ gật đầu. | 18✓ | ✓ | 3-5 gộp SFX, bỏ từ dẫn thoại; 2-3 nối P06/P07: "Bịch! Viên nặng nhất" bù viên thứ ba + bộp + vịt, giữ xác nhận ngắn nhất (gật đầu = hạ cánh cảm xúc, không thoại). |
| P09 | 9 | Bống tự đứng dậy.<br>Bống vẫy tay chào mẹ, ôm vịt con, nhấc chân lên — | 15✓ | 7 | Bống đứng dậy, vẫy tay chào mẹ.<br>Ôm vịt con, nhấc chân lên — | 13✓ | 5 | Bống đứng dậy rồi.<br>Vẫy tay — nhấc chân lên — | 9✓ | ✓ | 3-5 đơn giản (gộp + bỏ "tự"); 2-3 điện báo (đứng dậy rồi + vẫy tay — nhấc chân —). |
| P10 | 10 | Bống bước qua bậc cửa, nhẹ nhàng đặt vịt con vào chậu nước.<br>Tõm!<br>Vịt con nổi lên. | 18✓ | 8 | Bống bước qua bậc cửa, đặt vịt con vào chậu nước.<br>Tõm! Vịt con nổi lên rồi. | 17✓ | 6 | Bước qua rồi!<br>Vịt con — Tõm!<br>Nổi lên rồi. | 9✓ | ✓ | 3-5 bỏ "nhẹ nhàng"; 2-3 điện báo (bước qua rồi + SFX + kết quả). |
| P11 | 11 | Vịt con chơi nước xong rồi.<br>lộp bộp, lộp bộp.<br>Ngoài cửa vọng lại tiếng bước chân quen thuộc. | 19✓ | 9 | Vịt con chơi xong rồi.<br>lộp bộp, lộp bộp.<br>Ngoài cửa có tiếng bước chân — hình như là mẹ! | 19✓ | 7 | Vịt con chơi xong rồi.<br>lộp bộp, lộp bộp.<br>Ngoài cửa có tiếng bước chân. | 15✓ | ✓ | 3-5 bỏ "nước", đổi "quen thuộc" thành đoán cụ thể "hình như là mẹ!" (tự nhiên hơn + hồi hộp); 2-3 điện báo "ngoài cửa có tiếng bước chân". |
| P12 | 12 | Mẹ về rồi!<br>"Mẹ nhìn này, mấy viên sỏi vẫn còn đây, vịt con ướt hết rồi!"<br>Từ ngày đó… Bống nắm tay mẹ, còn vịt con cũng theo về nhà rồi. | 32✓ | 10 | Mẹ về rồi!<br>Từ ngày đó… Bống nắm tay mẹ, còn vịt con cũng theo về nhà rồi. | 18✓ | 8 | Mẹ về rồi!<br>Từ ngày đó… Bống nắm tay mẹ, còn vịt con cũng theo về nhà rồi. | 18✓ | ✓ | 3-5 bỏ thoại trùng phùng, giữ quay về + công thức kết; 2-3 giữ nguyên công thức kết（cam kết thiết kế；句長 12 > max_sentence_len=10 = 結構性 escalation，同 zh-TW）。 |
