# pt-BR Process Log: What's in the Worry Pocket? (PYO-006)

## B0 Language Foundation

### Refrain
- **Adopted**: `— Espera — eu preciso falar!`
- Rationale: `Espera` is natural BR toddler imperative (mamae/papai say it daily); `eu preciso falar` = "I need to talk" in child-native first person. Travessao dialogue format per pt-BR spec P5-1. Two-year-old can echo `falar!` at minimum, three-year-old can say full refrain.
- Rejected B: `— Para — eu preciso dizer!` (dizer less natural for toddlers)
- Rejected C: `— Espera, mamae — eu preciso contar!` (locks addressee to Mamae)

### SFX (5 frozen strings)
| # | Action | pt-BR | Rationale |
|---|---|---|---|
| 1 | Stone drops into pocket | `TUM!` | BR onomatopoeia for heavy dull impact; CAPS + `!` per spec O2 high-intensity. Registry: no existing pt-BR entry for this story. |
| 2 | Rubber duck squeezed/bounced | `QUEC!` | BR toy-squeeze sound; short, comic, child-friendly. Not `CHUIC` (too sibilant for duck). |
| 3 | Pulled down onto soft mat | `PLOFT!` | BR soft-landing plop; lighter than `PLOP` (EN), the F gives Brazilian mouthfeel. |
| 4 | Duck into water | `TCHIBUM!` | Classic BR child-native splash onomatopoeia (tchibum na agua!); universally recognized in Brazilian children's media. |
| 5 | Familiar footsteps | `tec, tec, tec!` | Light rhythmic footstep; comma-space separation per spec O5; lowercase sentence-internal per spec O2 (suspense, not explosion). |

### Names
- **Dedinha** (cuddles): Diminutivo of `dedo` (finger) -- evokes holding hands / `dar o dedinho` (pinky promise). Two syllables, -inha ending = peak BR toddler warmth. Alternative considered: Lontrinha (too generic, just "little otter").
- **Mamae Lontra** (mama_otter): Standard BR `mamae` + species. Alias `Mamae` in dialogue.

### Ending
- `E desde aquele dia… elas davam as maos em todo tchau e em todo oi.`
- Maps to brand closure "And from that day on..." / `E desde aquele dia…` (pt-BR native equivalent of "Desde aquele dia" with the connective `E` for storytelling warmth). The `tchau e oi` pair echoes the story's goodbye-and-hello cycle.

## B1 Blind Draft

### Pre-draft Budget Table

| Tier | max_total_len | Refrain x3 (full) | Refrain discount (0.25 x 2) | SFX repeats discount | Estimated available | Target midpoint |
|---|---|---|---|---|---|---|
| 5-6 | 761 | 6w x 3 = 18w | 6 x 0.25 x 2 = 3w saved | TUM x3 = 1w x 0.25 x 2 = 0.5w saved | ~757 effective | ~380 |
| 3-5 | 585 | 18w | 3w saved | 0.5w saved | ~582 effective | ~290 |
| 2-3 | 101 | 18w | 3w saved | TUM x3 = 0.5w saved | ~98 effective | ~50 |

Budget is comfortable for all tiers.

### Drafting Order
5-6 (full 12 pages) -> 3-5 (10 pages, skip P03/P06) -> 2-3 (8 pages, skip P03/P04/P06/P07)

### Gap Bridge Decisions (B1)

**3-5 bridges:**
- P02->P04 (skips P03): P04 opens with `Mamae Lontra disse que voltava. Dedinha apertou mais uma vez e deu um passo.` -- bridges Mama's return promise and squeeze from P03 beat.
- P06 skipped (P05->P07): P07 opens with `Mamae Lontra fez tchauzinho. Virou e foi embora.` -- bridges Mama's wave and departure from P06 beat.

**2-3 bridges:**
- P02->P05 (skips P03, P04): P03/P05 opens with `TUM!` -- second stone + refrain + second worry self-sufficient (reader sees progression from first stone).
- P05->P08 (skips P06, P07): P04/P08 opens with `TUM!` -- third stone + refrain + third worry self-sufficient (pattern established by now).
- P04->P05 (internal, skips nothing): P04 ends with `Mamae fez que sim.`; P05 opens with Dedinha standing up -- natural flow.

## B2 Calibration (zh-TW cross-check)

### Changes Made

| Page | Tier | Change | Reason |
|---|---|---|---|
| P01 | 5-6 | Added `devagarzinho` (slowly) for Mama letting go | zh-TW has `慢慢鬆開手` (slowly let go); B1 had plain `soltou` -- `devagarzinho` is more native BR and matches the gentleness. |
| P03 | 5-6 | Confirmed return promise wording matches zh-TW beat | zh-TW: `小黃鴨玩完水，我就回來` -- pt-BR `Eu volto quando o patinho acabar de brincar na agua` already captures verifiable return event. No change needed. |
| P08 | 5-6 | Added `O bolso saiu do chao.` (pocket lifted off the floor) | zh-TW has pocket lifting/shoulder lifting beat after third worry resolved; B1 missed the physical resolution marker. Native phrasing, not translation. |
| P08 | 5-6 | Added `Dedinha falou primeiro.` | zh-TW/storyboard specifies Cuddles speaks first in round 3 (proactive). B1 had this implicit; made it explicit per design requirement. |
| P11 | 5-6 | Added `Ai veio um barulho que ela conhecia —` | zh-TW has `門外傳來好熟悉的腳步聲` (familiar footsteps from outside the door); B1 had footsteps but lacked the "familiar/known" quality. Native BR phrasing. |
| P12 | 5-6 | Added `igualzinho prometeu` (just as promised) | zh-TW has implicit promise-kept; en-US has `just as promised`. Added for emotional payoff. Native BR diminutivo form. |
| P12 | 5-6 | Added stone/duck display dialogue | zh-TW P12 has `你看，小石頭還在，小黃鴨濕濕的！` -- the reunion show-and-tell. B1 missed this beat. |

### Semantic Completeness Verification

All 12 pages verified against zh-TW source:
- Three rounds of {disruption -> refrain -> name worry -> request -> step forward}: COMPLETE
- Three `TUM!` (stones): P01, P04/P05, P07/P08 -- COMPLETE
- Two `QUEC!` (duck): P05, P08 -- COMPLETE
- One `PLOFT!` (sit plop): P08 -- COMPLETE
- One `TCHIBUM!` (splash): P10 -- COMPLETE
- One `tec, tec, tec!` (footsteps): P11 -- COMPLETE
- Return promise and verification: P03/P08 (promise), P12 (fulfilled) -- COMPLETE
- Closure with ending formula: P12 all three tiers -- COMPLETE
