<!-- piyo-text-writer B1 blind draft + B2 calibration — copy/pt-BR.md（模式 B＝S4B pt-BR 改編）
     章節標題、檔頭 YAML 欄位與表格欄位沿用 templates/copy_table_template.md 的機檢契約。
     本檔已完成 B0 語感基建、B1 三檔盲稿與 B2 對源校準。 -->

# 圖文總表：O Que Tem no Bolso da Preocupacao?（whats-in-the-worry-pocket / pt-BR）

> 模式 B＝locale 改編（S4B，**改編不是翻譯**）；頁面選用完全繼承 storyboard 三檔選用表。
> 一頁一圖，文字只承擔聲音、台詞、內心與時間等分鏡指定負載。
> Display title `O Que Tem no Bolso da Preocupacao?` 為 B0 提案（待 Stacy 裁定品牌級命名）。
> `Dedinha`／`Mamãe Lontra` 為 B0 母語提案（待 registry 回寫裁定）。
> `TUM!`／`QUEC!`／`PLOFT!`／`TCHIBUM!`／`tec, tec, tec!` 為 B0 擬聲提案（待 TTS round-trip）。
>
> **B0 語感基建註記**
>
> - 疊句（採用）：`— Espera — eu preciso falar!`——travessao 對話制，BR 幼兒節拍「停一下＋我需要說」，三歲可跟唸；三檔三輪逐字同形、頁位不變。
> - 疊句備選 A：`— Para — eu preciso dizer!`——`para` 更口語但動詞 `dizer` 對 2 歲偏正式。
> - 疊句備選 B：`— Espera, mamãe — eu preciso contar!`——親密但鎖定 Mamãe Lontra，跨情境彈性低。
> - 採用句三輪功能契約：第一輪後接放手擔心與再握請求；第二輪後接看不見 Mamãe 與揮手請求；第三輪由 Dedinha 主動先說並確認重逢。
> - Dedinha 口癖卡：短句、第一人稱、先說擔心再提一個可完成的小需求（`Mais um aperto?`／`Tchau com a mão, mamãe?`／`Você volta?`）；不說大道理，不變成「從此不擔心」。
> - Mamãe Lontra 口癖卡：溫暖、少說、可預期；`Estou ouvindo.` 承接，`Volto quando o patinho acabar de brincar na água.` 約定具體重逢事件；不替 Dedinha 命名擔心、不說 `Seja corajosa` 或 `Não se preocupe`。
> - 擬聲詞組（B0 提案凍結字串表）：`TUM!`（石落袋）, `QUEC!`（鴨被擠）, `PLOFT!`（被拉坐）, `TCHIBUM!`（鴨入水）, `tec, tec, tec!`（腳步聲）。
> - 收束式（採用）：`E desde aquele dia… elas davam as mãos em todo tchau e em todo oi.`
> - 角色名提案：Dedinha（diminutivo de `dedo`＝小指，暗合「牽手」主題；BR 幼兒暱稱化、兩音節易唸）；Mamãe Lontra（BR 兒語 mamãe＋物種名，與 zh-TW 「水獺媽媽」同構）。
> - 讀序聲明：B0／B1 期間未開啟、搜尋或間接讀取任何 `text/zh-TW/**`、`copy/zh-TW.md`、`text/en-US/**` 或 `copy/en-US.md` 內容；只讀凍結的 design／storyboard 語義規格、指定 standards、pt-BR spec 與 registries。B1 完成後 B2 才首次開啟 zh-TW 母本逐頁校準。
> - B2 全量覆蓋：已逐頁交叉核對 5-6 P01-P12、3-5 P01-P10、2-3 P01-P08；事件／情緒／台詞意圖、石頭規則與 bridge 功能均以母本與 storyboard 交叉校準。

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: whats-in-the-worry-pocket
locale: pt-BR
mode: B
storyboard: content/PYO-006_whats-in-the-worry-pocket/PYO-006_storyboard.md
design: content/PYO-006_whats-in-the-worry-pocket/PYO-006_design.md
image_pool: 12
selection:
  "3-5": [P01, P02, P04, P05, P07, P08, P09, P10, P11, P12]
  "2-3": [P01, P02, P05, P08, P09, P10, P11, P12]
commitments:
  refrain: "— Espera — eu preciso falar!"
  ending: "E desde aquele dia…"
  onomatopoeia: ["TUM!", "QUEC!", "PLOFT!", "TCHIBUM!", "tec, tec, tec!"]
characters: [Dedinha, Mamãe Lontra]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Dedinha trouxe o patinho para brincar na água. Mamãe Lontra foi soltando a mão dela, devagarzinho.<br>TUM!<br>Uma pedrinha caiu dentro do bolso — ficou pesado, pesado. | 26✓ | 1 | Mamãe Lontra soltou a mão.<br>TUM!<br>Uma pedrinha caiu no bolso de Dedinha. Pesado, pesado! | 15✓ | 1 | Mamãe soltou a mão.<br>TUM!<br>O bolso ficou pesado, pesado! | 10✓ | ✓ | 5-6 建立玩水目標與媽媽慢慢放手；3-5 開門見山放手＋石落；2-3 電報式三拍。 |
| P02 | 2 | Mamãe Lontra abaixou, abriu as mãos e ficou esperando, quietinha.<br>— Espera — eu preciso falar!<br>— Eu tenho medo… de soltar a mão.<br>— Mais um aperto antes do tchau? | 27✓ | 2 | Mamãe Lontra abaixou e esperou.<br>— Espera — eu preciso falar!<br>— Eu tenho medo… de soltar a mão.<br>— Mais um aperto? | 19✓ | 2 | — Espera — eu preciso falar!<br>— Medo… de soltar a mão.<br>— Mais um aperto? | 12✓ | ✓ | 三檔疊句逐字一致；2-3 擔心用碎句 `Medo…` 電報式，保留具體擔心與需求。 |
| P03 | 3 | Mamãe Lontra deu mais um aperto. — Eu volto quando o patinho acabar de brincar na água.<br>Soltou a mão, e Dedinha deu um passinho com o patinho debaixo do braço. | 30✓ | — | — | — | — | — | — | ✓ | 5-6 only：媽媽約定可驗證重逢事件＋放手＋第一步。 |
| P04 | 4 | Mamãe Lontra deu um passo pro lado da porta. Dedinha continuou andando.<br>TUM!<br>Outra pedrinha caiu no bolso e puxou tudo pra trás — | 23✓ | 3 | Mamãe Lontra disse que voltava. Dedinha apertou mais uma vez e deu um passo.<br>TUM!<br>Outra pedrinha caiu no bolso e puxou tudo pra trás — | 25✓ | — | — | — | ✓ | 3-5 bridge 承接 P03 被跳：媽媽說會回來＋握手＋第一步，然後第二石 hook。 |
| P05 | 5 | QUEC!<br>Dedinha virou inteirinha de volta pra mamãe.<br>— Espera — eu preciso falar!<br>— Eu tenho medo… de não enxergar você lá dentro.<br>— Tchau com a mão lá na porta, mamãe? | 29✓ | 4 | QUEC!<br>— Espera — eu preciso falar!<br>— Eu tenho medo… de não enxergar você.<br>— Tchau com a mão, mamãe? | 17✓ | 3 | TUM!<br>— Espera — eu preciso falar!<br>— Medo… não vejo mamãe.<br>— Tchau com a mão? | 13✓ | ✓ | 2-3 bridge P02→P05：第二石 `TUM!` 自足傳遞進展；擔心＋揮手需求電報式。 |
| P06 | 6 | Mamãe Lontra fez um tchauzinho com a mão. Dedinha chegou pertinho da porta.<br>Lá dentro, alguém conhecido esperava, e a bacia de água estava lá. | 25✓ | — | — | — | — | — | — | ✓ | 5-6 only：媽媽揮手、安全線索（照顧者＋水盆）。 |
| P07 | 7 | Mamãe Lontra disse tchau e virou pra ir embora. Dedinha levantou um pé pra entrar.<br>TUM!<br>A pedrinha mais pesada de todas caiu no bolso e puxou ela direto pro chão — | 31✓ | 5 | Mamãe Lontra fez tchauzinho. Virou e foi embora.<br>Dedinha levantou um pé —<br>TUM!<br>A pedrinha mais pesada de todas puxou ela pra baixo — | 23✓ | — | — | — | ✓ | 3-5 comprime despedida + P06 跳接 bridge（已到門口）＋第三石 hook。 |
| P08 | 8 | PLOFT!<br>QUEC!<br>Dedinha falou primeiro.<br>— Espera — eu preciso falar!<br>— Eu tenho medo… de você não voltar.<br>— Você volta quando o patinho acabar de brincar?<br>— Volto, sim — disse Mamãe Lontra.<br>O bolso saiu do chão. | 34✓ | 6 | PLOFT!<br>QUEC!<br>— Espera — eu preciso falar!<br>— Eu tenho medo… de você não voltar.<br>— Você volta depois do patinho brincar?<br>— Volto, sim. | 21✓ | 4 | TUM!<br>— Espera — eu preciso falar!<br>— Medo… mamãe não volta.<br>— Você volta?<br>Mamãe fez que sim. | 15✓ | ✓ | 第三輪 Dedinha 主動先說；5-6 完整因果（口袋離地）；2-3 bridge P02→P05→P08 三次 `TUM!` 遞進自足。 |
| P09 | 9 | Dedinha levantou sozinha. Fez tchauzinho pra mamãe, e mamãe fez de volta.<br>Abraçou o patinho bem pertinho e levantou um pé — | 21✓ | 7 | Dedinha levantou e fez tchauzinho primeiro. Mamãe Lontra fez de volta.<br>Abraçou o patinho e levantou um pé — | 18✓ | 5 | Dedinha levantou.<br>Tchauzinho!<br>Levantou um pé — | 6✓ | ✓ | 三檔 hook：腳懸空＝動作中斷；2-3 電報式三拍（6w below band floor, deliberate hook-breath page）。 |
| P10 | 10 | Dedinha entrou com as três pedrinhas no bolso.<br>Colocou o patinho na água, devagarinho.<br>TCHIBUM!<br>Ele boiou. | 17✓ | 8 | Dedinha entrou com as três pedrinhas no bolso.<br>Colocou o patinho na água.<br>TCHIBUM!<br>Ele boiou. | 16✓ | 6 | Entrou!<br>Três pedrinhas no bolso!<br>TCHIBUM!<br>O patinho boiou. | 9✓ | ✓ | 高潮：跨門＋三石同在＋鴨入水；5-6 17w below band floor -- climax page is action-dense + SFX, not narration; 2-3 驚嘆句。 |
| P11 | 11 | O patinho já tinha brincado bastante. Dedinha tirou ele da água, todo molhadinho.<br>Aí veio um barulho que ela conhecia —<br>tec, tec, tec!<br>Dedinha olhou pra porta — e esperou — | 29✓ | 9 | O patinho já tinha brincado bastante. Dedinha tirou ele da água, molhadinho.<br>tec, tec, tec!<br>Dedinha olhou pra porta — e esperou — | 21✓ | 7 | O patinho brincou bastante.<br>tec, tec, tec!<br>Dedinha esperou — | 9✓ | ✓ | 懸念 hook：熟悉腳步＋等待；2-3 極簡三拍（9w below band floor, deliberate suspense-breath page）。 |
| P12 | 12 | Mamãe Lontra voltou, igualzinho prometeu.<br>— Olha, mamãe! As pedrinhas ainda estão aqui — e o patinho tá todo molhado!<br>De mão dada, foram pra casa.<br>E desde aquele dia… elas davam as mãos em todo tchau e em todo oi. | 39✓ | 10 | Mamãe Lontra voltou!<br>— Você voltou!<br>De mão dada, foram pra casa.<br>E desde aquele dia… elas davam as mãos em todo tchau e em todo oi. | 26⚠ | 8 | Mamãe voltou!<br>De mão dada, foram pra casa.<br>E desde aquele dia… sempre de mão dada. | 16✓ | ✓ | 三檔收束式 prefix `E desde aquele dia…` 一致；5-6/3-5 完整版＋Dedinha 展示石頭＋鴨；3-5 歡呼＋手牽手（26w slightly over band ceiling due to brand ending formula）；2-3 縮短版收束（9-word sentence limit）保留 `de mão dada` 回聲，語感完整。 |
