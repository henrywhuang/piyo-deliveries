<!-- piyo-text-writer B1 blind draft — copy/es-MX.md（模式 B＝S4B es-MX 改編）
     本檔已完成 B0 語感基建、B1 三檔盲稿與 B2 對源校準。 -->

# 圖文總表：¿Qué hay en el bolsillo de los miedos?（whats-in-the-worry-pocket / es-MX）

> 模式 B＝locale 改編（S4B，**改編不是翻譯**）；頁面選用完全繼承 storyboard 三檔選用表。
> 一頁一圖，文字只承擔聲音、台詞、內心與時間等分鏡指定負載；B1 三檔盲稿、B2 對源校準已完成。
> Display title `¿Qué hay en el bolsillo de los miedos?` 與 `Mimí`／`Mamá Nutria` 為 es-MX 提案。
> 擬聲詞組 `¡TUN!`／`¡CUAC!`／`¡PUM!`／`¡PLAS!`／`toc, toc, toc!` 為 es-MX 提案，待 TTS round-trip。
>
> **B0 語感基建註記**
>
> - 疊句：`¡Espera, te quiero decir!`——墨西哥幼兒口語自然節拍，保留「停一下＋我要說」的核心功能，tú 動詞制（R2.1），3 歲可整句覆述。三檔三輪逐字同形、頁位不變。
> - 疊句三輪功能契約：第一輪後接放手擔心與 abrazo 請求；第二輪後接看不見 Mamá 與揮手請求；第三輪由 Mimí 直問「¿Vas a regresar?」，Mamá 確認。
> - Mimí 口癖卡：短句、第一人稱、先說「me da miedo」再提一個可完成的需求（¿Un abrazo más? ／ ¿Adiós con la mano? ／ ¿Vas a regresar?）；不說抽象大道理。
> - Mamá Nutria 口癖卡：語氣溫暖、少說、可預期；給具體約定「Voy a regresar cuando tu patito termine de chapotear」；不替 Mimí 命名擔心、不說「Sé valiente」或「No te preocupes」。
> - 擬聲詞組（registry 提案）：¡TUN!（石落袋）, ¡CUAC!（小黃鴨）, ¡PUM!（拉坐）, ¡PLAS!（入水）, toc, toc, toc!（腳步）。
> - 讀序聲明：B0／B1 期間未開啟任何 `text/zh-TW/**` 或 `copy/zh-TW.md` 內容；只讀凍結的 design／storyboard 語義規格、en-US copy 結構參考（非文案來源）、es-MX spec、registries。B2 首次開啟 zh-TW 母本逐頁校準。

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: whats-in-the-worry-pocket
locale: es-MX
mode: B
storyboard: content/PYO-006_whats-in-the-worry-pocket/PYO-006_storyboard.md
design: content/PYO-006_whats-in-the-worry-pocket/PYO-006_design.md
image_pool: 12
selection:
  "3-5": [P01, P02, P04, P05, P07, P08, P09, P10, P11, P12]
  "2-3": [P01, P02, P05, P08, P09, P10, P11, P12]
commitments:
  refrain: "¡Espera, te quiero decir!"
  ending: "Y desde ese día…"
  onomatopoeia: ["¡TUN!", "¡CUAC!", "¡PUM!", "¡PLAS!", "toc, toc, toc!"]
characters: [Mimí, Mamá Nutria]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Mimí llegó a chapotear con su patito de hule. Mamá Nutria soltó despacito la mano de Mimí.<br>¡TUN!<br>Una piedra cayó en el bolsillo de Mimí y lo jaló hacia abajo. ¡Qué pesada! | 33✓ | 1 | Mimí llegó a chapotear con su patito. Mamá Nutria soltó su mano.<br>¡TUN!<br>Una piedra pesada cayó en el bolsillo de Mimí. | 22✓ | 1 | Mamá soltó la mano.<br>¡TUN!<br>Una piedra cayó en el bolsillo de Mimí.<br>¡Qué pesada! | 15✓ | ✓ | 5-6 completa: llegada, suelta, piedra, peso. 3-5 abrevia: sin hule ni despacito. 2-3 telegráfico: suelta, piedra, exclamación. |
| P02 | 2 | Mamá Nutria se agachó, abrió las manos y esperó.<br>—¡Espera, te quiero decir!<br>Me da miedo… me da miedo soltar la mano.<br>¿Un abrazo más antes de decir adiós? —dijo Mimí.<br>Mimí se paró derechita. | 35✓ | 2 | Mamá Nutria se agachó y esperó.<br>—¡Espera, te quiero decir!<br>Me da miedo… soltar la mano.<br>¿Un abrazo más antes de decir adiós?<br>Mimí se paró derechita. | 27⚠ | 2 | —¡Espera, te quiero decir!<br>Me da miedo soltar la mano.<br>¿Un abrazo más? | 13✓ | ✓ | Ronda 1: miedo a soltar + pedido de abrazo. 2-3 solo台詞, sin旁白. |
| P03 | 3 | Mamá Nutria le dio un abrazo más. —Voy a regresar cuando tu patito termine de chapotear.<br>Después soltó la mano, y Mimí dio un pasito con su patito. | 28✓ | — | — | — | — | — | — | ✓ | Solo 5-6: pacto concreto de regreso + primer paso. |
| P04 | 4 | Mamá Nutria dio un paso hacia la puerta. Mimí siguió caminando.<br>¡TUN!<br>Otra piedra cayó en su bolsillo. La jaló hacia atrás, dándole la vuelta… | 25✓ | 3 | Mamá Nutria le dio un abrazo más. —Voy a regresar cuando tu patito termine de chapotear. Mimí dio un paso.<br>¡TUN!<br>Otra piedra cayó en su bolsillo y la jaló hacia atrás… | 32⚠ | — | — | — | ✓ | 5-6 hook: segunda piedra jala hacia atrás. 3-5 bridge P03+P04: pacto + paso + segunda piedra. |
| P05 | 5 | ¡CUAC!<br>Mimí quedó volteada hacia Mamá Nutria.<br>—¡Espera, te quiero decir!<br>Me da miedo… no te voy a ver desde adentro.<br>¿Me dices adiós con la mano desde la puerta?<br>Mimí volteó hacia el salón de juegos. | 37✓ | 4 | ¡CUAC!<br>—¡Espera, te quiero decir!<br>Me da miedo… no te veo.<br>¿Me dices adiós desde la puerta?<br>Mimí volteó hacia el salón. | 22✓ | 3 | ¡TUN! Otra piedra.<br>¡CUAC!<br>—¡Espera, te quiero decir!<br>¡No te veo! | 11✓ | ✓ | Ronda 2: miedo a no ver a Mamá + pedido de adiós con la mano. 2-3 bridge: integra segunda piedra + pato + refrain + miedo. |
| P06 | 6 | Mamá Nutria le dijo adiós con la mano. Mimí caminó hasta la puerta.<br>Adentro, una señora conocida esperaba junto a la tina de agua. | 24✓ | — | — | — | — | — | — | ✓ | Solo 5-6: respuesta de Mamá + línea de seguridad (cuidadora conocida + tina). |
| P07 | 7 | Mamá Nutria se despidió y se dio la vuelta para irse. Mimí levantó un pie hacia la puerta.<br>¡TUN!<br>La tercera piedra, la más pesada de todas, cayó en su bolsillo y la jaló derecho hacia abajo… | 37✓ | 5 | Mamá Nutria le dijo adiós con la mano y se fue despacito.<br>Mimí levantó un pie hacia la puerta…<br>¡TUN!<br>La tercera piedra, la más pesada, la jaló hacia abajo… | 30⚠ | — | — | — | ✓ | 5-6 hook: tercera piedra (más pesada) jala hacia abajo. 3-5 bridge P06+P07: adiós con mano + despedida + tercera piedra. |
| P08 | 8 | ¡PUM!<br>¡CUAC!<br>Mimí habló primero.<br>—¡Espera, te quiero decir!<br>Me da miedo… que no regreses.<br>¿Vas a regresar cuando mi patito termine de chapotear?<br>—Sí. Voy a regresar —dijo Mamá Nutria.<br>El bolsillo de Mimí se levantó del tapete. | 39✓ | 6 | ¡PUM!<br>¡CUAC!<br>—¡Espera, te quiero decir!<br>Me da miedo… que no regreses.<br>¿Vas a regresar después de chapotear?<br>—Sí —dijo Mamá Nutria. | 22✓ | 4 | ¡TUN!<br>¡PUM! ¡CUAC!<br>—¡Espera, te quiero decir!<br>¿Vas a regresar?<br>Mamá dijo que sí. | 14✓ | ✓ | Ronda 3: Mimí habla primero, miedo a que Mamá no regrese + confirma reencuentro. 2-3 bridge: integra tercera piedra + plop + pato + pregunta directa. |
| P09 | 9 | Mimí se levantó solita. Le dijo adiós a Mamá Nutria con la mano y abrazó a su patito.<br>Levantó un pie para cruzar la puerta… | 25✓ | 7 | Mimí se paró solita y dijo adiós primero. Mamá Nutria le contestó con la mano.<br>Mimí abrazó a su patito y levantó un pie… | 24✓ | 5 | Mimí se paró.<br>Dijo adiós con la mano.<br>Levantó un pie… | 11✓ | ✓ | Hook: adiós voluntario + pie en el aire. 2-3 fragmentos telegráficos. |
| P10 | 10 | Mimí cruzó la puerta con las tres piedras en su bolsillo.<br>Bajó a su patito de hule hasta el agua.<br>¡PLAS!<br>Se quedó flotando. | 24✓ | 8 | Mimí cruzó la puerta con las tres piedras en su bolsillo.<br>Bajó a su patito hasta el agua.<br>¡PLAS!<br>Se quedó flotando. | 22✓ | 6 | ¡Mimí entró!<br>¡Tres piedras en su bolsillo!<br>¡PLAS!<br>Su patito se quedó flotando. | 13✓ | ✓ | Clímax: cruza, baja pato, splash, flota. 2-3 exclamaciones de logro. |
| P11 | 11 | Se acabó la hora de chapotear. Mimí sacó a su patito mojado.<br>Entonces se oyeron unos pasos que Mimí conocía bien:<br>toc, toc, toc!<br>Miró hacia la puerta… y esperó… | 30✓ | 9 | Se acabó la hora de chapotear. Mimí sacó a su patito mojado.<br>Se oyeron unos pasos que Mimí conocía:<br>toc, toc, toc!<br>Miró hacia la puerta… y esperó… | 28⚠ | 7 | Su patito ya chapoteó.<br>toc, toc, toc!<br>¡Pasos en la puerta! | 11✓ | ✓ | Hook suspense: pasos familiares sin revelar quién. 2-3 invierte orden para rematar con exclamación. |
| P12 | 12 | Mamá Nutria regresó, tal como lo prometió.<br>Mimí le enseñó a su patito mojado. —¡Mis piedritas siguen aquí… y tú también!<br>De la mano, se fueron caminando a casa.<br>Y desde ese día… se tomaron de la mano en cada adiós y en cada hola. | 45⚠ | 10 | Mamá Nutria regresó.<br>—¡Regresaste!<br>De la mano, se fueron a casa.<br>Y desde ese día… se tomaron de la mano en cada adiós y en cada hola. | 27⚠ | 8 | ¡Mamá regresó!<br>Y desde ese día… se tomaron de la mano. | 11✓ | ✓ | Reencuentro: Mamá cumple promesa. 5-6 muestra piedras + pato mojado. 2-3 solo la emoción + cierre. |

## 2. Notas B2 y autocomprobación del escritor

- **B0-B1-B2 completados**: B0 = bases lingüísticas es-MX nativas. B1 = borrador ciego desde text loads + B0. B2 = calibración contra zh-TW 5-6/3-5/2-3 fuente.
- **Concordancia**: copia/es-MX.md, 5-6.draft.json (12 entradas), 3-5.draft.json (10 entradas) y 2-3.draft.json (8 entradas) son la misma fuente.
- **W0 fidelidad de concepto = conforme**: tres rondas de miedo concreto + pedido; no se reemplaza con valentía ni se escribe "ya no tiene miedo."
- **W1 fidelidad al marco = conforme**: storyboard loads, selección de páginas y page-turn hooks se respetan íntegramente.
- **W2 alineación = conforme**: solo se escriben cargas autorizadas por la columna "文說什麼" del storyboard.
- **W5 reglas compartidas = conforme**: refrain idéntico tres檔三輪; ending prefix idéntico tres檔; nombres y SFX consistentes.
- **W7 2-3 registro = conforme**: fragmentos telegráficos, primera persona, exclamaciones; todas las páginas ≤ 16 palabras.
- **W8 adaptación ≠ traducción = conforme**: texto nativo es-MX con diminutivos (despacito, pasito, derechita, solita, piedritas), tuteo, raya para diálogo, sin calcos del zh-TW ni del en-US.
- **Ortografía**: ¡¿ dobles verificados en exclamaciones e interrogaciones; raya (U+2014) para diálogo; … (U+2026) para elipsis; tildes completas incluyendo Mimí y Mamá.

<!-- B1 三檔同源草稿：
     content/PYO-006_whats-in-the-worry-pocket/text/es-MX/5-6.draft.json、3-5.draft.json、2-3.draft.json。
     B2 對源校準已完成。 -->
