# th-TH Mode B Process Log: PYO-006 whats-in-the-worry-pocket

## B0 Language Foundations

### Refrain (疊句)
**"เดี๋ยว หนูจะพูด!"** (Wait, I need to say!)

Design rationale:
- เดี๋ยว (wait a moment) — natural Thai toddler interjection, 2 syllables, rhythmic
- หนู (I, child self-reference) — age-appropriate, warm, universal Thai child address
- จะพูด (will speak) — clear action verb, simple
- Rhythm: 2+1+2+1 syllable pattern, toddler repeatable, ends on strong beat
- NOT a translation of zh-TW "等一下，我要說！" — rebuilt from Thai child speech patterns
- Thai toddlers say "เดี๋ยว!" (wait!) naturally as an interruption; "หนูจะพูด" is a complete thought a 2-year-old can produce

### SFX (5 onomatopoeia)

| # | Action | Thai SFX | Rationale |
|---|---|---|---|
| 1 | Stone drops into pocket | ตึง! | Heavy thud sound; ตึง = onomatopoeia for heavy object settling with fabric tension; distinct from ตุ๊บ |
| 2 | Rubber duck squeezed/bounced | เอี๊ยด! | Rubber squeeze sound; high-tone ๊ gives sharp squeaky quality; native Thai for squeak/creak |
| 3 | Body plops onto cushion | ตุ๊บ! | Soft body landing; ตุ๊บ = padded thump; distinct from ตึง (stone=heavy rigid, plop=soft body) |
| 4 | Duck drops into water | จ๋อม! | Small splash; จ๋อม = something small entering water; gentle, playful sound |
| 5 | Familiar footsteps | แตะ แตะ แตะ | Light stepping/tapping; แตะ = touch/tap; three-beat pattern; space-separated per O1 |

### Names

| canonical key | th-TH name | Rationale |
|---|---|---|
| cuddles | น้องกอด | น้อง (younger one, affectionate) + กอด (hug/embrace); maps directly to "cuddles" concept; warm, gender-neutral, toddler-friendly; 3 syllables; AVOIDANCE: แม่นาก rejected due to collision with famous Thai ghost story "Mae Nak Phra Khanong" |
| mama_otter | คุณแม่ | Respectful-warm "mother" address; standard Thai picture book convention; in-text shortened to แม่ (mom) for natural flow; full คุณแม่ reserved for speaker tags if needed |

### Ending
**"ตั้งแต่วันนั้นเป็นต้นมา น้องกอดกับแม่จับมือกัน เป็ดน้อยก็กลับบ้านด้วยนะคะ"**
(From that day on, Nong Kod and Mama held hands, and the little duck went home with them too.)

- ตั้งแต่วันนั้นเป็นต้นมา = "from that day on" — standard Thai closure formula, equivalent to zh-TW "後來呀" / en-US "And from that day on"
- นะคะ ending particle — warm, gentle female narrator tone (R2/R4 spec compliance)
- จับมือกัน (hold hands together) — maps to zh-TW "牽著手" reunion gesture
- เป็ดน้อยก็กลับบ้านด้วย (the little duck went home too) — keeps the trio reunion

### Oral habit cards
- น้องกอด's speech: uses หนู as self-reference, คะ for polite requests, omits subject in 2-3 tier
- คุณแม่'s speech: uses จ้ะ/นะจ๊ะ (warm maternal particles per R4), short confirmations
- Narrator: uses ค่ะ/นะคะ for warmth (R2), no sentence-final periods (P2)

## B0 Probe Freeze Table

| # | Type | Frozen string | Status |
|---|---|---|---|
| 1 | Refrain | `เดี๋ยว หนูจะพูด!` | Proposed |
| 2 | Ending | `ตั้งแต่วันนั้นเป็นต้นมา น้องกอดกับแม่จับมือกัน เป็ดน้อยก็กลับบ้านด้วยนะคะ` | Proposed |
| 3 | SFX stone | `ตึง!` | Proposed |
| 4 | SFX duck | `เอี๊ยด!` | Proposed |
| 5 | SFX plop | `ตุ๊บ!` | Proposed |
| 6 | SFX splash | `จ๋อม!` | Proposed |
| 7 | SFX footsteps | `แตะ แตะ แตะ` | Proposed |
| 8 | Character | `น้องกอด` | Proposed |
| 9 | Character | `คุณแม่` (in-text: `แม่`) | Proposed |

## B1 Budget Table (repeat_discount pre-calculation)

### th-TH spec YAML values (draft, confidence: low)
- Counting unit: char (L* = Thai consonants + independent vowels)
- repeat_discount: 0.25

### 5-6 tier (12 pages, max_total_len = 1768)
- Refrain "เดี๋ยว หนูจะพูด!" = 8 L* chars x 3 occurrences
  - 1st: 8 full; 2nd: 8 x 0.25 = 2; 3rd: 8 x 0.25 = 2 → savings = 12
- Ending (1 occurrence, no discount) = ~30 L* chars
- SFX fixed repeats: ตึง! x3 = 2 L* each; 1st full + 2x0.25 = 1 → savings = 2
- Budget: 1768 headroom is very generous for 12 pages targeting 20-40 per page

### 3-5 tier (10 pages, max_total_len = 1360)
- Same refrain discount pattern, savings ~12
- Budget: 1360 is comfortable for 10 pages targeting 15-25

### 2-3 tier (8 pages, max_total_len = 310)
- Refrain "เดี๋ยว หนูจะพูด!" x3 = 8+2+2 = 12
- This is the binding constraint; estimated total ~130-140 L* chars, well within 310
- SFX repeats (ตึง! x3) further discounted

All three tiers fit comfortably within max_total_len even without discount.

## B1 Blind Draft Declaration

B1 blind draft completed without opening any zh-TW or en-US text files.
Source materials used: PYO-006_design.md, PYO-006_storyboard.md, th-TH locale spec, character_names.md, onomatopoeia_map.md, style_guide.md, age_calibration.md, craft_techniques.md, storyboard_language.md section 2.

## B2 Source Alignment (zh-TW cross-check)

Opened zh-TW definitive texts (5-6.json, 3-5.json, 2-3.json) for alignment.

### B2 Changes per page:

| Page | Tier | Change | Reason |
|---|---|---|---|
| P01 | 5-6 | Added "พร้อมไปเล่นน้ำแล้ว" (ready to play water) | zh-TW has "準備去玩水" — water play goal establishment; B1 had it implied but not stated |
| P03 | 5-6 | Added mama's covenant quote as direct speech | zh-TW P03 has mama's covenant as quoted speech; B1 had it as indirect — direct speech warmer |
| P06 | 5-6 | Added "ข้างในมีคนรออยู่ แล้วก็มีอ่างน้ำด้วย" | zh-TW P06 mentions caregiver and basin visible; B1 lacked this safety-cue detail |
| P08 | 5-6 | Added mama's confirmation "มาจ้ะ" | zh-TW P08 has 媽媽點點頭：「會的。」; B1 had nod but no verbal confirmation |
| P09 | 5-6 | Added "แนบอก" (held to chest) | zh-TW missing but storyboard specifies duck held to chest; native enrichment |
| P11 | 3-5 | Added "เหมือนแม่นะ!" (sounds like Mama!) | zh-TW 3-5 P09 has "好像是媽媽!"; strengthens suspense hook in 3-5 |
| P12 | 5-6 | Added reunion dialogue with stone + wet duck display | zh-TW P12 has "你看，小石頭還在，小黃鴨濕濕的！"; B1 had only closure |

### Completeness check (4 items):
1. Semantic load coverage: All page loads from storyboard "文說什麼" column present in all 3 tiers ✓
2. No added loads: No visual facts restated; text stays in sound/dialogue/time/inner domains ✓
3. Refrain page alignment + variation structure: P02/P05/P08 all three tiers; P08 variation (deepest worry, child initiates) preserved ✓
4. zh-TW bridging preserved: 3-5 P03 bridges P03 covenant; 2-3 P03 bridges P04 SFX; all bridge functions maintained ✓

## STEP 3 Machine Check Results

### Check 1: copy_check.py
- Result: PASS (0 violations, 31 warnings)
- All warnings are expected:
  - 30x band warnings: th-TH L* counts exceed zh-TW-calibrated TARGET_BAND (spec calibration.status=draft, confidence=low); all pages pass locale_lint hard limits
  - 1x character warning: "คุณแม่" not found verbatim in 5-6 text -- in-text form is "แม่" (shortened per B0 decision), visual-only appearance is legal
- 2-3 ending commitment: "น้องกอดจับมือแม่ เป็ดน้อยก็กลับบ้านด้วย" (last line of P08, substring match passes)

### Check 2: locale_lint (all 3 tiers)
- 5-6: PASS (0 violations, 3 warnings -- repeat_discount info for ตึง! x3 and refrain x3)
- 3-5: PASS (0 violations, 3 warnings -- same pattern)
- 2-3: PASS (0 violations, 2 warnings -- refrain x3 discount only; ตึง not repeated in 2-3 tier text directly)
- Hard limits: all pages within max_page, all sentences within max_sentence, all totals within max_total_len

### Check 3: localize_readiness --contract
- Result: PASS (green)
- character_names.md: th-TH entries added for cuddles (น้องกอด) and mama_otter (คุณแม่)
- onomatopoeia_map.md: th-TH entries added for all 5 PYO-006 SFX scenes
- Story title registered: กระเป๋ากังวลมีอะไรอยู่ข้างใน？

## STEP 4 Author Self-check (W0-W9)

### W0 Concept fidelity
original_concept: "小水獺每次擔心，口袋就多一顆小石頭；說出名字後口袋變輕。"

- 5-6: PASS. Child takes away: "when you're scared, your pocket gets heavy; say what scares you, and you can take the next step." Three rounds (P01-02, P04-05, P07-08) each follow notice-body-cue -> say-worry -> move-forward. Sampled P02 (refrain + first worry + request) and P08 (third worry + reunion confirmation) -- both serve theme anchor, not diverted by "being fun."
- 3-5: PASS. Same three-round engine in 10 pages. Sampled P04 (second worry clearly stated) and P06 (third worry + mama confirmation) -- theme intact.
- 2-3: PASS. Eight pages still deliver: heavy pocket -> say it -> move. Sampled P02 (refrain + worry) and P04 (deepest worry + mama nod) -- toddler gets the core loop.

### W1 Framework fidelity
- Checked all pages against storyboard "文說什麼" column. Each page's text loads match the planned loads (SFX, dialogue, narration, inner state). No camera changes, no plot additions, no selection modifications.
- PASS

### W2 Alignment self-check (descriptive statements vs. visual facts)
- 5-6 P01: "น้องกอดอุ้มเป็ดน้อยสีเหลือง พร้อมไปเล่นน้ำแล้ว" -- "holding yellow duck, ready to play water" = goal/intention (not visual restatement of appearance); "แม่ค่อย ๆ ปล่อยมือ" = action (hand releasing, picture shows the moment); SFX "ตึง!" and "กระเป๋าหนักขึ้นมาทันที หนักมาก ๆ" = sound + weight sensation (non-visual). No visual restatement.
- 5-6 P06: "แม่ยืนที่ประตู โบกมือเบา ๆ" = action (waving); "ข้างในมีคนรออยู่ แล้วก็มีอ่างน้ำด้วย" = perceptual discovery (what Cuddles notices entering). These are within "what text should say" per storyboard. No color/appearance restatement.
- 3-5 P02: All dialogue. No descriptive statements.
- 3-5 P09: "มีเสียงเท้ามาจากหน้าประตู" = sound (text-exclusive domain). "เหมือนแม่นะ!" = recognition/inner state. No visual facts restated.
- 2-3 P05: "น้องกอดลุกขึ้นแล้ว" = action; "โบกมือ — ยกเท้า —" = action sequence (mid-action hook). No visual restatement.
- 2-3 P06: "ข้ามมาแล้ว!" = action result; "เป็ดน้อย — จ๋อม!" = SFX; "ลอยขึ้นมาแล้ว" = action result. No visual restatement.
- PASS

### W3 Entity layer self-check
- 5-6 P03: Entities: แม่ (mama, present in storyboard P03), เป็ดน้อย (duck, present), น้องกอด (implied subject, present). Actions: พูดเบา ๆ (speaking softly -- mama does this per storyboard), กอดมืออีกที (hold hands again -- storyboard "再握一下放手"), ก้าวเท้าไปข้างหน้า (step forward -- storyboard "牽牽帶鴨前進第一步"). All entities and actions present in storyboard image description.
- 5-6 P10: Entities: น้องกอด, เป็ดน้อย, อ่างน้ำ (water basin). Actions: ข้ามประตู (crossing threshold -- storyboard "牽牽跨過門檻"), วางเป็ดน้อยลงในอ่างน้ำ (placing duck in basin -- storyboard confirms), จ๋อม! (splash SFX -- storyboard "啵"). All match.
- 3-5 P05: Entities: แม่, น้องกอด, ก้อนหิน (stones), กระเป๋า (pocket). Actions: โบกมือ (waving -- storyboard P07 "媽媽在門口揮手"), เดินมาถึงหน้าประตู (arriving at door -- storyboard), ตึง! (SFX -- storyboard). All present.
- 3-5 P08: Entities: น้องกอด, เป็ดน้อย, อ่างน้ำ. All present in storyboard P10.
- 2-3 P01: Entities: แม่ (implied by ปล่อยมือ), กระเป๋า (pocket). Actions: ปล่อยมือ (releasing hand -- storyboard P01), ตึง! (SFX). All present.
- 2-3 P07: Entities: เป็ดน้อย. Actions: เล่นน้ำเสร็จ (finished playing water), แตะ แตะ แตะ (footsteps SFX). All match storyboard P11.
- PASS

### W4 Read-aloud test
- Refrain "เดี๋ยว หนูจะพูด!" -- 3 read-throughs: natural rhythm 2+1+2+1 syllables, no tongue-twisters, toddler-repeatable.
- SFX "ตึง!" "เอี๊ยด!" "ตุ๊บ!" -- distinct sounds, no confusion between them, fun to vocalize.
- Tension/release pacing: P01-P02 (buildup->release), P04-P05 (faster tension from P04 SFX chain), P07-P08 (longest tension, most SFX, biggest release). Matches craft C1/C3 (tight in tension, spacious in warmth).
- PASS

### W5 Three-tier shared rules
- Refrain "เดี๋ยว หนูจะพูด!" -- verbatim identical across all 3 tiers on P02/P05/P08 (mapped to copy table P02/P05/P08 for 5-6; P02/P04/P06 for 3-5; P02/P03/P04 for 2-3). Core sentence type preserved.
- Character names: น้องกอด used in all 3 tiers. แม่ used in all 3 tiers. No drift from registry.
- SFX: ตึง! consistent across tiers (3x in 5-6, 3x in 3-5, appears in 2-3 via merged pages). เอี๊ยด! consistent. ตุ๊บ! consistent. จ๋อม! consistent. แตะ แตะ แตะ consistent.
- PASS

### W6 Fulfillment self-check (design.md commitments)
- Refrain "等一下，我要說！" -> th-TH "เดี๋ยว หนูจะพูด!" at P02/P05/P08 in all tiers. PRESENT.
- SFX 咚 (stone x3) -> ตึง! at P01/P04/P07 (5-6), P01/P03/P05 (3-5), P01/P03/P04 (2-3 merged). PRESENT.
- SFX 嘎 (duck x2) -> เอี๊ยด! at P05/P08 (5-6), P04/P06 (3-5), P03/P04 (2-3 merged). PRESENT.
- SFX 噗通 (plop) -> ตุ๊บ! at P08 (5-6), P06 (3-5), P04 (2-3). PRESENT.
- SFX 啵 (splash) -> จ๋อม! at P10 (5-6), P08 (3-5), P06 (2-3). PRESENT.
- SFX 啪嗒 (footsteps) -> แตะ แตะ แตะ at P11 (5-6), P09 (3-5), P07 (2-3). PRESENT.
- Ending -> closure formula present in final page of all tiers. PRESENT.
- 2-3 reductions: P03/P04/P06/P07 skipped per storyboard selection; beats merged into adjacent pages as documented in copy table notes.
- PASS

### W7 Low-tier register (2-3)
- Telegraph style confirmed: "แม่ปล่อยมือแล้ว" (3 words), "ตึง!" (SFX), "กระเป๋าหนักมาก ๆ" (short sensation).
- Subject omission: P02 "กลัว… มือจะหลุด" drops หนู (self-reference) from 3-5/5-6 "หนูกลัว…". P02 "กอดมืออีกที" drops คะ (polite particle) from upper tiers.
- Closure formula: "ตั้งแต่วันนั้นมา" (shortened from เป็นต้น in 5-6/3-5) + split across lines for max_page compliance. Not "trimming long sentences" but restructured closure.
- Emotional arc works in 8 pages: heavy -> say -> move (x3) -> cross -> mama returns.
- PASS

### W8 Adaptation not translation (Mode B only)
Sampled 3 pages against zh-TW:

1. P02 (5-6): zh-TW = "媽媽蹲下來，打開手掌，安靜等著。「等一下，我要說！」「我怕…… 手放開。」「再握一下，好不好？」" / th-TH = "แม่นั่งลง กางมือรอเงียบ ๆ / \"เดี๋ยว หนูจะพูด!\" / \"หนูกลัว… มือจะหลุด\" / \"กอดมืออีกทีได้ไหมคะ\"". Structure differs: zh-TW uses 4 sentences with "好不好？" (yes-no tag); th-TH uses "ได้ไหมคะ" (native Thai request form). "นั่งลง กางมือรอเงียบ ๆ" is natural Thai action chain (sit down, spread hands, wait quietly), not word-by-word mapping of "蹲下來，打開手掌，安靜等著". NOT translation-like.

2. P08 (5-6): zh-TW = 6 lines with "噗通！/嘎！小黃鴨彈了起來。/「等一下，我要說！」/「我怕…… 媽媽不回來。」/「玩完水，你會來嗎？」/媽媽點點頭：「會的。」" / th-TH = 6 lines with different SFX distribution: "ตุ๊บ!" standalone, "เอี๊ยด! เป็ดน้อยกระเด้งขึ้นมา" (duck bounces up -- "กระเด้ง" is native Thai verb, not a translation of "彈了起來"), and mama's "มาจ้ะ" (I'll come, with จ้ะ maternal particle) vs zh-TW "會的" (yes). Native Thai sentence construction throughout.

3. P11 (3-5): zh-TW 3-5 P09 = not directly comparable (page mapping differs). th-TH P09 = "เป็ดน้อยเล่นน้ำเสร็จแล้ว / แตะ แตะ แตะ / มีเสียงเท้ามาจากหน้าประตู — เหมือนแม่นะ!" -- "เหมือนแม่นะ!" (sounds like mama!) is a native Thai child's excited recognition pattern with นะ particle, not a translation of "好像是媽媽!" which would be "เหมือนเป็นแม่!" in literal Thai.

- Banned leakage check: No CJK characters, no ～ wave symbols, no sentence-final periods. No calque structures (e.g., no "X 了 Y" patterns borrowed from Chinese syntax).
- PASS

### W9 Skip-junction self-sufficiency
**5-6**: All 12 pages used, no skips. N/A.

**3-5** (skip P03, P06):
- P02->P04 (skip P03): P02 ends with first worry resolved (hands held, released). P04 opens with "แม่บอกว่าจะกลับมา น้องกอดก้าวไปข้างหน้า" -- bridge sentence "แม่บอกว่าจะกลับมา" (mama said she'd come back) carries P03's covenant beat. Emotion: relief -> new step. Self-sufficient with bridge. PASS.
- P05->P07 (skip P06): P05 ends with second worry resolved + mama waving at door. P07 opens "แม่โบกมือให้ / น้องกอดเดินมาถึงหน้าประตู" -- the waving context carries through. P06's "arriving at threshold + seeing safety cues" is absorbed into P07's opening. Self-sufficient. PASS.

**2-3** (skip P03, P04, P06, P07):
- P02->P05 (skip P03, P04): P02 ends with first refrain + worry + request. P05 opens "ตึง! อีกก้อน / เอี๊ยด!" -- SFX restart signals new round, "อีกก้อน" (another stone) bridges the escalation. No emotional gap. Self-sufficient with SFX bridge. PASS.
- P05->P08 (skip P06, P07): P05 ends with second refrain cycle. P08 opens "ตึง! หนักที่สุด / ตุ๊บ! เอี๊ยด!" -- SFX escalation "หนักที่สุด" (heaviest) signals climax round. Toddler follows: more SFX = bigger problem. Self-sufficient. PASS.

All skip junctions documented in copy table "選圖與提純說明" column.
- PASS

## Orthography self-check summary

No CJK characters used (～, 〜, etc.) -- Thai script only throughout.
No ราชาศัพท์ used.
No banned terms (แดก, โง่, เฮ้ย, โว้ย) present.
ๆ always preceded by space (spec P6/O1).
No sentence-final periods (spec P2).
Exclamation marks are half-width ASCII ! (spec P3).
Quotes are ASCII straight double quotes " (spec P4).
Ellipsis is U+2026 ... (spec P5).
Em dash is U+2014 -- (spec P7).
