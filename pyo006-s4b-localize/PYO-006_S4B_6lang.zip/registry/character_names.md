# 跨 Locale 角色名 Registry

> 每個角色一個 **canonical key**（= voice_config.json 的 voice key），各 locale 的名字鎖定於此表。
> 生成 agent **不得自創或改寫**角色名（鐵律 1：一致性 > 單句最優）。
> 「定案」= 已出貨（源自 golden corpus 與 tts_parser.py CHAR_NAMES）；「提案」= 待該 locale 首批內容審查後升級定案；空白 = 尚未提案。
> 別名欄：同一角色在文中允許的替代稱呼（暱稱、全名），TTS 分聲與一致性檢查都認這組。

---

## 故事標題

| story slug | zh-TW（定案） | ja（定案） | en-US（定案） | en-GB | es-MX | pt-BR | th-TH | vi-VN |
|---|---|---|---|---|---|---|---|---|
| three-little-pigs | 三隻小豬 | 三匹の子ぶた | The Three Little Pigs | The Three Little Pigs（提案：同 en-US） | **Los Tres Cochinitos**（提案・主選，主從 2026-07-08 拍板：cochinito 為 MX 在地暖稱、Cri-Cri 兒歌傳統，母語者人設 QA 2026-07-07 支持；備選 Los Tres Cerditos＝泛西語中性，源自 task2_latam） | Os Três Porquinhos（提案，源自 task2_latam） | ลูกหมูสามตัว（提案） | Ba Chú Lợn Con（定案·2026-07-20 Stacy 授權代裁——heo→lợn 北方錨，與角色名同批；原提案 Ba Chú Heo Con） |
| the-tortoise-and-the-hare | 龜兔賽跑 | ウサギとカメ | The Tortoise and the Hare | The Tortoise and the Hare（提案：同 en-US） | La Liebre y la Tortuga（提案，源自 task2_latam） | A Lebre e a Tartaruga（提案，源自 task2_latam） | กระต่ายกับเต่า（提案） | Rùa và Thỏ（提案） |
| goldilocks-and-the-three-bears | 金髮女孩與三隻熊 | ゴルディロックスと3びきのくま | Goldilocks and the Three Bears | Goldilocks and the Three Bears（提案：同 en-US） | Ricitos de Oro（提案，源自 task2_latam） | Cachinhos de Ouro（提案，源自 task2_latam，**非** Caracóis de Ouro） | ผมทองกับหมีสามตัว（提案） | Cô Bé Tóc Vàng và Ba Chú Gấu（提案） |
| wait-little-volcano | 等一下，小火山 | まってね、かざんくん | Wait, Little Volcano | | | | | |
| the-giant-turnip | 拔蘿蔔（定案·2026-07-20 關卡③ Green Light） | | The Giant Turnip（定案·2026-07-20 關卡④ Green Light） | | | | | |
| different-spots | 不一樣的斑點 | | | | | | | |
| the-little-swan-grows-in-time | 小天鵝慢慢長大 | | | | | O Pequeno Cisne Cresce no Seu Tempo（提案·2026-07-21 S4B pt-BR 盲稿） | | |
| the-weather-house-of-feelings | 心情天氣小屋（提案，源自 PYO-005 凍結 design） | | The Weather House of Feelings（提案） | | | | | |
| my-little-glow | 我有我的小光（提案，源自 PYO-009 凍結 design） | | My Little Glow（定案·2026-07-21 關卡④ Green Light） | | | | | |
| whats-in-the-worry-pocket | 擔心口袋裡有什麼？（提案，源自 PYO-006 凍結 design；2026-07-20 Human S4 Review R1 指令） | しんぱいポケットの なかには なにが ある？（提案·2026-07-21 S4B ja 盲稿） | What's in the Worry Pocket?（定案·2026-07-21 關卡④ Green Light） | What's in the Worry Pocket?（提案·同 en-US） | ¿Qué hay en el bolsillo de los miedos?（提案·2026-07-21 S4B es-MX 盲稿） | O Que Tem no Bolso da Preocupação?（提案·2026-07-21 S4B pt-BR 盲稿） | กระเป๋ากังวลมีอะไรอยู่ข้างใน？（提案·2026-07-21 S4B th-TH 盲稿） | Trong Túi Lo Có Gì?（提案·2026-07-21 S4B vi-VN 盲稿） |
| grandmas-apron-pockets | 阿嬤的圍裙口袋（提案，源自 PYO-014 凍結 design） | | Grandma's Apron Pockets（提案·2026-07-21 S4A en-US 盲稿） | | | | | |

---

## 三隻小豬（three-little-pigs）

| canonical key | zh-TW（定案） | ja（定案） | en-US（定案） | en-GB | es-MX | pt-BR | th-TH | vi-VN |
|---|---|---|---|---|---|---|---|---|
| biggie | 大毛 | ブータ | Biggie | Biggie（同 en-US） | el cochinito grande（定案·描述稱制，2026-07-19 Stacy 授權批次） | Palhinho（定案，2026-07-19 Stacy 授權批次——快審否決 Fofão：撞 1980s 巴西國民布偶 IP；palha 草＋-inho，草木磚三建材同構命名） | หมูฟาง（定案·建材同構制，2026-07-20 Stacy 授權代裁——快審否決舊案 อ้วน：身材標籤敏感；ฟาง＝草，對齊 pt-BR Palhinho 路線） | Lợn Ủn（別名：Ủn）（定案·2026-07-20 Stacy 授權代裁——heo＝南方詞、spec R5 北方錨與 bố/mẹ 同規，快審 verdict 改 lợn；ủn ỉn 豬叫命名巧思保留；Ủn/Ỉn 近音列 TTS A/B 必驗） |
| woody | 二毛 | ブーすけ | Woody | Woody（同 en-US） | el cochinito mediano（定案·同上；顯示名與正文統一用 mediano、不用 de en medio） | Lenhinho（定案，同上；lenha 木） | หมูไม้（定案·同上；ไม้＝木，對齊 canonical woody；舊案 นิด 撞二哥中等人設） | Lợn Ỉn（別名：Ỉn）（定案·同上） |
| bricky | 小毛 | ブーこ | Bricky | Bricky（同 en-US） | el cochinito chico（定案·同上） | Tijolinho（定案，同上；tijolo 磚） | หมูอิฐ（定案·同上；อิฐ＝磚，對齊 canonical bricky；舊案 แก้ว 玻璃＝易碎、與磚匠語義反諷錯位） | Lợn Út（別名：Út）（定案·同上；út＝老么，名即角色） |
| mama_pig | 豬媽媽 | おかあさんブタ（別名：おかあさん） | Mama Pig（別名：Mama） | | | | แม่หมู（提案） | Mẹ Lợn（定案·同上） |
| wolf | 大野狼 | おおかみのガオー（別名：おおかみ、ガオー） | Big Bad Wolf（別名：Wolf） | Big Bad Wolf（同 en-US） | el lobo feroz（別名：el lobo）（定案·MX 唯一慣稱，2026-07-19） | Lobo Mau（別名：Lobo）（定案·BR 正典名，2026-07-19） | หมาป่าตัวใหญ่（別名：หมาป่า）（提案） | Sói Xám（別名：Sói）（提案） |

合唱／群體稱呼（旁白聲線）：zh-TW「三隻小豬／兩隻小豬／三兄弟」；ja「3にん／ふたり」；en-US「Both piggies／All three piggies／the three little pigs／his brothers（後二＝v4 重做版旁白與 speaker tag，2026-07-19 S4A R1 提案回寫；tts_parser CHAR_NAMES 已同步）」。

## 龜兔賽跑（the-tortoise-and-the-hare）

| canonical key | zh-TW（定案） | ja（定案） | en-US（定案） | en-GB | es-MX | pt-BR | th-TH | vi-VN |
|---|---|---|---|---|---|---|---|---|
| tilly | 慢慢龜 | ゆっくん | Tilly | | Lentita（提案·2026-07-21 S4B es-MX 盲稿；lenta＋diminutivo -ita，暗示慢慢特質、MX 幼兒自然暱稱） | Lentinha（提案·2026-07-21 S4B pt-BR 盲稿；lenta＋diminutivo -inha，BR 幼兒暱稱自然形、暗示慢慢特質） | เต่าน้อย（提案） | Rùa Nhỏ（提案） |
| hops | 跳跳兔 | ピョンタ | Hops | | Saltón（提案·2026-07-21 S4B es-MX 盲稿；saltar＋增大詞尾 -ón，暗示彈跳活力） | Saltão（提案·2026-07-21 S4B pt-BR 盲稿；saltar＋aumentativo -ão，暗示彈跳活力、BR 增大詞尾） | กระต่ายจ้อน（提案） | Thỏ Nhanh（提案） |
| owl | 貓頭鷹裁判（別名：貓頭鷹） | フクロウ審判（別名：フクロウ） | Judge Owl（別名：Owl） | | Juez Búho（別名：Búho）（提案·2026-07-21 S4B es-MX 盲稿） | Juiz Coruja（別名：Coruja）（提案·2026-07-21 S4B pt-BR 盲稿；Juiz＝裁判、Coruja＝貓頭鷹） | นกฮูกกรรมการ（別名：นกฮูก）（提案） | Cú Mèo Trọng Tài（別名：Cú Mèo）（提案） |

## 金髮女孩與三隻熊（goldilocks-and-the-three-bears）

| canonical key | zh-TW（定案） | ja（定案） | en-US（定案） | en-GB | es-MX | pt-BR | th-TH | vi-VN |
|---|---|---|---|---|---|---|---|---|
| goldie | 小金 | ゴルディ | Goldie（別名：Goldilocks） | | | | น้องทอง（別名：ผมทอง）（提案） | Bé Tóc Vàng（提案） |
| papa_bear | 熊爸爸 | パパくま | Papa Bear | | | | พ่อหมี（提案） | Gấu Bố（提案） |
| mama_bear | 熊媽媽 | ママくま | Mama Bear | | | | แม่หมี（提案） | Gấu Mẹ（提案） |
| baby_bear | 小熊寶寶 | ベアくん（別名：こぐまのベアくん） | Baby Bear | | | | ลูกหมีน้อย（提案） | Gấu Con（提案） |

群體稱呼：zh-TW「三隻熊」；ja「3びきのくま」。

## 等一下，小火山（wait-little-volcano）

| canonical key | zh-TW（定案） | ja | en-US | en-GB | es-MX | pt-BR | th-TH | vi-VN |
|---|---|---|---|---|---|---|---|---|
| puff | 嘟嘟 | プク（提案） | Puff（提案） | | | | | |
| fluff | 毛毛 | モコ（提案） | Fluff（提案） | | | | | |

## 拔蘿蔔（the-giant-turnip）

| canonical key | zh-TW（定案） | ja | en-US（定案） | en-GB | es-MX | pt-BR | th-TH | vi-VN |
|---|---|---|---|---|---|---|---|---|
| grandpa | 爺爺（定案·2026-07-20 關卡③ Green Light） | | Grandpa（定案·2026-07-20 關卡④ Green Light） | | | | | |
| grandma | 奶奶（定案·2026-07-20 關卡③ Green Light） | | Grandma（定案·2026-07-20 關卡④ Green Light） | | | | | |
| sunny | 小翔（定案·2026-07-20 關卡③ Green Light） | | Sunny（定案·2026-07-20 關卡④ Green Light） | | | | | |
| woofy | 旺旺（定案·2026-07-20 關卡③ Green Light） | | Woofy（定案·2026-07-20 關卡④ Green Light） | | | | | |
| pip | 嘰嘰（定案·2026-07-20 關卡③ Green Light） | | Pip（定案·2026-07-20 關卡④ Green Light） | | | | | |

## 不一樣的斑點（different-spots）

| canonical key | zh-TW（提案） | ja | en-US | en-GB | es-MX | pt-BR | th-TH | vi-VN |
|---|---|---|---|---|---|---|---|---|
| dotty | 點點 | | | | | | | |
| roundy | 圓圓 | | | | | | | |

## 小天鵝慢慢長大（the-little-swan-grows-in-time）

| canonical key | zh-TW（定案） | ja | en-US（定案） | en-GB | es-MX | pt-BR | th-TH | vi-VN |
|---|---|---|---|---|---|---|---|---|
| swan_anan | 安安 | アンアン（提案·2026-07-21 S4B ja 盲稿；カタカナ P8 動物角色名慣例、canonical key 直寫） | An-An（定案·2026-07-20 關卡④ S4 R3 Green Light） | | An-An（提案·2026-07-21 S4B es-MX 盲稿） | Ani（提案·2026-07-21 S4B pt-BR 盲稿；diminutivo-friendly 2-syllable，An- root 保留 canonical key 語感） | | |

## 我有我的小光（my-little-glow）

| canonical key | zh-TW（提案） | ja | en-US | en-GB | es-MX | pt-BR | th-TH | vi-VN |
|---|---|---|---|---|---|---|---|---|
| glim | 亮亮（提案，源自 PYO-009 凍結 design） | | Glim（定案·2026-07-21 關卡④ Green Light） | | | | | |
| mama_glim | 亮亮媽媽（提案，源自 PYO-009 凍結 design） | | Mama Firefly（別名：Mama）（定案·2026-07-21 關卡④ Green Light） | | | | | |

## 獅子與老鼠（the-lion-and-the-mouse）

| canonical key | zh-TW | ja | en-US（提案） | en-GB | es-MX | pt-BR | th-TH | vi-VN |
|---|---|---|---|---|---|---|---|---|
| wei_wei | | | Leo（提案，源自 PYO-012 凍結 design；2026-07-20 Gate 4 Green Light） | | | | | |
| zhi_zhi | | | Pip（提案，源自 PYO-012 凍結 design；2026-07-20 Gate 4 Green Light） | | | | | |

## 擔心口袋裡有什麼？（whats-in-the-worry-pocket）

| canonical key | zh-TW | ja | en-US（定案） | en-GB | es-MX | pt-BR | th-TH | vi-VN |
|---|---|---|---|---|---|---|---|---|
| cuddles | 牽牽（別名：牽牽獺）（提案，源自 PYO-006 凍結 design；審稿指令 qianqian 對應此 frozen canonical key） | ぎゅっちゃん（提案·2026-07-21 S4B ja 盲稿；design doc 提案沿用——ぎゅっ＝抱緊擬聲＋ちゃん 暱稱） | Cuddles（定案·2026-07-21 關卡④ Green Light） | Cuddles（提案·同 en-US） | Mimí（提案·2026-07-21 S4B es-MX 盲稿） | Dedinha（提案·2026-07-21 S4B pt-BR 盲稿；diminutivo de dedo＝小指，暗合「牽手」主題） | น้องกอด（提案·2026-07-21 S4B th-TH 盲稿；น้อง＝幼兒暱稱前綴＋กอด＝hug，映射 canonical "cuddles"；避開แม่นาก ghost story 碰撞） | Bống（別名：Rái Bống）（提案·2026-07-21 S4B vi-VN 盲稿；Bống＝越南幼兒暱稱·圓潤音·1 音節便於幼兒呼叫；Rái Bống＝水獺寶寶正式名） |
| mama_otter | 水獺媽媽（別名：媽媽）（提案，源自 PYO-006 凍結 design；2026-07-20 Human S4 Review R1 指令） | カワウソのおかあさん（別名：おかあさん）（提案·2026-07-21 S4B ja 盲稿；design doc 提案沿用——カワウソ＝水獺＋おかあさん＝媽媽，對話短形 おかあさん） | Mama Otter（別名：Mama）（定案·2026-07-21 關卡④ Green Light） | Mama Otter（別名：Mama）（提案·同 en-US） | Mamá Nutria（提案·2026-07-21 S4B es-MX 盲稿） | Mamãe Lontra（提案·2026-07-21 S4B pt-BR 盲稿） | คุณแม่（別名：แม่）（提案·2026-07-21 S4B th-TH 盲稿；คุณแม่＝尊敬暖稱、標準泰語繪本慣例；in-text 短形 แม่） | Mẹ Rái（別名：Mẹ）（提案·2026-07-21 S4B vi-VN 盲稿；Mẹ＝北方標準「媽媽」R5 錨定；Rái＝水獺，對話短形 Mẹ） |

## 阿嬤的圍裙口袋（grandmas-apron-pockets）

| canonical key | zh-TW | ja | en-US | en-GB | es-MX | pt-BR | th-TH | vi-VN |
|---|---|---|---|---|---|---|---|---|
| child_xiaohe | 小禾（提案，源自 PYO-014 凍結 design） | | Mia（提案·2026-07-21 S4A en-US 盲稿，源自 PYO-014 凍結 design §7） | | | | | |
| grandma_lan | 蘭阿嬤（提案，源自 PYO-014 凍結 design） | | Grandma Lan（提案·2026-07-21 S4A en-US 盲稿，源自 PYO-014 凍結 design §7） | | | | | |

## 心情天氣小屋（the-weather-house-of-feelings）

| canonical key | zh-TW（提案） | ja | en-US（提案） | en-GB | es-MX | pt-BR | th-TH | vi-VN |
|---|---|---|---|---|---|---|---|---|
| milu | 咪嚕（提案，源自 PYO-005 凍結 design） | | Milu（提案） | | | | | |
| zippy | 咻咻（提案，源自 PYO-005 凍結 design） | | Zippy（提案） | | | | | |

---

## 命名規則

1. **新 locale 提案流程**：locale spec 的譯名慣例 → 在此表填「提案」＋來源 → 對抗審查／母語者人設 QA → 首批內容出貨後升「定案」。
2. **命名原則**：符合該 locale 幼兒語感（疊字、暱稱化）；三兄弟名需保留「性格對應」（老大隨性→老三勤勉）；音節數利於 TTS 斷句（zh-TW 曾因角色名斷句踩雷，見 pipeline/lessons_learned/tts.md L2）。
3. **同步義務**：此表更新後，接線該 locale 時必須同步 `tts_parser.py` CHAR_NAMES 與 `voice_config.json`（見 README「Locale 上線檢查清單」）。
