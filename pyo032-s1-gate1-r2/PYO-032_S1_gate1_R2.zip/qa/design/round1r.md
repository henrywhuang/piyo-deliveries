# 設計 QA 報告：who-falls-asleep-first / design / round 1r（復核輪）

```yaml
schema: piyo_design_qa_report/v0.9
slug: who-falls-asleep-first
stage: S1
round: 1r
date: "2026-07-30"
step3_check: {exit_code: 0, warnings: 5}
concept_fidelity: pass
theme_engine: pass
reviewer: skip（復核輪，Stacy 指示修訂）
triage: {real: 2, rejected: 0, escalated: 0}
verdict: pass
```

## Stacy R1 修改指令（2026-07-30）

| # | 指令 | 修改 |
|---|---|---|
| 1 | 毛毛 lock features `bilaterally symmetrical` 與右耳蝴蝶結自相矛盾 | 刪除毛毛 lock features 中 `bilaterally symmetrical` 標記，保留 `small pink bow on right ear` 作為識別記憶點 |
| 2 | 收束語「誰先睡著已經不重要了」= 旁白總結道理，違反品牌鐵律第二條（無說教） | §2 結尾④ + §3 P12 改為純場景收束：「三隻熊每天晚上都擠在一起。呼嚕嚕，噗嚕嚕，山洞裡暖暖的。」——只描述畫面與聲音，不下判斷 |

## 復核確認

- 機檢重跑：exit 0，5 警告（同 R1，均為單場景預期特性）
- concept_contract 各鍵未受影響（修改僅涉及 lock features 標記 + 收束語措辭）
- 收束語新版符合品牌鐵律第二條：旁白零說教，情感由擬聲詞（呼嚕嚕/噗嚕嚕）和場景描述（暖暖的）承載
