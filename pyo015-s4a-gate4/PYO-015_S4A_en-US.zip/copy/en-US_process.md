# PYO-015 en-US Mode B Process Log

## B0 Language Foundation

### Character Names

| zh-TW | registry key | en-US proposal |
|---|---|---|
| 栗栗 | lili | Hazel |
| 呼呼風 | huhu_wind | Breezy |
| 啾啾 | jiujiu_bird | Pip |

Rationale: Hazel = hazelnut-adjacent, squirrel-natural; Breezy = wind personified, playful; Pip = small bird, one syllable for 2-3 brevity.

### Refrain Variations

| context | en-US |
|---|---|
| core (all 3 appearances) | Find a clue, then guess who! |

- 6 words, rhymes clue/who
- Three-year-old finishable: adult says "Find a clue, then—" child says "guess who!"
- NOT a translation of zh-TW "看線索，再猜是誰！"; built from the mystery-game function

### Ending Formula

| zh-TW | en-US |
|---|---|
| 後來呀 | And from that day on |

Golden en-US picture book convention (brand_frozen_units: exempt from max_sentence_len).

### Onomatopoeia Proposals

| # | zh-TW | function | en-US proposal | tiers |
|---|---|---|---|---|
| 1 | 咻嚕 | wind carrying seeds | `WHOOSH` | all |
| 2 | 沙沙 | scratching/digging | `Scritch, scratch` | all |
| 3 | 唰啦啦 | leaves blowing in | `Swish` | 2-3 only |
| 4 | 啊嗚 | eating sound | (omitted for word budget) | — |

### Speech-Habit Cards

- **Hazel**: curious investigator; questions, exclamations, short deductive statements
- **Breezy**: carefree; "I just blow!" — disclaims responsibility playfully
- **Pip**: innocent; "I didn't mean to!" / "Oops!" — accidental agent

## Tier Budget Table

| tier | max_total_len | refrain (6w) x3 raw | discount (0.25) saves | effective budget | actual discounted |
|---|---|---|---|---|---|
| 5-6 | 505 | 18 | 9 | 496 non-refrain + 9 refrain | 476 |
| 3-5 | 389 | 18 | 9 | 380 non-refrain + 9 refrain | 250 |
| 2-3 | 88 | 18 | 9 | 79 non-refrain + 9 refrain | 83 |

## B1 Read Discipline Declaration

B1 blind draft completed without opening any zh-TW text files (`text/zh-TW/`, `copy/zh-TW.md`). Sources read during B1: `PYO-015_design.md`, `PYO-015_storyboard.md` "文說什麼" column, B0 cards above, `en-US.md` locale spec only.

## B2 Source Calibration Log

Opened zh-TW 3-5.json + copy/zh-TW.md after B1. Page-by-page check:

1. Semantic payload: all events/emotions/dialogue intents present in en-US drafts
2. No added payload: no visual facts restated beyond zh-TW scope
3. Refrain placement: P03/P06/P11 (storyboard) = matches zh-TW P03/P06/P11
4. Bridge function preserved at all skip-joins (see copy table notes)

No B2 revisions needed; blind draft already aligned with source semantics.
