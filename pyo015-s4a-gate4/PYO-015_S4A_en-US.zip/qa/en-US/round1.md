# QA 報告：who-hid-the-seeds / en-US / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: who-hid-the-seeds
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-22"
step1_lint: {exit_code: 0, warnings: 0}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 5, 朗讀口感: 7, 孩子抓得住度: 6}
  - id: en-US-parent
    scores: {睡前適讀性: 6, 零說教: 4}
  - id: en-US-editor
    scores: {母語自然度: 7, 文字工藝: 8}
step4_triage: {real: 6, rejected: 9, escalated: 0}
low_score_waivers:
  - {persona: en-US-parent, dimension: 零說教, reason: "brand_frozen_units lock-in：'And from that day on' 是品牌收束式（style_guide），E-3 判 PASS（描述行為非宣言）；Jessica 對收束式模板敏感但此為設計層決策，裁決 ❌"}
verdict: fix_required
```

## STEP 1 機檢

```
locale_lint 5-6.draft.json: ✅ 無違規（警告 0 筆）
locale_lint 3-5.draft.json: ✅ 無違規（警告 0 筆）
locale_lint 2-3.draft.json: ✅ 無違規（警告 3 筆：品牌凍結單元豁免、疊句折計×2）
```

三檔全部 exit 0。

## STEP 2 checklist 自檢

**主題錨復述**：風（Breezy）、鳥（Pip）與松鼠（Hazel）各以不同方式移動不同種子到不同地方，孩子跟著 Hazel 從種子外形、落點與痕跡做三輪推理，最終揭示只有松鼠有意藏食物——觀察證據後再判斷。

### quality_criteria checklist（19 A-E 項 + 9 快速掃描 = 28 適用項）

| 項 | 5-6 | 3-5 | 2-3 | 證據摘要 |
|---|---|---|---|---|
| A-1 完整弧線 | PASS | PASS | PASS | 觸發 P01→三輪偵探→P11 揭示→P14/P12/P10 收束 |
| A-2 衝突份量 | PASS | PASS | PASS | 核心衝突跨 ≥2 頁，Hazel 付出具體行動 |
| A-3 情緒起伏 | PASS | PASS | PASS | ≥3 轉折：興奮→忍笑→著急→豁然→安穩 |
| A-4 結尾回響 | PASS | PASS | PASS | "And from that day on" 以行為呼應開頭衝動 |
| A-5 開場鉤子 | PASS | PASS | PASS | P01 首頁即含懸念問句 |
| B-1 字數 | N/A | N/A | N/A | STEP 1 機檢範疇 |
| B-2 句長配情緒 | PASS | PASS | PASS | 緊張段短句 "Hold on!"；平緩段長句 |
| B-3 聲音裝置 | PASS | PASS | PASS | WHOOSH ×1、Scritch scratch ×1 各檔各出現 1 次 |
| B-4 對話比例 | PASS | PASS | PASS | 5-6/3-5 對話為主，2-3 旁白主導穿插短對白 |
| B-5 無百科腔 | PASS | PASS | PASS | 零 "Did you know" 句式 |
| C-1 主角辨識度 | PASS | PASS | PASS | 「以藏食者身分看世界」行為呈現 |
| C-2 成長弧線 | PASS | PASS | PASS | 衝動猜→三輪證據→P14 行為改變 |
| C-3 障礙阻力 | PASS | PASS | PASS | P09 落葉+袋翻=環境障礙影響劇情 |
| C-4 配角功能 | PASS | PASS | PASS | Breezy=觸發+障礙，Pip=鏡像 |
| D-1/D-2/D-3 | N/A | N/A | N/A | stage-N/A（需成圖） |
| D-4 翻頁牽引 | PASS | PASS | PASS | 各檔 ≥2 處文字可偵測 hook |
| E-1 主題行動 | PASS | PASS | PASS | 三輪觀察推理呈現，無旁白說教 |
| E-2 情感共鳴 | PASS | PASS | PASS | 行為傳遞好奇/好笑/著急/滿足 |
| E-3 末頁無教訓 | PASS | PASS | PASS | 收束式描述行為習慣，非三禁句式 |
| E-4 抽象度匹配 | PASS | PASS | PASS | "clues" 始終有具體支撐 |
| 快速掃描 #1-#10 | 8 PASS + 1 N/A(#7) + 1 N/A(#4) ×3 檔 | — | — | 同上各項 |

**計數**：文本階段適用項 28 項 × 3 檔 = 84 筆判定，84 PASS，0 FAIL。

### 對位逐頁比對

三檔 36 頁全數 PASS——無屬性重述違規。文字專屬負載（台詞、擬聲、內心、時間、事件敘述）均為合法負載類型。

### Concept fidelity

| 檔位 | 判定 | 證據 |
|---|---|---|
| 5-6 | PASS | 三輪偵探完整，P06 趣味即證據鏈，P12 趣味即概念核心 |
| 3-5 | PASS | 三站判斷鏈完整，P05/P10 趣味服務主題 |
| 2-3 | PASS | 三站主線可追，P04/P08 趣味服務主題；P02 風站壓縮但 P02-P03 spread 完整（E 觀察，裁決 ❌） |

### 趣味設計兌現

| 宣告 | 5-6 | 3-5 | 2-3 |
|---|---|---|---|
| opening_hook P01 | ✓ | ✓ | ✓ |
| refrain ×3 | ✓ P03/P06/P11 | ✓ P02/P05/P09 | ✓ P02/P04/P07 |
| refrain 變奏 P11 | ✓ 三組並排 | ✓ | ✓ 3-word triplet |
| page_turn_hook P09 | ✓ em-dash | ✓ | ✓ |
| WHOOSH | ✓ P04 | ✓ P03 | ✓ P03 |
| Scritch, scratch | ✓ P08 | ✓ P07 | ✓ P05 |
| 收束式 | ✓ P14 | ✓ P12 | ✓ P10 |

全數兌現。

### 回譯偏移標記

S4A en-US 逐頁全量覆蓋（36 頁）：5 輕微 + 9 無（5-6），2 輕微 + 10 無（3-5），8 輕微 + 2 無（2-3）。**0 筆中度**。
2-3 輕微偏移均為電報式壓縮合法範圍（省略受詞、簡化動作、語體轉換）。

### ESL 獵手

全三檔 36 頁掃描，發現 **1 筆**：

| 檔位 | 頁 | 原句 | 問題類型 | 嚴重度 | 建議 |
|---|---|---|---|---|---|
| 5-6 | P11 | "The answer isn't just one!" | ESL-語序 | 中 | "There's more than one answer!" |

盲稿讀序聲明抽驗：五組句法結構對照全數通過，en-US 句法獨立於 zh-TW，盲稿聲明可信。

## STEP 3 人設 blind QA

### en-US-teacher (Ms. Rivera)

| 檔位 | 頁 | 問題描述 | 嚴重度 |
|---|---|---|---|
| 2-3 | P06 | "satchel" 從未在 2-3 建立，2 歲不認識 | 高 |
| 2-3 | P09 | 零動作零感官錨點，抽象 "waited for spring" | 中 |
| 3-5 | P09 | 裸 "I" 無引號，朗讀人稱混亂 | 中 |
| 2-3 | P07 | "I hid!" 無引號，同上人稱問題 | 中 |
| 2-3 | P10 | "from that day on" 偏成人 | 低 |
| 5-6 | P01 | 開場文字量偏大 | 低 |
| 5-6 | P13 | P12 高潮後節奏斷裂 | 低 |

分檔明細：5-6（年齡 9/朗讀 8/抓住 8）、3-5（8/7/8）、2-3（5/7/6）

### en-US-parent (Jessica)

| 檔位 | 頁 | 問題描述 | 嚴重度 |
|---|---|---|---|
| 5-6 | P14 | "Next time..." + "And from that day on" 雙重說教 | 高 |
| 3-5 | P12 | 同上 | 高 |
| 2-3 | P10 | 同上 | 高 |
| 5-6 | P13-P14 | 能量弧線未下降 | 中 |
| 3-5 | P11-P12 | 同上 | 中 |
| 2-3 | P09-P10 | 同上 | 中 |
| 5-6 | P11 | "The answer isn't just one" 不自然 | 低 |
| 2-3 | P01-P04 | 片段堆疊像字卡 | 低 |

分檔明細：5-6（睡前 6/零說教 4）、3-5（6/4）、2-3（6/4）

### en-US-editor (Margaret)

| 檔位 | 頁 | 問題描述 | 嚴重度 |
|---|---|---|---|
| 5-6 | P11 | "The answer isn't just one!" 翻譯語序 | 中 |
| 3-5 | P09 | 無引號 "I" POV 跳躍 | 中 |
| 5-6 | P03 | "swept in one line" 搭配 | 低 |
| 2-3 | P09 | 缺定冠詞 "Three friends" | 低 |
| 2-3 | P07 | "I hid!" POV 跳（可接受） | 低 |

分檔明細：5-6（自然度 8/工藝 9）、3-5（7/8）、2-3（8/8）

## STEP 4 三分法分診

**主題錨復述**：風、鳥與松鼠各以不同方式移動種子，孩子跟著 Hazel 從證據推理——觀察後再判斷。

| # | 發現 | 涉及 | 訊源 | 收斂 | 裁決 | 依據 | 修改級別 |
|---|---|---|---|---|---|---|---|
| F1 | "The answer isn't just one!" ESL 語序 | 5-6 P11 | 獵手＋Margaret＋Jessica＋E | 4路 | ✅ | en-US spec 紅線 ESL calque/語序 | 字串級 |
| F2 | 裸 "I" 無引號 POV 跳 | 3-5 P09 | Margaret＋Rivera＋E | 3路 | ✅ | 第三人稱敘事突跳第一人稱無引號＝朗讀障礙 | 句級 |
| F3 | 裸 "I hid!" 無引號 | 2-3 P07 | Margaret＋Rivera | 2路 | ✅ | 同 F2 | 句級 |
| F4a | 結尾 "preachiness" | 三檔 P14/P12/P10 | Jessica | 1路 | ❌ | brand_frozen_units "And from that day on"（style_guide lock-in）＋E-3 PASS；角色台詞描述行為非宣言 | — |
| F4b | 結尾能量弧線 | 三檔末二頁 | Jessica＋Rivera | 2路 | ❌ | 頁面結構＝storyboard 凍結物；推翻 2 路收斂出處＝storyboard S2 凍結 | — |
| F5 | "satchel" 詞彙斷層 | 2-3 P06 | Rivera | 1路 | ✅ | 低頻詞未建立；"bag" 為高頻替代 | 字串級 |
| F6a | 缺定冠詞 "Three friends" | 2-3 P09 | Margaret | 1路 | ✅ | 已建立角色需 "The" | 字串級 |
| F6b | P09 零動作 | 2-3 P09 | Rivera | 1路 | ❌ | 2-3 電報式忠實實現 storyboard P13 beat | — |
| F7 | "from that day on" 太成人 | 2-3 P10 | Rivera＋Jessica | 2路 | ❌ | brand_frozen_units lock-in；推翻 2 路收斂出處＝style_guide | — |
| F8 | "swept in one line" 搭配 | 5-6 P03 | Margaret | 1路 | ✅ | "into a line" 更自然 | 字串級 |
| F9 | P01 文字密度 | 5-6 P01 | Rivera | 1路 | ❌ | 40w 在帶內；storyboard P01 指定內容 | — |
| F10 | P13 節奏斷裂 | 5-6 P13 | Rivera＋Jessica | 2路 | ❌ | storyboard P13 時間轉場 beat；推翻 2 路收斂出處＝storyboard S2 凍結 | — |
| F11 | 2-3 P02 風站壓縮 | 2-3 P02 | E | 1路 | ❌ | P02-P03 spread 完整呈現風機制 | — |
| F12 | 設計外擬聲詞 | 2-3 P02/P06 | E | 1路 | ❌ | 非文本缺陷，design.md 簿記 | — |
| F13 | "flashcard feel" | 2-3 P01-P04 | Jessica | 1路 | ❌ | W7 電報式語體設計要求 | — |

**修改指定**：
- F1：`"The answer isn't just one!"` → `"There's more than one answer!"`
- F2：3-5 P09 第二段加引號包覆為 Hazel 台詞
- F3：2-3 P07 第二段加引號包覆為 Hazel 台詞
- F5：`satchel` → `bag`
- F6a：`Three friends` → `The three friends`
- F8：`in one line` → `into a line`

**獨有訊源分佈**：獵手獨有 real 0｜回譯獨有 real 0｜人設獨有 real 3（F5, F6a, F8）｜多路收斂 real 3（F1, F2, F3）

全部 ✅ ∈ {字串級, 句級} → round 2 具復核輪資格。
