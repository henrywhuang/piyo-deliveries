# QA 報告：who-hid-the-seeds / en-US / round 2

> **復核輪**：round 1 全部 ✅ ∈ {字串級 ×4, 句級 ×2}，符合復核輪資格。STEP 1 機檢全量重跑＋逐筆落地驗證＋copy↔draft 同源檢＋E-lite 受修頁複審＋受修頁回譯同步。人設不重跑，分數沿用 round 1。

```yaml
schema: piyo_text_qa_report/v0.9
slug: who-hid-the-seeds
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-22"
step1_lint: {exit_code: 0, warnings: 3}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 5, 朗讀口感: 7, 孩子抓得住度: 6}
  - id: en-US-parent
    scores: {睡前適讀性: 6, 零說教: 4}
  - id: en-US-editor
    scores: {母語自然度: 7, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 0}
low_score_waivers:
  - {persona: en-US-parent, dimension: 零說教, reason: "brand_frozen_units lock-in（同 round 1）"}
verdict: pass
```

## STEP 1 機檢（全量重跑）

```
locale_lint 5-6.draft.json: ✅ 無違規（警告 0 筆）
locale_lint 3-5.draft.json: ✅ 無違規（警告 0 筆）
locale_lint 2-3.draft.json: ✅ 無違規（警告 3 筆：品牌凍結單元豁免、疊句折計×2）
copy_check en-US.md: ✅ 通過（警告 9 筆：3-5 P01/P12 超帶上緣 +1w ×2、2-3 七頁低於帶底為電報式合法）
```

四道全 exit 0。

## 逐筆落地驗證

| # | 裁決指定 | 檔案 | 驗證 |
|---|---|---|---|
| F1 | "The answer isn't just one!" → "There's more than one answer!" | 5-6.draft.json P11 + copy P11 | ✓ 落地 |
| F2 | 3-5 P09 第二段加引號 | 3-5.draft.json P09 + copy P09 | ✓ 落地 |
| F3 | 2-3 P07 第二段加引號 | 2-3.draft.json P07 + copy P07 | ✓ 落地 |
| F5 | satchel → bag | 2-3.draft.json P06 + copy P06 | ✓ 落地 |
| F6a | Three → The three | 2-3.draft.json P09 + copy P09 | ✓ 落地（字數 7→8✓） |
| F8 | in one line → into a line | 5-6.draft.json P03 + copy P03 | ✓ 落地 |

copy↔draft 同源檢：copy_check exit 0 確認。

## STEP 2 checklist 自檢

> 復核輪：E-lite 受修頁複審（非完整 checklist 重跑）。

**主題錨復述**：風、鳥與松鼠各以不同方式移動種子，孩子從證據推理——觀察後再判斷。

受修頁（6 頁）＋相鄰頁複審：

| 頁 | 修改 | beat 語義 | 跨頁波及 | 主題錨 | 對位 | 判定 |
|---|---|---|---|---|---|---|
| 5-6 P03 | "into a line" | 不變 | 無 | 不觸 | PASS | ✓ |
| 5-6 P11 | "There's more than one answer!" | 不變（三種途徑＝多答案） | 無 | 不觸 | PASS | ✓ |
| 3-5 P09 | 加引號 | 不變（內容同） | 無 | 不觸 | PASS | ✓ |
| 2-3 P06 | "bag" | 不變 | 無 | 不觸 | PASS | ✓ |
| 2-3 P07 | 加引號 | 不變（內容同） | 無 | 不觸 | PASS | ✓ |
| 2-3 P09 | "The three" | 不變 | 無 | 不觸 | PASS | ✓ |

相鄰頁（P02/P04, P10/P12, P08/P10, P05, P06/P08, P08/P10）無新問題。E-lite 通過。

## 受修頁回譯同步

受修頁回譯已更新（backtranslation.md 5-6 P11、2-3 P06、2-3 P09），偏移標記重填完成。內容未變頁（3-5 P09、2-3 P07）回譯不變、偏移標記不變。

覆蓋率機檢（S4A 逐頁全量）：`| P` 行數 = 14 + 12 + 10 = 36 = 三檔頁數和。無殘留「回修待重譯」。✓

## STEP 3 人設 blind QA

分數沿用 round 1，人設不重跑。

## STEP 4 三分法分診

本輪 ✅ = 0。收斂。

---

**round 2 結論**：6 筆修改全數落地驗證、機檢通過、E-lite 無新問題、回譯同步完成。QA 收斂，verdict: pass。
