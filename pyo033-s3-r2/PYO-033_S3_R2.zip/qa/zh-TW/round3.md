# QA 報告：who-hid-the-seeds / zh-TW / round 3
```yaml
schema: piyo_text_qa_report/v0.9
slug: who-hid-the-seeds
locale: zh-TW
tiers: ["2-3", "3-5", "5-6"]
round: 3
date: "2026-07-30"
step1_lint: {exit_code: 0, warnings: 0}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: zh-TW-teacher
    scores: {年齡適配度: 7, 朗讀口感: 9, 孩子抓得住度: 9}
  - id: zh-TW-parent
    scores: {睡前適讀性: 8, 零說教: 9}
  - id: zh-TW-editor
    scores: {母語自然度: 7, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

## 性質

本輪為 **Stacy gate3 R1 修訂復核輪**：Stacy 審閱 gate3 R1 審包後 verdict「不通過 — 需修改後重審」，指定三項修改。修改落地後全量機檢＋受修頁 E-lite 驗證。

### Stacy R1 修訂指令（逐項落地）

| # | 指令 | 範圍 | 修改級別 | 落地狀態 |
|---|---|---|---|---|
| 1 | 「橡實」→「小果子」 | 2-3 全檔（P01, P02）＋3-5 全檔（P01, P02, P09, P11） | 字串級 | ✅ replace_all 6 處 |
| 2 | 「蒼耳子」→「刺刺的小球球」 | 3-5 P05 | 字串級 | ⬜ R1 QA 已完成（round1），無需再改 |
| 3 | P09 旁白提問→角色內心獨白 | 5-6 P09 | 句級 | ✅「她在做什麼呢？」→「咚咚歪著頭看：她在做什麼呀？」 |

備註：5-6 保留「橡實」——Stacy 指示：六歲可學此詞，認知獎勵感。

## STEP 1 機檢

三檔 locale_lint 全量重跑：

```
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-033_who-hid-the-seeds/text/zh-TW/5-6.draft.json --locale zh-TW --band 5-6
→ exit 0, warnings 2 (repeat_discount)

python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-033_who-hid-the-seeds/text/zh-TW/3-5.draft.json --locale zh-TW --band 3-5
→ exit 0, warnings 2 (repeat_discount)

python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-033_who-hid-the-seeds/text/zh-TW/2-3.draft.json --locale zh-TW --band 2-3
→ exit 0, warnings 2 (repeat_discount)
```

copy_check.py exit 0（警告 22 筆，均為超帶上緣，已在 copy 表附理由）。

## STEP 2 checklist 自檢

**主題錨復述**：本書教「自然循環——忘記反而成就新生」，賣點＝身體笑話驅動的「不是這裡」疊句。

### 母本語感獵手

受修頁語感掃描（「橡實→小果子」六處＋5-6 P09 新句）：

- **2-3 P01**「咚咚抱著小果子跑呀跑」——「小果子」三拍自然，幼兒口語中性名詞，語感通順。✓
- **2-3 P02**「咚咚的小果子呢？」——問句節奏自然。✓
- **3-5 P01/P02/P09/P11** 四處「小果子」替換——與上下文融合無違和。✓
- **5-6 P09**「咚咚歪著頭看：她在做什麼呀？」——角色具名動作＋冒號引內心獨白，「呀」語氣詞承接好奇語感，與 P10「咚咚歪著頭」呼應。旁白提問品牌紅線已修正。✓

無翻譯腔殘留、無 AI 機械句。

### 受修頁 E-lite 驗證

| 頁 | 檔位 | 修改內容 | 對位 | 語感 | 判定 |
|---|---|---|---|---|---|
| P01 | 2-3/3-5 | 橡實→小果子 | 圖有咚咚抱物件跑 ✓ | 三拍自然 | ✓ |
| P02 | 2-3/3-5 | 橡實→小果子 | 圖有咚咚探頭困惑 ✓ | 問句通順 | ✓ |
| P09 | 5-6 | 旁白→角色獨白 | 圖有咚咚坐路邊望遠 ✓ | 「歪著頭看」動態自然 | ✓ |
| P09(3-5) | 3-5 | 橡實→小果子 | 嗅覺發現 ✓ | 通順 | ✓ |
| P11(3-5) | 3-5 | 橡實→小果子 | 埋入動作 ✓ | 通順 | ✓ |

相鄰頁抽驗（P08/P10 5-6、P08/P10 3-5、P01/P03 2-3）：文義銜接無受影響 ✓。

## STEP 3 人設 blind QA

復核輪：沿用 round 1 人設分數，不重跑。Stacy 修訂為字串級／句級，不影響人設體驗維度。

## STEP 4 三分法分診

復核輪：Stacy 指定修改全數落地，無新發現。AI QA 本輪無新增 ✅/❌/⏸️。
