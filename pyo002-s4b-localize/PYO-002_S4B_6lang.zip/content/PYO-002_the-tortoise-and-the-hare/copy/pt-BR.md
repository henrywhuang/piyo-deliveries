<!-- piyo-text-writer 模板 v0.9 — 圖文總表 copy/{locale}.md（模式 B＝S4 locale 改編）
     章節標題、檔頭 YAML 欄位與表格欄位是機檢契約（scripts/copy_check.py），不得增刪改名。
     本檔依 2026-07-21 盲稿改編制（B0-B2）產出：B0 語感基建卡已過編排裁定；
     B1 盲稿（未開啟任何 zh-TW / en-US 文本檔）；B2 對源校準改動逐頁記入「選圖與提純說明」欄（標【B2】）。 -->

# 圖文總表：A Lebre e a Tartaruga（the-tortoise-and-the-hare / pt-BR）

> 模式 B＝locale 改編（S4，**改編不是翻譯**——讀設計文件後用該語言重新講一次故事；
> zh-TW 定稿是參考素材、不是對位基準）。
> 頁面選用**完全繼承** storyboard 三檔選用表（照抄進檔頭 selection，不得自選、自增、自刪）；
> 一頁一圖：每檔每頁恰用一張圖、用圖序號嚴格遞增；未用圖三欄一律填「—」。
> 文字的專屬負載＝聲音、台詞、內心、時間；不重述圖已明示的視覺事實。
> 字數瞄準目標帶中值；超帶頁逐頁在說明欄附理由（frozen formula 所致）。
>
> B0 快審裁定注記（2026-07-21 S4B pt-BR 泳道）：
> ①疊句核心句＝pt-BR 原生重建："Tudo bem, devagarinho, passo a passo, eu vou seguindo."（-inho/-indo 韻；三歲接力：聽到「passo a passo」能跟出「eu vou seguindo」）；三檔逐字一致。
> ②收束式＝pt-BR 原生重建："E daquele dia em diante"（style_guide golden 收束式 "And from that day on" 的 pt-BR 原生對應；三檔統一概念）。
> ③角色名＝提案值：Lentinha（tilly）、Saltão（hops）、Juiz Coruja（owl）。
> ④擬聲詞提案：嘲笑 `Ha ha ha!`、兔子衝刺 `ZUUUM!`、腳步聲 `tec, tec, tec.`、撲蝶跳躍 `Boing! Boing!`、鼾聲 `Zzzzzzz.`；全為 registry 空白欄位之提案。

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: the-tortoise-and-the-hare
locale: pt-BR
mode: B
storyboard: content/PYO-002_the-tortoise-and-the-hare/PYO-002_storyboard.md
design: content/PYO-002_the-tortoise-and-the-hare/PYO-002_design.md
image_pool: 14
selection:
  "3-5": [P01, P02, P03, P05, P06, P08, P10, P11, P12, P13, P14]
  "2-3": [P01, P02, P03, P06, P10, P11, P12, P13, P14]
commitments:
  refrain: "Tudo bem, devagarinho, passo a passo, eu vou seguindo."
  ending: "E daquele dia em diante"
  onomatopoeia: [Ha ha ha!, ZUUUM!, "tec, tec, tec.", "Boing! Boing!", Zzzzzzz.]
characters: [Lentinha, Saltão, Juiz Coruja]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Saltão apontou e deu risada.<br>— Ha ha ha! Que lenta! Aposto que nem consegue terminar uma corrida!<br>Lentinha respirou fundo.<br>— Tá bom… eu aceito. | 24✓ | 1 | Saltão deu risada.<br>— Ha ha ha! Que lenta! Quer correr comigo?<br>— Tá bom… eu aceito. | 15✓ | 1 | — Sou rápido! Quer apostar?<br>— Tá bom! | 6✓ | ✓ | 5-6：嘲笑＋下戰帖完整（apontou＝圖中指向動作）。3-5：砍 apontou（圖交代），壓縮台詞。2-3：依 design §6 安全護欄——嘲笑轉友善邀請；電報式短應答。travessão 對話制 [P5-1] |
| P02 | 2 | — Preparar… apontar… JÁ! — gritou Juiz Coruja.<br>ZUUUM! Saltão saiu feito um foguete.<br>Lentinha ainda estava na linha de partida. Nem um passinho. | 22✓ | 2 | — Preparar… apontar… JÁ! — gritou Juiz Coruja.<br>ZUUUM! Saltão sumiu.<br>Lentinha ainda estava na linha de partida. | 16✓ | 2 | ZUUUM!<br>Saltão saiu bem rápido!<br>Lentinha andou devagar. | 8✓ | ✓ | ZUUUM!＝提案值（兔子衝刺 pt-BR，registry 空白→提案回寫 pending）。5-6：裁判出場＋比喻＋落差。3-5：砍比喻與落差細節。2-3：電報式——擬聲＋對比 |
| P03 | 3 | tec, tec, tec.<br>Lentinha ia andando pela trilha, um passinho de cada vez.<br>Baixinho, falou pra si mesma:<br>— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | 27✓ | 3 | tec, tec, tec. Lentinha andava, um passinho de cada vez.<br>— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | 19✓ | 3 | tec, tec, tec.<br>— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | 12✓ | ✓ | 疊句首次出現（三檔逐字一致，pt-BR 原生重建 B0 定案）。5-6：旁白鋪墊＋baixinho 傳遞內心性。3-5：tec motif 兌現。2-3：純疊句 |
| P04 | 4 | Saltão estava tão na frente que ficou entediado.<br>— Oba! Uma borboleta!<br>Boing! Boing!<br>Ele pulou no meio das flores, correndo atrás dela.<br>A borboleta pousou bem no nariz dele — e Saltão nem percebeu. | 33✓ | — | — | — | — | — | — | ✓ | 3-5/2-3 不選（兔追蝴蝶支線 beat）。5-6 only：肢體喜劇完整。Boing! Boing!＝提案值（撲蝶跳躍，registry 空白） |
| P05 | 5 | Lentinha chegou lá no alto da ladeira. A estrada ia longe, longe, longe.<br>Seus passos… foram… parando— | 17✓ | 4 | Lentinha chegou lá no alto. A estrada ia longe, longe.<br>Seus passos… foram… parando— | 14✓ | — | — | — | ✓ | 動作中斷型 hook 兌現。5-6：三重「longe」強化壓迫。3-5：二重壓縮。2-3 不選（至暗段不進 2-3） |
| P06 | 6 | Zzzzzzz.<br>Saltão estava deitado de barriga pra cima debaixo da árvore grandona, boca aberta.<br>Uma borboleta descansava na barriga dele, e ele nem sabia. | 24✓ | 5 | Zzzzzzz.<br>Saltão estava debaixo da árvore grandona, deitado de barriga pra cima.<br>Não sabia de nada. | 16✓ | 4 | Zzzzzzz.<br>Saltão dormiu debaixo da árvore! | 6✓ | ✓ | Zzzzzzz.＝與 en-US golden 定案值一致（7z）。5-6：喜劇細節完整。3-5：砍蝴蝶細節，保「não sabia」鋪 P10 反差。2-3：電報式 |
| P07 | 7 | O sol queimava, forte e sem piedade.<br>tec, tec, tec.<br>Os passos de Lentinha foram ficando mais lentos e mais baixinhos — mas ela não parou. | 25✓ | — | — | — | — | — | — | ✓ | 3-5/2-3 不選。tec motif 貫穿（同 P03）。3-5 跳接 P06→P08：P08 首句橋接承接環境壓力 |
| P08 | 8 | Os pés de Lentinha pararam.<br>Estava tão cansada… tão cansada que mal conseguia se manter de pé.<br>Será que ela ia desistir? | 22✓ | 6 | O sol foi ficando cada vez mais quente… Lentinha andou muito, muito tempo.<br>Seus pés pararam. Será que ela ia desistir? | 21✓ | — | — | — | ✓ | 懸念型 hook 兌現。3-5 首行＝橋接句（從 P06 跳過 P07；環境壓力＋時間回指）。2-3 不選 |
| P09 | 9 | Lentinha olhou pras próprias patinhas.<br>Respirou fundo, tremendo, e deu mais um passinho.<br>— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | 22✓ | — | — | — | — | — | — | ✓ | 疊句第二次（顫抖版）。3-5/2-3 不選。3-5 跳接 P08→P10：P10 首句橋接 |
| P10 | 10 | Saltão acordou num susto. Esfregou os olhos.<br>— QUE?! Lá longe, bem longe — Lentinha já estava quase na linha de chegada! | 20✓ | 7 | Mas Lentinha não desistiu.<br>Saltão acordou — e Lentinha já estava quase na linha de chegada! | 15✓ | 5 | Lentinha andou e andou.<br>Saltão acordou— | 6✓ | ✓ | 5-6：驚醒動作＋揭示。3-5：首行橋接（P08→P10，P09 不放棄 beat 回指）。2-3：首行橋接（P06→P10，tempo 回指）＋hook 截斷 |
| P11 | 11 | Saltão correu o mais rápido que podia!<br>Mas Lentinha já estava na linha de chegada — faltava só um passinho.<br>Seu pé levantou… quase tocando o chão— | 26✓ | 8 | Saltão correu o mais rápido que podia!<br>Mas o pé de Lentinha já estava bem em cima da linha de chegada— | 21✓ | 6 | Lentinha quase chegou! Saltão correu e correu!<br>O pé dela— | 10✓ | ✓ | 動作中斷型 hook 兌現。3-5：合併旁白。2-3：揭示句＋V-and-V 電報式＋懸念 |
| P12 | 12 | Lentinha cruzou a linha de chegada.<br>Ficou bem paradinha. Quieta e firme.<br>— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | 21✓ | 9 | Lentinha cruzou a linha de chegada.<br>— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | 15✓ | 7 | Lentinha conseguiu!<br>— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | 11✓ | ✓ | 疊句最終次（平靜篤定版）。高潮＝蛻變兌現。5-6：paradinha（diminutivo 溫度）＋firme 傳遞轉變。3-5：砍旁白標籤。2-3：電報式 conseguiu 即收 |
| P13 | 13 | — Lentinha venceu! — anunciou Juiz Coruja.<br>Saltão chegou ofegante.<br>— Você… você é incrível — disse ele.<br>Lentinha sorriu.<br>— Quer andar junto comigo? | 20✓ | 10 | — Lentinha venceu! — disse Juiz Coruja.<br>— Você… você é incrível.<br>— Quer andar junto comigo? | 13✓ | 8 | — Lentinha venceu!<br>— Você é incrível!<br>— Andar junto? | 7✓ | ✓ | 結尾四件套②認可＋邀請。5-6：ofegante（動作聲音負載）。3-5：砍動作（圖交代）。2-3：電報式 |
| P14 | 14 | — Eu nunca mais vou rir de ninguém por ser devagar — disse Saltão. — Eu quero andar com você, Lentinha!<br>E daquele dia em diante, Lentinha e Saltão andavam sempre juntos. Não pra ver quem era mais rápido — mas quem conseguia dar mais risada. | 42⚠ | 11 | — Eu nunca mais vou rir de ninguém por ser devagar — disse Saltão. — Eu quero andar com você!<br>E daquele dia em diante, Lentinha e Saltão andavam sempre juntos. Não pra ver quem era mais rápido — mas quem conseguia dar mais risada. | 41⚠ | 9 | E daquele dia em diante, Lentinha e Saltão andavam sempre juntos. | 11✓ | ✓ | 5-6/3-5 ⚠理由：frozen ending formula＋forward intention 同頁不可拆（結構性超帶，與 en-US 同構）。2-3：僅收束式（前瞻太抽象） |

<!-- 【STEP 2 並行產出】text/pt-BR/{5-6,3-5,2-3}.draft.json：<br>→\n 逐頁逐字同源。
     draft → 定稿 rename 歸 QA 收斂＋關卡放行（content/README.md 契約 1），本 skill 不做。 -->
