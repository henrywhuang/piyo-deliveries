<!-- piyo-text-writer B1 blind draft — copy/es-MX.md（模式 B＝S4B es-MX 改編）
     本檔已完成 B0 語感基建、B1 三檔盲稿與 B2 對源校準。 -->

# 圖文總表：La Liebre y la Tortuga（the-tortoise-and-the-hare / es-MX）

> 模式 B＝locale 改編（S4B，**改編不是翻譯**）；頁面選用完全繼承 storyboard 三檔選用表。
> 一頁一圖，文字只承擔聲音、台詞、內心與時間等分鏡指定負載；B1 三檔盲稿、B2 對源校準已完成。
> Display title `La Liebre y la Tortuga` 與 `Lentita`／`Saltón`／`Juez Búho` 為 es-MX 提案。
> 擬聲詞 `¡ZUUUM!`／`Zzzzzzz.`／`¡Ja, ja, ja!`／`¡Boing! ¡Boing!` 為 es-MX 提案，待 TTS round-trip。
>
> **B0 語感基建註記**
>
> - **角色名提案**（registry es-MX 欄空白，本次提案）：
>   - tilly（慢慢龜）→ **Lentita**（lenta＋diminutivo -ita＝暱稱化、音節少、暗示慢慢特質、MX 幼兒自然唸法；3 音節 len-TI-ta 好念好記）
>   - hops（跳跳兔）→ **Saltón**（saltar＋增大詞尾 -ón＝愛跳鬼、暗示彈跳活力、MX 暱稱慣例；2 音節 sal-TÓN 短快、符合角色急性子）
>   - owl（貓頭鷹裁判）→ **Juez Búho**（別名：Búho）（直白功能稱呼、幼兒可懂、MX 通用 búho＝貓頭鷹；正式場合 Juez 前綴、對話簡化 Búho）
> - **疊句核心句**（golden 鎖定；三檔逐字一致）：`"No pasa nada, despacito, paso a paso, no me paro."`——結構：安撫（No pasa nada）→節奏（despacito＝MX 招牌 diminutivo）→行動（paso a paso）→不停（no me paro）。韻律：-ito/-aro 半韻呼應，4 拍節奏適合 2-3 歲覆述。三次出現：P03（首次·自語）、P09（顫抖版）、P12（篤定版）。
> - **收束式 formula**：`"Y desde ese día"` + `"no para ver quién era más rápido, sino quién se reía más."`（三檔統一概念；2-3 僅 formula）。
> - **擬聲詞提案**（registry es-MX 欄空白，本次提案）：
>   - 嘲笑聲＝ `¡Ja, ja, ja!`（西語標準笑聲書寫，逗號式 R4.2）
>   - 兔子衝刺＝ `¡ZUUUM!`（3U 全大寫，映射 zh 咻／en ZOOM，西語化拼寫）
>   - 腳步聲＝ `chas, chas, chas.`（沙地慢步摩擦聲，小寫逗號三連 O3 格式）
>   - 撲蝶跳躍＝ `¡Boing! ¡Boing!`（跳躍彈跳聲，西語接受外來擬聲 boing）
>   - 鼾聲＝ `Zzzzzzz.`（7z 對齊 en-US registry 定案值）
> - **讀序聲明**：B0／B1 期間未開啟任何 `text/zh-TW/**`、`text/en-US/**`、`copy/zh-TW.md` 文案內容；只讀凍結的 design／storyboard 語義規格、en-US copy 結構參考（非文案來源）、es-MX spec、registries。B2 首次開啟 zh-TW 母本與 en-US 文本做四項逐頁校準。

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: the-tortoise-and-the-hare
locale: es-MX
mode: B
storyboard: content/PYO-002_the-tortoise-and-the-hare/PYO-002_storyboard.md
design: content/PYO-002_the-tortoise-and-the-hare/PYO-002_design.md
image_pool: 14
selection:
  "3-5": [P01, P02, P03, P05, P06, P08, P10, P11, P12, P13, P14]
  "2-3": [P01, P02, P03, P06, P10, P11, P12, P13, P14]
commitments:
  refrain: "No pasa nada, despacito, paso a paso, no me paro."
  ending: "Y desde ese día"
  onomatopoeia: ["¡ZUUUM!", "Zzzzzzz.", "chas, chas, chas.", "¡Ja, ja, ja!", "¡Boing! ¡Boing!"]
characters: [Lentita, Saltón, Juez Búho]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Saltón señaló a Lentita y se rio.<br>—¡Ja, ja, ja! ¡Qué lenta eres! ¡Apuesto a que ni llegas a la meta!<br>Lentita respiró hondo.<br>—Bueno… va. | 27✓ | 1 | Saltón se rio.<br>—¡Ja, ja, ja! ¡Qué lenta eres! ¿Una carrera?<br>Lentita dijo:<br>—Bueno… va. | 16✓ | 1 | —¡Soy rapidísimo! ¿Una carrera?<br>—¡Va! | 6✓ | ✓ | 5-6：嘲笑＋下戰帖完整版（señaló＝圖中指向動作）；respiró hondo＝interior courage。3-5：砍 pointed 動作（圖交代），壓縮台詞。2-3：依 design §6 安全護欄——嘲笑轉友善邀請（rapidísimo＝MX superlative 暱稱腔）。 |
| P02 | 2 | —¡Listos… en sus marcas… FUERA! —gritó Juez Búho.<br>¡ZUUUM! Saltón salió disparado.<br>Lentita seguía en la línea de salida. No había dado ni un solo paso. | 26✓ | 2 | —¡Listos… en sus marcas… FUERA! —gritó Juez Búho.<br>¡ZUUUM! Saltón desapareció.<br>Lentita seguía en la línea de salida. | 19✓ | 2 | ¡ZUUUM!<br>¡Saltón corrió rapidísimo!<br>Lentita caminó despacito. | 7✓ | ✓ | ¡ZUUUM!＝提案值（兔子衝刺）；裁判出場＋速度差距＋落差。3-5：砍比喻＋落差細節。2-3：電報式——擬聲＋對比；砍裁判台詞（圖交代）；despacito 種疊句核心詞。 |
| P03 | 3 | Lentita caminó por el sendero, un pasito a la vez.<br>Se dijo en voz bajita:<br>—No pasa nada, despacito, paso a paso, no me paro. | 25✓ | 3 | chas, chas, chas. Lentita caminó, un pasito a la vez.<br>—No pasa nada, despacito, paso a paso, no me paro. | 19✓ | 3 | chas, chas, chas.<br>—No pasa nada, despacito, paso a paso, no me paro. | 13✓ | ✓ | 疊句首次出現（三檔逐字一致·golden 鎖定）。5-6：旁白鋪墊＋"en voz bajita"傳遞內心性。3-5：chas motif 兌現（P07 被砍，motif 遷移至行走頁）。2-3：純疊句（P02 despacito 已建立行走語境）。 |
| P04 | 4 | Saltón iba tan adelante que se aburrió.<br>—¡Ooh! ¡Una mariposa!<br>¡Boing! ¡Boing!<br>Se lanzó entre las flores, persiguiéndola y rodando por el pasto.<br>La mariposa se le paró en la nariz, y Saltón ni cuenta se dio. | 36✓ | — | — | — | — | — | — | ✓ | 3-5／2-3 不選（兔追蝴蝶支線 beat）。¡Boing! ¡Boing!＝提案值；"ni cuenta se dio"＝MX 慣用式（不是 "no se dio cuenta"）。 |
| P05 | 5 | Lentita llegó a la cima. El camino se extendía largo, largo, largo.<br>Sus patitas… se… frenaron— | 18✓ | 4 | Lentita llegó a la cima. El camino seguía y seguía.<br>Sus patitas… se… frenaron— | 15✓ | — | — | — | ✓ | 動作中斷型 hook 兌現。5-6：「largo, largo, largo」三重壓迫感（對齊 zh 好長好長）。3-5：「seguía y seguía」壓縮至二重。2-3 不選（至暗段不進 2-3，design §6）。 |
| P06 | 6 | Zzzzzzz.<br>Saltón estaba despatarrado bajo el árbol grande, con la boca abierta.<br>Una mariposa descansaba en su panza, y él ni lo sabía. | 25✓ | 5 | Zzzzzzz.<br>Saltón estaba despatarrado bajo el árbol, bien dormido.<br>Ni lo sabía. | 14✓ | 4 | Zzzzzzz.<br>¡Saltón se quedó dormido bajo el árbol! | 8✓ | ✓ | Zzzzzzz.＝registry 定案值（7z）。5-6：喜劇細節完整（boca abierta＋mariposa en panza＝zh 蝴蝶肚皮）；despatarrado＝MX 慣用 sprawl。3-5：砍 mariposa 細節（圖交代），保「ni lo sabía」鋪 P10 驚醒反差。2-3：電報式。 |
| P07 | 7 | El sol pegaba fuerte y no había ni una sombrita.<br>chas, chas, chas.<br>Los pasos de Lentita eran cada vez más lentos, pero no se detuvo. | 25✓ | — | — | — | — | — | — | ✓ | 3-5／2-3 不選（過渡頁）。chas, chas, chas.＝提案值（慢步踏地 motif）。sombrita＝MX diminutivo＝比照 en-US scuff 頁同位。 |
| P08 | 8 | Las patitas de Lentita se pararon.<br>Estaba tan cansada… tan cansada que ya no podía más.<br>¿Se iba a rendir? | 21✓ | 6 | El sol pegaba cada vez más fuerte… Lentita caminó mucho, mucho rato.<br>Sus patitas se pararon. ¿Se iba a rendir? | 21✓ | — | — | — | ✓ | 懸念型 hook 兌現。3-5 首行＝橋接句（從 P06 跳過 P07）。2-3 不選（至暗段不進 2-3）。 |
| P09 | 9 | Lentita miró sus propias patitas.<br>Respiró hondo, temblandito, y dio un paso.<br>—No pasa nada, despacito, paso a paso, no me paro. | 23✓ | — | — | — | — | — | — | ✓ | 疊句第二次（顫抖版）。temblandito＝diminutivo on gerund＝MX 溫度（顫抖著但帶暱稱感）。3-5／2-3 不選。 |
| P10 | 10 | Saltón se despertó de golpe. Se talló los ojos.<br>—¡¿QUÉ?! Allá, al final del camino, ¡Lentita ya casi llegaba a la meta! | 23✓ | 7 | Pero Lentita no se rindió.<br>Saltón se despertó, ¡y Lentita ya casi llegaba a la meta! | 16✓ | 5 | Lentita caminó y caminó.<br>Saltón se despertó— | 7✓ | ✓ | 5-6：驚醒動作＋揭示；"se talló los ojos"＝MX tallarse（no restregarse）。3-5：首行橋接（P09 不放棄 beat 回指）。2-3：首行橋接（時間推移「caminó y caminó」）＋懸念 hook。 |
| P11 | 11 | ¡Saltón corrió con todas sus fuerzas!<br>Pero Lentita ya estaba en la meta, a un pasito.<br>Su patita se levantó… a punto de pisar— | 24✓ | 8 | ¡Saltón corrió con todas sus fuerzas!<br>¡Pero la patita de Lentita ya estaba justo encima de la meta! | 17✓ | 6 | ¡Lentita ya casi llegaba! ¡Saltón corrió y corrió!<br>Su patita— | 10✓ | ✓ | 動作中斷型 hook 兌現。3-5：合併旁白。2-3：揭示句移入首行＋電報式 V-y-V＋動作懸念。 |
| P12 | 12 | Lentita cruzó la meta.<br>Se quedó muy quietecita. Tranquila y segura.<br>—No pasa nada, despacito, paso a paso, no me paro. | 20✓ | 9 | Lentita cruzó la meta.<br>—No pasa nada, despacito, paso a paso, no me paro. | 14✓ | 7 | ¡Lentita llegó!<br>—No pasa nada, despacito, paso a paso, no me paro. | 12✓ | ✓ | 疊句最終次（平靜篤定版）；高潮兌現（至暗→安靜驕傲）。5-6："quietecita, tranquila y segura"傳遞轉變（diminutivo quietecita＝MX 暖質）。3-5：砍旁白（上下文自帶平靜感）。2-3：電報式 llegó 即收。 |
| P13 | 13 | —¡Lentita gana! —anunció Juez Búho.<br>Saltón llegó jadeando.<br>—Tú… eres increíble —le dijo.<br>Lentita sonrió.<br>—¿Caminamos juntos? | 18✓ | 10 | —¡Lentita gana! —dijo Juez Búho.<br>Saltón dijo:<br>—Tú… eres increíble.<br>Lentita dijo:<br>—¿Caminamos juntos? | 15✓ | 8 | —¡Lentita gana!<br>—¡Eres increíble!<br>—¿Caminamos juntos? | 6✓ | ✓ | 結尾：認可台詞＋邀請。5-6：動作描寫（jadeando＝聲音負載）＋"anunció"高規格宣布。3-5：simplified tags。2-3：電報式——短感嘆＋短邀請。 |
| P14 | 14 | —Ya no me voy a reír de nadie por ser lento —dijo Saltón—. ¡Quiero caminar contigo, Lentita!<br>Y desde ese día, Lentita y Saltón caminaron juntos. No para ver quién era más rápido, sino quién se reía más. | 37✓ | 11 | —Ya no me voy a reír de nadie por ser lento —dijo Saltón—. ¡Quiero caminar contigo!<br>Y desde ese día, Lentita y Saltón caminaron juntos. No para ver quién era más rápido, sino quién se reía más. | 36⚠ | 9 | Y desde ese día, Lentita y Saltón caminaron juntos. | 10✓ | ✓ | 5-6/3-5：結尾四件套——前瞻意願句＋收束式 Y desde ese día。3-5 ⚠理由：frozen ending formula＋forward intention statement 同頁不可拆（對齊 en-US 同頁 39⚠ 先例）。2-3：依 age_calibration 砍前瞻意願句（太抽象），僅留收束式。 |

## 2. Notas B2 y autocomprobación del escritor

- **B0-B1-B2 completados**: B0 = bases lingüísticas es-MX nativas (角色名 Lentita/Saltón/Juez Búho + 疊句原生重建 + 擬聲詞提案 + 收束式). B1 = borrador ciego desde design/storyboard loads + B0. B2 = calibración contra zh-TW 5-6/3-5/2-3 fuente y en-US.
- **B2 校準紀錄（四項逐頁）**：
  1. 負載缺漏：P07 zh 有 沙沙沙 motif → es-MX 已有 chas, chas, chas. 同位兌現。P04 蹦蹦 → Boing 已兌現。✓
  2. 情緒弧偏移：P09 zh 顫抖版（顫抖著踏出一步）→ es-MX temblandito 已帶入。P08 zh 快撐不住 → es-MX ya no podía más 已帶入。✓
  3. 收束語對齊：三語 formula 同源——zh 後來呀 / en-US And from that day on / es-MX Y desde ese día。✓ 三檔統一概念。
  4. 安全護欄：2-3 P01 zh 嘲笑→友善邀請 → es-MX 同樣用 ¡Soy rapidísimo! 友善語調。✓ 至暗段 P07-P09 不進 2-3。✓
- **Concordancia**: copy/es-MX.md, 5-6.draft.json (14 entradas), 3-5.draft.json (11 entradas) y 2-3.draft.json (9 entradas) son la misma fuente.
- **疊句折計**：疊句「No pasa nada, despacito, paso a paso, no me paro.」= 10 words。5-6 出現 3 次（首次 10 全額＋第 2 次 10×0.25＝2.5＋第 3 次 10×0.25＝2.5＝折計 15）。3-5 出現 2 次（10＋2.5＝12.5）。2-3 出現 3 次（10＋2.5＋2.5＝15）。
- **Word counts 估算（含折計）**：5-6 raw 338, discount -10 → ~328 ≤ 761 ✓；3-5 raw 207, discount -7.5 → ~200 ≤ 585 ✓；2-3 raw 79, discount -10 → ~69 ≤ 101 ✓。各頁 ≤ max_page_len。max_sentence_len spot-check: 疊句 10w ≤ 11（2-3 上限）✓。
