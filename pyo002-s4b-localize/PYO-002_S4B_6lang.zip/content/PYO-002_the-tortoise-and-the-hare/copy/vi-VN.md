<!-- piyo-text-writer B1 blind draft — copy/vi-VN.md（模式 B＝S4B vi-VN 改編）
     本檔已完成 B0 語感基建、B1 三檔盲稿與 B2 對源校準。 -->

# 圖文總表：Rùa và Thỏ（the-tortoise-and-the-hare / vi-VN）

> 模式 B＝locale 改編（S4B，**改編不是翻譯**）；頁面選用完全繼承 storyboard 三檔選用表。
> 一頁一圖，文字只承擔聲音、台詞、內心與時間等分鏡指定負載；B1 三檔盲稿、B2 對源校準已完成。
> Display title `Rùa và Thỏ` 與 `Rùa Nhỏ`／`Thỏ Nhanh`／`Cú Mèo Trọng Tài` 為 vi-VN 提案（registry）。
> 擬聲詞 `Ha ha ha!`／`Vèo!`／`Khò khò khò…` 為 vi-VN 提案（registry）；`sột soạt, sột soạt`／`Nhảy! Nhảy!` 為本次 B0 提案。
>
> **B0 語感基建註記**
>
> - **角色名**（registry vi-VN 欄提案值照抄）：
>   - tilly（慢慢龜）→ **Rùa Nhỏ**（rùa＝烏龜＋nhỏ＝小·北方標準日常暖稱；2 tiếng 好唸好記）
>   - hops（跳跳兔）→ **Thỏ Nhanh**（thỏ＝兔子＋nhanh＝快·暗示角色急性子；2 tiếng 對稱）
>   - owl（貓頭鷹裁判）→ **Cú Mèo Trọng Tài**（別名：Cú Mèo）（cú mèo＝貓頭鷹（北方口語形）＋trọng tài＝裁判；對話簡化 Cú Mèo）
> - **疊句核心句**（三檔逐字一致）：`"Không sao, đi thôi, từng bước từng bước, đừng dừng lại."`——結構：安撫（Không sao＝沒關係）→鼓勵（đi thôi＝走吧）→行動（từng bước từng bước＝一步一步）→不停（đừng dừng lại＝別停下）。韻律：từng bước 疊詞有節奏感、đừng/dừng 近音回響（聲母同 đ/d、只差聲調）；三歲可跟唸「từng bước từng bước」接「đừng dừng lại」。三次出現：P03（首次·自語）、P09（顫抖版）、P12（篤定版）。
> - **收束式 formula**：`"Từ ngày ấy"` + `"không phải để xem ai nhanh hơn — mà xem ai cười nhiều hơn."`（三檔統一概念；2-3 僅 formula 句）。
> - **擬聲詞**（registry 有提案值照抄＋本次提案空白欄）：
>   - 嘲笑聲＝ `Ha ha ha!`（registry 提案值；Latin 通用形）
>   - 兔子衝刺＝ `Vèo!`（registry 提案值；越南語原生疾風掠過聲）
>   - 腳步聲＝ `sột soạt, sột soạt.`（**B0 提案**——registry vi-VN 欄空白；sột soạt＝越南語 từ láy 摩擦沙響聲、慢步踏沙地原生擬聲；逗號式小寫 O4 格式；待 TTS round-trip）
>   - 撲蝶跳躍＝ `Nhảy! Nhảy!`（**B0 提案**——registry vi-VN 欄空白；nhảy＝跳、動作擬態詞化·首字大寫重複；5-6 P04 only、3-5/2-3 不選；待 TTS round-trip）
>   - 鼾聲＝ `Khò khò khò…`（registry 提案值；越南語鼾聲 từ láy、省略號收尾表持續）
> - **讀序聲明**：B0／B1 期間未開啟任何 `text/zh-TW/**`、`text/en-US/**`、`copy/zh-TW.md`、`copy/en-US.md` 文案內容；只讀凍結的 design／storyboard 語義規格、vi-VN spec、registries。B2 首次開啟 zh-TW 母本與 en-US 文本做四項逐頁校準。

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: the-tortoise-and-the-hare
locale: vi-VN
mode: B
storyboard: content/PYO-002_the-tortoise-and-the-hare/PYO-002_storyboard.md
design: content/PYO-002_the-tortoise-and-the-hare/PYO-002_design.md
image_pool: 14
selection:
  "3-5": [P01, P02, P03, P05, P06, P08, P10, P11, P12, P13, P14]
  "2-3": [P01, P02, P03, P06, P10, P11, P12, P13, P14]
commitments:
  refrain: "Không sao, đi thôi, từng bước từng bước, đừng dừng lại."
  ending: "Từ ngày ấy"
  onomatopoeia: [Ha ha ha!, Vèo!, "sột soạt, sột soạt.", Khò khò khò…, "Nhảy! Nhảy!"]
characters: [Rùa Nhỏ, Thỏ Nhanh, Cú Mèo Trọng Tài]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Thỏ Nhanh chỉ tay cười phá lên. "Ha ha ha! Chậm ơi là chậm! Dám chạy thi với tớ không?"<br>Rùa Nhỏ hít một hơi thật sâu. "Được… thi thì thi." | 31✓ | 1 | Thỏ Nhanh cười lớn. "Ha ha ha! Chậm thế! Chạy thi nhé?"<br>Rùa Nhỏ nói khẽ: "Được… thi thì thi." | 20✓ | 1 | "Tớ nhanh lắm! Thi chạy nhé?"<br>"Được!" | 7✓ | ✓ | 5-6：嘲笑＋下戰帖完整（chỉ tay＝圖中指向動作）。3-5：砍 chỉ tay（圖交代），壓縮台詞。2-3：依 design §6 安全護欄——嘲笑轉友善邀請；電報式短應答 |
| P02 | 2 | "Sẵn sàng… Chạy!" Cú Mèo Trọng Tài vẫy cờ.<br>Vèo! Thỏ Nhanh lao đi như gió.<br>Rùa Nhỏ vẫn còn đứng ở vạch xuất phát. Chưa bước nổi một bước nào. | 31✓ | 2 | "Sẵn sàng… Chạy!" Cú Mèo vẫy cờ.<br>Vèo! Thỏ Nhanh mất hút.<br>Rùa Nhỏ vẫn đứng yên ở vạch xuất phát. | 21✓ | 2 | Vèo!<br>Thỏ Nhanh chạy vù đi!<br>Rùa Nhỏ đi chậm thôi. | 11✓ | ✓ | Vèo!＝registry 提案值。5-6：裁判出場＋如gió＋落差（chưa bước nổi）。3-5：砍比喻＋落差細節。2-3：電報式——擬聲＋對比＋判斷句；砍裁判台詞 |
| P03 | 3 | Rùa Nhỏ một mình đi trên con đường nhỏ, từng bước chậm rãi.<br>Rùa Nhỏ thì thầm với chính mình: "Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | 31✓ | 3 | sột soạt, sột soạt. Rùa Nhỏ đi từng bước từng bước.<br>"Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | 22✓ | 3 | sột soạt, sột soạt.<br>"Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | 15✓ | ✓ | 疊句首次出現（三檔逐字一致）。5-6：旁白鋪墊＋「thì thầm với chính mình」傳遞內心性。3-5：sột soạt motif 兌現（P07 被砍，motif 遷至行走頁）。2-3：純疊句（P02 已建立行走語境） |
| P04 | 4 | Thỏ Nhanh chạy nhanh quá, chán quá rồi.<br>"Ôi! Bướm kìa!"<br>Nhảy! Nhảy!<br>Thỏ Nhanh nhảy tung tăng vào vườn hoa, đuổi theo con bướm.<br>Con bướm đậu ngay trên mũi — mà Thỏ Nhanh chẳng hay biết gì. | 38✓ | — | — | — | — | — | — | ✓ | 3-5／2-3 不選（兔追蝴蝶支線 beat）。Nhảy! Nhảy!＝B0 提案。P03→P05（3-5）自足：P03 建立 Rùa Nhỏ 獨行節奏＋疊句，P05 直接展示路遠壓力。P03→P06（2-3）自足：P03 行走，P06 切 Thỏ Nhanh 睡覺＝平行切換自然 |
| P05 | 5 | Rùa Nhỏ leo lên tới đỉnh dốc. Con đường phía trước dài thăm thẳm.<br>Bước chân Rùa Nhỏ… chậm… dần… lại— | 21✓ | 4 | Rùa Nhỏ leo tới đỉnh dốc. Con đường phía trước còn dài lắm.<br>Bước chân… chậm… dần… lại— | 18✓ | — | — | — | ✓ | 動作中斷型 hook 兌現。5-6：「dài thăm thẳm」三重壓迫（từ láy 強化）。3-5：壓縮至「còn dài lắm」。2-3 不選（至暗段不進 2-3） |
| P06 | 6 | Khò khò khò…<br>Thỏ Nhanh nằm ngửa dưới gốc cây to, chân tay dang rộng, miệng há hốc.<br>Con bướm đậu trên bụng — mà Thỏ Nhanh chẳng biết gì hết. | 30✓ | 5 | Khò khò khò…<br>Thỏ Nhanh nằm ngửa dưới gốc cây to, ngủ say như chết.<br>Chẳng biết gì hết. | 19✓ | 4 | Khò khò khò…<br>Thỏ Nhanh ngủ gục rồi! | 8✓ | ✓ | Khò khò khò…＝registry 提案值。5-6：喜劇細節完整（miệng há hốc＋bướm trên bụng）。3-5：砍 bướm 細節（圖交代），保「chẳng biết gì」鋪 P10 反差。2-3：電報式——擬聲＋判斷句 |
| P07 | 7 | Nắng nóng gay gắt, không một bóng cây.<br>sột soạt, sột soạt.<br>Bước chân Rùa Nhỏ chậm dần, nhẹ dần — nhưng không dừng lại. | 24✓ | — | — | — | — | — | — | ✓ | 3-5／2-3 不選（過渡頁）。sột soạt motif 兌現。3-5 P06→P08 橋接：P08 開頭補「Nắng mỗi lúc một nóng hơn」承接環境壓力。2-3 P06→P10 橋接：P10 開頭補「Rùa Nhỏ cứ đi mãi」承接時間推移 |
| P08 | 8 | Bước chân Rùa Nhỏ dừng lại.<br>Mệt quá rồi… mệt đến mức muốn bỏ cuộc.<br>Rùa Nhỏ có bỏ cuộc không? | 21✓ | 6 | Nắng mỗi lúc một nóng hơn… Rùa Nhỏ đi đã lâu lắm rồi.<br>Bước chân dừng lại. Rùa Nhỏ có bỏ cuộc không? | 23✓ | — | — | — | ✓ | 懸念型 hook 兌現。3-5 首行＝橋接句（從 P06 跳過 P07；橋接＝P07 環境壓力＋時間回指）。2-3 不選（至暗段不進 2-3） |
| P09 | 9 | Rùa Nhỏ nhìn xuống đôi chân mình.<br>Hít một hơi thật sâu, run run bước thêm một bước.<br>"Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | 29✓ | — | — | — | — | — | — | ✓ | 疊句第二次（顫抖版）。3-5／2-3 不選。3-5 P08→P10 橋接：P10 首行「Nhưng Rùa Nhỏ không bỏ cuộc.」承接情緒反轉。2-3 無需橋接（至暗段整段不進） |
| P10 | 10 | Thỏ Nhanh giật mình tỉnh dậy, dụi mắt.<br>"CÁI GÌ?!" Ở tít xa xa — Rùa Nhỏ đã gần tới đích rồi! | 21✓ | 7 | Nhưng Rùa Nhỏ không bỏ cuộc.<br>Thỏ Nhanh tỉnh dậy — Rùa Nhỏ đã gần tới đích rồi! | 17✓ | 5 | Rùa Nhỏ cứ đi mãi.<br>Thỏ Nhanh tỉnh dậy— | 9✓ | ✓ | 5-6：驚醒動作＋揭示。3-5：首行橋接（從 P08 跳過 P09；橋接＝P09 不放棄 beat 回指），砍動作細節。2-3：首行橋接（從 P06 跳過 P07-P09；橋接＝時間推移回指「đi mãi」）＋懸念型 hook（「tỉnh dậy—」截斷） |
| P11 | 11 | Thỏ Nhanh chạy hết sức!<br>Nhưng Rùa Nhỏ đã đứng ngay trước vạch đích — chỉ còn một bước nữa thôi.<br>Bàn chân nhấc lên… sắp đặt xuống— | 27✓ | 8 | Thỏ Nhanh chạy hết sức!<br>Nhưng bàn chân Rùa Nhỏ đã ở ngay trên vạch đích— | 16✓ | 6 | Rùa Nhỏ gần tới rồi! Thỏ Nhanh chạy thật nhanh!<br>Bàn chân— | 12✓ | ✓ | 動作中斷型 hook 兌現。3-5：合併旁白為一句。2-3：「gần tới rồi」揭示移入首行＋電報式＋動作懸念 |
| P12 | 12 | Rùa Nhỏ bước qua vạch đích.<br>Rùa Nhỏ đứng yên. Bình tĩnh và vững vàng.<br>"Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | 26✓ | 9 | Rùa Nhỏ bước qua vạch đích.<br>"Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | 17✓ | 7 | Rùa Nhỏ tới rồi!<br>"Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | 15✓ | ✓ | 疊句最終次（篤定版）。高潮設計兌現（至暗→安靜驕傲）。5-6：「bình tĩnh và vững vàng」傳遞轉變。3-5：砍旁白標籤。2-3：電報式「tới rồi」即收 |
| P13 | 13 | "Rùa Nhỏ thắng rồi!" Cú Mèo Trọng Tài tuyên bố.<br>Thỏ Nhanh chạy tới, thở hổn hển. "Bạn… bạn giỏi quá," Thỏ Nhanh nói.<br>Rùa Nhỏ mỉm cười. "Đi cùng nhau nhé?" | 32✓ | 10 | "Rùa Nhỏ thắng rồi!" Cú Mèo nói.<br>Thỏ Nhanh nói: "Bạn… bạn giỏi quá."<br>Rùa Nhỏ nói: "Đi cùng nhau nhé?" | 21✓ | 8 | "Rùa Nhỏ thắng rồi!"<br>"Bạn giỏi quá!"<br>"Đi cùng nhau nhé?" | 11✓ | ✓ | 結尾四件套②認可台詞＋邀請。5-6：動作描寫（thở hổn hển＝聲音負載）＋「tuyên bố」正式宣布。3-5：砍動作描寫（圖交代）。2-3：電報式——短感嘆＋短邀請 |
| P14 | 14 | "Tớ sẽ không bao giờ cười ai chậm nữa," Thỏ Nhanh nói. "Tớ muốn đi cùng Rùa Nhỏ!"<br>Từ ngày ấy, Rùa Nhỏ và Thỏ Nhanh luôn đi cùng nhau. Không phải để xem ai nhanh hơn — mà xem ai cười nhiều hơn. | 43⚠ | 11 | "Tớ sẽ không bao giờ cười ai chậm nữa," Thỏ Nhanh nói. "Tớ muốn đi cùng Rùa Nhỏ!"<br>Từ ngày ấy, Rùa Nhỏ và Thỏ Nhanh luôn đi cùng nhau. Không phải để xem ai nhanh hơn — mà xem ai cười nhiều hơn. | 43⚠ | 9 | Từ ngày ấy, hai bạn luôn đi cùng nhau. | 9✓ | ✓ | 5-6/3-5 ⚠理由：frozen ending formula＋forward intention statement 同頁不可拆（已知 pattern：zh-TW gate3、en-US gate4 均 escalated＋accepted）。2-3：依 age_calibration 砍前瞻意願句，僅留收束式＝全員溫度收尾 |

<!-- 【STEP 2 並行產出】text/vi-VN/{5-6,3-5,2-3}.draft.json：<br>→\n 逐頁逐字同源。
     draft → 定稿 rename 歸 QA 收斂＋關卡放行（content/README.md 契約 1），本 skill 不做。 -->
