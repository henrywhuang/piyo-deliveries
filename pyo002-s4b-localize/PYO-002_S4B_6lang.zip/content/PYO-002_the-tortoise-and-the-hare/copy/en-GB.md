<!-- piyo-text-writer 模板 v0.9 — 圖文總表 copy/{locale}.md（模式 B＝S4B locale 改編・派生變體）
     章節標題、檔頭 YAML 欄位與表格欄位是機檢契約（scripts/copy_check.py），不得增刪改名。
     本檔依 S4B 派生變體制產出——直接以 en-US 定稿為底本做 BrE 分歧校。
     派生底本＝en-US 定稿（content/PYO-002_the-tortoise-and-the-hare/text/en-US/*.json）。
     BrE 分歧校結論：逐頁逐詞審校三檔共 35 頁，零改動——en-US 底本無 US-only 拼寫、
     無 US-only 詞彙、無 US 文化物件、無 US 句構標記（gotten/come+bare inf 等），
     所有擬聲詞與 golden 句式沿用，角色名共用。 -->

# 圖文總表：The Tortoise and the Hare（the-tortoise-and-the-hare / en-GB）

> 模式 B＝locale 改編（S4B，**派生變體**——en-GB 直接以 en-US 定稿為底本做 BrE 分歧校；
> 非盲稿改編制，不跑 B0/B1/B2）。
> 頁面選用**完全繼承** storyboard 三檔選用表（照抄進檔頭 selection，不得自選、自增、自刪）；
> 一頁一圖：每檔每頁恰用一張圖、用圖序號嚴格遞增；未用圖三欄一律填「—」。
> 文字的專屬負載＝聲音、台詞、內心、時間；不重述圖已明示的視覺事實。
> 字數瞄準目標帶中值；超帶頁逐頁在說明欄附理由（frozen formula 所致）。
>
> 派生變體審校注記：
> ①疊句核心句＝golden 鎖定，兩英語版一致："It's okay, nice and slow, step by step, here I go."
> ②收束式 formula＝兩英語版一致："And from that day on"
> ③角色名 registry 定案：Tilly, Hops, Judge Owl（en-GB 欄空白＝沿用 en-US，character_names.md）
> ④擬聲詞全部沿用 en-US：ZOOM!, Zzzzzzz., scuff, Ha ha ha!, Boing!（onomatopoeia_map.md en-GB 欄空白）
> ⑤BrE 分歧校靶區逐項掃描結果：零命中（詳見下方說明欄）

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: the-tortoise-and-the-hare
locale: en-GB
mode: B
variant: derived
base_locale_text: en-US
storyboard: content/PYO-002_the-tortoise-and-the-hare/PYO-002_storyboard.md
design: content/PYO-002_the-tortoise-and-the-hare/PYO-002_design.md
image_pool: 14
selection:
  "3-5": [P01, P02, P03, P05, P06, P08, P10, P11, P12, P13, P14]
  "2-3": [P01, P02, P03, P06, P10, P11, P12, P13, P14]
commitments:
  refrain: "It's okay, nice and slow, step by step, here I go."
  ending: "And from that day on"
  onomatopoeia: [ZOOM!, Zzzzzzz., "scuff, scuff, scuff.", Ha ha ha!, "Boing! Boing!"]
characters: [Tilly, Hops, Judge Owl]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Hops pointed and laughed. "Ha ha ha! You're SO slow! I bet you can't even finish a race!"<br>Tilly took a deep breath. "Okay… you're on." | 26✓ | 1 | Hops laughed. "Ha ha ha! You're SO slow! Want to race?"<br>Tilly said, "Okay… you're on." | 16✓ | 1 | "I'm fast! Race me?"<br>"Okay!" | 5✓ | ✓ | 【派生變體】零改動。BrE 掃描：無 US-only 詞彙或拼寫。laughed/breath/race/finish 皆共用詞。 |
| P02 | 2 | "Ready… set… GO!" called Judge Owl.<br>ZOOM! Hops shot off like a rocket.<br>Tilly was still at the starting line. She hadn't moved a single step. | 26✓ | 2 | "Ready… set… GO!" called Judge Owl.<br>ZOOM! Hops was gone.<br>Tilly was still at the starting line. | 17✓ | 2 | ZOOM!<br>Hops ran so, so fast!<br>Tilly walked slow. | 9✓ | ✓ | 【派生變體】零改動。ZOOM!＝共用擬聲。"shot off like a rocket"＝共用比喻。 |
| P03 | 3 | Tilly walked along the path, one little step at a time.<br>She whispered to herself, "It's okay, nice and slow, step by step, here I go." | 26✓ | 3 | scuff, scuff, scuff. Tilly walked, one step at a time.<br>"It's okay, nice and slow, step by step, here I go." | 21✓ | 3 | scuff, scuff, scuff.<br>"It's okay, nice and slow, step by step, here I go." | 14✓ | ✓ | 【派生變體】零改動。疊句 golden 鎖定。scuff＝共用擬聲。 |
| P04 | 4 | Hops was so far ahead, he got bored.<br>"Ooh! A butterfly!"<br>Boing! Boing!<br>He leaped into the flowers, chasing and tumbling.<br>The butterfly landed right on his nose — and Hops didn't even notice. | 33✓ | — | — | — | — | — | — | ✓ | 【派生變體】零改動。"got bored"（非 gotten）＝BrE 合法。Boing!＝共用擬聲。leaped＝BrE 接受（leapt 亦可，但 en-US 原文 leaped 在 BrE 非硬違規，保留不改以維持底本一致性）。 |
| P05 | 5 | Tilly reached the top of the hill. The road ahead stretched on and on and on.<br>Her feet… slowed… down— | 20✓ | 4 | Tilly reached the top of the hill. The road ahead went on and on.<br>Her feet… slowed… down— | 18✓ | — | — | — | ✓ | 【派生變體】零改動。 |
| P06 | 6 | Zzzzzzz.<br>Hops lay flat on his back under the big tree, mouth wide open.<br>A butterfly rested on his belly, and he didn't know a thing. | 26✓ | 5 | Zzzzzzz.<br>Hops lay under the big tree, flat on his back, sound asleep.<br>He didn't know a thing. | 18✓ | 4 | Zzzzzzz.<br>Hops fell asleep under the big tree! | 8✓ | ✓ | 【派生變體】零改動。Zzzzzzz.＝registry 定案值（7z）。belly＝共用詞（BrE tummy 為同義替代但非必要替換）。 |
| P07 | 7 | The sun beat down, hot and harsh.<br>scuff, scuff, scuff.<br>Tilly's steps got slower and softer — but she didn't stop. | 20✓ | — | — | — | — | — | — | ✓ | 【派生變體】零改動。scuff motif 沿用。 |
| P08 | 8 | Tilly's feet stopped.<br>She was so tired… so tired she could barely hold on.<br>Was she going to give up? | 20✓ | 6 | The sun got hotter and hotter… Tilly walked for a long, long time.<br>Her feet stopped. Was she going to give up? | 22✓ | — | — | — | ✓ | 【派生變體】零改動。barely＝共用詞。 |
| P09 | 9 | Tilly looked down at her own two feet.<br>She took one shaky breath, and one shaky step.<br>"It's okay, nice and slow, step by step, here I go." | 28✓ | — | — | — | — | — | — | ✓ | 【派生變體】零改動。疊句 golden 鎖定（顫抖版上下文）。 |
| P10 | 10 | Hops woke up with a jolt. He rubbed his eyes.<br>"WHAT?!" Way, way down the road — Tilly was almost at the finish line! | 23✓ | 7 | But Tilly didn't give up.<br>Hops woke up — and Tilly was almost at the finish line! | 16✓ | 5 | Tilly walked and walked.<br>Hops woke up— | 7✓ | ✓ | 【派生變體】零改動。jolt/rubbed＝共用詞。 |
| P11 | 11 | Hops ran as fast as he could!<br>But Tilly was already at the finish line — one step away.<br>Her foot lifted… about to come down— | 25✓ | 8 | Hops ran as fast as he could!<br>But Tilly's foot was right above the finish line— | 16✓ | 6 | Tilly was almost there! Hops ran and ran!<br>Her foot— | 10✓ | ✓ | 【派生變體】零改動。 |
| P12 | 12 | Tilly stepped across the finish line.<br>She stood very still. Quiet and steady.<br>"It's okay, nice and slow, step by step, here I go." | 24✓ | 9 | Tilly stepped across the finish line.<br>"It's okay, nice and slow, step by step, here I go." | 17✓ | 7 | Tilly made it!<br>"It's okay, nice and slow, step by step, here I go." | 14✓ | ✓ | 【派生變體】零改動。疊句 golden 鎖定（平靜篤定版）。 |
| P13 | 13 | "Tilly wins!" announced Judge Owl.<br>Hops ran up, panting and puffing. "You… you're amazing," he said.<br>Tilly smiled. "Want to walk together?" | 22✓ | 10 | "Tilly wins!" said Judge Owl.<br>Hops said, "You… you're amazing."<br>Tilly said, "Want to walk together?" | 16✓ | 8 | "Tilly wins!"<br>"You're amazing!"<br>"Walk together?" | 6✓ | ✓ | 【派生變體】零改動。amazing＝共用詞（非 awesome＝US 讚語標記）。panting/puffing＝共用詞。 |
| P14 | 14 | "I won't laugh at anyone for being slow again," said Hops. "I want to walk with you, Tilly!"<br>And from that day on, Tilly and Hops walked together. Not to see who was fastest — but who could smile the most. | 40✓ | 11 | "I won't laugh at anyone for being slow again," said Hops. "I want to walk with you!"<br>And from that day on, Tilly and Hops walked together. Not to see who was fastest — but who could smile the most. | 39⚠ | 9 | And from that day on, Tilly and Hops walked together. | 10✓ | ✓ | 【派生變體】零改動。5-6/3-5 ⚠理由同 en-US：frozen ending formula＋forward intention statement 同頁不可拆。收束式 golden 鎖定。 |

<!-- 【派生變體產出】text/en-GB/{5-6,3-5,2-3}.draft.json：與 en-US 定稿逐字一致（零改動）。
     draft → 定稿 rename 歸 QA 收斂＋關卡放行（content/README.md 契約 1），本 skill 不做。 -->

## 2. BrE 分歧校報告

### 掃描靶區與結果

| 靶區 | 掃描結果 | 說明 |
|---|---|---|
| US-only 拼寫（-ize/-or/-er/單L/gray/cozy/pajamas） | 零命中 | 底本無觸發詞 |
| US-only 詞彙（en-GB spec 第 3 段對照表 + banned_terms） | 零命中 | 無 mom/cookie/candy/trash/sidewalk/closet/gotten/sweater 等 |
| US 句構標記（gotten/come+bare inf/"Do you got"） | 零命中 | "got bored"(P04)＝BrE 合法 simple past |
| US 讚語標記（awesome/Good job） | 零命中 | "amazing"(P13)＝共用詞，非 US 標記 |
| US 文化物件（Thanksgiving/dollar/mailbox/Grade N） | 零命中 | 龜兔賽跑題材無文化物件 |
| 稱謂系統（Mom/Mommy） | 零命中 | 無家長角色 |
| Oxford comma | 零命中 | 底本無串列結構（三項以上逗號列舉） |
| 標點（引號/刪節號/破折號） | 符合 | 雙引號 U+0022 + 刪節號 U+2026 + 直式 apostrophe U+0027＝與 en-GB spec 一致 |
| come/go+bare infinitive (S2.4) | 零命中 | 無此句構 |

### 考量但不改的項目

| 項目 | 位置 | 考量 | 決定 |
|---|---|---|---|
| leaped → leapt | 5-6 P04 | BrE 偏好 leapt，但 leaped 在 BrE 非硬違規（兩形皆合法） | 保留 leaped，維持底本一致性；en-GB spec banned_terms 未列 leaped |
| belly → tummy | 5-6 P06 | BrE 兒語有時偏好 tummy，但 belly 在 BrE 完全合法且為標準詞 | 保留 belly，非分歧詞 |
