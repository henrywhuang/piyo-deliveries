# 關卡4整合審閱：龜兔賽跑（S4 證據包／en-GB）

- 生成時間：2026-07-22 11:21:54 +0800
- 書目錄：`content/PYO-002_the-tortoise-and-the-hare`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：en-GB
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-002_storyboard.md` | 2026-07-21 17:08:45 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-21 17:08:45 |
| text/en-GB/5-6 | `text/en-GB/5-6.draft.json` | 2026-07-21 22:26:12 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-21 17:08:45 |
| text/en-GB/3-5 | `text/en-GB/3-5.draft.json` | 2026-07-21 22:26:20 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-21 17:08:45 |
| text/en-GB/2-3 | `text/en-GB/2-3.draft.json` | 2026-07-21 22:26:25 |
| qa/en-GB/backtranslation.md | （缺） | — |
| qa/en-GB round | `qa/en-GB/round1.md` | 2026-07-22 11:20:51 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | en-GB 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 14 | 14 頁有文 | 14 頁有文 | 0/14 | 0 |
| 3-5 | 11 | 11 頁有文 | 11 頁有文 | 0/11 | 0 |
| 2-3 | 9 | 9 頁有文 | 9 頁有文 | 0/9 | 0 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | en-GB 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 跳跳兔大聲笑著說：「哈哈哈！你走路好慢喔！要不要比賽跑步？」／慢慢龜握了握拳，小聲回答：「好…… 比就比。」 | Hops pointed and laughed. "Ha ha ha! You're SO slow! I bet you can't even finish a race!"／Tilly took a deep breath. "Okay… you're on." | （缺） | — |
| P02 | P02 | 貓頭鷹裁判揮旗：「預備——跑！」／咻！／跳跳兔一下子就跑得不見了。／慢慢龜還站在起跑線上，一步都沒跨出去。 | "Ready… set… GO!" called Judge Owl.／ZOOM! Hops shot off like a rocket.／Tilly was still at the starting line. She hadn't moved a single step. | （缺） | — |
| P03 | P03 | 慢慢龜在小路上一步一步往前走。／她小聲對自己說：「沒關係，慢慢走，一步一步，不要停。」 | Tilly walked along the path, one little step at a time.／She whispered to herself, "It's okay, nice and slow, step by step, here I go." | （缺） | — |
| P04 | P04 | 跳跳兔跑太遠了，覺得好無聊。／「哇！蝴蝶！」／蹦！蹦！／他衝進花田追呀追。／蝴蝶停在他鼻尖上，他一點也不知道。 | Hops was so far ahead, he got bored.／"Ooh! A butterfly!"／Boing! Boing!／He leaped into the flowers, chasing and tumbling.／The butterfly landed right on his nose — and Hops didn't even notice. | （缺） | — |
| P05 | P05 | 慢慢龜爬呀爬，終於爬到坡頂。／可是前面還有好長好長的路。／她的腳步…… 慢了下來。 | Tilly reached the top of the hill. The road ahead stretched on and on and on.／Her feet… slowed… down— | （缺） | — |
| P06 | P06 | 呼嚕呼嚕……／跳跳兔在大樹蔭下睡得好熟好熟，蝴蝶在他肚皮上歇腳。／他一點也不知道。 | Zzzzzzz.／Hops lay flat on his back under the big tree, mouth wide open.／A butterfly rested on his belly, and he didn't know a thing. | （缺） | — |
| P07 | P07 | 太陽好大好大，路上熱得發燙。／沙沙沙…… 沙沙沙……／慢慢龜的腳步越來越輕，可是她沒有停。 | The sun beat down, hot and harsh.／scuff, scuff, scuff.／Tilly's steps got slower and softer — but she didn't stop. | （缺） | — |
| P08 | P08 | 慢慢龜的腳步，停了。／好累好累…… 她快要撐不住了。／慢慢龜…… 她要放棄了嗎？ | Tilly's feet stopped.／She was so tired… so tired she could barely hold on.／Was she going to give up? | （缺） | — |
| P09 | P09 | 慢慢龜看著自己的腳。／她深深吸了一口氣，顫抖著踏出一步。／「沒關係，慢慢走，一步一步，不要停。」 | Tilly looked down at her own two feet.／She took one shaky breath, and one shaky step.／"It's okay, nice and slow, step by step, here I go." | （缺） | — |
| P10 | P10 | 跳跳兔猛然醒過來，揉揉眼睛。／「啊！」他看見遠遠的地方——慢慢龜快到終點了！ | Hops woke up with a jolt. He rubbed his eyes.／"WHAT?!" Way, way down the road — Tilly was almost at the finish line! | （缺） | — |
| P11 | P11 | 跳跳兔拔腿狂追！／可是慢慢龜已經到了終點線前面。／她的腳，正要踩下去—— | Hops ran as fast as he could!／But Tilly was already at the finish line — one step away.／Her foot lifted… about to come down— | （缺） | — |
| P12 | P12 | 慢慢龜的腳，踩過了終點線。／她停下來，輕輕地說：／「沒關係，慢慢走，一步一步，不要停。」 | Tilly stepped across the finish line.／She stood very still. Quiet and steady.／"It's okay, nice and slow, step by step, here I go." | （缺） | — |
| P13 | P13 | 貓頭鷹宣布：「慢慢龜贏了！」／跳跳兔喘著氣跑到，愣住了：「你…… 好厲害喔。」／慢慢龜笑了笑，伸出手：「一起走吧！」 | "Tilly wins!" announced Judge Owl.／Hops ran up, panting and puffing. "You… you're amazing," he said.／Tilly smiled. "Want to walk together?" | （缺） | — |
| P14 | P14 | 跳跳兔認真地說：「以後我再也不笑別人慢了，我要跟慢慢龜一起走！」／後來呀，慢慢龜和跳跳兔常常一起散步——不比快慢，只比誰笑得最多。 | "I won't laugh at anyone for being slow again," said Hops. "I want to walk with you, Tilly!"／And from that day on, Tilly and Hops walked together. Not to see who was fastest — but who could smile the most. | （缺） | — |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | en-GB 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 跳跳兔笑著說：「你走路好慢喔！來比賽吧！」／慢慢龜說：「好…… 比就比。」 | Hops laughed. "Ha ha ha! You're SO slow! Want to race?"／Tilly said, "Okay… you're on." | （缺） | — |
| P02 | P02 | 「預備——跑！」／咻！／跳跳兔一下子就不見了。／慢慢龜還站在起跑線上。 | "Ready… set… GO!" called Judge Owl.／ZOOM! Hops was gone.／Tilly was still at the starting line. | （缺） | — |
| P03 | P03 | 沙沙沙…… 慢慢龜一步一步往前走。／「沒關係，慢慢走，一步一步，不要停。」 | scuff, scuff, scuff. Tilly walked, one step at a time.／"It's okay, nice and slow, step by step, here I go." | （缺） | — |
| P04 | P05 | 慢慢龜爬到坡頂，前面還有好長好長的路。／她的腳步…… 慢了下來。 | Tilly reached the top of the hill. The road ahead went on and on.／Her feet… slowed… down— | （缺） | — |
| P05 | P06 | 呼嚕呼嚕……／跳跳兔在大樹下睡得好熟好熟。／他一點也不知道。 | Zzzzzzz.／Hops lay under the big tree, flat on his back, sound asleep.／He didn't know a thing. | （缺） | — |
| P06 | P08 | 太陽好大好大…… 慢慢龜走了好久。／她的腳步，停了。／她…… 要放棄了嗎？ | The sun got hotter and hotter… Tilly walked for a long, long time.／Her feet stopped. Was she going to give up? | （缺） | — |
| P07 | P10 | 可是慢慢龜沒有放棄。／跳跳兔醒來了——慢慢龜快到終點了！ | But Tilly didn't give up.／Hops woke up — and Tilly was almost at the finish line! | （缺） | — |
| P08 | P11 | 跳跳兔拔腿狂追！／可是慢慢龜的腳，正要踩過終點線—— | Hops ran as fast as he could!／But Tilly's foot was right above the finish line— | （缺） | — |
| P09 | P12 | 慢慢龜踩過了終點線。／「沒關係，慢慢走，一步一步，不要停。」 | Tilly stepped across the finish line.／"It's okay, nice and slow, step by step, here I go." | （缺） | — |
| P10 | P13 | 「慢慢龜贏了！」／跳跳兔說：「你…… 好厲害喔。」／慢慢龜說：「一起走吧！」 | "Tilly wins!" said Judge Owl.／Hops said, "You… you're amazing."／Tilly said, "Want to walk together?" | （缺） | — |
| P11 | P14 | 跳跳兔說：「以後我再也不笑別人慢了，我要跟慢慢龜一起走！」／後來呀，慢慢龜和跳跳兔常常一起散步——不比快慢，只比誰笑得最多。 | "I won't laugh at anyone for being slow again," said Hops. "I want to walk with you!"／And from that day on, Tilly and Hops walked together. Not to see who was fastest — but who could smile the most. | （缺） | — |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | en-GB 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 跳跳兔說：「我跑得比較快喔！比比看？」／慢慢龜說：「好！」 | "I'm fast! Race me?"／"Okay!" | （缺） | — |
| P02 | P02 | 咻！／跳跳兔跑得好快好快！／慢慢龜慢慢走。 | ZOOM!／Hops ran so, so fast!／Tilly walked slow. | （缺） | — |
| P03 | P03 | 沙沙沙…… 慢慢龜走呀走。／「沒關係，慢慢走，一步一步，不要停。」 | scuff, scuff, scuff.／"It's okay, nice and slow, step by step, here I go." | （缺） | — |
| P04 | P06 | 呼嚕呼嚕……／跳跳兔在大樹下睡著了！ | Zzzzzzz.／Hops fell asleep under the big tree! | （缺） | — |
| P05 | P10 | 慢慢龜一直走呀走。／跳跳兔醒來了—— | Tilly walked and walked.／Hops woke up— | （缺） | — |
| P06 | P11 | 慢慢龜快到了！跳跳兔追呀追！／慢慢龜的腳，要踩過去了—— | Tilly was almost there! Hops ran and ran!／Her foot— | （缺） | — |
| P07 | P12 | 慢慢龜到了！／「沒關係，慢慢走，一步一步，不要停。」 | Tilly made it!／"It's okay, nice and slow, step by step, here I go." | （缺） | — |
| P08 | P13 | 「慢慢龜贏了！」／跳跳兔說：「好厲害！」／慢慢龜說：「一起走！」 | "Tilly wins!"／"You're amazing!"／"Walk together?" | （缺） | — |
| P09 | P14 | 後來呀，慢慢龜和跳跳兔常常一起散步——不比快慢，只比誰笑得最多。 | And from that day on, Tilly and Hops walked together. | （缺） | — |

（缺）回譯檔：找不到 `content/PYO-002_the-tortoise-and-the-hare/qa/en-GB/backtranslation.md`

## 三、QA 摘要（qa/en-GB）

- `qa/en-GB/round1.md`：round 1／verdict escalated

最新 round：`qa/en-GB/round1.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: the-tortoise-and-the-hare
locale: en-GB
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: 2026-07-22
step1_lint:
  exit_code: 1
  warnings: 6
step2_checklist:
  pass: 12
  fail: 0
step3_personas:
  - id: en-GB-teacher
    scores:
      年齡適配度: 8
      英式語感: 8
      孩子抓得住度: 8
  - id: en-GB-parent
    scores:
      睡前適讀性: 9
      零說教: 9
  - id: en-GB-editor
    scores:
      母語自然度: 9
      文字工藝: 9
step4_triage:
  real: 0
  rejected: 0
  escalated: 1
verdict: escalated
```

### ESL 獵手發現（原文引用）

### ESL 獵手報告（en-GB）

逐頁掃描三檔：
- **獵物①翻譯腔**：未發現明顯翻譯痕跡。改編文呈現目標語言母語自然感。
- **獵物② AI 機械句**：未發現 style_guide §3.4 四型（電報式裸動詞堆疊 / 成分懸空 / 超規律平行 / 無語氣詞乾句）。2-3 檔位的電報式短句屬 W7 合法語體，非 AI 機械句。

## 四、⏸️ 上呈批次

- （`qa/en-GB/round1.md`）所有 violations 為 frozen formula 結構性超限（golden 鎖定句式不可縮短），歸 STEP 4 ⏸️ 上呈。
- （`qa/en-GB/round1.md`）| E1 | STEP 1 機檢 | frozen refrain 11w>8 + ending formula 10w>8 (2-3 P03/P09/P12/P14, same as en-US gate4) | ⏸️ | — | frozen formula golden 鎖定，同 zh-TW gate3 + en-US gate4 先例 |
- （`qa/en-GB/round1.md`）✅ real = 0, ❌ rejected = 0, ⏸️ escalated = 1
- （`qa/en-GB/round1.md`）### ⏸️ 上呈項
- （`qa/en-GB/round1.md`）✅=0（無真問題回修），但有 ⏸️ 上呈項（frozen formula 結構性超限）。verdict = escalated（等同先例處理）。

