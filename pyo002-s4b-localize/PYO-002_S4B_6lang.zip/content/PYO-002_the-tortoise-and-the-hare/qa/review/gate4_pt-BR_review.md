# 關卡4整合審閱：龜兔賽跑（S4 證據包／pt-BR）

- 生成時間：2026-07-22 11:21:54 +0800
- 書目錄：`content/PYO-002_the-tortoise-and-the-hare`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：pt-BR
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-002_storyboard.md` | 2026-07-21 17:08:45 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-21 17:08:45 |
| text/pt-BR/5-6 | `text/pt-BR/5-6.draft.json` | 2026-07-21 22:29:31 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-21 17:08:45 |
| text/pt-BR/3-5 | `text/pt-BR/3-5.draft.json` | 2026-07-21 22:29:38 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-21 17:08:45 |
| text/pt-BR/2-3 | `text/pt-BR/2-3.draft.json` | 2026-07-21 22:29:42 |
| qa/pt-BR/backtranslation.md | `qa/pt-BR/backtranslation.md` | 2026-07-22 11:21:46 |
| qa/pt-BR round | `qa/pt-BR/round1.md` | 2026-07-22 11:20:51 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | pt-BR 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 14 | 14 頁有文 | 14 頁有文 | 8/14 | 0 |
| 3-5 | 11 | 11 頁有文 | 11 頁有文 | 7/11 | 0 |
| 2-3 | 9 | 9 頁有文 | 9 頁有文 | 5/9 | 0 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | pt-BR 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 跳跳兔大聲笑著說：「哈哈哈！你走路好慢喔！要不要比賽跑步？」／慢慢龜握了握拳，小聲回答：「好…… 比就比。」 | Saltão apontou e deu risada.／— Ha ha ha! Que lenta! Aposto que nem consegue terminar uma corrida!／Lentinha respirou fundo.／— Tá bom… eu aceito. | 「我好快！賭一下？」「好！」→ 接受挑戰 | 無 |
| P02 | P02 | 貓頭鷹裁判揮旗：「預備——跑！」／咻！／跳跳兔一下子就跑得不見了。／慢慢龜還站在起跑線上，一步都沒跨出去。 | — Preparar… apontar… JÁ! — gritou Juiz Coruja.／ZUUUM! Saltão saiu feito um foguete.／Lentinha ainda estava na linha de partida. Nem um passinho. | （缺） | — |
| P03 | P03 | 慢慢龜在小路上一步一步往前走。／她小聲對自己說：「沒關係，慢慢走，一步一步，不要停。」 | tec, tec, tec.／Lentinha ia andando pela trilha, um passinho de cada vez.／Baixinho, falou pra si mesma:／— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | 嗒嗒嗒。Lentinha 一步一步走。「沒關係，慢慢地，一步一步，我繼續走。」→ 疊句首次 | 無 |
| P04 | P04 | 跳跳兔跑太遠了，覺得好無聊。／「哇！蝴蝶！」／蹦！蹦！／他衝進花田追呀追。／蝴蝶停在他鼻尖上，他一點也不知道。 | Saltão estava tão na frente que ficou entediado.／— Oba! Uma borboleta!／Boing! Boing!／Ele pulou no meio das flores, correndo atrás dela.／A borboleta pousou bem no nariz dele — e Saltão nem percebeu. | （缺） | — |
| P05 | P05 | 慢慢龜爬呀爬，終於爬到坡頂。／可是前面還有好長好長的路。／她的腳步…… 慢了下來。 | Lentinha chegou lá no alto da ladeira. A estrada ia longe, longe, longe.／Seus passos… foram… parando— | Lentinha 到坡頂。前方好長的路。腳步慢了……→ hook | 無 |
| P06 | P06 | 呼嚕呼嚕……／跳跳兔在大樹蔭下睡得好熟好熟，蝴蝶在他肚皮上歇腳。／他一點也不知道。 | Zzzzzzz.／Saltão estava deitado de barriga pra cima debaixo da árvore grandona, boca aberta.／Uma borboleta descansava na barriga dele, e ele nem sabia. | （缺） | — |
| P07 | P07 | 太陽好大好大，路上熱得發燙。／沙沙沙…… 沙沙沙……／慢慢龜的腳步越來越輕，可是她沒有停。 | O sol queimava, forte e sem piedade.／tec, tec, tec.／Os passos de Lentinha foram ficando mais lentos e mais baixinhos — mas ela não parou. | （缺） | — |
| P08 | P08 | 慢慢龜的腳步，停了。／好累好累…… 她快要撐不住了。／慢慢龜…… 她要放棄了嗎？ | Os pés de Lentinha pararam.／Estava tão cansada… tão cansada que mal conseguia se manter de pé.／Será que ela ia desistir? | 太陽越來越熱……走了好久好久。腳停了。要放棄嗎？→ hook | 無 |
| P09 | P09 | 慢慢龜看著自己的腳。／她深深吸了一口氣，顫抖著踏出一步。／「沒關係，慢慢走，一步一步，不要停。」 | Lentinha olhou pras próprias patinhas.／Respirou fundo, tremendo, e deu mais um passinho.／— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | Lentinha 看著自己的小腳。深呼吸，顫抖著再走一步。「沒關係，慢慢地……」→ 疊句第二次 | 無 |
| P10 | P10 | 跳跳兔猛然醒過來，揉揉眼睛。／「啊！」他看見遠遠的地方——慢慢龜快到終點了！ | Saltão acordou num susto. Esfregou os olhos.／— QUE?! Lá longe, bem longe — Lentinha já estava quase na linha de chegada! | （缺） | — |
| P11 | P11 | 跳跳兔拔腿狂追！／可是慢慢龜已經到了終點線前面。／她的腳，正要踩下去—— | Saltão correu o mais rápido que podia!／Mas Lentinha já estava na linha de chegada — faltava só um passinho.／Seu pé levantou… quase tocando o chão— | Saltão 全力衝刺！但 Lentinha 的腳已在終點線上——→ hook | 無 |
| P12 | P12 | 慢慢龜的腳，踩過了終點線。／她停下來，輕輕地說：／「沒關係，慢慢走，一步一步，不要停。」 | Lentinha cruzou a linha de chegada.／Ficou bem paradinha. Quieta e firme.／— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | Lentinha 過了終點！靜靜地站著。「沒關係，慢慢地，一步一步，我繼續走。」→ 疊句最終次 | 無 |
| P13 | P13 | 貓頭鷹宣布：「慢慢龜贏了！」／跳跳兔喘著氣跑到，愣住了：「你…… 好厲害喔。」／慢慢龜笑了笑，伸出手：「一起走吧！」 | — Lentinha venceu! — anunciou Juiz Coruja.／Saltão chegou ofegante.／— Você… você é incrível — disse ele.／Lentinha sorriu.／— Quer andar junto comigo? | （缺） | — |
| P14 | P14 | 跳跳兔認真地說：「以後我再也不笑別人慢了，我要跟慢慢龜一起走！」／後來呀，慢慢龜和跳跳兔常常一起散步——不比快慢，只比誰笑得最多。 | — Eu nunca mais vou rir de ninguém por ser devagar — disse Saltão. — Eu quero andar com você, Lentinha!／E daquele dia em diante, Lentinha e Saltão andavam sempre juntos. Não pra ver quem era mais rápido — mas quem conseguia dar mais risada. | 「我再也不笑別人慢了」Saltão 說。「想跟你一起走！」從那天開始一起散步——不比快慢，比誰笑得多。→ 收束式 | 無 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | pt-BR 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 跳跳兔笑著說：「你走路好慢喔！來比賽吧！」／慢慢龜說：「好…… 比就比。」 | Saltão deu risada.／— Ha ha ha! Que lenta! Quer correr comigo?／— Tá bom… eu aceito. | 「我好快！賭一下？」「好！」→ 接受挑戰 | 無 |
| P02 | P02 | 「預備——跑！」／咻！／跳跳兔一下子就不見了。／慢慢龜還站在起跑線上。 | — Preparar… apontar… JÁ! — gritou Juiz Coruja.／ZUUUM! Saltão sumiu.／Lentinha ainda estava na linha de partida. | （缺） | — |
| P03 | P03 | 沙沙沙…… 慢慢龜一步一步往前走。／「沒關係，慢慢走，一步一步，不要停。」 | tec, tec, tec. Lentinha andava, um passinho de cada vez.／— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | 嗒嗒嗒。Lentinha 一步一步走。「沒關係，慢慢地，一步一步，我繼續走。」→ 疊句首次 | 無 |
| P04 | P05 | 慢慢龜爬到坡頂，前面還有好長好長的路。／她的腳步…… 慢了下來。 | Lentinha chegou lá no alto. A estrada ia longe, longe.／Seus passos… foram… parando— | （缺） | — |
| P05 | P06 | 呼嚕呼嚕……／跳跳兔在大樹下睡得好熟好熟。／他一點也不知道。 | Lentinha chegou lá no alto. A estrada ia longe, longe.／Seus passos… foram… parando— | Lentinha 到坡頂。前方好長的路。腳步慢了……→ hook | 無 |
| P06 | P08 | 太陽好大好大…… 慢慢龜走了好久。／她的腳步，停了。／她…… 要放棄了嗎？ | Zzzzzzz.／Saltão estava debaixo da árvore grandona, deitado de barriga pra cima.／Não sabia de nada. | （缺） | — |
| P07 | P10 | 可是慢慢龜沒有放棄。／跳跳兔醒來了——慢慢龜快到終點了！ | Mas Lentinha não desistiu.／Saltão acordou — e Lentinha já estava quase na linha de chegada! | （缺） | — |
| P08 | P11 | 跳跳兔拔腿狂追！／可是慢慢龜的腳，正要踩過終點線—— | O sol foi ficando cada vez mais quente… Lentinha andou muito, muito tempo.／Seus pés pararam. Será que ela ia desistir? | 太陽越來越熱……走了好久好久。腳停了。要放棄嗎？→ hook | 無 |
| P09 | P12 | 慢慢龜踩過了終點線。／「沒關係，慢慢走，一步一步，不要停。」 | Lentinha cruzou a linha de chegada.／— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | （缺） | — |
| P10 | P13 | 「慢慢龜贏了！」／跳跳兔說：「你…… 好厲害喔。」／慢慢龜說：「一起走吧！」 | Mas Lentinha não desistiu.／Saltão acordou — e Lentinha já estava quase na linha de chegada! | （缺） | — |
| P11 | P14 | 跳跳兔說：「以後我再也不笑別人慢了，我要跟慢慢龜一起走！」／後來呀，慢慢龜和跳跳兔常常一起散步——不比快慢，只比誰笑得最多。 | Saltão correu o mais rápido que podia!／Mas o pé de Lentinha já estava bem em cima da linha de chegada— | Saltão 全力衝刺！但 Lentinha 的腳已在終點線上——→ hook | 無 |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | pt-BR 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 跳跳兔說：「我跑得比較快喔！比比看？」／慢慢龜說：「好！」 | — Sou rápido! Quer apostar?／— Tá bom! | 「我好快！賭一下？」「好！」→ 接受挑戰 | 無 |
| P02 | P02 | 咻！／跳跳兔跑得好快好快！／慢慢龜慢慢走。 | ZUUUM!／Saltão saiu bem rápido!／Lentinha andou devagar. | （缺） | — |
| P03 | P03 | 沙沙沙…… 慢慢龜走呀走。／「沒關係，慢慢走，一步一步，不要停。」 | tec, tec, tec.／— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | 嗒嗒嗒。Lentinha 一步一步走。「沒關係，慢慢地，一步一步，我繼續走。」→ 疊句首次 | 無 |
| P04 | P06 | 呼嚕呼嚕……／跳跳兔在大樹下睡著了！ | Zzzzzzz.／Saltão dormiu debaixo da árvore! | （缺） | — |
| P05 | P10 | 慢慢龜一直走呀走。／跳跳兔醒來了—— | Lentinha andou e andou.／Saltão acordou— | （缺） | — |
| P06 | P11 | 慢慢龜快到了！跳跳兔追呀追！／慢慢龜的腳，要踩過去了—— | Zzzzzzz.／Saltão dormiu debaixo da árvore! | （缺） | — |
| P07 | P12 | 慢慢龜到了！／「沒關係，慢慢走，一步一步，不要停。」 | Lentinha conseguiu!／— Tudo bem, devagarinho, passo a passo, eu vou seguindo. | （缺） | — |
| P08 | P13 | 「慢慢龜贏了！」／跳跳兔說：「好厲害！」／慢慢龜說：「一起走！」 | — Lentinha venceu!／— Você é incrível!／— Andar junto? | （缺） | — |
| P09 | P14 | 後來呀，慢慢龜和跳跳兔常常一起散步——不比快慢，只比誰笑得最多。 | E daquele dia em diante, Lentinha e Saltão andavam sempre juntos. | （缺） | — |

## 三、QA 摘要（qa/pt-BR）

- `qa/pt-BR/round1.md`：round 1／verdict escalated

最新 round：`qa/pt-BR/round1.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: the-tortoise-and-the-hare
locale: pt-BR
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: 2026-07-22
step1_lint:
  exit_code: 1
  warnings: 7
step2_checklist:
  pass: 12
  fail: 0
step3_personas:
  - id: pt-BR-professora
    scores:
      年齡適配度: 8
      巴西語感: 8
      孩子抓得住度: 8
  - id: pt-BR-mae
    scores:
      睡前適讀性: 8
      零說教: 9
  - id: pt-BR-editora
    scores:
      母語自然度: 8
      文字工藝: 8
step4_triage:
  real: 0
  rejected: 0
  escalated: 1
verdict: escalated
```

### ESL 獵手發現（原文引用）

### ESL 獵手報告（pt-BR）

逐頁掃描三檔：
- **獵物①翻譯腔**：未發現明顯翻譯痕跡。改編文呈現目標語言母語自然感。
- **獵物② AI 機械句**：未發現 style_guide §3.4 四型（電報式裸動詞堆疊 / 成分懸空 / 超規律平行 / 無語氣詞乾句）。2-3 檔位的電報式短句屬 W7 合法語體，非 AI 機械句。

## 四、⏸️ 上呈批次

- （`qa/pt-BR/round1.md`）所有 violations 為 frozen formula 結構性超限（golden 鎖定句式不可縮短），歸 STEP 4 ⏸️ 上呈。
- （`qa/pt-BR/round1.md`）| E1 | STEP 1 機檢 | frozen ending formula 11>9 max_sentence_len (2-3 P14) | ⏸️ | — | frozen formula golden 鎖定，同 zh-TW gate3 + en-US gate4 先例 |
- （`qa/pt-BR/round1.md`）✅ real = 0, ❌ rejected = 0, ⏸️ escalated = 1
- （`qa/pt-BR/round1.md`）### ⏸️ 上呈項
- （`qa/pt-BR/round1.md`）✅=0（無真問題回修），但有 ⏸️ 上呈項（frozen formula 結構性超限）。verdict = escalated（等同先例處理）。

