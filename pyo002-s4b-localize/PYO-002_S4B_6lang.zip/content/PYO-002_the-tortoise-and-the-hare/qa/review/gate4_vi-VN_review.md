# 關卡4整合審閱：龜兔賽跑（S4 證據包／vi-VN）

- 生成時間：2026-07-22 11:21:54 +0800
- 書目錄：`content/PYO-002_the-tortoise-and-the-hare`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：vi-VN
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-002_storyboard.md` | 2026-07-21 17:08:45 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-21 17:08:45 |
| text/vi-VN/5-6 | `text/vi-VN/5-6.draft.json` | 2026-07-21 22:47:31 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-21 17:08:45 |
| text/vi-VN/3-5 | `text/vi-VN/3-5.draft.json` | 2026-07-21 22:47:51 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-21 17:08:45 |
| text/vi-VN/2-3 | `text/vi-VN/2-3.draft.json` | 2026-07-21 22:49:28 |
| qa/vi-VN/backtranslation.md | `qa/vi-VN/backtranslation.md` | 2026-07-22 11:21:46 |
| qa/vi-VN round | `qa/vi-VN/round1.md` | 2026-07-22 11:20:51 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | vi-VN 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 14 | 14 頁有文 | 14 頁有文 | 8/14 | 0 |
| 3-5 | 11 | 11 頁有文 | 11 頁有文 | 7/11 | 0 |
| 2-3 | 9 | 9 頁有文 | 9 頁有文 | 5/9 | 0 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | vi-VN 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 跳跳兔大聲笑著說：「哈哈哈！你走路好慢喔！要不要比賽跑步？」／慢慢龜握了握拳，小聲回答：「好…… 比就比。」 | Thỏ Nhanh chỉ tay cười phá lên. "Ha ha ha! Chậm ơi là chậm! Dám chạy thi với tớ không?"／Rùa Nhỏ hít một hơi thật sâu. "Được… thi thì thi." | 「我快lắm！比chạy nhé？」「Được！」→ 接受挑戰 | 無 |
| P02 | P02 | 貓頭鷹裁判揮旗：「預備——跑！」／咻！／跳跳兔一下子就跑得不見了。／慢慢龜還站在起跑線上，一步都沒跨出去。 | "Sẵn sàng… Chạy!" Cú Mèo Trọng Tài vẫy cờ.／Vèo! Thỏ Nhanh lao đi như gió.／Rùa Nhỏ vẫn còn đứng ở vạch xuất phát. Chưa bước nổi một bước nào. | （缺） | — |
| P03 | P03 | 慢慢龜在小路上一步一步往前走。／她小聲對自己說：「沒關係，慢慢走，一步一步，不要停。」 | Rùa Nhỏ một mình đi trên con đường nhỏ, từng bước chậm rãi.／Rùa Nhỏ thì thầm với chính mình: "Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | 嗦嗦。Rùa Nhỏ 一個人走。自言自語「沒關係，走吧，一步一步，別停下。」→ 疊句首次 | 無 |
| P04 | P04 | 跳跳兔跑太遠了，覺得好無聊。／「哇！蝴蝶！」／蹦！蹦！／他衝進花田追呀追。／蝴蝶停在他鼻尖上，他一點也不知道。 | Thỏ Nhanh chạy nhanh quá, chán quá rồi.／"Ôi! Bướm kìa!"／Nhảy! Nhảy!／Thỏ Nhanh nhảy tung tăng vào vườn hoa, đuổi theo con bướm.／Con bướm đậu ngay trên mũi — mà Thỏ Nhanh chẳng hay biết gì. | （缺） | — |
| P05 | P05 | 慢慢龜爬呀爬，終於爬到坡頂。／可是前面還有好長好長的路。／她的腳步…… 慢了下來。 | Rùa Nhỏ leo lên tới đỉnh dốc. Con đường phía trước dài thăm thẳm.／Bước chân Rùa Nhỏ… chậm… dần… lại— | Rùa Nhỏ 到坡頂。前方好長的路。腳步慢了……→ hook | 無 |
| P06 | P06 | 呼嚕呼嚕……／跳跳兔在大樹蔭下睡得好熟好熟，蝴蝶在他肚皮上歇腳。／他一點也不知道。 | Khò khò khò…／Thỏ Nhanh nằm ngửa dưới gốc cây to, chân tay dang rộng, miệng há hốc.／Con bướm đậu trên bụng — mà Thỏ Nhanh chẳng biết gì hết. | （缺） | — |
| P07 | P07 | 太陽好大好大，路上熱得發燙。／沙沙沙…… 沙沙沙……／慢慢龜的腳步越來越輕，可是她沒有停。 | Nắng nóng gay gắt, không một bóng cây.／sột soạt, sột soạt.／Bước chân Rùa Nhỏ chậm dần, nhẹ dần — nhưng không dừng lại. | （缺） | — |
| P08 | P08 | 慢慢龜的腳步，停了。／好累好累…… 她快要撐不住了。／慢慢龜…… 她要放棄了嗎？ | Bước chân Rùa Nhỏ dừng lại.／Mệt quá rồi… mệt đến mức muốn bỏ cuộc.／Rùa Nhỏ có bỏ cuộc không? | 太陽好燙。走了好久好久。腳停了。要放棄嗎？→ hook | 無 |
| P09 | P09 | 慢慢龜看著自己的腳。／她深深吸了一口氣，顫抖著踏出一步。／「沒關係，慢慢走，一步一步，不要停。」 | Rùa Nhỏ nhìn xuống đôi chân mình.／Hít một hơi thật sâu, run run bước thêm một bước.／"Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | Rùa Nhỏ 看著自己的腳。深吸一口氣，顫抖著踏一步。「沒關係，走吧……」→ 疊句第二次 | 無 |
| P10 | P10 | 跳跳兔猛然醒過來，揉揉眼睛。／「啊！」他看見遠遠的地方——慢慢龜快到終點了！ | Thỏ Nhanh giật mình tỉnh dậy, dụi mắt.／"CÁI GÌ?!" Ở tít xa xa — Rùa Nhỏ đã gần tới đích rồi! | （缺） | — |
| P11 | P11 | 跳跳兔拔腿狂追！／可是慢慢龜已經到了終點線前面。／她的腳，正要踩下去—— | Thỏ Nhanh chạy hết sức!／Nhưng Rùa Nhỏ đã đứng ngay trước vạch đích — chỉ còn một bước nữa thôi.／Bàn chân nhấc lên… sắp đặt xuống— | Thỏ Nhanh 全力衝刺！但 Rùa Nhỏ 快到了——→ hook | 無 |
| P12 | P12 | 慢慢龜的腳，踩過了終點線。／她停下來，輕輕地說：／「沒關係，慢慢走，一步一步，不要停。」 | Rùa Nhỏ bước qua vạch đích.／Rùa Nhỏ đứng yên. Bình tĩnh và vững vàng.／"Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | Rùa Nhỏ 到了！靜靜地站著。「沒關係，走吧，一步一步，別停下。」→ 疊句最終次 | 無 |
| P13 | P13 | 貓頭鷹宣布：「慢慢龜贏了！」／跳跳兔喘著氣跑到，愣住了：「你…… 好厲害喔。」／慢慢龜笑了笑，伸出手：「一起走吧！」 | "Rùa Nhỏ thắng rồi!" Cú Mèo Trọng Tài tuyên bố.／Thỏ Nhanh chạy tới, thở hổn hển. "Bạn… bạn giỏi quá," Thỏ Nhanh nói.／Rùa Nhỏ mỉm cười. "Đi cùng nhau nhé?" | （缺） | — |
| P14 | P14 | 跳跳兔認真地說：「以後我再也不笑別人慢了，我要跟慢慢龜一起走！」／後來呀，慢慢龜和跳跳兔常常一起散步——不比快慢，只比誰笑得最多。 | "Tớ sẽ không bao giờ cười ai chậm nữa," Thỏ Nhanh nói. "Tớ muốn đi cùng Rùa Nhỏ!"／Từ ngày ấy, Rùa Nhỏ và Thỏ Nhanh luôn đi cùng nhau. Không phải để xem ai nhanh hơn — mà xem ai cười nhiều hơn. | 「我再也不笑別人慢了」Thỏ Nhanh 說。「想跟 Rùa Nhỏ 一起走！」從那天起一起走——不比快慢，比誰笑得多。→ 收束式 | 無 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | vi-VN 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 跳跳兔笑著說：「你走路好慢喔！來比賽吧！」／慢慢龜說：「好…… 比就比。」 | Thỏ Nhanh cười lớn. "Ha ha ha! Chậm thế! Chạy thi nhé?"／Rùa Nhỏ nói khẽ: "Được… thi thì thi." | 「我快lắm！比chạy nhé？」「Được！」→ 接受挑戰 | 無 |
| P02 | P02 | 「預備——跑！」／咻！／跳跳兔一下子就不見了。／慢慢龜還站在起跑線上。 | "Sẵn sàng… Chạy!" Cú Mèo vẫy cờ.／Vèo! Thỏ Nhanh mất hút.／Rùa Nhỏ vẫn đứng yên ở vạch xuất phát. | （缺） | — |
| P03 | P03 | 沙沙沙…… 慢慢龜一步一步往前走。／「沒關係，慢慢走，一步一步，不要停。」 | sột soạt, sột soạt. Rùa Nhỏ đi từng bước từng bước.／"Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | 嗦嗦。Rùa Nhỏ 一個人走。自言自語「沒關係，走吧，一步一步，別停下。」→ 疊句首次 | 無 |
| P04 | P05 | 慢慢龜爬到坡頂，前面還有好長好長的路。／她的腳步…… 慢了下來。 | Rùa Nhỏ leo tới đỉnh dốc. Con đường phía trước còn dài lắm.／Bước chân… chậm… dần… lại— | （缺） | — |
| P05 | P06 | 呼嚕呼嚕……／跳跳兔在大樹下睡得好熟好熟。／他一點也不知道。 | Rùa Nhỏ leo tới đỉnh dốc. Con đường phía trước còn dài lắm.／Bước chân… chậm… dần… lại— | Rùa Nhỏ 到坡頂。前方好長的路。腳步慢了……→ hook | 無 |
| P06 | P08 | 太陽好大好大…… 慢慢龜走了好久。／她的腳步，停了。／她…… 要放棄了嗎？ | Khò khò khò…／Thỏ Nhanh nằm ngửa dưới gốc cây to, ngủ say như chết.／Chẳng biết gì hết. | （缺） | — |
| P07 | P10 | 可是慢慢龜沒有放棄。／跳跳兔醒來了——慢慢龜快到終點了！ | Nhưng Rùa Nhỏ không bỏ cuộc.／Thỏ Nhanh tỉnh dậy — Rùa Nhỏ đã gần tới đích rồi! | （缺） | — |
| P08 | P11 | 跳跳兔拔腿狂追！／可是慢慢龜的腳，正要踩過終點線—— | Nắng mỗi lúc một nóng hơn… Rùa Nhỏ đi đã lâu lắm rồi.／Bước chân dừng lại. Rùa Nhỏ có bỏ cuộc không? | 太陽好燙。走了好久好久。腳停了。要放棄嗎？→ hook | 無 |
| P09 | P12 | 慢慢龜踩過了終點線。／「沒關係，慢慢走，一步一步，不要停。」 | Rùa Nhỏ bước qua vạch đích.／"Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | （缺） | — |
| P10 | P13 | 「慢慢龜贏了！」／跳跳兔說：「你…… 好厲害喔。」／慢慢龜說：「一起走吧！」 | Nhưng Rùa Nhỏ không bỏ cuộc.／Thỏ Nhanh tỉnh dậy — Rùa Nhỏ đã gần tới đích rồi! | （缺） | — |
| P11 | P14 | 跳跳兔說：「以後我再也不笑別人慢了，我要跟慢慢龜一起走！」／後來呀，慢慢龜和跳跳兔常常一起散步——不比快慢，只比誰笑得最多。 | Thỏ Nhanh chạy hết sức!／Nhưng bàn chân Rùa Nhỏ đã ở ngay trên vạch đích— | Thỏ Nhanh 全力衝刺！但 Rùa Nhỏ 快到了——→ hook | 無 |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | vi-VN 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 跳跳兔說：「我跑得比較快喔！比比看？」／慢慢龜說：「好！」 | "Tớ nhanh lắm! Thi chạy nhé?"／"Được!" | 「我快lắm！比chạy nhé？」「Được！」→ 接受挑戰 | 無 |
| P02 | P02 | 咻！／跳跳兔跑得好快好快！／慢慢龜慢慢走。 | Vèo!／Thỏ Nhanh chạy vù đi!／Rùa Nhỏ đi chậm thôi. | （缺） | — |
| P03 | P03 | 沙沙沙…… 慢慢龜走呀走。／「沒關係，慢慢走，一步一步，不要停。」 | sột soạt, sột soạt.／"Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | 嗦嗦。Rùa Nhỏ 一個人走。自言自語「沒關係，走吧，一步一步，別停下。」→ 疊句首次 | 無 |
| P04 | P06 | 呼嚕呼嚕……／跳跳兔在大樹下睡著了！ | Khò khò khò…／Thỏ Nhanh ngủ gục rồi! | （缺） | — |
| P05 | P10 | 慢慢龜一直走呀走。／跳跳兔醒來了—— | Rùa Nhỏ cứ đi mãi.／Thỏ Nhanh tỉnh dậy— | （缺） | — |
| P06 | P11 | 慢慢龜快到了！跳跳兔追呀追！／慢慢龜的腳，要踩過去了—— | Khò khò khò…／Thỏ Nhanh ngủ gục rồi! | （缺） | — |
| P07 | P12 | 慢慢龜到了！／「沒關係，慢慢走，一步一步，不要停。」 | Rùa Nhỏ tới rồi!／"Không sao, đi thôi, từng bước từng bước, đừng dừng lại." | （缺） | — |
| P08 | P13 | 「慢慢龜贏了！」／跳跳兔說：「好厲害！」／慢慢龜說：「一起走！」 | "Rùa Nhỏ thắng rồi!"／"Bạn giỏi quá!"／"Đi cùng nhau nhé?" | （缺） | — |
| P09 | P14 | 後來呀，慢慢龜和跳跳兔常常一起散步——不比快慢，只比誰笑得最多。 | Từ ngày ấy, hai bạn luôn đi cùng nhau. | （缺） | — |

## 三、QA 摘要（qa/vi-VN）

- `qa/vi-VN/round1.md`：round 1／verdict escalated

最新 round：`qa/vi-VN/round1.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: the-tortoise-and-the-hare
locale: vi-VN
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: 2026-07-22
step1_lint:
  exit_code: 1
  warnings: 9
step2_checklist:
  pass: 12
  fail: 0
step3_personas:
  - id: vi-VN-teacher
    scores:
      年齡適配度: 8
      朗讀口感: 8
      孩子抓得住度: 8
  - id: vi-VN-parent
    scores:
      睡前適讀性: 8
      零說教: 9
  - id: vi-VN-editor
    scores:
      母語自然度: 8
      文字工藝: 8
step4_triage:
  real: 0
  rejected: 0
  escalated: 1
verdict: escalated
```

### ESL 獵手發現（原文引用）

### ESL 獵手報告（vi-VN）

逐頁掃描三檔：
- **獵物①翻譯腔**：未發現明顯翻譯痕跡。改編文呈現目標語言母語自然感。
- **獵物② AI 機械句**：未發現 style_guide §3.4 四型（電報式裸動詞堆疊 / 成分懸空 / 超規律平行 / 無語氣詞乾句）。2-3 檔位的電報式短句屬 W7 合法語體，非 AI 機械句。

## 四、⏸️ 上呈批次

- （`qa/vi-VN/round1.md`）所有 violations 為 frozen formula 結構性超限（golden 鎖定句式不可縮短），歸 STEP 4 ⏸️ 上呈。
- （`qa/vi-VN/round1.md`）| E1 | STEP 1 機檢 | frozen refrain 11>10 max_sentence_len (2-3 P03/P12) | ⏸️ | — | frozen formula golden 鎖定，同 zh-TW gate3 + en-US gate4 先例 |
- （`qa/vi-VN/round1.md`）✅ real = 0, ❌ rejected = 0, ⏸️ escalated = 1
- （`qa/vi-VN/round1.md`）### ⏸️ 上呈項
- （`qa/vi-VN/round1.md`）✅=0（無真問題回修），但有 ⏸️ 上呈項（frozen formula 結構性超限）。verdict = escalated（等同先例處理）。

