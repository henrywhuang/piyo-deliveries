# 關卡4整合審閱：龜兔賽跑（S4 證據包／es-MX）

- 生成時間：2026-07-22 11:21:54 +0800
- 書目錄：`content/PYO-002_the-tortoise-and-the-hare`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：es-MX
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-002_storyboard.md` | 2026-07-21 17:08:45 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-21 17:08:45 |
| text/es-MX/5-6 | `text/es-MX/5-6.draft.json` | 2026-07-21 22:29:20 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-21 17:08:45 |
| text/es-MX/3-5 | `text/es-MX/3-5.draft.json` | 2026-07-21 22:29:28 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-21 17:08:45 |
| text/es-MX/2-3 | `text/es-MX/2-3.draft.json` | 2026-07-21 22:29:33 |
| qa/es-MX/backtranslation.md | `qa/es-MX/backtranslation.md` | 2026-07-22 11:21:46 |
| qa/es-MX round | `qa/es-MX/round1.md` | 2026-07-22 11:20:51 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | es-MX 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 14 | 14 頁有文 | 14 頁有文 | 8/14 | 0 |
| 3-5 | 11 | 11 頁有文 | 11 頁有文 | 7/11 | 0 |
| 2-3 | 9 | 9 頁有文 | 9 頁有文 | 5/9 | 0 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | es-MX 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 跳跳兔大聲笑著說：「哈哈哈！你走路好慢喔！要不要比賽跑步？」／慢慢龜握了握拳，小聲回答：「好…… 比就比。」 | Saltón señaló a Lentita y se rio.／—¡Ja, ja, ja! ¡Qué lenta eres! ¡Apuesto a que ni llegas a la meta!／Lentita respiró hondo.／—Bueno… va. | 「我超快！比一場？」「好！」→ 接受挑戰 | 無 |
| P02 | P02 | 貓頭鷹裁判揮旗：「預備——跑！」／咻！／跳跳兔一下子就跑得不見了。／慢慢龜還站在起跑線上，一步都沒跨出去。 | —¡Listos… en sus marcas… FUERA! —gritó Juez Búho.／¡ZUUUM! Saltón salió disparado.／Lentita seguía en la línea de salida. No había dado ni un solo paso. | （缺） | — |
| P03 | P03 | 慢慢龜在小路上一步一步往前走。／她小聲對自己說：「沒關係，慢慢走，一步一步，不要停。」 | Lentita caminó por el sendero, un pasito a la vez.／Se dijo en voz bajita:／—No pasa nada, despacito, paso a paso, no me paro. | 嚓嚓嚓。Lentita 一步一步走。「沒關係，慢慢來，一步一步，不停下。」→ 疊句首次 | 無 |
| P04 | P04 | 跳跳兔跑太遠了，覺得好無聊。／「哇！蝴蝶！」／蹦！蹦！／他衝進花田追呀追。／蝴蝶停在他鼻尖上，他一點也不知道。 | Saltón iba tan adelante que se aburrió.／—¡Ooh! ¡Una mariposa!／¡Boing! ¡Boing!／Se lanzó entre las flores, persiguiéndola y rodando por el pasto.／La mariposa se le paró en la nariz, y Saltón ni cuenta se dio. | （缺） | — |
| P05 | P05 | 慢慢龜爬呀爬，終於爬到坡頂。／可是前面還有好長好長的路。／她的腳步…… 慢了下來。 | Lentita llegó a la cima. El camino se extendía largo, largo, largo.／Sus patitas… se… frenaron— | Lentita 到坡頂。前方好長的路。腳步……慢了——→ hook | 無 |
| P06 | P06 | 呼嚕呼嚕……／跳跳兔在大樹蔭下睡得好熟好熟，蝴蝶在他肚皮上歇腳。／他一點也不知道。 | Zzzzzzz.／Saltón estaba despatarrado bajo el árbol grande, con la boca abierta.／Una mariposa descansaba en su panza, y él ni lo sabía. | （缺） | — |
| P07 | P07 | 太陽好大好大，路上熱得發燙。／沙沙沙…… 沙沙沙……／慢慢龜的腳步越來越輕，可是她沒有停。 | El sol pegaba fuerte y no había ni una sombrita.／chas, chas, chas.／Los pasos de Lentita eran cada vez más lentos, pero no se detuvo. | （缺） | — |
| P08 | P08 | 慢慢龜的腳步，停了。／好累好累…… 她快要撐不住了。／慢慢龜…… 她要放棄了嗎？ | Las patitas de Lentita se pararon.／Estaba tan cansada… tan cansada que ya no podía más.／¿Se iba a rendir? | 太陽越來越熱……Lentita 走了很久很久。腳停了。要放棄嗎？→ hook | 無 |
| P09 | P09 | 慢慢龜看著自己的腳。／她深深吸了一口氣，顫抖著踏出一步。／「沒關係，慢慢走，一步一步，不要停。」 | Lentita miró sus propias patitas.／Respiró hondo, temblandito, y dio un paso.／—No pasa nada, despacito, paso a paso, no me paro. | Lentita 看著自己的小腳。深呼吸，顫抖著踏一步。「沒關係，慢慢來……」→ 疊句第二次 | 無 |
| P10 | P10 | 跳跳兔猛然醒過來，揉揉眼睛。／「啊！」他看見遠遠的地方——慢慢龜快到終點了！ | Saltón se despertó de golpe. Se talló los ojos.／—¡¿QUÉ?! Allá, al final del camino, ¡Lentita ya casi llegaba a la meta! | （缺） | — |
| P11 | P11 | 跳跳兔拔腿狂追！／可是慢慢龜已經到了終點線前面。／她的腳，正要踩下去—— | ¡Saltón corrió con todas sus fuerzas!／Pero Lentita ya estaba en la meta, a un pasito.／Su patita se levantó… a punto de pisar— | Saltón 全力衝刺！但 Lentita 的腳已在終點線上——→ hook | 無 |
| P12 | P12 | 慢慢龜的腳，踩過了終點線。／她停下來，輕輕地說：／「沒關係，慢慢走，一步一步，不要停。」 | Lentita cruzó la meta.／Se quedó muy quietecita. Tranquila y segura.／—No pasa nada, despacito, paso a paso, no me paro. | Lentita 跨過終點。靜靜地站著。「沒關係，慢慢來，一步一步，不停下。」→ 疊句最終次 | 無 |
| P13 | P13 | 貓頭鷹宣布：「慢慢龜贏了！」／跳跳兔喘著氣跑到，愣住了：「你…… 好厲害喔。」／慢慢龜笑了笑，伸出手：「一起走吧！」 | —¡Lentita gana! —anunció Juez Búho.／Saltón llegó jadeando.／—Tú… eres increíble —le dijo.／Lentita sonrió.／—¿Caminamos juntos? | （缺） | — |
| P14 | P14 | 跳跳兔認真地說：「以後我再也不笑別人慢了，我要跟慢慢龜一起走！」／後來呀，慢慢龜和跳跳兔常常一起散步——不比快慢，只比誰笑得最多。 | —Ya no me voy a reír de nadie por ser lento —dijo Saltón—. ¡Quiero caminar contigo, Lentita!／Y desde ese día, Lentita y Saltón caminaron juntos. No para ver quién era más rápido, sino quién se reía más. | 「我再也不笑別人慢了」Saltón 說。「想跟你一起走！」從那天起一起散步——不比快慢，比誰笑得多。→ 收束式 | 無 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | es-MX 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 跳跳兔笑著說：「你走路好慢喔！來比賽吧！」／慢慢龜說：「好…… 比就比。」 | Saltón se rio.／—¡Ja, ja, ja! ¡Qué lenta eres! ¿Una carrera?／Lentita dijo:／—Bueno… va. | 「我超快！比一場？」「好！」→ 接受挑戰 | 無 |
| P02 | P02 | 「預備——跑！」／咻！／跳跳兔一下子就不見了。／慢慢龜還站在起跑線上。 | —¡Listos… en sus marcas… FUERA! —gritó Juez Búho.／¡ZUUUM! Saltón desapareció.／Lentita seguía en la línea de salida. | （缺） | — |
| P03 | P03 | 沙沙沙…… 慢慢龜一步一步往前走。／「沒關係，慢慢走，一步一步，不要停。」 | chas, chas, chas. Lentita caminó, un pasito a la vez.／—No pasa nada, despacito, paso a paso, no me paro. | 嚓嚓嚓。Lentita 一步一步走。「沒關係，慢慢來，一步一步，不停下。」→ 疊句首次 | 無 |
| P04 | P05 | 慢慢龜爬到坡頂，前面還有好長好長的路。／她的腳步…… 慢了下來。 | Lentita llegó a la cima. El camino seguía y seguía.／Sus patitas… se… frenaron— | （缺） | — |
| P05 | P06 | 呼嚕呼嚕……／跳跳兔在大樹下睡得好熟好熟。／他一點也不知道。 | Lentita llegó a la cima. El camino seguía y seguía.／Sus patitas… se… frenaron— | Lentita 到坡頂。前方好長的路。腳步……慢了——→ hook | 無 |
| P06 | P08 | 太陽好大好大…… 慢慢龜走了好久。／她的腳步，停了。／她…… 要放棄了嗎？ | Zzzzzzz.／Saltón estaba despatarrado bajo el árbol, bien dormido.／Ni lo sabía. | （缺） | — |
| P07 | P10 | 可是慢慢龜沒有放棄。／跳跳兔醒來了——慢慢龜快到終點了！ | Pero Lentita no se rindió.／Saltón se despertó, ¡y Lentita ya casi llegaba a la meta! | （缺） | — |
| P08 | P11 | 跳跳兔拔腿狂追！／可是慢慢龜的腳，正要踩過終點線—— | El sol pegaba cada vez más fuerte… Lentita caminó mucho, mucho rato.／Sus patitas se pararon. ¿Se iba a rendir? | 太陽越來越熱……Lentita 走了很久很久。腳停了。要放棄嗎？→ hook | 無 |
| P09 | P12 | 慢慢龜踩過了終點線。／「沒關係，慢慢走，一步一步，不要停。」 | Lentita cruzó la meta.／—No pasa nada, despacito, paso a paso, no me paro. | （缺） | — |
| P10 | P13 | 「慢慢龜贏了！」／跳跳兔說：「你…… 好厲害喔。」／慢慢龜說：「一起走吧！」 | Pero Lentita no se rindió.／Saltón se despertó, ¡y Lentita ya casi llegaba a la meta! | （缺） | — |
| P11 | P14 | 跳跳兔說：「以後我再也不笑別人慢了，我要跟慢慢龜一起走！」／後來呀，慢慢龜和跳跳兔常常一起散步——不比快慢，只比誰笑得最多。 | ¡Saltón corrió con todas sus fuerzas!／¡Pero la patita de Lentita ya estaba justo encima de la meta! | Saltón 全力衝刺！但 Lentita 的腳已在終點線上——→ hook | 無 |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | es-MX 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 跳跳兔說：「我跑得比較快喔！比比看？」／慢慢龜說：「好！」 | —¡Soy rapidísimo! ¿Una carrera?／—¡Va! | 「我超快！比一場？」「好！」→ 接受挑戰 | 無 |
| P02 | P02 | 咻！／跳跳兔跑得好快好快！／慢慢龜慢慢走。 | ¡ZUUUM!／¡Saltón corrió rapidísimo!／Lentita caminó despacito. | （缺） | — |
| P03 | P03 | 沙沙沙…… 慢慢龜走呀走。／「沒關係，慢慢走，一步一步，不要停。」 | chas, chas, chas.／—No pasa nada, despacito, paso a paso, no me paro. | 嚓嚓嚓。Lentita 一步一步走。「沒關係，慢慢來，一步一步，不停下。」→ 疊句首次 | 無 |
| P04 | P06 | 呼嚕呼嚕……／跳跳兔在大樹下睡著了！ | Zzzzzzz.／¡Saltón se quedó dormido bajo el árbol! | （缺） | — |
| P05 | P10 | 慢慢龜一直走呀走。／跳跳兔醒來了—— | Lentita caminó y caminó.／Saltón se despertó— | （缺） | — |
| P06 | P11 | 慢慢龜快到了！跳跳兔追呀追！／慢慢龜的腳，要踩過去了—— | Zzzzzzz.／¡Saltón se quedó dormido bajo el árbol! | （缺） | — |
| P07 | P12 | 慢慢龜到了！／「沒關係，慢慢走，一步一步，不要停。」 | ¡Lentita llegó!／—No pasa nada, despacito, paso a paso, no me paro. | （缺） | — |
| P08 | P13 | 「慢慢龜贏了！」／跳跳兔說：「好厲害！」／慢慢龜說：「一起走！」 | —¡Lentita gana!／—¡Eres increíble!／—¿Caminamos juntos? | （缺） | — |
| P09 | P14 | 後來呀，慢慢龜和跳跳兔常常一起散步——不比快慢，只比誰笑得最多。 | Y desde ese día, Lentita y Saltón caminaron juntos. | （缺） | — |

## 三、QA 摘要（qa/es-MX）

- `qa/es-MX/round1.md`：round 1／verdict pass

最新 round：`qa/es-MX/round1.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: the-tortoise-and-the-hare
locale: es-MX
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: 2026-07-22
step1_lint:
  exit_code: 0
  warnings: 7
step2_checklist:
  pass: 12
  fail: 0
step3_personas:
  - id: es-MX-educadora
    scores:
      年齡適配度: 8
      墨西哥語感: 9
      孩子抓得住度: 8
  - id: es-MX-mama
    scores:
      睡前適讀性: 8
      零說教: 9
  - id: es-MX-editora
    scores:
      母語自然度: 8
      文字工藝: 8
step4_triage:
  real: 0
  rejected: 0
  escalated: 0
verdict: pass
```

### ESL 獵手發現（原文引用）

### ESL 獵手報告（es-MX）

逐頁掃描三檔：
- **獵物①翻譯腔**：未發現明顯翻譯痕跡。改編文呈現目標語言母語自然感。
- **獵物② AI 機械句**：未發現 style_guide §3.4 四型（電報式裸動詞堆疊 / 成分懸空 / 超規律平行 / 無語氣詞乾句）。2-3 檔位的電報式短句屬 W7 合法語體，非 AI 機械句。

## 四、⏸️ 上呈批次

- （`qa/es-MX/round1.md`）✅ real = 0, ❌ rejected = 0, ⏸️ escalated = 0

