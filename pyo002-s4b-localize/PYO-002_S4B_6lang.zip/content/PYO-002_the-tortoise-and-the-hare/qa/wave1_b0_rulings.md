# Wave 1 B0 Rulings — PYO-002 The Tortoise and the Hare

```yaml
schema: piyo_b0_rulings/v1
book_id: PYO-002
slug: the-tortoise-and-the-hare
wave: 1
lanes: [ja, es-MX, pt-BR, en-GB]
date: 2026-07-21
```

## 凍結字串表

### 疊句核心句（三檔逐字一致·golden 鎖定）

| # | locale | 凍結字形 | 結構 | 備註 |
|---|---|---|---|---|
| R1 | ja | `「だいじょうぶ、ゆっくり ゆっくり、いっぽ いっぽ、とまらない。」` | 安撫→節奏→行動→不停 | 25 char vs 2-3 max 21＝frozen formula 超限（同 en-US 先例） |
| R2 | es-MX | `"No pasa nada, despacito, paso a paso, no me paro."` | 安撫→節奏→行動→不停 | -ito/-aro 半韻；三檔全 PASS |
| R3 | pt-BR | `"Tudo bem, devagarinho, passo a passo, eu vou seguindo."` | 安撫→節奏→行動→不停 | -inho/-indo 韻；三檔全 PASS |
| R4 | en-GB | `"It's okay, nice and slow, step by step, here I go."` | 沿用 en-US golden | 2-3 11w > max 8＝frozen formula 超限（同 en-US） |

### 收束式 formula

| # | locale | 凍結字形 | 備註 |
|---|---|---|---|
| R5 | ja | `その ひから` | 5-6/3-5 含前瞻意願句 |
| R6 | es-MX | `"Y desde ese día"` | 三檔統一概念 |
| R7 | pt-BR | `"E daquele dia em diante"` | 三檔統一概念 |
| R8 | en-GB | `"And from that day on"` | 沿用 en-US golden |

### 角色名（registry 來源）

| # | locale | tilly | hops | owl | 狀態 |
|---|---|---|---|---|---|
| R9 | ja | `ゆっくん` | `ピョンタ` | `フクロウ審判` | 定案 |
| R10 | es-MX | `Lentita` | `Saltón` | `Juez Búho` | 提案 |
| R11 | pt-BR | `Lentinha` | `Saltão` | `Juiz Coruja` | 提案 |
| R12 | en-GB | `Tilly` | `Hops` | `Judge Owl` | 沿用 en-US 定案 |

### 擬聲詞（registry 來源）

| # | locale | 嘲笑聲 | 兔子衝刺 | 腳步聲 | 撲蝶跳躍 | 鼾聲 | 狀態 |
|---|---|---|---|---|---|---|---|
| R13 | ja | `あはは！` | `ピュー！` | `とことこ` | `ぴょんぴょん` | `ぐうぐう` | 定案＋提案（腳步/撲蝶） |
| R14 | es-MX | `¡Ja, ja, ja!` | `¡ZUUUM!` | `chas, chas, chas.` | `¡Boing! ¡Boing!` | `Zzzzzzz.` | 全提案 |
| R15 | pt-BR | `Ha ha ha!` | `ZUUUM!` | `tec, tec, tec.` | `Boing! Boing!` | `Zzzzzzz.` | 全提案 |
| R16 | en-GB | `Ha ha ha!` | `ZOOM!` | `scuff, scuff, scuff.` | `Boing! Boing!` | `Zzzzzzz.` | 沿用 en-US |

## B3 機檢摘要

| locale | 5-6 | 3-5 | 2-3 | 結構性 escalation |
|---|---|---|---|---|
| ja | PASS 0 | PASS 0 | 2 violations | frozen refrain 25>21 max_sentence_len |
| es-MX | PASS 0 | PASS 0 | PASS 0 | — |
| pt-BR | PASS 0 | PASS 0 | 1 violation | frozen ending formula 11w>9 max |
| en-GB | PASS 0 | PASS 0 | 3 violations | frozen refrain 11w>8 + ending 10w>8（同 en-US） |

## 已知結構性 escalation（frozen formula 先例）

2-3 tier frozen formula 句長超限是跨語共通 pattern：
- zh-TW gate3：P09 收束式 28>15（escalated + Green Light 2026-07-20）
- en-US gate4：refrain 11w>8 + ending 10w>8（escalated + Green Light 2026-07-20）
- 本波 ja/pt-BR/en-GB 同類狀況，QA 依先例處理
