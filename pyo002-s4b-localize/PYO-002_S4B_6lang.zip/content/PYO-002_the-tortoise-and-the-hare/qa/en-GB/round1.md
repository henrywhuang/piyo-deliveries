# QA Round 1 — PYO-002 The Tortoise and the Hare (en-GB)

```yaml
schema: piyo_text_qa_report/v0.9
slug: the-tortoise-and-the-hare
locale: en-GB
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: 2026-07-22
step1_lint:
  exit_code: 1
  warnings: 6
step2_checklist:
  pass: 12
  fail: 0
step3_personas:
  - id: en-GB-teacher
    scores:
      年齡適配度: 8
      英式語感: 8
      孩子抓得住度: 8
  - id: en-GB-parent
    scores:
      睡前適讀性: 9
      零說教: 9
  - id: en-GB-editor
    scores:
      母語自然度: 9
      文字工藝: 9
step4_triage:
  real: 0
  rejected: 0
  escalated: 1
verdict: escalated
```

**主題錨復述**：堅持自己的步伐、不放棄每一步就能走到終點——力量來自「不停下」而非「比別人快」。

## STEP 1 機檢

locale_lint.py 三檔結果：

| 檔位 | 結果 | violations | warnings |
|---|---|---|---|
| 5-6 | PASS | 0 | — |
| 3-5 | PASS | 0 | — |
| 2-3 | FAIL (3 violations) | 3 | — |

總計：3 violations, 6 warnings（repeat_discount informational 等）。
所有 violations 為 frozen formula 結構性超限（golden 鎖定句式不可縮短），歸 STEP 4 ⏸️ 上呈。

## STEP 2 checklist 自檢

### E 繪本編輯審查

checklist 文本適用項：12 項全部通過。

**對位審查**：逐頁比對 workbench bundle（storyboard 負載欄 × 改編文 × zh-TW 母本）：
- 三檔頁面選用與 storyboard 一致（5-6=14 頁, 3-5=11 頁, 2-3=9 頁）
- 疊句三次出現位置正確（P03 首次 → P09 顫抖版 → P12 篤定版）
- 翻頁 hook 三處佈點兌現（P05 動作中斷 / P08 懸念 / P11 動作中斷）
- 收束式 formula 三檔到位
- 圖文分工合理：文字負載聲音、台詞、內心、時間；不重述圖可交代的視覺事實

**concept fidelity**：三檔讀完後孩子帶走的核心教訓一致——「堅持自己的步伐不放棄」+ 「力量來自不停下」。無主題漂移。

### ESL 獵手報告（en-GB）

逐頁掃描三檔：
- **獵物①翻譯腔**：未發現明顯翻譯痕跡。改編文呈現目標語言母語自然感。
- **獵物② AI 機械句**：未發現 style_guide §3.4 四型（電報式裸動詞堆疊 / 成分懸空 / 超規律平行 / 無語氣詞乾句）。2-3 檔位的電報式短句屬 W7 合法語體，非 AI 機械句。

## STEP 3 人設 blind QA

### en-GB-teacher

分數：年齡適配度=8, 英式語感=8, 孩子抓得住度=8

無重大發現。文本適合目標年齡段讀者。

### en-GB-parent

分數：睡前適讀性=9, 零說教=9

無重大發現。文本適合目標年齡段讀者。

### en-GB-editor

分數：母語自然度=9, 文字工藝=9

無重大發現。文本適合目標年齡段讀者。

## STEP 4 三分法分診

裁決對象：STEP 2-3 所有發現。

| # | 來源 | 描述 | 裁決 | 修改級別 | 理由 |
|---|---|---|---|---|---|
| E1 | STEP 1 機檢 | frozen refrain 11w>8 + ending formula 10w>8 (2-3 P03/P09/P12/P14, same as en-US gate4) | ⏸️ | — | frozen formula golden 鎖定，同 zh-TW gate3 + en-US gate4 先例 |

✅ real = 0, ❌ rejected = 0, ⏸️ escalated = 1

### ⏸️ 上呈項

| # | 類型 | 描述 | 先例 |
|---|---|---|---|
| E1 | frozen formula 結構性超限 | frozen refrain 11w>8 + ending formula 10w>8 (2-3 P03/P09/P12/P14, same as en-US gate4) | zh-TW gate3 + en-US gate4 均 escalated + Green Light accepted |

上述 frozen formula 超限為三檔逐字一致的 golden 鎖定句式，不可回修。同類 pattern 在 zh-TW gate3 (P09 收束式 28>15) 和 en-US gate4 (refrain 11w>8, ending 10w>8) 均已 escalated + Stacy accepted。

### 訊源計量

| 訊源 | 獨有 real | 備註 |
|---|---|---|
| 獵手獨有 | 0 | — |
| 回譯獨有 | 0 | — |
| 人設獨有 | 0 | — |
| 多路收斂 | 0 | — |

### 收斂判定

✅=0（無真問題回修），但有 ⏸️ 上呈項（frozen formula 結構性超限）。verdict = escalated（等同先例處理）。
