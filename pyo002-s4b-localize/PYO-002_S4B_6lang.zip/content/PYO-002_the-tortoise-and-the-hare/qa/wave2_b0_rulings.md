# Wave 2 B0 Rulings — PYO-002 The Tortoise and the Hare

```yaml
schema: piyo_b0_rulings/v1
book_id: PYO-002
slug: the-tortoise-and-the-hare
wave: 2
lanes: [th-TH, vi-VN]
date: 2026-07-21
```

## 凍結字串表

### 疊句核心句（三檔逐字一致·golden 鎖定）

| # | locale | 凍結字形 | 結構 | 備註 |
|---|---|---|---|---|
| R1 | th-TH | `"ไม่เป็นไร ค่อย ๆ เดิน ทีละก้าว ไม่หยุดนะ"` | 安撫→節奏→行動→不停 | 三檔全 PASS（line break 分句解決 2-3 超限） |
| R2 | vi-VN | `"Không sao, đi thôi, từng bước từng bước, đừng dừng lại."` | 安撫→鼓勵→行動→不停 | 11 tiếng；2-3 超 max_sentence_len 10＝frozen formula 超限（同 en-US 先例） |

### 收束式 formula

| # | locale | 凍結字形 | 備註 |
|---|---|---|---|
| R3 | th-TH | `"ตั้งแต่วันนั้นเป็นต้นมา"` | 三檔統一概念 |
| R4 | vi-VN | `"Từ ngày ấy"` | 三檔統一概念 |

### 角色名（registry 來源）

| # | locale | tilly | hops | owl | 狀態 |
|---|---|---|---|---|---|
| R5 | th-TH | `เต่าน้อย` | `กระต่ายจ้อน` | `นกฮูกกรรมการ` | 提案 |
| R6 | vi-VN | `Rùa Nhỏ` | `Thỏ Nhanh` | `Cú Mèo Trọng Tài` | 提案 |

### 擬聲詞（registry 來源）

| # | locale | 嘲笑聲 | 兔子衝刺 | 腳步聲 | 撲蝶跳躍 | 鼾聲 | 狀態 |
|---|---|---|---|---|---|---|---|
| R7 | th-TH | `ฮ่าฮ่าฮ่า!` | `วี้ดดด!` | `กร๊อบ ๆ` | `โดด! โดด!` | `กรน กรน...` | 既有提案＋本次提案（腳步/撲蝶） |
| R8 | vi-VN | `Ha ha ha!` | `Vèo!` | `sột soạt, sột soạt.` | `Nhảy! Nhảy!` | `Khò khò khò…` | 既有提案＋本次提案（腳步/撲蝶） |

## B3 機檢摘要

| locale | 5-6 | 3-5 | 2-3 | 結構性 escalation |
|---|---|---|---|---|
| th-TH | PASS 0 | PASS 0 | PASS 0 | —（line break 分句解決 formula 超限） |
| vi-VN | PASS 0 | PASS 0 | 2 violations | frozen refrain 11>10 max_sentence_len |

## 已知結構性 escalation（frozen formula 先例）

vi-VN 2-3 tier frozen refrain 句長超限同 Wave 1 共通 pattern（zh-TW/en-US/ja/en-GB 先例），QA 依先例處理。
th-TH 透過 line break 分句策略避免超限（泰語 spec 允許換行作句界）。
