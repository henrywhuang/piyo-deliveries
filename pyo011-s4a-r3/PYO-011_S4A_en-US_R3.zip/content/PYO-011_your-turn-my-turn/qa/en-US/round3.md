# QA 報告：your-turn-my-turn / en-US / round 3

```yaml
schema: piyo_text_qa_report/v0.9
slug: your-turn-my-turn
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 3
date: "2026-07-23"
step1_lint: {exit_code: 0, warnings: 16}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 6, 朗讀口感: 7, 孩子抓得住度: 7}
  - id: en-US-parent
    scores: {睡前適讀性: 6, 零說教: 9}
  - id: en-US-editor
    scores: {母語自然度: 9, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

**本輪性質**：Stacy gate4 R1 審包返「不通過——需修改後重審」，15+ 項指令性修改（含 E-2 裁定 Option A）。本輪為回應 gate 審指示的修改驗證輪：全量機檢重跑＋受修頁 E-lite＋回譯同步。人設不重跑，分數沿用 round 1（修改均由 Stacy 指示，不影響讀者體驗模擬效度）。

## STEP 1 機檢

### copy_check（全量重跑）
```
python3 .claude/skills/piyo-text-writer/scripts/copy_check.py content/PYO-011_your-turn-my-turn/copy/en-US.md
```
exit 0。警告 12 筆（帶判定超帶上緣 10 筆 + 低於帶下緣 1 筆，2-3 P04 = 9 < 10）。

### locale_lint ×3（全量重跑）
```
locale_lint --pages-file text/en-US/5-6.draft.json --locale en-US --band 5-6  → exit 0（2 warnings: repeat_discount）
locale_lint --pages-file text/en-US/3-5.draft.json --locale en-US --band 3-5  → exit 0（2 warnings: repeat_discount）
locale_lint --pages-file text/en-US/2-3.draft.json --locale en-US --band 2-3  → exit 0（4 warnings: brand frozen 句長豁免 + repeat_discount; 折計後總量 98 → 87.5 ≤ 88）
```

### Stacy 指示修改逐筆落地驗證

**en-US 修改（三檔）**：

| # | Stacy 指示 | 影響檔位 | 落地內容 | 核銷 |
|---|---|---|---|---|
| S1 | P08 補翻轉重複拍（沙漏流完→再翻→又流） | 5-6, 3-5 | 5-6: "It ran out! He flipped it again. Shh, shh, shh — it started all over." / 3-5: "It ran out! He flipped it again." | ✓ |
| S2 | P09 道歉加「我忘了你也在等」 | 5-6 | "I'm sorry — I forgot you were waiting, too" | ✓ |
| S3 | P10 "wait"→"count"（Dash 在數不是在等） | 5-6 | "Now it was Dash's turn to count." | ✓ |
| S4 | P10 "held up the hourglass"→"raised his hand" | 5-6, 3-5 | "Dash raised his hand—" | ✓ |
| S5 | E-2 裁定 Option A：三檔高潮 "I want to watch you swing!" | 5-6, 3-5, 2-3 | 5-6 P11 / 3-5 P09 / 2-3 P08 均已落地 | ✓ |
| S6 | 2-3 P06 規則句替代 "Let's try!" | 2-3 | "Sand out — switch!" | ✓ |

**zh-TW 修改**：

| # | Stacy 指示 | 影響檔位 | 落地內容 | 核銷 |
|---|---|---|---|---|
| Z1 | 5-6 P12 「沙坑邊」→「鞦韆旁」 | 5-6 | "他們把沙漏留在鞦韆旁" | ✓ |
| Z2 | 三檔收束加唱疊句 | 5-6, 3-5, 2-3 | 5-6 P12 / 3-5 P10 / 2-3 P09 均加「都會唱那首輪流歌：「輪到你，輪到我！」」 | ✓ |
| Z3 | 3-5 P05 空鞦韆矛盾修正 | 3-5 | "風推著空鞦韆，晃呀晃。兩個人坐在旁邊" | ✓ |

**2-3 字數預算調整（R2 附帶修正，因 14w/page hard limit）**：

| 頁 | 修改 | 字數 | 理由 |
|---|---|---|---|
| P03 | "stood below"→"waited" | 11→10 | -1w offset for total budget |
| P05 | "A little hourglass"→"An hourglass" | 11→10 | -1w offset for total budget |
| P06 | drop "said Dash", shorten rule | 14→10 | -1w vs original; 電報式 "Sand out — switch!" |
| P07 | revert to original（完整回合裝不進 14w） | 17→12 | 核心拍保留：Waddle kicks sky + refrain + hook |
| P08 | drop "You go first!", refrain "."→"!" | 17→14 | 14w exact limit; refrain 統一 repeat_discount |

### copy↔draft 同源檢
copy_check exit 0 含同源驗證。

## STEP 2 checklist 自檢

**主題錨復述句**：本書教的是——兔兔 Dash 和企鵝 Waddle 為鞦韆搶先，經歷共乘失敗與冷戰，用沙漏建立「你的回合，我的回合」輪流規則，最終主動讓出自己的回合——「公平不是都一樣，而是大家都被看見」。

**E-lite 複審範圍**（受修頁＋相鄰頁）：
- 5-6: P07, P08*, P09*, P10*, P11*, P12
- 3-5: P05, P06*, P07, P08*, P09*
- 2-3: P02, P03*, P04, P05*, P06*, P07, P08*

**E-lite 結果**：

1. **對位原則**：受修頁均為台詞/內心/聲音負載，無視覺重述。P08 翻轉重複拍＝動作敘事（動態線索），P11 climax＝台詞＋內心——均屬文字專屬負載，合規。
2. **concept fidelity**：E-2 修正後三檔高潮均為「我想看你盪」（vicarious joy），完全對齊 zh-TW 母本主題錨「公平＝被看見」。concept fidelity 全檔通過。
3. **相鄰頁連貫性**：P07→P08（5-6）翻轉發現→翻轉重複流暢；P10→P11（5-6）舉手→沙漏漏完過渡自然；P08→P09（2-3）climax→brand formula 情感弧完整。
4. **三檔共用規則**：疊句 "Your turn, my turn!" 三檔一致✓；角色名 Dash/Waddle 三檔一致✓；擬聲詞 ZIP!/creak/Shh 三檔一致✓。

**回譯同步**：11 頁重譯完成（5-6: P08/P09/P10/P11, 3-5: P06/P08/P09, 2-3: P03/P05/P06/P08），所有 drift marker 已由 E 重填。中度偏移全數降級：
- 5-6 P11：中度→輕微（E-2 「我想看你盪」已到位）
- 3-5 P09：中度→輕微（同上）
- 2-3 P08：中度→輕微（climax 到位，互惠省略因 14w limit）

覆蓋率：31/31（三檔頁數 12+10+9），無殘留「回修待重譯」。

## STEP 3 人設 blind QA

Stacy gate 指示修改輪，人設不重跑。分數沿用 round 1：

| 人設 | 維度 | 摘要分 |
|---|---|---|
| en-US-teacher | 年齡適配度 | 6 |
| en-US-teacher | 朗讀口感 | 7 |
| en-US-teacher | 孩子抓得住度 | 7 |
| en-US-parent | 睡前適讀性 | 6 |
| en-US-parent | 零說教 | 9 |
| en-US-editor | 母語自然度 | 9 |
| en-US-editor | 文字工藝 | 8 |

## STEP 4 三分法分診

**主題錨復述句**：兔兔和企鵝為鞦韆搶先→嘗試失敗→用沙漏建立輪流→主動讓出。公平＝大家都被看見。

Round 2 唯一 ⏸️（E-2 vicarious joy→patience 偏移）已由 Stacy 裁定 **Option A 落地**：三檔高潮統一為 "I want to watch you swing!"。回譯確認三檔均對齊 zh-TW「我想看你盪」。

本輪無新裁決對象。✅=0, ❌=0, ⏸️=0。

**Registry 更新**（附帶完成）：
- `character_names.md`：新增 your-turn-my-turn 書名列 + Dash/Waddle 角色段落
- `onomatopoeia_map.md`：新增 3 場景鍵（衝刺搶先/鞦韆嘎吱/沙漏流沙）
