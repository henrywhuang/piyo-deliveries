# QA 報告：your-turn-my-turn / en-US / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: your-turn-my-turn
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-22"
step1_lint: {exit_code: 0, warnings: 8}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 6, 朗讀口感: 7, 孩子抓得住度: 7}
  - id: en-US-parent
    scores: {睡前適讀性: 6, 零說教: 9}
  - id: en-US-editor
    scores: {母語自然度: 9, 文字工藝: 8}
step4_triage: {real: 4, rejected: 8, escalated: 1}
verdict: fix_required
```

模式 B / S4A en-US 首輪 QA。

## STEP 1 機檢

### copy_check
```
python3 .claude/skills/piyo-text-writer/scripts/copy_check.py content/PYO-011_your-turn-my-turn/copy/en-US.md
```
exit 0。8 筆警告（帶判定超帶上緣 6 筆＋低於帶下緣 2 筆）：

| 頁 | 檔位 | 類型 | 理由 |
|---|---|---|---|
| P04 | 3-5 | 超帶(29>25) | CREEAK 喜劇能量＋橋接句 |
| P10 | 5-6 | 超帶(43>40) | B2 新增 action-interrupt hook |
| P08 | 3-5 | 超帶(29>25) | 高潮頁完整回合呈現 |
| P09 | 3-5 | 超帶(26>25) | 讓出高潮＋互惠承諾 |
| P12 | 5-6 | 超帶(41>40) | 收束式含 brand formula |
| P10 | 3-5 | 超帶(33>25) | 收束頁保留走向溜滑梯＋留沙漏 |
| P04 | 2-3 | 低帶(9<10) | 電報式 "Stuck!" 一字收喜劇 |
| P08 | 2-3 | 低帶(8<10) | 高潮僅留讓出台詞＋疊句 |

### locale_lint ×3
```
locale_lint --pages-file text/en-US/5-6.draft.json --locale en-US --band 5-6  → exit 0 (2 warnings: repeat_discount)
locale_lint --pages-file text/en-US/3-5.draft.json --locale en-US --band 3-5  → exit 0 (2 warnings: repeat_discount)
locale_lint --pages-file text/en-US/2-3.draft.json --locale en-US --band 2-3  → exit 0 (4 warnings: brand frozen 句長豁免 + repeat_discounts)
```

### localize_readiness
exit 2（parse error：PYO-011 book.yaml 用 block list 格式，腳本只解析 inline list；非內容違規；contract 由 copy_check 已驗）

## STEP 2 checklist 自檢

**主題錨復述句**：本書教的是——兩個小動物（兔兔 Dash、企鵝 Waddle）為同一個玩具搶先，發現沙漏後用「你的回合，我的回合」建立公平輪流，最終主動讓出自己的回合——「公平不是都一樣，而是大家都被看見」。

### quality_criteria checklist（A-E 19 項＋快速掃描 9 項＝28 項）
全 28 項通過（文本階段適用項）。

### 對位逐頁比對
三檔各抽 2 頁，零違反。
- 5-6: P03（ZIP!＝聲音負載、tummy funny＝內心）、P08（caught sunlight＝時間＋動作、Shh,shh,shh＝聲音）
- 3-5: P05（sat on grass, not looking＝心理狀態、creak＝聲音）、P07（台詞＋疊句＋擬聲）
- 2-3: P03（ZIP!＋creak＝聲音）、P05（walked＝場景轉換、Shh＝聲音）

### concept fidelity 逐檔判定
- 5-6: ✓ 孩子帶走「搶→失敗→沙漏工具→輪流→主動讓出」完整弧線
- 3-5: ✓ 濃縮版保留核心衝突→工具→讓出
- 2-3: ✓ 電報式骨架保留疊句＋讓出

### 模式 B 回譯偏移
回譯 31 頁完成（S4A 逐頁全量），偏移分佈：
- 無：18 頁
- 輕微：10 頁
- 中度：3 頁（5-6 P11、3-5 P09、2-3 P08 — 高潮頁 vicarious joy→patience 偏移，概念層，轉 STEP 4 分診）

### ESL 獵手
母語資深編輯人格獨立審查（雙獵物：ESL 翻譯腔＋AI 機械句）。零發現——文本完全像美國原創童書，無 ESL calque、無搭配詞錯誤、無 AI 機械句型。抽驗盲稿讀序聲明：句法結構無逐句對位痕跡，判讀序聲明可信。

## STEP 3 人設 blind QA

### en-US-teacher（Ms. Rivera）

#### 逐句挑錯

| 檔位 | 頁 | 原句 | 問題 | 嚴重度 | 建議 |
|---|---|---|---|---|---|
| 5-6 | P10 | "Last time, Waddle counted for Dash" | 時間轉場令 5 歲幼兒困惑 | 中 | 改 "Before" 或去時間標記 |
| 3-5 | P04 | "Neither of them knew what to do." | 像在教訓不像講故事 | 中 | 改為行為呈現 |
| 2-3 | P05 | 從 P04→P05 缺少悲傷節拍 | 情緒過渡跳接 | 中 | D-4 結構性，見 STEP 4 |
| 2-3 | P08 | 只有兩行 | 高潮頁翻太快 | 中 | 考慮補文字 |

#### 分檔評分

| 維度 | 5-6 | 3-5 | 2-3 | 摘要分 |
|---|---|---|---|---|
| 年齡適配度 | 8 | 8 | 6 | **6** |
| 朗讀口感 | 8 | 8 | 7 | **7** |
| 孩子抓得住度 | 9 | 8 | 7 | **7** |

### en-US-parent（Jessica）

#### 逐句挑錯

| 檔位 | 頁 | 原句 | 問題 | 嚴重度 | 建議 |
|---|---|---|---|---|---|
| 5-6 | P10 | "Last time" | 時間跳躍不自然 | 中 | 簡化時間標記 |
| 2-3 | P08 | 只有兩行 | 高潮頁稀疏 | 中 | 見 STEP 4 |
| 2-3 | P09 | "And from that day on" | 缺夕陽 wind-down | 低 | 2-3 預算已滿 |

#### 分檔評分

| 維度 | 5-6 | 3-5 | 2-3 | 摘要分 |
|---|---|---|---|---|
| 睡前適讀性 | 8 | 8 | 6 | **6** |
| 零說教 | 9 | 9 | 9 | **9** |

### en-US-editor（Margaret）

#### 逐句挑錯

| 檔位 | 頁 | 原句 | 問題 | 嚴重度 | 建議 |
|---|---|---|---|---|---|
| 5-6 | P10 | "Last time" | 節奏散文化 | 低 | "Before" |
| 3-5 | P07 | "I'm sorry I grabbed it" | "it" 跨翻頁代詞歧義 | 低 | 明指 "the swing" |

稱 publication-ready。

#### 分檔評分

| 維度 | 5-6 | 3-5 | 2-3 | 摘要分 |
|---|---|---|---|---|
| 母語自然度 | 9 | 9 | 9 | **9** |
| 文字工藝 | 9 | 8 | 9 | **8** |

## STEP 4 三分法分診

**主題錨復述句**：兔兔和企鵝為鞦韆搶先→嘗試失敗→用沙漏建立輪流規則→主動讓出回合。公平＝大家都被看見。

### 裁決表

| # | 來源 | 檔位 | 頁 | 現象 | 收斂 | 裁決 | 修改級別 | 依據 |
|---|---|---|---|---|---|---|---|---|
| F1 | Rivera(中), Jessica(中), Margaret(低) | 5-6 | P10 | "Last time" 時間歧義 | 3路 | **✅** | 字串級 | "Last time"→"Before"；3 路收斂，spec 無時間連接詞鎖定 |
| F2 | Rivera(中) | 3-5 | P04 | "Neither of them knew what to do" telling-not-showing | 2路(Rivera+E對位) | **✅** | 句級 | →"They just sat there."；行為呈現替代認知陳述 |
| F6 | Margaret(低) | 3-5 | P07 | "I grabbed it" 代詞歧義 | 1路 | **✅** | 字串級 | →"I grabbed the swing"；P06 引入 hourglass 後 "it" 指涉不明 |
| E-1 | E 對位 | 2-3 | P05 | "Shh, shh, shh." 句末缺翻頁鉤子 | 1路(E) | **✅** | 字串級 | →"Shh, shh, shh—"；em dash 對齊 zh-TW P08 翻頁懸念 |
| D-1 | Rivera(中) | 2-3 | P04→P05 | 缺悲傷節拍過渡 | 1路 | **❌** | — | Storyboard 2-3 selection 跳接為設計決策；P05 "walked to the sandbox" 已為場景橋接句 |
| D-2 | Jessica(中), Rivera(中) | 2-3 | P08 | 高潮頁只有兩行 | 2路(+1反Margaret) | **❌** | — | **推翻 2 路收斂。** Storyboard P11 selection note："2-3 電報式只留讓出台詞＋疊句"＝設計決策；Margaret 9/10 反證 |
| D-3 | Jessica(低) | 2-3 | P09 | 缺夕陽 wind-down | 1路 | **❌** | — | Storyboard note："2-3 只留 formula＋疊句"；style_guide §五："收束式＝聽覺睡眠訊號"；87.5/88 預算已滿 |
| D-4 | Rivera(中) | 2-3 | — | 後半節奏引擎熄火 | 1路 | **❌** | — | E 已判 2-3 檔 concept fidelity 通過；電報式語體合法 |
| D-5 | Rivera(低) | 5-6 | P08 | hourglass 是黑箱 | 1路 | **❌** | — | 插圖負責；storyboard P08 image 描述含沙漏 |
| D-6 | Jessica(中) | 5-6 | P12 | "always sang their song" 偏亮 | 1路 | **❌** | — | Brand formula "And from that day on" 已拍板＝收束式必備 |
| D-7 | Rivera(低) | 3-5 | P05 | 壓縮掉猜拳後缺嘗試-失敗節拍 | 1路 | **❌** | — | 選用表凍結；P04 共乘失敗本身即為嘗試-失敗 |
| D-8 | Jessica(低) | 3-5 | P04 | "Neither of them knew what to do" 同 F2 | 與F2合併 | ✅→F2 | — | — |
| E-2 | 回譯中度偏移 | 全檔 | P11/P09/P08 | 高潮 vicarious joy→patience 偏移 | 3頁中度 | **⏸️** | 創作級 | zh-TW 高潮線「我想看你盪」（觀看＝利他快樂）→ en-US "There's always next time"（耐心/充裕心態）。語義核心從利他轉耐心＝concept fidelity 層級，上呈 Stacy |

**獨有訊源分佈**：獵手獨有 real 0 / 回譯獨有 real 1（E-1） / 人設獨有 real 2（F2, F6） / 多路收斂 real 1（F1）

### ⏸️ 上呈批次

**E-2**：高潮頁（5-6 P11、3-5 P09、2-3 P08）的 vicarious joy→patience 偏移。zh-TW 母本的高潮情感核心是「我想看你盪」——觀看對方的快樂本身就是快樂（利他快樂）；en-US 改編為 "There's always next time"（耐心/充裕心態），情感核心從「看你快樂我就快樂」偏移至「夠了就讓出」。這是 concept fidelity 層級的決策，裁決傾向：保留現版（en-US 原生表達「There's always next time」自然且溫暖，patience 與利他快樂在兒童語境中功能近似），但須 Stacy 裁定。
