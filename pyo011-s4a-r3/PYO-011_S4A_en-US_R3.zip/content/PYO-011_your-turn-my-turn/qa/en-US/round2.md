# QA 報告：your-turn-my-turn / en-US / round 2

```yaml
schema: piyo_text_qa_report/v0.9
slug: your-turn-my-turn
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-22"
step1_lint: {exit_code: 0, warnings: 8}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 6, 朗讀口感: 7, 孩子抓得住度: 7}
  - id: en-US-parent
    scores: {睡前適讀性: 6, 零說教: 9}
  - id: en-US-editor
    scores: {母語自然度: 9, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 1}
verdict: escalated
```

**復核輪聲明**：本輪為復核輪（v0.14 擴權）。Round 1 四筆 ✅ 全數 ∈ {字串級, 句級}，符合復核輪資格。人設不重跑，分數沿用 round 1。

## STEP 1 機檢

### copy_check（復核輪全量重跑）
```
python3 .claude/skills/piyo-text-writer/scripts/copy_check.py content/PYO-011_your-turn-my-turn/copy/en-US.md
```
exit 0。警告同 round 1（8 筆帶判定，理由不變）。

修改落地後字數變化：
- 5-6 P10: 43⚠→42⚠（"Last time"→"Before" 減 1 word）
- 3-5 P04: 29⚠→26⚠（"Neither of them knew what to do."→"They just sat there." 減 3 words）
- 3-5 P07: 25✓→26⚠（"it"→"the swing" 加 1 word）
- 2-3 P05: 11✓→11✓（句末 period→em dash，字數不變）

### locale_lint ×3（復核輪全量重跑）
```
locale_lint --pages-file text/en-US/5-6.draft.json --locale en-US --band 5-6  → exit 0
locale_lint --pages-file text/en-US/3-5.draft.json --locale en-US --band 3-5  → exit 0
locale_lint --pages-file text/en-US/2-3.draft.json --locale en-US --band 2-3  → exit 0
```

### 修改逐筆落地驗證（diff 對裁決指定內容核銷）

| # | 裁決指定 | draft.json 實際 | copy 表實際 | 核銷 |
|---|---|---|---|---|
| F1 | 5-6 P10 "Last time"→"Before" | `"Before, Waddle counted for Dash"` | P10 5-6 欄已更新 | ✓ |
| F2 | 3-5 P04 末句→"They just sat there." | `"They just sat there."` | P04 3-5 欄已更新 | ✓ |
| F6 | 3-5 P07 "it"→"the swing" | `"I'm sorry I grabbed the swing. Look!"` | P09 3-5 欄已更新 | ✓ |
| E-1 | 2-3 P05 句末 period→em dash | `"Shh, shh, shh—"` | P08 2-3 欄已更新 | ✓ |

### copy↔draft 同源檢
copy_check exit 0 含同源驗證。

## STEP 2 checklist 自檢

**主題錨復述句**：本書教的是——兔兔 Dash 和企鵝 Waddle 為鞦韆搶先，經歷共乘失敗與冷戰，用沙漏建立「你的回合，我的回合」輪流規則，最終主動讓出自己的回合——「公平不是都一樣，而是大家都被看見」。

**E-lite 複審範圍**（受修頁＋相鄰頁）：
- 5-6: P09, P10*, P11
- 3-5: P03, P04*, P05, P06, P07*, P08
- 2-3: P04, P05*, P06

**E-lite 結果**：四筆修改均 clean，無新問題，無對位違反，與相鄰頁連貫性完整。

**回譯同步**：3 頁重譯完成（5-6 P10、3-5 P04、3-5 P07），drift marker 全部重填（均為輕微），覆蓋率 31/31，無殘留「回修待重譯」。

## STEP 3 人設 blind QA

復核輪不重跑人設。分數沿用 round 1：

| 人設 | 維度 | 摘要分 |
|---|---|---|
| en-US-teacher | 年齡適配度 | 6 |
| en-US-teacher | 朗讀口感 | 7 |
| en-US-teacher | 孩子抓得住度 | 7 |
| en-US-parent | 睡前適讀性 | 6 |
| en-US-parent | 零說教 | 9 |
| en-US-editor | 母語自然度 | 9 |
| en-US-editor | 文字工藝 | 8 |

## STEP 4 三分法分診

**主題錨復述句**：兔兔和企鵝為鞦韆搶先→嘗試失敗→用沙漏建立輪流→主動讓出。公平＝大家都被看見。

復核輪無新裁決對象。Round 1 四筆 ✅ 已全部落地驗證（見 STEP 1 核銷表）。

**⏸️ 沿用**：E-2（高潮 vicarious joy→patience 偏移）從 round 1 帶入，維持 ⏸️ 上呈。

### ⏸️ 上呈批次

**E-2**：高潮頁（5-6 P11、3-5 P09、2-3 P08）的 vicarious joy→patience 偏移。zh-TW 母本的高潮情感核心是「我想看你盪」（觀看對方的快樂本身就是快樂＝利他快樂）；en-US 改編為 "There's always next time"（耐心/充裕心態），情感核心從「看你快樂我就快樂」偏移至「夠了就讓出」。裁決傾向：保留現版（en-US 原生表達自然且溫暖，patience 與利他快樂在兒童語境中功能近似），須 Stacy 裁定。
