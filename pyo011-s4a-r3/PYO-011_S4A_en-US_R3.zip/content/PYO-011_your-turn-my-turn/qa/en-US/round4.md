# QA 報告：your-turn-my-turn / en-US / round 4

```yaml
schema: piyo_text_qa_report/v0.9
slug: your-turn-my-turn
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 4
date: "2026-07-23"
step1_lint: {exit_code: 0, warnings: 21}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 6, 朗讀口感: 7, 孩子抓得住度: 7}
  - id: en-US-parent
    scores: {睡前適讀性: 6, 零說教: 9}
  - id: en-US-editor
    scores: {母語自然度: 9, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

**本輪性質**：Stacy gate4 R2 審包返「不通過——剩 1 項文字修改＋1 項 R3 提交附件」。本輪為復核輪：P07 修改落地驗證＋機檢全量重跑＋受修頁 E-lite＋回譯同步。人設不重跑，分數沿用 round 1。

## STEP 1 機檢

### copy_check（全量重跑）
```
python3 .claude/skills/piyo-text-writer/scripts/copy_check.py content/PYO-011_your-turn-my-turn/copy/en-US.md
```
exit 0。警告 13 筆明細：

**超帶上緣（11 筆）**：

| 檔位 | 頁 | 字數 | 帶頂 | 理由 |
|---|---|---|---|---|
| 3-5 | P04 | 26 | 25 | CREEAK 喜劇能量＋They just sat there 行為呈現 |
| 5-6 | P08 | 48 | 40 | 發現頁完整動態（翻轉重複拍×2＋沙沙沙×2＋翻頁懸念） |
| 3-5 | P06 | 28 | 25 | 道歉＋展示＋規則＋疊句＋擬聲＝五負載不可缺一 |
| 5-6 | P09 | 43 | 40 | 道歉展示＋規則＋疊句首拍＋雙擬聲＋「忘了你也在等」 |
| 3-5 | P07 | 26 | 25 | 數 1-2-3 回合＋kicked the sky＋tummy hurt |
| 5-6 | P10 | 41 | 40 | B2 新增 action-interrupt hook "raised his hand—" |
| 3-5 | P08 | 28 | 25 | 數 1-2-3＋kicked＋tummy hurt＋refrain＋hook |
| 5-6 | P11 | 41 | 40 | CLIMAX 五聲部（讓出＋驚喜＋refrain＋vicarious joy＋互惠） |
| 3-5 | P09 | 34 | 25 | CLIMAX 四聲部＋互惠承諾 |
| 5-6 | P12 | 41 | 40 | 收束頁 brand formula＋溜滑梯＋沙漏＋疊句 |
| 3-5 | P10 | 33 | 25 | 收束頁 formula＋slide＋hourglass＋refrain |

**低於帶下緣（2 筆）**：

| 檔位 | 頁 | 字數 | 帶底 | 理由 |
|---|---|---|---|---|
| 2-3 | P03 | 9 | 10 | R3 微調 "sat on the swing"→"took the swing"（-1w total 預算）；電報式三事實句合法 |
| 2-3 | P04 | 9 | 10 | 電報式 "Stuck!" 一字收喜劇拍 |

### locale_lint ×3（全量重跑）

**5-6**（2 warnings）：
1. `[repeat_discount]` "Your turn, my turn!" ×2（P09,P12）第 2 次起 ×0.25
2. `[repeat_discount]` 折計 420 → 417

**3-5**（2 warnings）：
1. `[repeat_discount]` "Your turn, my turn!" ×3（P07,P08,P10）第 2 次起 ×0.25
2. `[repeat_discount]` 折計 248 → 242

**2-3**（4 warnings）：
1. `[max_sentence_len] [frozen]` P09 句長 11 > 上限 8——品牌凍結單元 "And from that day on, they sang:" 豁免
2. `[repeat_discount]` "Creak, creak!" ×2（P03,P06）第 2 次起 ×0.25
3. `[repeat_discount]` "Your turn, my turn!" ×4（P06,P07,P08,P09）第 2 次起 ×0.25
4. `[repeat_discount]` 折計 98 → 87.5 ≤ 88

**全 21 筆 warnings 與 karaoke 斷行關聯說明**：
- repeat_discount 警告（6 筆）：疊句 "Your turn, my turn!" 三檔重複＝design 宣告的核心輪流口號，非冗餘——karaoke 渲染逐詞高亮，重複句型不影響斷行
- brand frozen 句長豁免（1 筆）：P09 收束式句長超限但為品牌凍結公式，TTS 一口氣唸完、karaoke 不斷行
- 超帶上緣（11 筆）：均為該頁功能負載密集（CLIMAX/收束/發現/道歉）；行數≤4，karaoke 斷行照 `\n` 分行——每行 ≤15 words，渲染安全
- 低於帶下緣（2 筆）：2-3 電報式短頁，karaoke 單行高亮反而效果更佳
- 新增行偏長明細（R3 scope 內）：2-3 P07 L1 "Dash swung! One, two, three — switch!" = 6 words/行，不觸 karaoke 斷行問題

### Stacy 指示修改逐筆落地驗證

| # | Stacy 指示 | 影響檔位 | 落地內容 | 核銷 |
|---|---|---|---|---|
| R3-1 | 2-3 P07（母版 P10）刪 "Waddle kicked the sky!" → 改寫 Dash 前一回合 | 2-3 | "Dash swung! One, two, three — switch!\n\"Your turn, my turn!\"\nThe sand ran out—"（14w exactly） | ✓ |

**附帶 total 預算微調**（P07 +2w → raw 100 → effective 89.5 > 88；需 -2w elsewhere）：

| 頁 | 修改 | 字數 | 理由 |
|---|---|---|---|
| P02 | "An empty swing!" → "Empty swing!" | 11→10 | 2-3 電報式刪冠詞更俐落 |
| P03 | "Dash sat on the swing" → "Dash took the swing" | 10→9 | "took" 比 "sat on" 動作性更強，2-3 風格更乾脆 |

### copy↔draft 同源檢
copy_check exit 0 含同源驗證。

## STEP 2 checklist 自檢

**主題錨復述句**：本書教的是——兔兔 Dash 和企鵝 Waddle 為鞦韆搶先，經歷共乘失敗與冷戰，用沙漏建立「你的回合，我的回合」輪流規則，最終主動讓出自己的回合——「公平不是都一樣，而是大家都被看見」。

**E-lite 複審範圍**（受修頁＋相鄰頁；僅 2-3 受修）：
- 2-3: P01, P02*, P03*, P04, P06, P07*

**E-lite 結果**：

1. **對位原則**：P07 新句 "Dash swung! One, two, three — switch!" 為動作敘事＋聲音（計數＝口語動作），非視覺屬性重述。Stacy 指示依據＝「插畫已示企企踢天空，文字該承載圖不能表達的 Dash 前一回合」——圖文分工精確對位。
2. **concept fidelity**：P07 新文字直接呈現輪流機制運作（數 1-2-3→換），比原句更緊扣主題錨「輪流也好玩」。concept fidelity 全檔通過。
3. **相鄰頁連貫性**：P06→P07（規則建立→規則執行）流暢；P07→P08（沙漏漏完→讓出高潮）鉤子完整。P02→P03 "Empty swing→took the swing" 動作銜接自然。
4. **P02/P03 微調語感**："Empty swing!" 電報式比 "An empty swing!" 更有發現感；"Dash took the swing" 比 "sat on" 更有搶先的動作張力——均為 2-3 風格優化，非砍字湊數。

**回譯同步**：3 頁重譯完成（2-3 P02/P03/P07）。P07 偏移標記由 E 重填：
- P07：輕微（Stacy R3 指示改文字承載 Dash 前一回合動作，與 zh-TW 母版同拍——核心「1-2-3→換」到位）
- P02/P03：無偏移（微詞調整不影響語義）

覆蓋率：31/31（三檔頁數 12+10+9），無殘留「回修待重譯」。

## STEP 3 人設 blind QA

Stacy gate 指示修改輪，人設不重跑。分數沿用 round 1。

## STEP 4 三分法分診

**主題錨復述句**：兔兔和企鵝為鞦韆搶先→嘗試失敗→用沙漏建立輪流→主動讓出。公平＝大家都被看見。

本輪無新裁決對象。✅=0, ❌=0, ⏸️=0。

## R3 附件

### 附件 1：Registry 補登確認

**commit ref**：`4b6bad4`（2026-07-23）——PYO-015 S4 R1 五維審修改 commit 同步寫入。

**character_names.md 新增內容**：
- 書名列：`your-turn-my-turn | 輪到你，輪到我（提案）| | Your Turn, My Turn（提案·S4A en-US 盲稿）`
- 角色段落：`## 輪到你，輪到我（your-turn-my-turn）`
  - `dash | 兔兔（提案）| | Dash（提案·S4A en-US 盲稿）`
  - `waddle | 企企（提案）| | Waddle（提案·S4A en-US 盲稿）`

**onomatopoeia_map.md 新增 3 場景鍵**：
1. `衝刺搶先（your-turn-my-turn）`：zh-TW `咻——`（P03）→ en-US `ZIP!`（O1 全大寫）
2. `鞦韆嘎吱（your-turn-my-turn）`：zh-TW `嘎吱嘎吱`（P03/P04/P07/P09/P10）→ en-US `creak, creak`（O4 小寫逗號雙連）；強調形 `CREEAK!`（P04，O1+O2）
3. `沙漏流沙（your-turn-my-turn）`：zh-TW `沙沙沙`（P08/P09/P10/P11）→ en-US `Shh, shh, shh`（O4 節奏三連）

**咻—— 拉長符號合規檢查**：
- 字形＝ U+54BB `咻` + U+2014 `—` × 2（標準 CJK em dash pair）
- 用途＝trailing-off mark（聲音漸遠），非母音延長
- Registry 既有先例：`呼——`（深呼吸·wait-little-volcano）、`唰啦——`（花瓣受風·different-spots）——同一慣例
- Registry 腳註「拉長符號一律為全形 `～` U+FF5E」適用於 golden corpus 母音延長場景（如 `ふう～～～っ`）；`——` 用於 trail-off 場景，功能語法不同，不衝突
- **結論：合規**

### 附件 2：Lint 21 項 warnings 全明細

見 STEP 1 機檢節——逐筆列出 copy_check 13 筆 + locale_lint 8 筆 = 21 筆 warnings，每筆附理由與 karaoke 斷行關聯判定。

R2 為 16 筆 → R3 為 21 筆，差異原因：
- copy_check +1：P03 2-3 新增 band 下緣警告（9 < 10，R3 total 預算微調所致）
- copy_check 重分類：R2 分類有遺漏（10 超帶 + 1 低帶 = 11，實際 12）→ R3 精確：11 超帶 + 2 低帶 = 13
- locale_lint 不變：8 筆
