# 圖文總表：Your Turn, My Turn（your-turn-my-turn / en-US）

> 模式 B＝locale 改編（S4A en-US，**改編不是翻譯**——讀設計文件後用英文重新講一次故事；
> zh-TW 定稿是參考素材、不是對位基準）。
> 頁面選用**完全繼承** storyboard 三檔選用表（照抄進檔頭 selection，不得自選、自增、自刪）；
> 一頁一圖：每檔每頁恰用一張圖、用圖序號嚴格遞增；未用圖三欄一律填「—」。
> 文字的專屬負載＝聲音、台詞、內心、時間；不重述圖已明示的視覺事實。
> 字數瞄準目標帶**中值**，不貼帶頂、不打太滿。

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: your-turn-my-turn
locale: en-US
mode: B
storyboard: content/PYO-011_your-turn-my-turn/PYO-011_storyboard.md
design: content/PYO-011_your-turn-my-turn/PYO-011_design.md
image_pool: 12
selection:
  "3-5": [P01, P02, P03, P04, P07, P08, P09, P10, P11, P12]
  "2-3": [P01, P02, P03, P04, P08, P09, P10, P11, P12]
commitments:
  refrain: "Your turn, my turn!"
  ending:
    "5-6": "And from that day on, wherever they played, Dash and Waddle always sang their song:"
    "3-5": "And from that day on, they always sang their song:"
    "2-3": "And from that day on, they sang:"
  onomatopoeia: [ZIP!, "Shh, shh, shh", "creak, creak", CREEAK!]
characters: [Dash, Waddle]
```

### B0 語感基建卡

**疊句三變奏提案**（英文原生重建，非逐字翻譯）：

| # | 提案 | 節奏分析 | 選用理由 |
|---|---|---|---|
| A（選定） | Your turn, my turn! | 4 words, 兩個平衡 trochaic 拍（YOUR-turn / MY-turn），playground chant 天然節奏 | 最短、最可跟唸、P11 高潮語義翻轉完美運作（Dash 在自己回合說 "your turn"） |
| B | Your turn now, my turn now! | 6 words, 三拍重複結構 | 更明確但冗長，跟唸負擔重 |
| C | You go, I go! | 4 words, 動詞驅動 | 動作感強但失去 turn-taking 概念精準度 |

**擬聲詞凍結字串表**（en-US 原生重建）：

| # | 動作 | zh-TW motif | en-US 凍結字串 | 格式 | 規則依據 |
|---|---|---|---|---|---|
| 1 | 兔兔衝刺 | 咻—— | `ZIP!` | 獨立效果行 ALL CAPS | O1 |
| 2 | 沙漏沙流 | 沙沙沙 | `shh, shh, shh` | 節奏三連 lowercase | O4 |
| 3 | 鞦韆盪 | 嘎吱嘎吱 | `creak, creak` | 節奏雙連 lowercase | O4 |
| 4 | 鞦韆吱嘎（強調） | 嘎吱嘎吱 | `CREEAK!` | 獨立效果行 ALL CAPS 拉長 | O1+O2 |
| 5 | 企企搖擺走 | 搖呀搖 | waddled（動詞融入敘事） | 非獨立擬聲 | zh-TW 同為描述性 |

**角色口癖卡**：

| 角色 | en-US 名 | 說話風格 | 代表性句式 |
|---|---|---|---|
| dash | Dash | 短促驚嘆句、動作詞先行、衝動但心軟 | "Me first!" / "Hop on!" / "I'm sorry" / "One more for you!" |
| waddle | Waddle | 稍完整句式、講道理、規則至上但偷偷好玩 | "No, me first!" / "Rock, paper, scissors!" / "Rules are rules!" / "You go first." |

**收束式**："And from that day on, wherever they played, Dash and Waddle always sang their song: / Your turn, my turn!"（使用 en-US brand frozen formula "And from that day on"）

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Dash threw the ball. Waddle caught it and threw it back.<br>Back and forth, back and forth — they never, ever missed. | 21✓ | 1 | Dash threw the ball. Waddle caught it and threw it back.<br>Back and forth, back and forth. | 17✓ | 1 | Dash threw the ball.<br>Waddle threw it back.<br>Back and forth! | 11✓ | ✓ | 5-6 用 "never, ever missed" 強化已建立的輪替節奏；3-5 簡化去強調詞；2-3 電報式三拍，"back and forth" 保留節奏錨 |
| P02 | 2 | Then they spotted something — an empty swing!<br>They both ran for it at once.<br>"Me first!" shouted Dash.<br>"No, me first!" shouted Waddle. | 23✓ | 2 | Then they spotted it — an empty swing!<br>"Me first!" shouted Dash.<br>"No, me first!" shouted Waddle. | 16✓ | 2 | Empty swing!<br>"Me first!" said Dash.<br>"Me first!" said Waddle. | 10✓ | ✓ | 3-5 砍中間跑步旁白；2-3 電報式，shouted→said 簡化語感，"No" 省略讓雙方台詞鏡像；R3 微調刪冠詞（2-3 電報式更俐落＋total 字數預算） |
| P03 | 3 | ZIP! Dash got there first.<br>He hopped onto the seat and pushed off — creak, creak — higher and higher!<br>But then he looked down. Waddle was still standing there.<br>Dash's tummy felt funny. | 32✓ | 3 | ZIP! Dash got there first.<br>Creak, creak — he swung higher and higher.<br>Waddle was still standing there. Dash's tummy felt funny. | 21✓ | 3 | ZIP! Dash took the swing.<br>Creak, creak!<br>Waddle waited. | 9✓ | ✓ | ZIP! + creak 三檔一致；5-6 保留 hopping/pushing 動態 + 內心 tummy；3-5 砍動態細節保結果；2-3 電報式只留三個事實句，內心交圖；R3 微調 "sat on"→"took"（-1w, 2-3 更乾脆動作動詞＋total 字數預算） |
| P04 | 4 | "Hop on!" said Dash. "We can share!"<br>They squeezed together on the tiny seat. Waddle held on tight. Dash held on tighter.<br>The swing didn't budge. Not one bit.<br>CREEAK! The seat tilted sideways, and they almost slid right off! | 40✓ | 4 | "Hop on!" said Dash. "We can share!"<br>They squeezed onto the seat together. The swing didn't budge.<br>CREEAK! They almost slid off!<br>They just sat there. | 26⚠ | 4 | "Hop on!" said Dash.<br>They squeezed together. CREEAK! Stuck! | 9✓ | ✓ | 5-6 喜劇能量完整（tighter/不動/tilted）；3-5 精簡保留 CREEAK 笑點；QA F2 修正：末句改為行為呈現（showing）替代認知陳述（telling）；2-3 電報式 "Stuck!" 一字收喜劇 |
| P05 | 5 | "I know!" said Waddle. "Rock, paper, scissors — winner goes first!"<br>They played. Waddle won.<br>Waddle waddled right to the swing. Dash sat down to wait.<br>He kicked the dirt. And kicked. And kicked some more. | 35✓ | — | — | — | — | — | — | ✓ | 5-6 only（猜拳支線）；kicked × 3 遞進傳達焦躁；waddled 融入敘事替代獨立擬聲 |
| P06 | 6 | "You've been on there forever!" Dash shouted.<br>"I won fair and square!" Waddle said. "Rules are rules!"<br>They argued and argued until neither one wanted to play anymore.<br>The swing sat empty. | 32✓ | — | — | — | — | — | — | ✓ | 5-6 only（爭吵頁）；"Rules are rules" 傳達企企規則固執；"swing sat empty" 事件收束非視覺重述 |
| P07 | 7 | Neither of them said a word.<br>They sat on the grass, back to back. The empty swing creaked in the wind.<br>Creak… creak… | 23✓ | 5 | They sat on the grass, not looking at each other.<br>The empty swing creaked in the wind.<br>Creak… creak… | 19✓ | — | — | — | ✓ | 5-6 冷戰低谷（back to back + 沉默）；3-5 改為「不看彼此」承接共乘失敗的悶悶；2-3 跳過（跳接 P04→P08 由 P08 橋接句處理） |
| P08 | 8 | Dash turned his head. Over by the sandbox, something caught the sunlight — a little hourglass!<br>He picked it up and flipped it over. Shh, shh, shh — the sand trickled down.<br>It ran out! He flipped it again. Shh, shh, shh — it started all over.<br>Dash's eyes went wide— | 48⚠ | 6 | Dash turned his head. By the sandbox — a little hourglass!<br>He flipped it over. Shh, shh, shh. It ran out! He flipped it again.<br>Dash's eyes went wide— | 28⚠ | 5 | Dash walked to the sandbox.<br>An hourglass!<br>Shh, shh, shh— | 10✓ | ✓ | S4 R1 修正：5-6/3-5 補翻轉重複拍（沙漏流完→再翻→又開始），對齊 zh-TW P08 二度翻轉；5-6 保留發現過程（picked up/flipped/trickled）；3-5 精簡保留驚喜節奏；2-3「Dash walked to the sandbox」為 P04→P08 場景橋接句（承接共乘失敗後離開鞦韆走到沙坑）；B2 校準：三檔句末 period→em dash 對齊 zh-TW P08 翻頁懸念「兔兔的眼睛亮了——」（QA E-1 修正：2-3 補 em dash 懸念標記） |
| P09 | 9 | "Waddle, I'm sorry — I forgot you were waiting, too," said Dash. "Look what I found!"<br>He held up the hourglass. "When the sand runs out, we switch!"<br>"Your turn, my turn!"<br>Waddle grabbed the rope and pushed off — creak, creak!<br>Shh, shh, shh. | 43⚠ | 7 | "Waddle, I'm sorry I grabbed the swing. Look!"<br>Dash held up the hourglass. "When the sand runs out, we switch!"<br>"Your turn, my turn!"<br>Creak, creak! | 26⚠ | 6 | "Sorry! Sand out — switch!"<br>"Your turn, my turn!"<br>Creak, creak! | 10✓ | ✓ | S4 R1 修正：5-6 道歉加「忘了你也在等」（對齊 zh-TW P09 具體道歉）；2-3 規則句替代模糊 "Let's try!"（對齊 zh-TW P06 沙漏規則說明）；R2 2-3 壓縮：drop "said Dash"＋"Sand out"電報式（word budget -1 offset）；5-6 完整道歉 + 規則說明 + 疊句首拍 + 雙擬聲；3-5 道歉改為「搶了鞦韆」（QA F6 修正：消除翻頁代詞歧義）；2-3 電報式道歉 + 疊句 + 擬聲 |
| P10 | 10 | Before, Waddle counted for Dash — "One, two, three!"<br>Now it was Dash's turn to count.<br>Waddle kicked the sky with his little feet — and Dash laughed so hard his tummy hurt!<br>"Your turn, my turn!" they sang.<br>Dash raised his hand— | 41⚠ | 8 | Waddle counted for Dash — "One, two, three!"<br>Now Dash waited. Waddle kicked the sky!<br>Dash laughed until his tummy hurt.<br>"Your turn, my turn!"<br>Dash raised his hand— | 28⚠ | 7 | Dash swung! One, two, three — switch!<br>"Your turn, my turn!"<br>The sand ran out— | 14✓ | ✓ | S4 R3 Stacy 指示：2-3 刪 "Waddle kicked the sky!"（插畫已示企企踢天空）、改寫 Dash 前一回合動作「數 1-2-3→換」——文字承載圖不能表達的前因（讀者聽到的是 Dash 盪完的交接，圖承載 Waddle 接棒）；5-6/3-5 不變：5-6 "wait"→"count"（R1）、5-6/3-5 "raised his hand"（R1）；B2 校準三檔翻頁鉤子不變 |
| P11 | 11 | The sand ran out. It was Dash's turn.<br>But Dash didn't hop on.<br>"One more for you!" he said.<br>Waddle blinked. "Really?"<br>"Your turn, my turn." Dash smiled. "I want to watch you swing!"<br>"Next time," said Waddle, "you go first." | 41⚠ | 9 | The sand ran out. Dash's turn!<br>But Dash didn't hop on. "One more for you!"<br>"Your turn, my turn." Dash smiled. "I want to watch you swing!"<br>"Next time," said Waddle, "you go first." | 34⚠ | 8 | "One more for you!"<br>"Your turn, my turn!"<br>"I want to watch you swing!" | 14✓ | ✓ | CLIMAX；S4 R1 E-2 裁定（Option A）：三檔高潮統一為 "I want to watch you swing!"（vicarious joy 對齊 zh-TW「我想看你盪」——觀看對方的快樂本身就是快樂）；5-6 完整：讓出 + 驚喜 + vicarious joy + 互惠承諾；3-5 補 Dash smiled. "I want to watch you swing!"；R2 2-3：drop reciprocal "You go first!"（14w per-page hard limit；互惠保留在 5-6/3-5）；refrain "."→"!" 統一 repeat_discount 使 total ≤88 |
| P12 | 12 | As the sun set, Dash and Waddle walked toward the slide.<br>They left the hourglass by the swing, for the next friend.<br>And from that day on, wherever they played, Dash and Waddle always sang their song:<br>"Your turn, my turn!" | 41⚠ | 10 | As the sun set, Dash and Waddle walked toward the slide.<br>They left the hourglass for the next friend.<br>And from that day on, they always sang their song:<br>"Your turn, my turn!" | 33⚠ | 9 | And from that day on, they sang:<br>"Your turn, my turn!" | 11✓ | ✓ | 收束頁三檔均含 brand frozen formula "And from that day on" + 疊句收尾；5-6 完整（走向溜滑梯 + 沙漏留給下個朋友 + 收束式）；3-5 精簡但保 slide + hourglass + formula；2-3 只留 formula + 疊句 |
