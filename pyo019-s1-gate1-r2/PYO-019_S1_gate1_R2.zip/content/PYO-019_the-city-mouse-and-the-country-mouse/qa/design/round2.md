# 設計 QA 報告：the-city-mouse-and-the-country-mouse / design / round 2

```yaml
schema: piyo_design_qa_report/v0.9
slug: the-city-mouse-and-the-country-mouse
stage: S1
round: 2
date: "2026-07-28"
step3_check: {exit_code: 0, warnings: 1}
concept_fidelity: pass
theme_engine: pass
reviewer: {pass: 10, fail: 0}
triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

## R1 修改摘要（Stacy 指示 4 項＋備註 1 項）

1. **P12 收尾接回關係**：加「也照著遠遠的城市」——城鄉同框月光收束
2. **疊句 P07 補回**：refrain.beats 改為 [P05,P06,P07,P08]；P07 翻頁拉力改「疊句接龍前半」；theme_cycles 第二輪 P06/P07 各一次疊句明確對齊
3. **禾禾 lock features 補短尾搖晃**：增 `short stubby tail, wobbly side-to-side waddle`、straw hat 改 `small round straw hat`
4. **P11 旁白替角色說結論**：刪「特別安心」只留「特別香。」
5. **（備註2）§6 2-3 檔措辭**：「一至兩次」改「至少兩次」

## 主編審核

**主題錨復述句**：本書屬「自我認知」主題域、「接受獨特性／做自己」子主題，目標能力為「辨認並說出我喜歡的（生活方式）——從體驗對比中發現自己的偏好」。

| # | 維度 | 判定 | 證據（引 §/P 位） | 修改方向 |
|---|---|---|---|---|
| ① | 主題錨符合度 | pass | §0A story_engine 論證 target_ability 在高潮不可替代；climax_irreplaceability 論證若拿掉 target_ability 高潮因果斷裂；forbidden_substitutes 排除勇氣與友誼兩條滑坡路徑。theme_cycles 三個週期展示偏好從未辨識→浮現→做出選擇的完整遞進。 | — |
| ② | 節奏 | pass | §5 pace_curve P07 最快→P08 最慢形成全書最強烈節奏落差，精準服務蛻變一拍。P01-P02 中速→P05-P07 連續加速→P08 急煞→P11-P12 最慢沉澱，呼吸節奏清晰。 | — |
| ③ | 趣味 | pass | §5 humor 三型齊備：認知落差 P04、身體笑話 P06、失控升級 P07。5 個不同擬聲詞。三次驚嚇的狼狽後果逐級升級，笑點來自身體而非語言嘲弄。 | — |
| ④ | 角色豐滿度 | pass | §1 兩角色均有反差記憶點。禾禾可愛缺點→溫柔後果→蛻變弧線完整。亮亮暗面層次（「沒關係」＝習慣了隨時躲藏）。主角數 2 ≤ 上限 3。 | — |
| ⑤ | 結構完整與敘事型忠實 | pass | 成長旅程＋三次嘗試嵌入。三幕完整。結尾四件套全備（①P09 同框②P09 感謝交換③P11 前瞻意願句④P12 收束語）。12 頁在 5-6 合法範圍。 | — |
| ⑥ | AI 套路與說教感 | pass | 核心教訓僅限 P08 對白＋P11 意願句，旁白層零說教。metaphor_rules 嚴格城鄉中性，亮亮結尾台詞防止城市被貶低。P11 角色自述偏好而非道德宣言。 | — |
| ⑦ | 三歲測試四步 | pass | 全部具象動作無抽象概念。因果簡單單鏈。§6 2-3 取捨方向砍掉旅途/內心覺察/道別細節，留核心循環＋疊句。 | — |
| ⑧ | 情緒強度適齡帶 | pass | 驚嚇來源全部去牙化（聲音/影子/機械）。後果為喜劇性，無疼痛受傷。P08 短暫哭泣即轉堅定。§6 三檔降級合理。 | — |
| ⑨ | 重複句記憶規律 | pass | 疊句 4 次 [P05,P06,P07,P08]，P08 變體從驚嘆轉為決定性感受。三次嘗試 beats=[P05,P06,P07] count=3 符合配額。每次形成固定節拍，幼兒可預期。 | — |
| ⑩ | 自然邏輯＋文化 | pass | 食物文化中性。城鄉價值嚴格中立（亮亮 P09 台詞＋metaphor_rules）。歸途路線與去程鏡像對稱。P01/P11 同場景同食物首尾呼應。場景 4 處 ≤6。 | — |

## 分診

10/10 pass，無 fail 項。✅ 真問題 = 0 → 一輪收斂。

機檢警告 1 筆（城市大宅連續 5 拍 P04-P08）：同 round 1——敘事結構所需，城市段三次驚嚇遞進＋蛻變時刻均發生在同一華麗餐廳場景，場景連續但驅動力逐拍不同，畫面重複風險由 S2 分鏡細化構圖多樣性控管。
