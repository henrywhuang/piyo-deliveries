# 圖文總表：The City Mouse and the Country Mouse（the-city-mouse-and-the-country-mouse / en-US）

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: the-city-mouse-and-the-country-mouse
locale: en-US
mode: B
storyboard: content/PYO-019_the-city-mouse-and-the-country-mouse/PYO-019_storyboard.md
design: content/PYO-019_the-city-mouse-and-the-country-mouse/PYO-019_design.md
image_pool: 12
selection:
  "3-5": [P01, P02, P04, P05, P06, P07, P08, P09, P11, P12]
  "2-3": [P01, P02, P05, P06, P07, P08, P11, P12]
commitments:
  refrain: "So yummy… but so scary!"
  ending: "And from that day on…"
  onomatopoeia: ["Crunch, crunch, crunch", STOMP STOMP STOMP!, MEOW!, BUZZZZZ!, "Thump-thump, thump-thump"]
characters: [Nibble, Glitz]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Crunch, crunch, crunch.<br>Nibble was eating her breakfast, nice and quiet.<br>"Nibble!" Glitz popped his head through the door.<br>"The city has sooo many yummy things! Come with me!" | 29✓ | 1 | Crunch, crunch, crunch.<br>Nibble was eating her breakfast.<br>"Nibble!" Glitz popped in.<br>"The city has sooo many yummy things! Come with me!" | 22✓ | 1 | Crunch, crunch, crunch.<br>"Yummy things in the city! Let's go!" said Glitz. | 12✓ | ✓ | 三檔共享 crunch×3 開場音效；2-3 精簡直入，省去 Nibble 早餐描述（圖已示） |
| P02 | 2 | Nibble wasn't so sure.<br>She had never been to the city before!<br>"Okay… I'll come and see!"<br>Off went two little mice. | 22✓ | 2 | Nibble had never been to the city!<br>"Okay… I'll come and see!"<br>Off they went. | 15✓ | 2 | Nibble had never been to the city.<br>Off she went with Glitz! | 12✓ | ✓ | 5-6 保留猶豫＋決定完整弧線；3-5 精簡猶豫；2-3 電報式——never been 提供首次離家語境 |
| P03 | 3 | They walked and walked and walked.<br>The houses grew taller, the lights grew brighter, the streets grew louder.<br>"So big!" Nibble looked up and up and up. | 27✓ | — | — | — | — | — | — | ✓ | 3-5/2-3 跳此頁。5-6 triple escalation（grew taller/brighter/louder）對應分鏡三段遞進 |
| P04 | 4 | "Here we are!" Glitz said proudly.<br>Nibble's mouth fell open. She couldn't say a word.<br>So big, so big…<br>Everything was sooo big! | 23✓ | 3 | They walked and walked. "Here we are!" said Glitz.<br>Nibble's mouth fell open.<br>So big, so big…<br>Everything was sooo big! | 21✓ | — | — | — | ✓ | 3-5 橋接跳 P03：補「They walked and walked」承接旅程（對位 zh-TW 3-5「走了好久好久」）；2-3 跳此頁 |
| P05 | 5 | A great big cake! Nibble was just about to take a bite—<br>STOMP STOMP STOMP! STOMP STOMP STOMP!<br>Giant footsteps!<br>"So yummy… but so scary!" | 25✓ | 4 | A big cake! Nibble was about to bite—<br>STOMP STOMP STOMP!<br>"So yummy… but so scary!" | 16✓ | 3 | In the city! A big cake!<br>STOMP STOMP STOMP!<br>"So yummy… but so scary!" | 14✓ | ✓ | 疊句#1；5-6 雙連 STOMP（對位 zh-TW 碰碰碰×2）；3-5 單連；2-3 橋接跳 P03-P04：補「In the city!」確立場景轉換（對位 zh-TW 2-3「到了城市」） |
| P06 | 6 | Glitz found a plate of cheese. Nibble took one tiny lick—<br>MEOW! A giant shadow!<br>Nibble tumbled headfirst into the cream!<br>"So yummy… but so scary!" | 26✓ | 5 | Cheese! Nibble took a tiny lick—<br>MEOW! A giant shadow!<br>Nibble tumbled into the cream!<br>"So yummy… but so scary!" | 20✓ | 4 | Cheese!<br>MEOW! A big shadow!<br>"So yummy… but so scary!" | 10✓ | ✓ | 疊句#2；2-3 省去奶油摔（圖已示），保留影子驚嚇（對位 zh-TW 2-3「好大的影子」） |
| P07 | 7 | Glitz found a fruit tart! Nibble climbed right up—<br>BUZZZZZ!<br>Tipped over! Cream everywhere! Two little mice ran and ran—<br>"So yummy… but so scary!" | 25✓ | 6 | Fruit tart! Nibble climbed up—<br>BUZZZZZ!<br>Tipped over! Two mice ran and ran—<br>"So yummy… but so scary!" | 18✓ | 5 | Fruit tart!<br>BUZZZZZ!<br>They ran and ran and ran—<br>"So yummy… but so scary!" | 14✓ | ✓ | 疊句#3；「ran and ran—」em dash 為翻頁鉤子（動作中斷型，對位分鏡 P07 hook）；2-3 triple ran Rule of Three |
| P08 | 8 | Thump-thump, thump-thump.<br>Nibble's heart was pounding so fast.<br>"So yummy… but I don't feel safe."<br>"I want to go home," Nibble whispered. | 22✓ | 7 | Thump-thump, thump-thump.<br>"So yummy… but I don't feel safe.<br>I want to go home." | 14✓ | 6 | Thump-thump, thump-thump.<br>"So yummy… but I don't feel safe."<br>"I want to go home." | 14✓ | ✓ | 疊句變奏 P08（scary→not safe）：外部恐懼→內在安全感蛻變。5-6 加心跳描寫＋whispered 聲線；3-5 14w 低於帶下緣（15），climax 頁刻意靜默合理 |
| P09 | 9 | "Thank you for bringing me to the city!" Nibble hugged Glitz tight.<br>"Come back anytime!" Glitz laughed.<br>"Me? I just love the busy city!" | 24✓ | 8 | "Thank you for bringing me!" Nibble hugged Glitz.<br>"Come back anytime!" Glitz laughed.<br>"I just love the busy city!" | 19✓ | — | — | — | ✓ | 2-3 跳此頁。Glitz 自定：各有所好。5-6 保留「Me?」反問語氣 |
| P10 | 10 | Nibble walked home all by herself.<br>The big roads turned back into little paths, the paths turned back into grass.<br>Moonlight sparkled on the dew, and crickets sang their song. | 30✓ | — | — | — | — | — | — | ✓ | 3-5/2-3 跳此頁。5-6 逆向遞減（roads→paths→grass）對稱 P03 遞進；月光/露水/蟋蟀三感官歸鄉 |
| P11 | 11 | Crunch, crunch, crunch.<br>The same old wheat, but today it tasted extra yummy.<br>"I like eating at home best, nice and quiet.<br>Next time Glitz visits, I'll make him a feast!" | 31✓ | 9 | Nibble walked all the way home.<br>Crunch, crunch, crunch.<br>"I like eating at home best, nice and quiet." | 18✓ | 7 | Nibble went home.<br>Crunch, crunch, crunch.<br>Mmmm! Yummy! | 8✓ | ✓ | 首尾 crunch×3 呼應 P01。3-5 橋接跳 P10：補「walked all the way home」（對位 zh-TW「走回家了」）；2-3 橋接跳 P09/P10：補「went home」＋純感官「Mmmm! Yummy!」（style_guide §5：2-3 不出道理） |
| P12 | 12 | Moonlight shone into the little burrow, and far away, the city lights twinkled too.<br>Nibble curled up in her cozy nest.<br>And from that day on… | 26✓ | 10 | Moonlight shone into the burrow, and far away, the city twinkled too.<br>And from that day on… | 17✓ | 8 | Moonlight on Nibble. Moonlight on Glitz.<br>And from that day on… | 11✓ | ✓ | 全員同框收束。5-6 月光＋窩＋城市；3-5 精簡去「little」與 Nibble nest；2-3 電報式平行句「Moonlight on Nibble. Moonlight on Glitz.」對位 zh-TW 2-3「月亮照著禾禾，也照著亮亮」 |

## 2. 數據摘要

| 項目 | 5-6 | 3-5 | 2-3 |
|---|---|---|---|
| 頁數 | 12 | 10 | 8 |
| 原始字數 | 310 | 180 | 95 |
| 疊句折計（repeat_discount=0.25） | −7.5 | −7.5 | −7.5 |
| 折計後字數 | 302.5 | 172.5 | 87.5 |
| 硬上限（max_total_len） | 505 | 389 | 88 |
| 帶外⚠ | 0 | 1（P08: 14w < 15） | 1（P11: 8w < 10） |

疊句出現：P05/P06/P07（三次），核心句 "So yummy… but so scary!" 三檔逐字一致。
變奏：P08 "So yummy… but I don't feel safe."（三檔一致，不折計）。
收束式：P12 "And from that day on…"（三檔一致）。

## 3. B0 語感基建

### 疊句

| 項 | 值 |
|---|---|
| 核心句 | So yummy… but so scary! |
| 變奏 P08 | So yummy… but I don't feel safe. |
| 設計 | 前半「So yummy」保留正向體驗，後半 scary→not safe 從外部恐懼轉向內在安全感需求，標誌 Nibble 蛻變拍點 |

### 擬聲詞凍結字串表

| # | 場景 | en-US 凍結形 | 規則 | 頁位 |
|---|---|---|---|---|
| 1 | 老鼠啃食 | `crunch, crunch, crunch` | O3 小寫逗號三連 | P01/P11 |
| 2 | 巨大腳步聲 | `STOMP STOMP STOMP!` | O1 全大寫 | P05（5-6 雙連） |
| 3 | 貓叫 | `MEOW!` | O1 全大寫 | P06 |
| 4 | 蜂鳴 | `BUZZZZZ!` | O1+O2 全大寫字母重複 | P07 |
| 5 | 心跳聲 | `thump-thump, thump-thump` | O3 連字號雙拍逗號雙連 | P08 |

### 角色口癖卡

| 角色 | 口癖特徵 |
|---|---|
| Nibble（she） | 安靜觀察者；語氣詞 "Okay…"；重複式驚嘆 "So big!"；內心聲 "I want to go home" |
| Glitz（he） | 熱情社交者；邀請語氣 "Come with me!"；笑著說 "Come back anytime!"；自信宣言 "I just love the busy city!" |

### 讀序聲明

B1 期間未開啟 zh-TW 或 en-US 文本檔。B2 校準始開 zh-TW 定稿三檔＋copy/zh-TW.md。
