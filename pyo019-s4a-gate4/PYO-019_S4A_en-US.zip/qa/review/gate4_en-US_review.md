# 關卡4整合審閱：城市老鼠與鄉下老鼠（S4 證據包／en-US）

- 生成時間：2026-07-29 20:26:29 +0800
- 書目錄：`content/PYO-019_the-city-mouse-and-the-country-mouse`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：en-US
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-019_storyboard.md` | 2026-07-29 10:58:34 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-29 18:49:39 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-29 20:04:31 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-29 18:49:39 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-29 20:04:37 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-29 18:49:39 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-29 20:04:40 |
| qa/en-US/backtranslation.md | `qa/en-US/backtranslation.md` | 2026-07-29 20:26:19 |
| qa/en-US round | `qa/en-US/round1.md` | 2026-07-29 20:23:37 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | en-US 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 12 | 12 頁有文 | 12 頁有文 | 12/12 | 3 |
| 3-5 | 10 | 10 頁有文 | 10 頁有文 | 10/10 | 1 |
| 2-3 | 8 | 8 頁有文 | 8 頁有文 | 8/8 | 1 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 咯吱咯吱、咯吱咯吱。／禾禾安安靜靜地吃早餐。／「禾禾！」亮亮探進洞口。／「城市有好～多好吃的！跟我去吧！」 | Crunch, crunch, crunch.／Nibble was eating her breakfast, nice and quiet.／"Nibble!" Glitz popped his head through the door.／"The city has sooo many yummy things! Come with me!" | 嘎吱、嘎吱、嘎吱。小啃正在吃她的早餐，安安靜靜的。「小啃！」亮晶晶把頭探進門裡。「城市裡有好～多好吃的東西！跟我一起去嘛！」 | 無 |
| P02 | P02 | 禾禾猶豫了一下。／她從來沒去過城市呢。／「好吧…… 我跟你去看看！」／兩隻小老鼠出發了。 | Nibble wasn't so sure.／She had never been to the city before!／"Okay… I'll come and see!"／Off went two little mice. | 小啃不太確定。她從來沒有去過城市！「好吧……我去看看！」兩隻小老鼠出發了。 | 無 |
| P03 | P03 | 走呀走、走呀走。／房子越來越高，燈越來越亮，聲音越來越吵。／「好高好高呀！」禾禾抬起頭。 | They walked and walked and walked.／The houses grew taller, the lights grew brighter, the streets grew louder.／"So big!" Nibble looked up and up and up. | 她們走啊走啊走。房子越來越高，燈光越來越亮，街道越來越吵。「好大！」小啃抬頭看啊看啊看。 | 輕微：「好大」vs 母本「好高好高呀」——en-US 用 big（通用震撼）替代 高（具體高度），均表達城市規模震撼，改編合理 |
| P04 | P04 | 「到了到了！」亮亮得意地說。／禾禾看傻了，一句話都說不出來。／好大好大……／什麼東西都好大好大！ | "Here we are!" Glitz said proudly.／Nibble's mouth fell open. She couldn't say a word.／So big, so big…／Everything was sooo big! | 「我們到啦！」亮晶晶驕傲地說。小啃的嘴巴張得好大，一句話都說不出來。好大、好大……每樣東西都好～大！ | 無 |
| P05 | P05 | 好大的蛋糕！禾禾剛要咬一口——／碰碰碰！碰碰碰！／巨大的腳步聲！／「好好吃…… 可是好可怕！」 | A great big cake! Nibble was just about to take a bite—／STOMP STOMP STOMP! STOMP STOMP STOMP!／Giant footsteps!／"So yummy… but so scary!" | 一塊好大的蛋糕！小啃正要咬下去——咚咚咚！咚咚咚！巨大的腳步聲！「好好吃……可是好可怕！」 | 無 |
| P06 | P06 | 亮亮又找來一盤起司。禾禾剛舔一口——／喵！巨大的影子！／禾禾一頭栽進奶油裡！／「好好吃…… 可是好可怕！」 | Glitz found a plate of cheese. Nibble took one tiny lick—／MEOW! A giant shadow!／Nibble tumbled headfirst into the cream!／"So yummy… but so scary!" | 亮晶晶發現了一盤起司。小啃舔了小小一口——喵！一個巨大的影子！小啃一頭栽進了奶油裡！「好好吃……可是好可怕！」 | 無 |
| P07 | P07 | 亮亮又找到水果塔！禾禾剛爬上去——／嗡嗡嗡！／翻了！噴了！兩隻老鼠跑呀跑——／「好好吃…… 可是好可怕！」 | Glitz found a fruit tart! Nibble climbed right up—／BUZZZZZ!／Tipped over! Cream everywhere! Two little mice ran and ran—／"So yummy… but so scary!" | 亮晶晶發現了一個水果塔！小啃直接爬了上去——嗡嗡嗡嗡嗡！翻倒了！奶油到處都是！兩隻小老鼠跑啊跑——「好好吃……可是好可怕！」 | 無 |
| P08 | P08 | 撲通撲通、撲通撲通。／禾禾的心跳好快好快。／「好好吃…… 可是我一點都不安心。」／禾禾小小聲地說：「我要回家。」 | Thump-thump, thump-thump.／Nibble's heart was pounding so fast.／"So yummy… but I don't feel safe."／"I want to go home," Nibble whispered. | 撲通撲通、撲通撲通。小啃的心跳得好快好快。「好好吃……可是我覺得不安全。」「我想回家，」小啃小聲說。 | 輕微：「覺得不安全」vs 母本「一點都不安心」——en-US safe 的直譯（安全）vs zh-TW 安心（更柔和），核心語義一致，是 locale 語域差異 |
| P09 | P09 | 「謝謝你帶我來城市！」禾禾抱住亮亮。／「隨時再來玩喔！」亮亮笑著說。／「我呀，最喜歡熱鬧的城市了！」 | "Thank you for bringing me to the city!" Nibble hugged Glitz tight.／"Come back anytime!" Glitz laughed.／"Me? I just love the busy city!" | 「謝謝你帶我來城市！」小啃緊緊抱住亮晶晶。「隨時回來玩！」亮晶晶笑著說。「我嘛？我就是喜歡熱鬧的城市！」 | 無 |
| P10 | P10 | 禾禾一個人走回家。／大馬路變回小路，小路變回草地。／月光照著露水，蟋蟀唱著歌。 | Nibble walked home all by herself.／The big roads turned back into little paths, the paths turned back into grass.／Moonlight sparkled on the dew, and crickets sang their song. | 小啃自己一個人走回家。大馬路變回了小路，小路變回了草地。月光在露珠上閃閃發亮，蟋蟀唱著牠們的歌。 | 無 |
| P11 | P11 | 咯吱咯吱、咯吱咯吱。／同樣的麥子，今天特別香。／「我最喜歡在家裡，安安靜靜地吃飯。／下次亮亮來，我請他！」 | Crunch, crunch, crunch.／The same old wheat, but today it tasted extra yummy.／"I like eating at home best, nice and quiet.／Next time Glitz visits, I'll make him a feast!" | 嘎吱、嘎吱、嘎吱。一樣的老麥子，可是今天吃起來特別好吃。「我最喜歡在家裡吃東西了，安安靜靜的。下次亮晶晶來，我要做一頓大餐給他吃！」 | 輕微：「特別好吃」vs 母本「特別香」——en-US tasted extra yummy（味覺）vs zh-TW 特別香（嗅覺），是 text-writer 刻意的感官通道改編 |
| P12 | P12 | 月光照進田野小洞，也照著遠遠的城市。／禾禾縮進暖暖的窩裡。／後來呀…… | Moonlight shone into the little burrow, and far away, the city lights twinkled too.／Nibble curled up in her cozy nest.／And from that day on… | 月光照進小小的地洞裡，遠方，城市的燈火也一閃一閃。小啃在她舒服的窩裡蜷成一團。從那天起…… | 無 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 咯吱咯吱。禾禾在吃早餐。／「城市有好多好吃的，跟我去吧！」亮亮說。 | Crunch, crunch, crunch.／Nibble was eating her breakfast.／"Nibble!" Glitz popped in.／"The city has sooo many yummy things! Come with me!" | 嘎吱、嘎吱、嘎吱。小啃正在吃早餐。「小啃！」亮晶晶探頭進來。「城市裡有好～多好吃的東西！跟我一起去嘛！」 | 無 |
| P02 | P02 | 禾禾從來沒去過城市呢。／「好吧，我跟你去看看！」 | Nibble had never been to the city!／"Okay… I'll come and see!"／Off they went. | 小啃從來沒有去過城市！「好吧……我去看看！」她們出發了。 | 無 |
| P03 | P04 | 走了好久好久，到了城市的大房子。／好大好大！什麼都好大好大！ | They walked and walked. "Here we are!" said Glitz.／Nibble's mouth fell open.／So big, so big…／Everything was sooo big! | （缺） | — |
| P04 | P05 | 好大的蛋糕！剛要咬一口——／碰碰碰！／「好好吃…… 可是好可怕！」 | A big cake! Nibble was about to bite—／STOMP STOMP STOMP!／"So yummy… but so scary!" | 她們走啊走啊。「我們到啦！」亮晶晶說。小啃的嘴巴張得好大。好大、好大……每樣東西都好～大！ | 無 |
| P05 | P06 | 一盤起司！舔一口——喵！／滑進碟子，全身奶油。／「好好吃…… 可是好可怕！」 | Cheese! Nibble took a tiny lick—／MEOW! A giant shadow!／Nibble tumbled into the cream!／"So yummy… but so scary!" | 一塊大蛋糕！小啃正要咬下去——咚咚咚！「好好吃……可是好可怕！」 | 無 |
| P06 | P07 | 水果塔！剛爬上去——嗡嗡嗡！／翻了！噴了！跑呀跑——／「好好吃…… 可是好可怕！」 | Fruit tart! Nibble climbed up—／BUZZZZZ!／Tipped over! Two mice ran and ran—／"So yummy… but so scary!" | 起司！小啃舔了小小一口——喵！一個巨大的影子！小啃栽進了奶油裡！「好好吃……可是好可怕！」 | 無 |
| P07 | P08 | 撲通撲通、撲通撲通。／「好好吃…… 可是我一點都不安心。／我要回家。」 | Thump-thump, thump-thump.／"So yummy… but I don't feel safe.／I want to go home." | 水果塔！小啃爬了上去——嗡嗡嗡嗡嗡！翻倒了！兩隻小老鼠跑啊跑——「好好吃……可是好可怕！」 | 無 |
| P08 | P09 | 「謝謝你帶我來！」禾禾抱住亮亮。／「隨時再來喔！我最喜歡熱鬧的城市了！」 | "Thank you for bringing me!" Nibble hugged Glitz.／"Come back anytime!" Glitz laughed.／"I just love the busy city!" | 撲通撲通、撲通撲通。「好好吃……可是我覺得不安全。我想回家。」 | 輕微：同 5-6 P08（安全 vs 安心語域差異） |
| P09 | P11 | 禾禾走回家了。咯吱咯吱。／「我最喜歡在家裡，安安靜靜地吃飯！」 | Nibble walked all the way home.／Crunch, crunch, crunch.／"I like eating at home best, nice and quiet." | 「謝謝你帶我來！」小啃抱住亮晶晶。「隨時回來玩！」亮晶晶笑著說。「我就是喜歡熱鬧的城市！」 | 無 |
| P10 | P12 | 月光照進小洞，也照著遠遠的城市。／後來呀…… | Moonlight shone into the burrow, and far away, the city twinkled too.／And from that day on… | （缺） | — |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 咯吱咯吱。／「城市有好吃的，走吧！」亮亮說。 | Crunch, crunch, crunch.／"Yummy things in the city! Let's go!" said Glitz. | 嘎吱、嘎吱、嘎吱。「城市裡有好吃的東西！我們走吧！」亮晶晶說。 | 無 |
| P02 | P02 | 禾禾從來沒去過城市。／跟著亮亮出發了！ | Nibble had never been to the city.／Off she went with Glitz! | 小啃從來沒有去過城市。她跟著亮晶晶出發了！ | 無 |
| P03 | P05 | 到了城市。好大的蛋糕！／碰碰碰！／「好好吃…… 可是好可怕！」 | In the city! A big cake!／STOMP STOMP STOMP!／"So yummy… but so scary!" | （缺） | — |
| P04 | P06 | 一盤起司！／喵！好大的影子！／「好好吃…… 可是好可怕！」 | Cheese!／MEOW! A big shadow!／"So yummy… but so scary!" | （缺） | — |
| P05 | P07 | 水果塔！／嗡嗡嗡！翻了！噴了！跑呀跑——／「好好吃…… 可是好可怕！」 | Fruit tart!／BUZZZZZ!／They ran and ran and ran—／"So yummy… but so scary!" | 到城市了！一塊大蛋糕！咚咚咚！「好好吃……可是好可怕！」 | 無 |
| P06 | P08 | 撲通撲通。／「好好吃…… 可是我不安心。／我要回家。」 | Thump-thump, thump-thump.／"So yummy… but I don't feel safe."／"I want to go home." | 起司！喵！一個大影子！「好好吃……可是好可怕！」 | 無 |
| P07 | P11 | 禾禾回到家了。／咯吱咯吱。好香好香！ | Nibble went home.／Crunch, crunch, crunch.／Mmmm! Yummy! | 水果塔！嗡嗡嗡嗡嗡！她們跑啊跑啊跑——「好好吃……可是好可怕！」 | 無 |
| P08 | P12 | 月亮照著禾禾，也照著亮亮。／後來呀…… | Moonlight on Nibble. Moonlight on Glitz.／And from that day on… | 撲通撲通、撲通撲通。「好好吃……可是我覺得不安全。」「我想回家。」 | 輕微：同 5-6 P08 |

## 三、QA 摘要（qa/en-US）

- `qa/en-US/round1.md`：round 1／verdict pass

最新 round：`qa/en-US/round1.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: the-city-mouse-and-the-country-mouse
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-29"
step1_lint: {exit_code: 0, warnings: 9}
step2_checklist: {pass: 24, fail: 0}
step3_mode: consolidated
step3_personas: []
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

### ESL 獵手發現（原文引用）

### ESL 獵手

逐頁掃描 en-US spec R1-R7 雷區＋style_guide §3.4 四型 AI 機械句：

- R2 縮寫：全文正確使用（wasn't/I'll/couldn't/don't），無翻譯腔
- R3 tag：said 為主力，whispered/laughed 限情緒峰值
- R5 sight words：骨架全高頻，內容詞具體可畫
- R6 重複句：三組逐字一致
- R7 幼幼版：2-3 fragment 合法(Cheese!/Mmmm!)

ESL calque/搭配/語序異常：0 筆。
AI 機械句四型：0 筆。

## 四、⏸️ 上呈批次

- （`qa/en-US/round1.md`）| ⏸️ escalated | 0 |

