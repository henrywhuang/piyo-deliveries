# 關卡WB整合審閱：城市老鼠與鄉下老鼠（E 對位底稿／en-US）

- 生成時間：2026-07-29 20:19:53 +0800
- 書目錄：`content/PYO-019_the-city-mouse-and-the-country-mouse`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate WB`（決定性腳本，純解析＋排版）
- locale：en-US
- 用途：E 主審與裁決 agent 的單檔輸入 bundle——文字＝QA 對象本體逐字轉錄；可疑頁保留開原檔抽驗權

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-019_storyboard.md` | 2026-07-29 10:58:34 |
| copy | `copy/en-US.md` | 2026-07-29 20:12:21 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-29 18:49:39 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-29 20:04:31 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-29 18:49:39 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-29 20:04:37 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-29 18:49:39 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-29 20:04:40 |
| qa/en-US/backtranslation.md | （缺） | — |

## 檔頭 commitments 逐字轉錄（兌現比對用）

```yaml
schema: piyo_copy/v0.9
slug: the-city-mouse-and-the-country-mouse
locale: en-US
mode: B
storyboard: content/PYO-019_the-city-mouse-and-the-country-mouse/PYO-019_storyboard.md
design: content/PYO-019_the-city-mouse-and-the-country-mouse/PYO-019_design.md
image_pool: 12
selection:
  "3-5": [P01, P02, P04, P05, P06, P07, P08, P09, P11, P12]
  "2-3": [P01, P02, P05, P06, P07, P08, P11, P12]
commitments:
  refrain: "So yummy… but so scary!"
  ending: "And from that day on…"
  onomatopoeia: ["Crunch, crunch, crunch", STOMP STOMP STOMP!, MEOW!, BUZZZZZ!, "Thump-thump, thump-thump"]
characters: [Nibble, Glitz]
```

## 檔位 5-6（12 頁）

### 5-6｜P01（母版 P01）

- 圖說什麼：暖棕色小洞裡，禾禾戴著草帽坐在小桌前，嘴裡嚼著麥子，桌上幾粒麥子和一顆堅果。小蟋蟀趴在麥穗上。洞口陽光灑進來，亮亮探進半個腦袋，蝴蝶結精神抖擻，一手指著外面。
- 文說什麼：禾禾吃早餐的日常聲音，亮亮到訪嫌東西太簡單、邀禾禾去城市嚐好吃的。擬聲詞「咯吱咯吱」。
- 鉤子：視覺引導：亮亮的手指向洞口外的光，禾禾的視線跟著移過去
- 選圖與提純說明：三檔共享 crunch×3 開場音效；2-3 精簡直入，省去 Nibble 早餐描述（圖已示）
- 匹配欄：✓

【zh-TW】
咯吱咯吱、咯吱咯吱。
禾禾安安靜靜地吃早餐。
「禾禾！」亮亮探進洞口。
「城市有好～多好吃的！跟我去吧！」

【en-US】
Crunch, crunch, crunch.
Nibble was eating her breakfast, nice and quiet.
"Nibble!" Glitz popped his head through the door.
"The city has sooo many yummy things! Come with me!"

### 5-6｜P02（母版 P02）

- 圖說什麼：田野洞口外，金色麥田一望無際。禾禾跨出洞口，身體微微猶豫回頭看了一眼；亮亮已走在前面，尾巴翹得高高的回頭招手。兩隻小身影走向遠方的路。
- 文說什麼：禾禾猶豫了一下，好奇心贏了，兩隻老鼠收拾出發。
- 鉤子：動作中斷：兩隻老鼠的腳步剛踏出洞口，旅途正要展開
- 選圖與提純說明：5-6 保留猶豫＋決定完整弧線；3-5 精簡猶豫；2-3 電報式——never been 提供首次離家語境
- 匹配欄：✓

【zh-TW】
禾禾猶豫了一下。
她從來沒去過城市呢。
「好吧…… 我跟你去看看！」
兩隻小老鼠出發了。

【en-US】
Nibble wasn't so sure.
She had never been to the city before!
"Okay… I'll come and see!"
Off went two little mice.

### 5-6｜P03（母版 P03）

- 圖說什麼：兩隻老鼠走在路上，路從泥巴小徑變成石板大路，兩邊從矮草慢慢長成高牆和路燈。禾禾抬著頭東張西望，嘴巴微微張開。亮亮輕鬆走著，用尾巴指著前方。
- 文說什麼：沿途景物越來越大越來越亮越來越吵的遞進描寫，節奏加快。
- 鉤子：視覺引導：路盡頭出現巨大的輪廓，禾禾的頭越抬越高
- 選圖與提純說明：3-5/2-3 跳此頁。5-6 triple escalation（grew taller/brighter/louder）對應分鏡三段遞進
- 匹配欄：✓

【zh-TW】
走呀走、走呀走。
房子越來越高，燈越來越亮，聲音越來越吵。
「好高好高呀！」禾禾抬起頭。

【en-US】
They walked and walked and walked.
The houses grew taller, the lights grew brighter, the streets grew louder.
"So big!" Nibble looked up and up and up.

### 5-6｜P04（母版 P04）

- 圖說什麼：兩隻小老鼠站在巨大桌腳旁邊仰頭看。桌腿像柱子、椅腳比他們高好幾倍。禾禾整個人後仰，嘴巴張得大大的什麼話都說不出來。亮亮雙手一攤得意地笑。
- 文說什麼：禾禾被城市震懾說不出話，亮亮得意介紹。城市的巨大由感嘆呈現。
- 鉤子：視覺引導：兩隻老鼠仰頭往上看，畫面上緣只到桌面邊緣，看不見桌上有什麼
- 選圖與提純說明：3-5 橋接跳 P03：補「They walked and walked」承接旅程（對位 zh-TW 3-5「走了好久好久」）；2-3 跳此頁
- 匹配欄：✓

【zh-TW】
「到了到了！」亮亮得意地說。
禾禾看傻了，一句話都說不出來。
好大好大……
什麼東西都好大好大！

【en-US】
"Here we are!" Glitz said proudly.
Nibble's mouth fell open. She couldn't say a word.
So big, so big…
Everything was sooo big!

### 5-6｜P05（母版 P05）

- 圖說什麼：桌腳後面，禾禾縮成一團瞪大眼睛，手裡還抓著一小塊蛋糕屑，亮亮蹲在旁邊拍拍她的背。上方桌面邊緣露出巨大蛋糕的一角，一道人影的陰影正掃過地板。
- 文說什麼：蛋糕出現引發期待——「碰碰碰」腳步聲打斷。疊句「好好吃…… 可是好可怕！」第一次出現。
- 鉤子：動作中斷：蛋糕還在頭頂上沒吃到，兩隻老鼠縮在桌腳後不敢動
- 選圖與提純說明：疊句#1；5-6 雙連 STOMP（對位 zh-TW 碰碰碰×2）；3-5 單連；2-3 橋接跳 P03-P04：補「In the city!」確立場景轉換（對位 zh-TW 2-3「到了城市」）
- 匹配欄：✓

【zh-TW】
好大的蛋糕！禾禾剛要咬一口——
碰碰碰！碰碰碰！
巨大的腳步聲！
「好好吃…… 可是好可怕！」

【en-US】
A great big cake! Nibble was just about to take a bite—
STOMP STOMP STOMP! STOMP STOMP STOMP!
Giant footsteps!
"So yummy… but so scary!"

### 5-6｜P06（母版 P06）

- 圖說什麼：禾禾的臉佔畫面大半，額頭到下巴全是白色奶油，只露出兩隻圓圓大眼睛驚嚇地瞪著。一隻小爪子還抓著一片起司。身後亮亮也沾了奶油但笑嘻嘻的。牆面掠過一道尖耳巨影。
- 文說什麼：起司登場——「喵」貓影打斷，滑進碟子全身奶油。疊句第二次。搞笑描寫。
- 鉤子：懸念：全身奶油還沒擦乾淨，亮亮又發現更大的東西
- 選圖與提純說明：疊句#2；2-3 省去奶油摔（圖已示），保留影子驚嚇（對位 zh-TW 2-3「好大的影子」）
- 匹配欄：✓

【zh-TW】
亮亮又找來一盤起司。禾禾剛舔一口——
喵！巨大的影子！
禾禾一頭栽進奶油裡！
「好好吃…… 可是好可怕！」

【en-US】
Glitz found a plate of cheese. Nibble took one tiny lick—
MEOW! A giant shadow!
Nibble tumbled headfirst into the cream!
"So yummy… but so scary!"

### 5-6｜P07（母版 P07）

- 圖說什麼：桌面天翻地覆，翻倒的水果塔拖著一長條奶油痕跡。禾禾跑在前面、草帽飛掉了，亮亮在後面跑得西裝外套飄起來，身後一團模糊的嗡嗡震動追上來。
- 文說什麼：水果塔上場——「嗡嗡嗡」吸塵器追著跑，場面最大混亂。疊句第三次但語氣動搖。極短句密集擬聲。
- 鉤子：動作中斷：水果塔翻倒奶油四濺，兩隻老鼠還在拔腿跑
- 選圖與提純說明：疊句#3；「ran and ran—」em dash 為翻頁鉤子（動作中斷型，對位分鏡 P07 hook）；2-3 triple ran Rule of Three
- 匹配欄：✓

【zh-TW】
亮亮又找到水果塔！禾禾剛爬上去——
嗡嗡嗡！
翻了！噴了！兩隻老鼠跑呀跑——
「好好吃…… 可是好可怕！」

【en-US】
Glitz found a fruit tart! Nibble climbed right up—
BUZZZZZ!
Tipped over! Cream everywhere! Two little mice ran and ran—
"So yummy… but so scary!"

### 5-6｜P08（母版 P08）

- 圖說什麼：一隻巨大鞋子的深處，禾禾縮在最裡面，雙手捂著胸口。她的眼睛含著淚光，但嘴巴緊緊抿成一條線，表情從害怕慢慢轉成堅定。整個畫面安靜下來。
- 文說什麼：最安靜的一頁，心跳「撲通撲通」。禾禾說出「吃不安心，我要回家」。疊句變體完成蛻變。
- 鉤子：懸念：禾禾說出「我要回家」，她真的會離開嗎？
- 選圖與提純說明：疊句變奏 P08（scary→not safe）：外部恐懼→內在安全感蛻變。5-6 加心跳描寫＋whispered 聲線；3-5 14w 低於帶下緣（15），climax 頁刻意靜默合理
- 匹配欄：✓

【zh-TW】
撲通撲通、撲通撲通。
禾禾的心跳好快好快。
「好好吃…… 可是我一點都不安心。」
禾禾小小聲地說：「我要回家。」

【en-US】
Thump-thump, thump-thump.
Nibble's heart was pounding so fast.
"So yummy… but I don't feel safe."
"I want to go home," Nibble whispered.

### 5-6｜P09（母版 P09）

- 圖說什麼：月光下兩隻老鼠的臉靠得很近。禾禾張開雙手抱著亮亮，亮亮伸手回抱她。兩隻老鼠的眼睛都亮亮的，背後城市燈火模模糊糊。
- 文說什麼：禾禾感謝亮亮帶她去城市，亮亮說城市也在等他回去。道別擁抱。
- 鉤子：視覺引導：禾禾轉身走向月光照亮的田野方向
- 選圖與提純說明：2-3 跳此頁。Glitz 自定：各有所好。5-6 保留「Me?」反問語氣
- 匹配欄：✓

【zh-TW】
「謝謝你帶我來城市！」禾禾抱住亮亮。
「隨時再來玩喔！」亮亮笑著說。
「我呀，最喜歡熱鬧的城市了！」

【en-US】
"Thank you for bringing me to the city!" Nibble hugged Glitz tight.
"Come back anytime!" Glitz laughed.
"Me? I just love the busy city!"

### 5-6｜P10（母版 P10）

- 圖說什麼：月光從上方照下來，一條小路從石板慢慢變回泥巴路。禾禾的小身影獨自走在路上，腳步穩穩的。路邊草叢上露珠反射月光，一隻蟋蟀趴在草葉上。
- 文說什麼：歸途安靜敘述，大馬路變回小路再變回草地，月光露水蟋蟀。
- 鉤子：視覺引導：前方出現熟悉的田野小洞口，月光照在洞口上
- 選圖與提純說明：3-5/2-3 跳此頁。5-6 逆向遞減（roads→paths→grass）對稱 P03 遞進；月光/露水/蟋蟀三感官歸鄉
- 匹配欄：✓

【zh-TW】
禾禾一個人走回家。
大馬路變回小路，小路變回草地。
月光照著露水，蟋蟀唱著歌。

【en-US】
Nibble walked home all by herself.
The big roads turned back into little paths, the paths turned back into grass.
Moonlight sparkled on the dew, and crickets sang their song.

### 5-6｜P11（母版 P11）

- 圖說什麼：禾禾坐回小桌前，面前同樣的幾粒麥子和小堅果。她捧起一粒麥子放進嘴裡嚼著，兩頰鼓鼓的、眼睛瞇成彎月，笑得好滿足。洞裡暖暖的光照著她，小蟋蟀趴回麥穗上。
- 文說什麼：禾禾笑著說出「我最喜歡在自己家裡，安安靜靜地吃飯」。意願句承載核心教訓。「咯吱咯吱」回歸。
- 鉤子：視覺引導：月光從洞口照進來，引向下一頁的安靜收束
- 選圖與提純說明：首尾 crunch×3 呼應 P01。3-5 橋接跳 P10：補「walked all the way home」（對位 zh-TW「走回家了」）；2-3 橋接跳 P09/P10：補「went home」＋純感官「Mmmm! Yummy!」（style_guide §5：2-3 不出道理）
- 匹配欄：✓

【zh-TW】
咯吱咯吱、咯吱咯吱。
同樣的麥子，今天特別香。
「我最喜歡在家裡，安安靜靜地吃飯。
下次亮亮來，我請他！」

【en-US】
Crunch, crunch, crunch.
The same old wheat, but today it tasted extra yummy.
"I like eating at home best, nice and quiet.
Next time Glitz visits, I'll make him a feast!"

### 5-6｜P12（母版 P12）

- 圖說什麼：暖暖的田野小洞裡，禾禾縮進草窩，草帽掛在洞壁上。月光從圓圓洞口照進來，洞口外遠遠的城市天際線亮著點點燈火。禾禾閉著眼睛，嘴角帶著微笑。
- 文說什麼：月光連接田野和城市的收束畫面。固定收束語「後來呀……」。
- 鉤子：—
- 選圖與提純說明：全員同框收束。5-6 月光＋窩＋城市；3-5 精簡去「little」與 Nibble nest；2-3 電報式平行句「Moonlight on Nibble. Moonlight on Glitz.」對位 zh-TW 2-3「月亮照著禾禾，也照著亮亮」
- 匹配欄：✓

【zh-TW】
月光照進田野小洞，也照著遠遠的城市。
禾禾縮進暖暖的窩裡。
後來呀……

【en-US】
Moonlight shone into the little burrow, and far away, the city lights twinkled too.
Nibble curled up in her cozy nest.
And from that day on…

## 檔位 3-5（10 頁）

### 3-5｜P01（母版 P01）

- 圖說什麼：暖棕色小洞裡，禾禾戴著草帽坐在小桌前，嘴裡嚼著麥子，桌上幾粒麥子和一顆堅果。小蟋蟀趴在麥穗上。洞口陽光灑進來，亮亮探進半個腦袋，蝴蝶結精神抖擻，一手指著外面。
- 文說什麼：禾禾吃早餐的日常聲音，亮亮到訪嫌東西太簡單、邀禾禾去城市嚐好吃的。擬聲詞「咯吱咯吱」。
- 鉤子：視覺引導：亮亮的手指向洞口外的光，禾禾的視線跟著移過去
- 選圖與提純說明：三檔共享 crunch×3 開場音效；2-3 精簡直入，省去 Nibble 早餐描述（圖已示）
- 匹配欄：✓

【zh-TW】
咯吱咯吱。禾禾在吃早餐。
「城市有好多好吃的，跟我去吧！」亮亮說。

【en-US】
Crunch, crunch, crunch.
Nibble was eating her breakfast.
"Nibble!" Glitz popped in.
"The city has sooo many yummy things! Come with me!"

### 3-5｜P02（母版 P02）

- 圖說什麼：田野洞口外，金色麥田一望無際。禾禾跨出洞口，身體微微猶豫回頭看了一眼；亮亮已走在前面，尾巴翹得高高的回頭招手。兩隻小身影走向遠方的路。
- 文說什麼：禾禾猶豫了一下，好奇心贏了，兩隻老鼠收拾出發。
- 鉤子：動作中斷：兩隻老鼠的腳步剛踏出洞口，旅途正要展開
- 選圖與提純說明：5-6 保留猶豫＋決定完整弧線；3-5 精簡猶豫；2-3 電報式——never been 提供首次離家語境
- 匹配欄：✓

【zh-TW】
禾禾從來沒去過城市呢。
「好吧，我跟你去看看！」

【en-US】
Nibble had never been to the city!
"Okay… I'll come and see!"
Off they went.

### 3-5｜P03（母版 P04）

- 圖說什麼：兩隻小老鼠站在巨大桌腳旁邊仰頭看。桌腿像柱子、椅腳比他們高好幾倍。禾禾整個人後仰，嘴巴張得大大的什麼話都說不出來。亮亮雙手一攤得意地笑。
- 文說什麼：禾禾被城市震懾說不出話，亮亮得意介紹。城市的巨大由感嘆呈現。
- 鉤子：視覺引導：兩隻老鼠仰頭往上看，畫面上緣只到桌面邊緣，看不見桌上有什麼
- 選圖與提純說明：3-5 橋接跳 P03：補「They walked and walked」承接旅程（對位 zh-TW 3-5「走了好久好久」）；2-3 跳此頁
- 匹配欄：✓

【zh-TW】
走了好久好久，到了城市的大房子。
好大好大！什麼都好大好大！

【en-US】
They walked and walked. "Here we are!" said Glitz.
Nibble's mouth fell open.
So big, so big…
Everything was sooo big!

### 3-5｜P04（母版 P05）

- 圖說什麼：桌腳後面，禾禾縮成一團瞪大眼睛，手裡還抓著一小塊蛋糕屑，亮亮蹲在旁邊拍拍她的背。上方桌面邊緣露出巨大蛋糕的一角，一道人影的陰影正掃過地板。
- 文說什麼：蛋糕出現引發期待——「碰碰碰」腳步聲打斷。疊句「好好吃…… 可是好可怕！」第一次出現。
- 鉤子：動作中斷：蛋糕還在頭頂上沒吃到，兩隻老鼠縮在桌腳後不敢動
- 選圖與提純說明：疊句#1；5-6 雙連 STOMP（對位 zh-TW 碰碰碰×2）；3-5 單連；2-3 橋接跳 P03-P04：補「In the city!」確立場景轉換（對位 zh-TW 2-3「到了城市」）
- 匹配欄：✓

【zh-TW】
好大的蛋糕！剛要咬一口——
碰碰碰！
「好好吃…… 可是好可怕！」

【en-US】
A big cake! Nibble was about to bite—
STOMP STOMP STOMP!
"So yummy… but so scary!"

### 3-5｜P05（母版 P06）

- 圖說什麼：禾禾的臉佔畫面大半，額頭到下巴全是白色奶油，只露出兩隻圓圓大眼睛驚嚇地瞪著。一隻小爪子還抓著一片起司。身後亮亮也沾了奶油但笑嘻嘻的。牆面掠過一道尖耳巨影。
- 文說什麼：起司登場——「喵」貓影打斷，滑進碟子全身奶油。疊句第二次。搞笑描寫。
- 鉤子：懸念：全身奶油還沒擦乾淨，亮亮又發現更大的東西
- 選圖與提純說明：疊句#2；2-3 省去奶油摔（圖已示），保留影子驚嚇（對位 zh-TW 2-3「好大的影子」）
- 匹配欄：✓

【zh-TW】
一盤起司！舔一口——喵！
滑進碟子，全身奶油。
「好好吃…… 可是好可怕！」

【en-US】
Cheese! Nibble took a tiny lick—
MEOW! A giant shadow!
Nibble tumbled into the cream!
"So yummy… but so scary!"

### 3-5｜P06（母版 P07）

- 圖說什麼：桌面天翻地覆，翻倒的水果塔拖著一長條奶油痕跡。禾禾跑在前面、草帽飛掉了，亮亮在後面跑得西裝外套飄起來，身後一團模糊的嗡嗡震動追上來。
- 文說什麼：水果塔上場——「嗡嗡嗡」吸塵器追著跑，場面最大混亂。疊句第三次但語氣動搖。極短句密集擬聲。
- 鉤子：動作中斷：水果塔翻倒奶油四濺，兩隻老鼠還在拔腿跑
- 選圖與提純說明：疊句#3；「ran and ran—」em dash 為翻頁鉤子（動作中斷型，對位分鏡 P07 hook）；2-3 triple ran Rule of Three
- 匹配欄：✓

【zh-TW】
水果塔！剛爬上去——嗡嗡嗡！
翻了！噴了！跑呀跑——
「好好吃…… 可是好可怕！」

【en-US】
Fruit tart! Nibble climbed up—
BUZZZZZ!
Tipped over! Two mice ran and ran—
"So yummy… but so scary!"

### 3-5｜P07（母版 P08）

- 圖說什麼：一隻巨大鞋子的深處，禾禾縮在最裡面，雙手捂著胸口。她的眼睛含著淚光，但嘴巴緊緊抿成一條線，表情從害怕慢慢轉成堅定。整個畫面安靜下來。
- 文說什麼：最安靜的一頁，心跳「撲通撲通」。禾禾說出「吃不安心，我要回家」。疊句變體完成蛻變。
- 鉤子：懸念：禾禾說出「我要回家」，她真的會離開嗎？
- 選圖與提純說明：疊句變奏 P08（scary→not safe）：外部恐懼→內在安全感蛻變。5-6 加心跳描寫＋whispered 聲線；3-5 14w 低於帶下緣（15），climax 頁刻意靜默合理
- 匹配欄：✓

【zh-TW】
撲通撲通、撲通撲通。
「好好吃…… 可是我一點都不安心。
我要回家。」

【en-US】
Thump-thump, thump-thump.
"So yummy… but I don't feel safe.
I want to go home."

### 3-5｜P08（母版 P09）

- 圖說什麼：月光下兩隻老鼠的臉靠得很近。禾禾張開雙手抱著亮亮，亮亮伸手回抱她。兩隻老鼠的眼睛都亮亮的，背後城市燈火模模糊糊。
- 文說什麼：禾禾感謝亮亮帶她去城市，亮亮說城市也在等他回去。道別擁抱。
- 鉤子：視覺引導：禾禾轉身走向月光照亮的田野方向
- 選圖與提純說明：2-3 跳此頁。Glitz 自定：各有所好。5-6 保留「Me?」反問語氣
- 匹配欄：✓

【zh-TW】
「謝謝你帶我來！」禾禾抱住亮亮。
「隨時再來喔！我最喜歡熱鬧的城市了！」

【en-US】
"Thank you for bringing me!" Nibble hugged Glitz.
"Come back anytime!" Glitz laughed.
"I just love the busy city!"

### 3-5｜P09（母版 P11）

- 圖說什麼：禾禾坐回小桌前，面前同樣的幾粒麥子和小堅果。她捧起一粒麥子放進嘴裡嚼著，兩頰鼓鼓的、眼睛瞇成彎月，笑得好滿足。洞裡暖暖的光照著她，小蟋蟀趴回麥穗上。
- 文說什麼：禾禾笑著說出「我最喜歡在自己家裡，安安靜靜地吃飯」。意願句承載核心教訓。「咯吱咯吱」回歸。
- 鉤子：視覺引導：月光從洞口照進來，引向下一頁的安靜收束
- 選圖與提純說明：首尾 crunch×3 呼應 P01。3-5 橋接跳 P10：補「walked all the way home」（對位 zh-TW「走回家了」）；2-3 橋接跳 P09/P10：補「went home」＋純感官「Mmmm! Yummy!」（style_guide §5：2-3 不出道理）
- 匹配欄：✓

【zh-TW】
禾禾走回家了。咯吱咯吱。
「我最喜歡在家裡，安安靜靜地吃飯！」

【en-US】
Nibble walked all the way home.
Crunch, crunch, crunch.
"I like eating at home best, nice and quiet."

### 3-5｜P10（母版 P12）

- 圖說什麼：暖暖的田野小洞裡，禾禾縮進草窩，草帽掛在洞壁上。月光從圓圓洞口照進來，洞口外遠遠的城市天際線亮著點點燈火。禾禾閉著眼睛，嘴角帶著微笑。
- 文說什麼：月光連接田野和城市的收束畫面。固定收束語「後來呀……」。
- 鉤子：—
- 選圖與提純說明：全員同框收束。5-6 月光＋窩＋城市；3-5 精簡去「little」與 Nibble nest；2-3 電報式平行句「Moonlight on Nibble. Moonlight on Glitz.」對位 zh-TW 2-3「月亮照著禾禾，也照著亮亮」
- 匹配欄：✓

【zh-TW】
月光照進小洞，也照著遠遠的城市。
後來呀……

【en-US】
Moonlight shone into the burrow, and far away, the city twinkled too.
And from that day on…

## 檔位 2-3（8 頁）

### 2-3｜P01（母版 P01）

- 圖說什麼：暖棕色小洞裡，禾禾戴著草帽坐在小桌前，嘴裡嚼著麥子，桌上幾粒麥子和一顆堅果。小蟋蟀趴在麥穗上。洞口陽光灑進來，亮亮探進半個腦袋，蝴蝶結精神抖擻，一手指著外面。
- 文說什麼：禾禾吃早餐的日常聲音，亮亮到訪嫌東西太簡單、邀禾禾去城市嚐好吃的。擬聲詞「咯吱咯吱」。
- 鉤子：視覺引導：亮亮的手指向洞口外的光，禾禾的視線跟著移過去
- 選圖與提純說明：三檔共享 crunch×3 開場音效；2-3 精簡直入，省去 Nibble 早餐描述（圖已示）
- 匹配欄：✓

【zh-TW】
咯吱咯吱。
「城市有好吃的，走吧！」亮亮說。

【en-US】
Crunch, crunch, crunch.
"Yummy things in the city! Let's go!" said Glitz.

### 2-3｜P02（母版 P02）

- 圖說什麼：田野洞口外，金色麥田一望無際。禾禾跨出洞口，身體微微猶豫回頭看了一眼；亮亮已走在前面，尾巴翹得高高的回頭招手。兩隻小身影走向遠方的路。
- 文說什麼：禾禾猶豫了一下，好奇心贏了，兩隻老鼠收拾出發。
- 鉤子：動作中斷：兩隻老鼠的腳步剛踏出洞口，旅途正要展開
- 選圖與提純說明：5-6 保留猶豫＋決定完整弧線；3-5 精簡猶豫；2-3 電報式——never been 提供首次離家語境
- 匹配欄：✓

【zh-TW】
禾禾從來沒去過城市。
跟著亮亮出發了！

【en-US】
Nibble had never been to the city.
Off she went with Glitz!

### 2-3｜P03（母版 P05）

- 圖說什麼：桌腳後面，禾禾縮成一團瞪大眼睛，手裡還抓著一小塊蛋糕屑，亮亮蹲在旁邊拍拍她的背。上方桌面邊緣露出巨大蛋糕的一角，一道人影的陰影正掃過地板。
- 文說什麼：蛋糕出現引發期待——「碰碰碰」腳步聲打斷。疊句「好好吃…… 可是好可怕！」第一次出現。
- 鉤子：動作中斷：蛋糕還在頭頂上沒吃到，兩隻老鼠縮在桌腳後不敢動
- 選圖與提純說明：疊句#1；5-6 雙連 STOMP（對位 zh-TW 碰碰碰×2）；3-5 單連；2-3 橋接跳 P03-P04：補「In the city!」確立場景轉換（對位 zh-TW 2-3「到了城市」）
- 匹配欄：✓

【zh-TW】
到了城市。好大的蛋糕！
碰碰碰！
「好好吃…… 可是好可怕！」

【en-US】
In the city! A big cake!
STOMP STOMP STOMP!
"So yummy… but so scary!"

### 2-3｜P04（母版 P06）

- 圖說什麼：禾禾的臉佔畫面大半，額頭到下巴全是白色奶油，只露出兩隻圓圓大眼睛驚嚇地瞪著。一隻小爪子還抓著一片起司。身後亮亮也沾了奶油但笑嘻嘻的。牆面掠過一道尖耳巨影。
- 文說什麼：起司登場——「喵」貓影打斷，滑進碟子全身奶油。疊句第二次。搞笑描寫。
- 鉤子：懸念：全身奶油還沒擦乾淨，亮亮又發現更大的東西
- 選圖與提純說明：疊句#2；2-3 省去奶油摔（圖已示），保留影子驚嚇（對位 zh-TW 2-3「好大的影子」）
- 匹配欄：✓

【zh-TW】
一盤起司！
喵！好大的影子！
「好好吃…… 可是好可怕！」

【en-US】
Cheese!
MEOW! A big shadow!
"So yummy… but so scary!"

### 2-3｜P05（母版 P07）

- 圖說什麼：桌面天翻地覆，翻倒的水果塔拖著一長條奶油痕跡。禾禾跑在前面、草帽飛掉了，亮亮在後面跑得西裝外套飄起來，身後一團模糊的嗡嗡震動追上來。
- 文說什麼：水果塔上場——「嗡嗡嗡」吸塵器追著跑，場面最大混亂。疊句第三次但語氣動搖。極短句密集擬聲。
- 鉤子：動作中斷：水果塔翻倒奶油四濺，兩隻老鼠還在拔腿跑
- 選圖與提純說明：疊句#3；「ran and ran—」em dash 為翻頁鉤子（動作中斷型，對位分鏡 P07 hook）；2-3 triple ran Rule of Three
- 匹配欄：✓

【zh-TW】
水果塔！
嗡嗡嗡！翻了！噴了！跑呀跑——
「好好吃…… 可是好可怕！」

【en-US】
Fruit tart!
BUZZZZZ!
They ran and ran and ran—
"So yummy… but so scary!"

### 2-3｜P06（母版 P08）

- 圖說什麼：一隻巨大鞋子的深處，禾禾縮在最裡面，雙手捂著胸口。她的眼睛含著淚光，但嘴巴緊緊抿成一條線，表情從害怕慢慢轉成堅定。整個畫面安靜下來。
- 文說什麼：最安靜的一頁，心跳「撲通撲通」。禾禾說出「吃不安心，我要回家」。疊句變體完成蛻變。
- 鉤子：懸念：禾禾說出「我要回家」，她真的會離開嗎？
- 選圖與提純說明：疊句變奏 P08（scary→not safe）：外部恐懼→內在安全感蛻變。5-6 加心跳描寫＋whispered 聲線；3-5 14w 低於帶下緣（15），climax 頁刻意靜默合理
- 匹配欄：✓

【zh-TW】
撲通撲通。
「好好吃…… 可是我不安心。
我要回家。」

【en-US】
Thump-thump, thump-thump.
"So yummy… but I don't feel safe."
"I want to go home."

### 2-3｜P07（母版 P11）

- 圖說什麼：禾禾坐回小桌前，面前同樣的幾粒麥子和小堅果。她捧起一粒麥子放進嘴裡嚼著，兩頰鼓鼓的、眼睛瞇成彎月，笑得好滿足。洞裡暖暖的光照著她，小蟋蟀趴回麥穗上。
- 文說什麼：禾禾笑著說出「我最喜歡在自己家裡，安安靜靜地吃飯」。意願句承載核心教訓。「咯吱咯吱」回歸。
- 鉤子：視覺引導：月光從洞口照進來，引向下一頁的安靜收束
- 選圖與提純說明：首尾 crunch×3 呼應 P01。3-5 橋接跳 P10：補「walked all the way home」（對位 zh-TW「走回家了」）；2-3 橋接跳 P09/P10：補「went home」＋純感官「Mmmm! Yummy!」（style_guide §5：2-3 不出道理）
- 匹配欄：✓

【zh-TW】
禾禾回到家了。
咯吱咯吱。好香好香！

【en-US】
Nibble went home.
Crunch, crunch, crunch.
Mmmm! Yummy!

### 2-3｜P08（母版 P12）

- 圖說什麼：暖暖的田野小洞裡，禾禾縮進草窩，草帽掛在洞壁上。月光從圓圓洞口照進來，洞口外遠遠的城市天際線亮著點點燈火。禾禾閉著眼睛，嘴角帶著微笑。
- 文說什麼：月光連接田野和城市的收束畫面。固定收束語「後來呀……」。
- 鉤子：—
- 選圖與提純說明：全員同框收束。5-6 月光＋窩＋城市；3-5 精簡去「little」與 Nibble nest；2-3 電報式平行句「Moonlight on Nibble. Moonlight on Glitz.」對位 zh-TW 2-3「月亮照著禾禾，也照著亮亮」
- 匹配欄：✓

【zh-TW】
月亮照著禾禾，也照著亮亮。
後來呀……

【en-US】
Moonlight on Nibble. Moonlight on Glitz.
And from that day on…

