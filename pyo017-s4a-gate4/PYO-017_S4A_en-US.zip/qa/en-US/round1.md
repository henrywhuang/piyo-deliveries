# QA 報告：my-spots-are-different / en-US / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: my-spots-are-different
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-29"
step1_lint: {exit_code: 0, warnings: 0}
step2_checklist: {pass: 26, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 5, 朗讀口感: 6, 孩子抓得住度: 5}
  - id: en-US-parent
    scores: {睡前適讀性: 6, 零說教: 6}
  - id: en-US-editor
    scores: {母語自然度: 8, 文字工藝: 8}
step4_triage: {real: 3, rejected: 16, escalated: 0}
verdict: fix_required
```

## STEP 1 機檢

```
# copy_check.py — exit 0, 0 violations
python3 .claude/skills/piyo-text-qa/scripts/copy_check.py content/PYO-017_my-spots-are-different/copy/en-US.md

# locale_lint ×3 — all exit 0
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-017_my-spots-are-different/text/en-US/5-6.draft.json --locale en-US --band 5-6
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-017_my-spots-are-different/text/en-US/3-5.draft.json --locale en-US --band 3-5
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-017_my-spots-are-different/text/en-US/2-3.draft.json --locale en-US --band 2-3

# localize_readiness --contract — green
python3 .claude/skills/piyo-text-qa/scripts/localize_readiness.py content/PYO-017_my-spots-are-different --contract --locale en-US
```

全部 exit 0。5-6 P11 41 字帶標 ⚠（超帶上緣 40），非硬違規。無警告需人工判讀。

## STEP 2 checklist 自檢

**主題錨復述**：本書教「不一樣不是需要修好的問題，而是你之所以是你的標記」——由 P11 主動選擇被看見→P12 媽媽辨認行動→P13 自述三層承載，旁白零說教。賣點＝偽裝失敗三連擊身體喜劇＋「猜猜我是誰」翻轉＋情感核心「被認出來」。

### A-E checklist（17 pass / 2 N/A / 0 fail）

| 項 | 判定 | 證據摘要 |
|---|---|---|
| A-1 主角可愛缺點 | PASS | 三檔均以行動呈現（拼命偽裝），無批判旁白 |
| A-2 溫柔後果 | PASS | P05/P07/P10 失敗後果＝更搞笑（泥巴裂/果汁沖/葉子炸），非受傷或被罰 |
| B-1 三次嘗試結構 | PASS | 泥巴→果汁→樹葉，方法遞進失敗遞增 |
| B-2 故事引擎運轉 | PASS | target_ability 為高潮不可替代解法（P11-P12 雙層翻轉） |
| C-1 擬聲詞 | PASS | Splat/Crack/SQUISH/SPLISH SPLASH/ACHOOOO 五組齊全 |
| C-2 疊句 | PASS | "Patch's spots are NOT the same!" P05/P07/P10 + 變奏 P12 |
| C-3 page-turn hooks | PASS | P03 "Off he ran!" / P05 疊句 / P07 疊句 / P10 疊句 |
| D-1 字數帶 | N/A | STEP 1 locale_lint 已管 |
| D-2 頁數帶 | N/A | storyboard_check S2 已管 |
| E-1 零旁白說教 | PASS | 旁白僅事件推進＋疊句，無「這個故事告訴我們」類 |
| E-2 結尾非大團圓 | PASS | P13 同伴互看發現各自不同＋斑斑自述，非「從此幸福快樂」 |
| E-3 最後一頁無教訓宣告 | PASS | P13 "Everyone's spots were a little bit different, after all." 為旁白觀察，非說教模式 |
| E-4 角色自主 | PASS | P11 斑斑主動走進遊戲（非被推入、非被教導） |
| E-5 情緒真實 | PASS | P08 低谷沮喪自然（非突然振作） |
| E-6 感官描寫 | PASS | 觸覺（泥巴 smear）/聽覺（crack/ACHOOOO）/視覺（purple streaks）多通道 |
| E-7 文化安全 | PASS | 差異嚴格限定為斑點形狀（非膚色/體型），偽裝材料為自然物 |
| E-8 名稱一致 | PASS | Patch/Dot/Mama 三檔一致，registry 對照通過 |

### 快速掃描（9 pass / 0 fail）

| 項 | 判定 |
|---|---|
| QS-1 標題與主題契約一致 | PASS |
| QS-2 角色數不超標 | PASS |
| QS-3 場景數不超標 | PASS |
| QS-4 無突兀新角色 | PASS |
| QS-5 疊句位置與設計一致 | PASS |
| QS-6 結尾四件套完整 | PASS |
| QS-7 三檔一致性 | PASS |
| QS-8 跨檔共享頁語義一致 | PASS |
| QS-9 擬聲詞 registry 一致 | PASS |

### 對位逐頁比對（33/33 pass）

E 逐頁對照 storyboard「圖說什麼/文說什麼」欄，三檔 33 頁全部通過。無文字重述圖已明示屬性的違反。事件敘述句（如 "Patch smeared mud all over himself"）屬旁白事件推進，非屬性重述，判合法。

### concept fidelity（3/3 pass）

| 檔位 | 判定 | 說明 |
|---|---|---|
| 5-6 | PASS | 完整三次嘗試＋雙層翻轉＋自述，主題錨完整承載 |
| 3-5 | PASS | 省 P08 不影響主題——三次失敗＋認出＋自述完整 |
| 2-3 | PASS | 單次嘗試＋認出＋自述，主題錨壓縮但完整 |

### 趣味設計兌現比對

| 宣告 | 判定 | 證據 |
|---|---|---|
| opening_hook: 反常 (P01) | PASS | 斑斑斑點形狀各異 vs 同伴圓形——差異在 P02 亮相 |
| refrain "Patch's spots are NOT the same!" | PASS | 5-6: P05/P07/P10 ×3 + P12 變奏；3-5: P05/P07/P10 ×3 + P12；2-3: P05 + P12 |
| page_turn_hooks P03/P05 | PASS | P03 "Off he ran!" / P05 疊句翻頁拉力 |
| slapstick (P04-P05, P06-P07, P09-P10) | PASS | 泥巴/果汁/樹葉三組 physical comedy 完整 |
| game_reveal (P11) | PASS | 猜猜我是誰→一猜就中→認知翻轉 |
| mama_recognition (P12) | PASS | nose to nose + "my favorite thing about you" 辨認行動 |
| ending quartet (P13) | PASS | ①全員同框 ②Dot 發現差異 ③斑斑自述 ④"And from that day on…" |

### 回譯偏移摘要

33 頁逐頁全量回譯完成。偏移標記：無 17 頁、輕微 16 頁、中度 0 頁。所有「輕微」均為改編制合法範圍內的語義微調（如 "funny" vs "奇怪"、"came close" vs "跑過來"），無語義漂移。無中度以上偏移，不觸發 STEP 4 分診。

### ESL 獵手

主題錨復述：同上。

**整體評估**：en-US 三檔文本母語自然度高，盲稿語感可信。翻譯腔訊號：0。AI 機械句訊號：0。

| # | 檔位 | 頁 | 獵物類型 | 原文 | 問題 | 建議 |
|---|---|---|---|---|---|---|
| H1 | 5-6 | P02 | ESL 搭配 | "Patch looked down at himself, then looked at everyone else." | 結構性鏡像重複 "looked...then looked"——母語者傾向省略第二個動詞 | "Patch looked down at himself, then at everyone else." |
| H2 | 3-5 | P04 | ESL 搭配 | "then poked out little round dots." | "poke out" 語義＝突出/伸出，非戳入；母語搭配＝poke (dots) into/in | "then poked little round dots." |
| H3 | 2-3 | P12 | AI 機械句 | "Mama, nose to nose." | 逗號造成呼格歧義（Mama 作呼喚 vs 主語）——但 2-3 電報式片語為 W7 合法語體 | "Mama — nose to nose." 或維持原狀 |

## STEP 3 人設 blind QA

### Ms. Rivera（幼教老師）

**分檔評分**

| 檔位 | 年齡適配度 | 朗讀口感 | 孩子抓得住度 |
|---|---|---|---|
| 2-3 | 5 | 6 | 5 |
| 3-5 | 8 | 8 | 8 |
| 5-6 | 8 | 7 | 7 |

**發現摘要**

| # | 嚴重度 | 檔位 | 頁 | 發現 |
|---|---|---|---|---|
| R1 | HIGH | 2-3 | P05→P11 | 只保留一次嘗試＋兩次疊句，2-3 幼兒需要更多重複循環建立預期 |
| R2 | HIGH | 2-3 | P11 | 遊戲前提缺少葉子頁（P09-P10 被跳），「猜猜我是誰」遊戲設定不明 |
| R3 | MEDIUM | 2-3 | P02 | "Your spots look funny!" 第二人稱直接控訴對 2 歲幼兒較強烈 |
| R4 | MEDIUM | 3-5 | — | 跳 P08 缺少情緒低谷呼吸，節奏稍急 |
| R5 | MEDIUM | 5-6 | P11 | 單頁 6 beats（遮臉→猜→猜錯→走進→認出→評論）密度偏高 |
| R6 | MEDIUM | 2-3 | P12-P13 | 連續兩頁安靜頁，2-3 幼兒注意力維持較困難 |
| R7 | MEDIUM | 全 | P13 | "And from that day on…" 收束式缺乏入睡訊號（如晚安/入睡動作） |

### Jessica（家長）

**分檔評分**

| 檔位 | 睡前適讀性 | 零說教 |
|---|---|---|
| 5-6 | 7 | 6 |
| 3-5 | 7 | 7 |
| 2-3 | 6 | 6 |

**發現摘要**

| # | 嚴重度 | 檔位 | 頁 | 發現 |
|---|---|---|---|---|
| J1 | HIGH | 全 | P13 | "Everyone's spots were a little bit different, after all." 中 "after all" 有道德提點感 |
| J2 | HIGH | 2-3 | P05→P11 | 跳接失去反覆結構，2-3 幼兒無法建立「下次會怎樣」期待 |
| J3 | MEDIUM | 全 | P13 | "I don't ever want to make my spots round again!" 角色自我宣言式結尾 |
| J4 | MEDIUM | 5-6 | P08 | "He couldn't tell his spots apart anymore…" 語義稍模糊 |
| J5 | MEDIUM | 全 | P13 | 收束式 "And from that day on…" 缺睡前情境訊號 |
| J6 | MEDIUM | 2-3 | P02 | "Your spots look funny!" 對 2 歲幼兒偏強烈 |
| J7 | MEDIUM | 2-3 | P13 | "Everyone's spots were different!" 對 2-3 幼兒過度抽象 |

### Margaret（資深編輯）

**分檔評分**

| 檔位 | 母語自然度 | 文字工藝 |
|---|---|---|
| 5-6 | 8 | 8 |
| 3-5 | 9 | 9 |
| 2-3 | 8 | 8 |

**發現摘要**

| # | 嚴重度 | 檔位 | 頁 | 發現 |
|---|---|---|---|---|
| M1 | MEDIUM | 5-6 | P07 | "washed away into purple streaks" — "into" 搭配不自然，應為 "in" |
| M2 | MEDIUM | 5-6 | P11 | "Round spots all looked the same" 缺冠詞 "The" |
| M3 | MEDIUM | 3-5 | P11 | "Guess who I am!" 缺引號——但此為群體喊叫，bare 處理一致 |
| M4 | LOW | 5-6 | P13 | "I don't ever want to" — "don't ever" 稍強烈，但兒童口語可接受 |
| M5 | LOW | 5-6 | P11 | 單頁密度偏高（6 beats），可考慮刪 "One guess — that's all it took." |
| M6 | LOW | 5-6 | P02 | "looked...then looked" 重複——同 H1 |
| M7 | LOW | 2-3 | P01 | "Little leopard cubs" 缺冠詞 "The"——但 2-3 電報式合法 |
| M8 | LOW | 2-3 | P03 | "No no no!" 逗號分隔可考慮——但電報式節奏優先 |

## STEP 4 三分法分診

**主題錨復述**：本書教「不一樣不是需要修好的問題，而是你之所以是你的標記」——由斑斑主動選擇被看見（P11）、媽媽辨認行動（P12）、斑斑自述（P13）三層承載，旁白零說教。情感核心＝「被認出來」。

### 裁決表

| # | 來源 | 檔位/頁 | 發現摘要 | 收斂計數 | 裁決 | 修改級別 | 依據 |
|---|---|---|---|---|---|---|---|
| T01 | H1+M6 | 5-6 P02 | "looked...then looked" 結構重複 | 2（獵手×人設） | ✅ | 字串級 | 母語搭配慣例：省略第二個動詞。替換："then looked at everyone else" → "then at everyone else" |
| T02 | M1 | 5-6 P07 | "washed away into" 搭配不自然 | 1 | ✅ | 字串級 | "wash away into" 非標準搭配；"wash away in" 為自然搭配。替換："into" → "in" |
| T03 | H2 | 3-5 P04 | "poked out" 語義錯誤 | 1 | ✅ | 字串級 | "poke out"＝突出/伸出，非戳入。5-6 P04 正確用 "poked...into"。替換：刪 "out" |
| T04 | H3 | 2-3 P12 | "Mama, nose to nose." 呼格歧義 | 1 | ❌ | — | 2-3 電報式片語為 W7 合法語體（style_guide §3.4 2-3 邊界）；圖＋上下文充分消歧 |
| T05 | J1 | 全 P13 | "after all" 有道德提點感 | 1 | ❌ | — | E 判 E-3 PASS；zh-TW「原來」為同質旁白觀察語氣，非說教模式。quality_criteria E-3 排除模式均不匹配 |
| T06 | R1+J2 | 2-3 P05→P11 | 跳接失去反覆結構 | 2（人設×人設） | ❌ | — | 推翻 2 路收斂。Lock-in：copy/en-US.md selection "2-3": [P01,P02,P03,P04,P05,P11,P12,P13] 為 S2 storyboard 凍結選頁表。人設 blind 於 storyboard 是 STEP 3 刻意設計。文本在選頁範圍內正確執行 |
| T07 | R3+J6 | 2-3 P02 | "Your spots" 第二人稱控訴偏強烈 | 2（人設×人設） | ❌ | — | 推翻 2 路收斂。Lock-in：copy/en-US.md P02 提純說明「2-3 合併為第二人稱直接控訴」——明文設計選擇 |
| T08 | J3 | 全 P13 | Patch 自我宣言式結尾 | 1 | ❌ | — | Lock-in：design.md 結尾③「斑斑在 P13 以自述表達『再也不想把斑點變圓了』（角色自己說，不由旁白代言）」 |
| T09 | R7+J5 | 全 P13 | 收束式缺睡前訊號 | 2（人設×人設） | ❌ | — | 推翻 2 路收斂。Lock-in：design.md 結尾④「後來呀……」= brand frozen closing formula，全書共用 |
| T10 | M2 | 5-6 P11 | "Round spots" 缺冠詞 "The" | 1 | ❌ | — | 兒童文學風格允許 bare noun；加 "The" 使 P11 字數 41→42，惡化帶標 ⚠ |
| T11 | R5+M5 | 5-6 P11 | 單頁密度偏高（41 字 / 6 beats） | 2（人設×人設） | ❌ | — | 推翻 2 路收斂。Lock-in：41 字僅超帶上緣 1 字（⚠ 非硬違規）；修改需刪句＝創作級，觸發完整輪——收益不抵成本。copy_check ⚠ 已如實標記 |
| T12 | J4 | 5-6 P08 | "He couldn't tell his spots apart anymore…" 語義模糊 | 1 | ❌ | — | zh-TW「什麼斑點都分不清了」同等模糊度；上下文（三次失敗後）充分消歧 |
| T13 | R4 | 3-5 | 跳 P08 缺情緒低谷 | 1 | ❌ | — | S2 storyboard 凍結選頁表（3-5 跳 P08 by design） |
| T14 | M3 | 3-5 P11 | "Guess who I am!" 缺引號 | 1 | ❌ | — | 一致慣例：named character 直接引語用引號，群體喊叫＋內心獨白 bare。"Guess who I am!" 為群體遊戲喊叫 |
| T15 | M4 | 5-6 P13 | "don't ever" 稍強烈 | 1 | ❌ | — | design.md 結尾③要求角色自述；"don't ever" 為兒童口語自然強調 |
| T16 | M7 | 2-3 P01 | "Little leopard cubs" 缺 "The" | 1 | ❌ | — | 2-3 電報式 W7 語體合法省略冠詞 |
| T17 | M8 | 2-3 P03 | "No no no!" 可加逗號 | 1 | ❌ | — | 2-3 電報式節奏優先；連續感嘆無逗號＝口語衝擊力 |
| T18 | J7 | 2-3 P13 | "Everyone's spots were different!" 過度抽象 | 1 | ❌ | — | zh-TW 2-3 P13「大家的斑點，都不一樣！」同等抽象度；忠於母本 |
| T19 | R6 | 2-3 P12-P13 | 連續兩頁安靜頁 | 1 | ❌ | — | S2 storyboard 凍結選頁表（P12-P13 為結尾固定結構） |

### 收斂計數

- 推翻 2 路收斂：T06（S2 凍結）、T07（copy 設計選擇）、T09（brand frozen）、T11（刪句＝創作級）——均引 lock-in 明文出處

### 修改級別彙整

✅ 全數 ∈ {字串級}——round 2 具復核輪資格。

### 訊源計量

獨有訊源分佈：獵手獨有 real 1｜回譯獨有 real 0｜人設獨有 real 1｜多路收斂 real 1

### ⏸️ 上呈批次

（無）

---

**回修指令**

| # | 檔案 | 修改 |
|---|---|---|
| T01 | text/en-US/5-6.draft.json P02 | "then looked at everyone else" → "then at everyone else" |
| T02 | text/en-US/5-6.draft.json P07 | "washed away into purple streaks" → "washed away in purple streaks" |
| T03 | text/en-US/3-5.draft.json P04 | "then poked out little round dots." → "then poked little round dots." |

回修後同步更新 copy/en-US.md 對應頁文案＋字數。
