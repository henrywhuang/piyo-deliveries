# QA 報告：my-spots-are-different / en-US / round 2（復核輪）

```yaml
schema: piyo_text_qa_report/v0.9
slug: my-spots-are-different
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-29"
step1_lint: {exit_code: 0, warnings: 0}
step2_checklist: {pass: 26, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 5, 朗讀口感: 6, 孩子抓得住度: 5}
  - id: en-US-parent
    scores: {睡前適讀性: 6, 零說教: 6}
  - id: en-US-editor
    scores: {母語自然度: 8, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

> **復核輪聲明**：round 1 裁決 ✅ 全數 ∈ {字串級}（3 筆），依 SKILL.md v0.14 復核輪資格執行。STEP 1 機檢全量重跑＋修改逐筆落地驗證＋copy↔draft 同源檢＋E-lite＋受修頁回譯同步。**人設不重跑**，分數沿用 round 1。

## STEP 1 機檢（全量重跑）

```
# copy_check.py — exit 0, 10 warnings (all ⚠, 0 violations)
python3 .claude/skills/piyo-text-writer/scripts/copy_check.py content/PYO-017_my-spots-are-different/copy/en-US.md

# locale_lint ×3 — all exit 0
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-017_my-spots-are-different/text/en-US/5-6.draft.json --locale en-US --band 5-6   # exit 0, warnings 2 (repeat_discount)
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-017_my-spots-are-different/text/en-US/3-5.draft.json --locale en-US --band 3-5   # exit 0, warnings 2 (repeat_discount)
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-017_my-spots-are-different/text/en-US/2-3.draft.json --locale en-US --band 2-3   # exit 0, warnings 0

# localize_readiness --contract — green
python3 .claude/skills/piyo-localize/scripts/localize_readiness.py content/PYO-017_my-spots-are-different --contract --locale en-US
```

全部 exit 0。copy_check 10 筆 ⚠ 同 round 1（帶下緣低標頁＋P11 帶上緣 41 字）。

## 修改逐筆落地驗證

| # | 裁決指定 | 實際 diff | 核銷 |
|---|---|---|---|
| T01 | 5-6 P02: "then looked at everyone else" → "then at everyone else" | `-then looked at everyone else.` / `+then at everyone else.` | ✓ 完全匹配 |
| T02 | 5-6 P07: "into" → "in" | `-washed away into purple` / `+washed away in purple` | ✓ 完全匹配 |
| T03 | 3-5 P04: "poked out" → "poked" | `-then poked out little round dots.` / `+then poked little round dots.` | ✓ 完全匹配 |

3/3 核銷完成，無殘餘修改。

## copy↔draft 同源檢

受修頁逐字比對：

| 頁 | copy 文案 | draft text | 一致 |
|---|---|---|---|
| 5-6 P02 | …then at everyone else. / 26✓ | …then at everyone else." | ✓ |
| 5-6 P07 | …washed away in purple streaks… / 23✓ | …washed away in purple streaks… | ✓ |
| 3-5 P04 | …then poked little round dots. / 16✓ | …then poked little round dots." | ✓ |

字數更新確認：5-6 P02 27→26✓、3-5 P04 17→16✓、5-6 P07 不變 23✓。

## STEP 2 checklist 自檢

> 復核輪 E-lite：僅複審受修頁＋相鄰頁。

**主題錨復述**：本書教「不一樣不是需要修好的問題，而是你之所以是你的標記」——由斑斑主動選擇被看見、媽媽辨認行動、自述三層承載。

### 受修頁複審

| 頁 | 修改內容 | 對位 | 語義保留 | 新問題 |
|---|---|---|---|---|
| 5-6 P02 | 刪第二個 "looked" | ✓ 無變化 | ✓ 觀察自己→觀察他人語義不變 | 無 |
| 5-6 P07 | "into" → "in" | ✓ 無變化 | ✓ 雨沖果汁語義不變 | 無 |
| 3-5 P04 | 刪 "out" | ✓ 無變化 | ✓ 戳圓點動作語義不變 | 無 |

### 相鄰頁複審

| 頁 | 與受修頁銜接 | 判定 |
|---|---|---|
| 5-6 P01 | → P02：嬉戲場景→發現差異，銜接自然 | ✓ |
| 5-6 P03 | P02 →：發現差異→決心改變，銜接自然 | ✓ |
| 5-6 P06 | → P07：果汁操作→雨沖失敗，銜接自然 | ✓ |
| 5-6 P08 | P07 →：雨沖失敗→沮喪低谷，銜接自然 | ✓ |
| 3-5 P03 | → P04：決心改變→泥巴操作，銜接自然 | ✓ |
| 3-5 P05 | P04 →：泥巴操作→泥巴裂開，銜接自然 | ✓ |

E-lite 結論：3 筆修改均為字串級搭配修正，不影響對位、語義或銜接。0 新問題。

## 受修頁回譯同步

3 頁受修頁由獨立 blind 回譯員重譯（輸入僅含受修頁 en-US 切片），逐字貼回 backtranslation.md。E 比對偏移標記：

| 頁 | 回譯 | 偏移 | 與 round 1 比較 |
|---|---|---|---|
| 5-6 P02 | 「那個看起來好好笑——像一顆星星！」…低頭看看自己，又看看其他人。 | 輕微（同 r1） | 無變化——刪 "looked" 不影響中文語義 |
| 5-6 P07 | 嘩啦嘩啦！雨落了下來！果汁被沖走，留下紫色的痕跡…… | 輕微（同 r1） | 無變化——"in" vs "into" 中文無差 |
| 3-5 P04 | 啪、啪、啪！…把泥巴抹得到處都是，然後戳出一個個小圓點。 | 無（同 r1） | 無變化——刪 "out" 不影響中文「戳出」 |

backtranslation.md 無殘留「回修待重譯」。覆蓋率機檢：S4A＝逐頁全量，`| P` 行數 = 13+12+8 = 33 = 三檔頁數和。

## STEP 3 人設 blind QA

分數沿用 round 1，原因＝復核輪規則（字串級修改不影響人設維度評分）。

## STEP 4 三分法分診

round 2 ✅ = 0。QA 收斂。
