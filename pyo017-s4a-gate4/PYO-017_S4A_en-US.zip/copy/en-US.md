# 圖文總表：My Spots Are Different（my-spots-are-different / en-US）

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: my-spots-are-different
locale: en-US
mode: B
storyboard: content/PYO-017_my-spots-are-different/PYO-017_storyboard.md
design: content/PYO-017_my-spots-are-different/PYO-017_design.md
image_pool: 13
selection:
  "3-5": [P01, P02, P03, P04, P05, P06, P07, P09, P10, P11, P12, P13]
  "2-3": [P01, P02, P03, P04, P05, P11, P12, P13]
commitments:
  refrain: "Patch's spots are NOT the same!"
  ending: "And from that day on…"
  onomatopoeia: ["Splat, splat, splat!", Crack, SQUISH!, SPLISH SPLASH!, ACHOOOO!]
characters: [Patch, Dot, Mama]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | The little leopard cubs chased butterflies across the grassland.<br>Patch ran ahead of everyone — so fast, so fast! | 18✓ | 1 | The little leopard cubs chased butterflies.<br>Patch ran ahead of everyone! | 11✓ | 1 | Little leopard cubs chased butterflies!<br>Patch ran so, so fast! | 10✓ | ✓ | 5-6 擴展場景（草地），3-5 砍場景，2-3 電報式 |
| P02 | 2 | "That one looks funny — like a star!" said Dot.<br>"Yeah, mine are all round," said another cub.<br>Patch looked down at himself, then at everyone else. | 26✓ | 2 | "That spot looks funny — like a star!" said Dot.<br>Patch looked down at himself, then at everyone else. | 18✓ | 2 | "Your spots look funny! Like stars!"<br>Patch looked down at his spots. | 12✓ | ✓ | 3-5 砍另一隻附和，2-3 合併為第二人稱直接控訴 |
| P03 | 3 | Patch touched the star-shaped spot on his side.<br>No way! I have to make my spots round!<br>Off he ran! | 20✓ | 3 | Patch touched his star spot —<br>No way! I have to make them round!<br>Off he ran! | 16✓ | 3 | No no no!<br>Patch wanted round spots! | 7✓ | ✓ | 5-6 含確認動作（觸摸），3-5 簡化，2-3 只留情緒爆發＋意圖 |
| P04 | 4 | Splat, splat, splat! Splat, splat, splat!<br>Patch smeared mud all over himself,<br>then poked little round dots into the mud with one finger. | 23✓ | 4 | Splat, splat, splat! Splat, splat, splat!<br>Patch smeared mud all over,<br>then poked little round dots. | 16✓ | 4 | Splat, splat, splat!<br>Patch put mud on his spots. | 9✓ | ✓ | 擬聲詞三檔一致 O3 節奏三連；2-3 砍一組 splat＋動作極簡化 |
| P05 | 5 | Crack… crack… the mud split apart!<br>The star spot peeked out first.<br>Patch's spots are NOT the same! | 18✓ | 5 | Crack… crack… the mud split!<br>The star spot peeked right out.<br>Patch's spots are NOT the same! | 17✓ | 5 | Crack… crack… the mud broke!<br>Patch's spots are NOT the same! | 11✓ | ✓ | 疊句#1 三檔一致；2-3 砍星星斑點細節（圖已說） |
| P06 | 6 | SQUISH! Patch squeezed the berries until they burst.<br>He painted round dots all over himself with the juice —<br>even better than last time! | 23✓ | 6 | SQUISH! Patch squeezed the berries.<br>He painted round dots all over with the juice. | 14✓ | — | — | — | ✓ | 句式與 P04 平行換材料；3-5 砍旁白判斷 |
| P07 | 7 | SPLISH SPLASH! Down came the rain!<br>The juice washed away in purple streaks — spots messier than before!<br>Patch's spots are NOT the same! | 23✓ | 7 | SPLISH SPLASH! Down came the rain!<br>The juice all washed away!<br>Patch's spots are NOT the same! | 17✓ | — | — | — | ✓ | 疊句#2 三檔一致（2-3 未選） |
| P08 | 8 | The rain stopped.<br>Patch sat alone under the big tree,<br>looking down at the puddle.<br>He couldn't tell his spots apart anymore… | 22✓ | — | — | — | — | — | — | ✓ | 5-6 專屬低谷頁，呼吸感文字 |
| P09 | 9 | Patch stood up.<br>He tied big round leaves all over himself with long vines —<br>this time, round spots everywhere! | 19✓ | 8 | Patch stood up.<br>He tied big leaves all over himself —<br>round spots everywhere! | 13✓ | — | — | — | ✓ | 3-5 砍 vines 細節 |
| P10 | 10 | A leaf tickled his nose —<br>ACHOOOO!<br>Leaves exploded everywhere!<br>Patch's spots are NOT the same! | 15✓ | 9 | A leaf tickled his nose —<br>ACHOOOO!<br>Leaves went flying!<br>Patch's spots are NOT the same! | 15✓ | — | — | — | ✓ | 疊句#3 三檔一致；全書最快節奏 |
| P11 | 11 | Everyone grabbed leaves and covered their faces.<br>Guess who I am!<br>Round spots all looked the same — guess after guess, all wrong.<br>Patch held up a leaf and walked right in.<br>"It's Patch!" said Dot. One guess — that's all it took. | 41⚠ | 10 | Everyone covered their faces — Guess who I am!<br>Wrong, wrong — they all looked the same.<br>Patch walked right in. "It's Patch!" | 21✓ | 6 | Everyone played a game! Guess who?<br>Patch walked in — "It's Patch!" | 11✓ | ✓ | 5-6 完整互猜過程＋Dot 具名喊出，3-5 壓縮，2-3 電報式遊戲→認出；2-3 跳接自足：P05 泥巴失敗→P11 遊戲新場景，遊戲呼喊自然設定新語境 |
| P12 | 12 | "That's MY Patch!"<br>Mama came close, nose to nose.<br>"Your star-shaped spots are my favorite thing about you."<br>Patch's spots are not the same. | 24✓ | 11 | "That's MY Patch!" Mama came close, nose to nose.<br>"Your spots are my favorite."<br>Patch's spots are not the same. | 20✓ | 7 | Mama, nose to nose.<br>"My favorite little spots!"<br>Patch's spots are not the same. | 14✓ | ✓ | 疊句變奏（句號）三檔一致；5-6 含 star-shaped 回扣，3-5 壓縮台詞，2-3 電報式 Mama 片語＋極短台詞 |
| P13 | 13 | "This one's a little oval!" said Dot.<br>Everyone's spots were a little bit different, after all.<br>"I don't ever want to make my spots round again!" said Patch.<br>And from that day on… | 33✓ | 12 | "This one's a long one!" said Dot.<br>Everyone's spots were all different.<br>"No more round spots!"<br>And from that day on… | 21✓ | 8 | Everyone's spots were different!<br>"No more round spots!"<br>And from that day on… | 13✓ | ✓ | 結尾四件套三檔完整：①全員同框 ②Dot 發現差異（3-5/2-3 由旁白承載）③斑斑自述 ④收束式 |
