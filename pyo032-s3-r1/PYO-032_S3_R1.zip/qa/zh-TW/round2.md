# QA 報告：who-falls-asleep-first / zh-TW / round 2（復核輪）

```yaml
schema: piyo_text_qa_report/v0.9
slug: who-falls-asleep-first
locale: zh-TW
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-30"
step1_lint: {exit_code: 0, warnings: 4}
step2_checklist: {pass: 3, fail: 0}
step3_personas:
  - id: zh-TW-teacher
    scores: {年齡適配度: 8, 朗讀口感: 9, 孩子抓得住度: 9}
  - id: zh-TW-parent
    scores: {睡前適讀性: 9, 零說教: 10}
  - id: zh-TW-editor
    scores: {母語自然度: 9, 文字工藝: 9}
step4_triage: {real: 0, rejected: 0, escalated: 3}
verdict: escalated
```

本輪為復核輪：STEP 1 機檢全量＋修改逐筆落地驗證＋copy↔draft 同源檢＋E-lite。人設不重跑，分數沿用 round 1。

## STEP 1 機檢

```
5-6：exit 0，違規 0，警告 0
3-5：exit 0，違規 0，警告 2（repeat_discount：疊句「我才不會先睡著！」×3，合法）
2-3：exit 0，違規 0，警告 2（repeat_discount：疊句「我才不會先睡著！」×4，合法）
```

附：3-5/2-3 page 欄修正為流水序號（image 欄保留 storyboard 頁碼），與 PYO-001 慣例對齊。

## STEP 2 checklist 自檢

**主題錨復述句**：這是一個「比賽誰先睡著」的入睡儀式故事——比賽是入口，被家人包圍的安心才是出口；小寶是最後醒著的贏家，但勝負早已不重要。

### E-lite 複審範圍

受修頁＋鄰頁：5-6 P07/P08/P09、3-5 P08/P09/P10、2-3 P05/P06/P07

### 修改落地驗證

| # | 裁決指定 | 實際修改 | 核銷 |
|---|---|---|---|
| 1 | 5-6 P08 末行改描述性，呼嚕嚕/噗嚕嚕降至各 ≤3 | →「兩種打呼聲，一大一小，輪流響著……」；呼嚕嚕=3(P04,P10,P12)、噗嚕嚕=3(P07,P10,P12) | ✓ |
| 2+3 | 2-3 P10(image) 補截斷疊句＋動作中斷 hook | 補「我才不會先……」→ refrain 三拍兌現＋截斷=中斷態 | ✓ |
| 14 | 3-5 P10(image) 插入「爸爸」 | →「靠在爸爸暖暖的大肚子上」+2 字 | ✓ |

### copy↔draft 同源檢

三處修改文本（copy `<br>` ↔ draft `\n`）與字數均一致。✓

### E-lite 逐筆判定

| # | 檔位 | 頁 | 判定 | 說明 |
|---|---|---|---|---|
| 1 | 5-6 | P08 | PASS | B-3 降頻達成（呼嚕 3、噗嚕 3）；描述句與前後觀察語態銜接自然 |
| 2+3 | 2-3 | P06(image P10) | PASS | 疊句三拍弧線完整（宣告→宣告→截斷）；翻頁鉤子增強 |
| 14 | 3-5 | P09(image P10) | PASS | 指稱鏈閉合；字串級改動，零副作用 |

**觀察（非 FAIL）**：5-6 P07「小小的噗嚕嚕」若以字串匹配計，噗嚕嚕全書=4。P07 為名詞用法，非表演性擬聲。copy 總表已核准 P07 文本，非本輪受修頁。

### 母本語感獵手（round 1 已完成）

round 1 STEP 2C 結果：獵物① 0 命中、獵物② 2 命中（P12 prose 傳染→round 1 STEP 4 分診判 ❌ 誤報，依據：design「固定收束語」＋copy commitments 鎖定）。本輪受修頁（P08/P10 image）不在 2C 命中範圍。

## STEP 3 人設 blind QA

復核輪人設不重跑。分數沿用 round 1（摘要分＝最弱檔位）：

| 人設 | 維度 | 摘要分 |
|---|---|---|
| zh-TW-teacher | 年齡適配度 / 朗讀口感 / 孩子抓得住度 | 8 / 9 / 9 |
| zh-TW-parent | 睡前適讀性 / 零說教 | 9 / 10 |
| zh-TW-editor | 母語自然度 / 文字工藝 | 9 / 9 |

## STEP 4 三分法分診

✅ real = 0（round 1 的 4 筆 ✅ 已修復落地，E-lite 驗證通過）
❌ rejected = 0
⏸️ escalated = 3（round 1 ⏸️ 照常上呈）

### ⏸️ 上呈批次（承接 round 1）

**上呈項 A**：5-6 P09「好大好大**一坨**」——三路收斂（語域/節奏/家長觀感），裁決傾向保留。若 Stacy 決定柔化：→「好大好大一團」。詳見 round 1 分診。
