# QA 報告：`gate4_en-US_review.md`（PYO-013 拔蘿蔔）

- QA 日期：2026-07-20
- QA 對象：`content/PYO-013_the-giant-turnip/qa/review/gate4_en-US_review.md`（2026-07-20 19:51 生成，`make_review.py --gate 4`）
- QA 方法：以套件內來源檔（六份 text JSON、storyboard、qa/en-US round1-3、backtranslation.md、共享 registry、gate3 決策）做決定性逐項核對；引文比對以腳本執行，非目測
- QA 結論：**審包內容可信，可交 Stacy 審讀**。核心宣稱全數驗證通過，零實質錯誤；下列 4 項觀察供審讀時參考，均不構成退件理由

## 一、驗證通過項（逐項核對結果）

| # | 審包宣稱 | 核對方式 | 結果 |
|---|---|---|---|
| 1 | 逐頁三欄對照的「zh-TW 母本」「en-US 改編」引文 | 腳本逐列比對 35 列 vs `text/` 六份 JSON（換行↔「／」正規化後全等比對） | ✅ 35/35 完全一致，無漏頁、無改寫、無截斷 |
| 2 | 「回譯」欄與偏移標記 | 逐列比對 `qa/en-US/backtranslation.md` | ✅ 回譯全文一致；35 列偏移標記全「無」，總覽「偏移標記數 0」屬實 |
| 3 | 三檔選用頁數 13／12／10 與母版頁映射（3-5 P07→母版 P08；2-3 P07→P09、P08→P10、P09→P12、P10→P13） | 對照 storyboard §1 三檔選用表 | ✅ 完全一致 |
| 4 | round3 YAML 摘要（lint 0 違規 11 警告、checklist 25/0、persona 分數、triage 0/16/1、verdict escalated） | 對照 `qa/en-US/round3.md` 原檔 | ✅ 原樣引用無出入；teacher 4 分、parent 4 分低分如實披露未粉飾 |
| 5 | ESL 獵手段落（35/35 頁 finding 0）與 Round 3 重點表 | 對照 round3.md | ✅ 逐字一致 |
| 6 | `verdict: escalated` 原樣保留、審包不含 decision、不代表 freeze 或 Stage 推進 | 對照 CLAUDE.md 審核紀律第 4 條 | ✅ 合規——未為送審改寫 AI verdict |
| 7 | Registry proposal bundle：title＋5 角色名＋9 音效；「共享 registry 尚無 PYO-013 entry」 | 角色名對 design §7 提案；9 音效逐一對六份 en-US 文本；grep `character_names.md`／`onomatopoeia_map.md` | ✅ 角色名一致；9 音效與文本實際出現**完全對應（無遺漏、無多列）**；共享 registry 確無 PYO-013 條目 |
| 8 | 機檢可重現性 | 本機重跑 locale_lint：en-US 三檔 exit 0、警告數與折計值（87.5／202／294）與 round3 記載一致 | ✅ 可重現 |

## 二、觀察項（不構成退件）

1. **「STEP 4 最終分診」表的『Gate 4 證據摘要』欄是改寫而非原文**：如 R3-03 round3 作「滾動聲與大笑」→ 審包作「滾動聲與笑點」、R3-05「刪錯咬細節」→「提純錯咬細節」。語義等價、且該欄本就標為「證據摘要」，無失真；僅提醒與標題「原文引用」（僅指 ESL 段）的適用範圍勿混讀。
2. **來源檔案表的 mtime 無法在本快照驗證**：本包為移動式快照，磁碟 mtime 已被複製動作覆蓋（例如 storyboard 實際 mtime 2026-07-19 22:13，審包記 2026-07-20 18:29）。相對先後序（zh 母本早於 en 改編）仍成立；此為快照環境限制，非審包錯誤。
3. **審包未註記母本側兩項 gate3 已接受的 structural escalation**（3-5 P12 句長 32、2-3 電報式收束）。gate4 是 en-US 證據審、母本已凍結，不列不算缺陷；但只讀本審包的審讀者看到 P12 母本長句可能重新起疑，建議未來版本的 `make_review.py` 在來源檔案表附一行 gate3 decision 參照。
4. **審讀聚焦建議（內容judgment，非審包錯誤）**：5-6 P12 母本「嘰嘰的那一口，是全世界最好喝的湯」在 en-US 收為 "Pip took one little sip. Mmm!"，是 35 頁中母本情感濃度削減最明顯的一頁；回譯判「無偏移」在盲稿改編制下成立，但建議 Stacy 逐頁審讀時人工確認此頁接受。同理 3-5 P11 en-US 增句 "They'd pulled together, and now they ate together"（母本無此平行句，round3 R3-13 已判非說教）。

## 三、連帶提醒

- gate4 bundle 只涵蓋 en-US 音效；zh-TW 六個 motif（嘿喲嘿喲、啪嗒啪嗒、汪汪、噗——、咚咚咚、咕嚕嚕）在 `onomatopoeia_map.md` 亦無條目，Green Light 後回寫 registry 時應一併登記（源：design §5）。
- 本快照無 `.git/` 與 `.claude/skills/piyo-text-qa/`（含 `make_review.py`），故本 QA 以「輸出對來源」決定性比對代替重跑產生器；結論不受影響。
