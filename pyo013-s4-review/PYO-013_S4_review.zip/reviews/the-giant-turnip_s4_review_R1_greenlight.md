# S4 Greenlight：《拔蘿蔔》

## 審稿識別
- 繪本編號：PYO-013
- 繪本 Slug：the-giant-turnip
- 書名（zh-TW）：《拔蘿蔔》
- 審稿輪次：R1（本 skill〔skill-s4-copywriting-review v0.9〕首輪；生產管線 piyo-text-qa 另有 en-US round1-3 紀錄，於 qa/en-US/）
- 審稿日期：2026-07-20
- 審稿依據：piyo-copywriting-review v0.9（docs/skill/skill-s4-copywriting-review.md）
- 審稿對象檔案：
  - zh-TW：`text/zh-TW/2-3.json`、`text/zh-TW/3-5.json`、`text/zh-TW/5-6.json`（gate3 凍結版，SHA 見 `qa/review/gate3_decision.md`）
  - en-US：`text/en-US/2-3.draft.json`、`text/en-US/3-5.draft.json`、`text/en-US/5-6.draft.json`
- 本報告檔名：the-giant-turnip_s4_review_R1_greenlight.md
- 判定：**GREENLIGHT — 五維度全部通過**（AI 審稿判定；不取代關卡④ Stacy 親審，見備註 1）

## 來源文件核對
- S2 storyboard：`PYO-013_storyboard.md`（schema piyo_storyboard/v0.10；三檔選用表 13／12／10 頁）
- Storyboard greenlit：是（book.yaml status=S4A，gate2 已過；gate3 zh-TW 已 Green Light 2026-07-20）
- 提案卡：`docs/planning/book_slate.md` PYO-013——家庭關係／家庭合作，「一個大蘿蔔拔不出來，全家一個接一個加入，最後一起完成」，累加式，2-3 極適合疊句
- 概念契約：design §0A `target_ability`＝察覺一個人做不到→主動開口邀請→歡迎每一個（包括最小的）幫手

## 五維度判定
| 維度 | 判定 |
|---|---|
| 朗讀自然度 | 通過 |
| 幼兒可理解性 | 通過 |
| 圖文配合度 | 通過 |
| 品牌與 Registry 合規 | 通過（registry 條目為「提案」狀態，待關卡④人工核可回寫） |
| 三檔 × 兩語一致性 | 通過 |

## 審查過程紀錄（逐維度證據）

### 維度一：朗讀自然度 — 通過
- **zh-TW**：逐頁朗讀無卡口。疊句「嘿喲嘿喲，拔呀拔——拔不動！」節奏可跟唱、三歲可接「拔不動！」；語氣詞全走台灣口語（「後來呀」「來！」「好暖好暖」），無簡體語感滲漏（linter banned_terms 零命中）。5-6 P07「安靜安靜……」→ P10 爆發「噗——！」的蓄力—釋放結構完整。
- **en-US**：像美國幼稚園老師的說書口吻，非 ESL 腔。母語天然表達齊備："Well, now!"、"Could you lend a hand?"、"Wrong thing!"、縮寫（I'll、wouldn't、They'd）、具體動詞（raced、dashed、burst）。倒裝 "Down went the whole line" 與 "came the tiniest little voice" 是道地 storybook register。piyo-text-qa round3 blind ESL 獵手 35/35 頁 finding 0，與本輪人工朗讀判斷一致。
- **換氣測試**：2-3 每頁一口氣可完；5-6 最長頁（P06 五行）兩口氣內。**翻頁 hook**：P02-P04 以呼喚句收尾送出畫外、P07 懸念問句、2-3 P07 "All ready—" 破折號交棒進 P08 疊句，均屬「話沒說完就翻頁」型。

### 維度二：幼兒可理解性 — 通過
- **每頁一件事**：逐頁成立；5-6 P05（錯咬→歸位→再拔）是兩拍複合，5-6 檔可承受，3-5／2-3 已依 design §6 提純。
- **概念具體度**：全書無抽象詞。「合作」只以可見行為顯現（手→腰→圍裙→衣角→尾巴的鏈條），符合 design metaphor_rules。「每個人都有用」出自爺爺台詞（角色第一人稱），非旁白宣講。
- **情緒動作化**：疲憊＝坐地喘氣／HUFF… PUFF…；遲疑＝愣住／blinked；喜悅＝倒成一串大笑，無「他很生氣」式旁白宣告。
- **三檔質化差異**（非只刪長補短）：2-3＝電報句＋高密度疊句＋公式化累加（"X joined."×3）；3-5＝短中句混合＋簡單因果（泥土裂開）；5-6＝因果複句＋心理描寫＋個性微拍（助跑、錯咬）。兩語皆成立。

### 維度三：圖文配合度 — 通過
- 逐頁對照 storyboard「文說什麼」負載：en-US 六類負載全數兌現（含 P06 喘息擬聲 HUFF… PUFF…、P07 rustle… rustle…、P12 Mmm!）；zh-TW 各頁核心負載（時間、心理、台詞邀請、勞動疊句）全兌現，P06／P07／P12 的「擬聲」負載以旁白敘述承接（見備註 5，不擋）。
- **圖文重複檢測**：無整頁複述畫面的情形。鏈條「誰抓住誰」的點名屬累加式民間故事的口傳骨架，非重複圖面；文字補的是圖畫不出來的東西——時間（Overnight／傍晚／後來呀）、聲音、心理（能拔得動嗎？）、持續狀態（一動也不動）。
- **情緒匹配**：P06 低谷（文字急停短句）、P07 屏息（懸念問句）、P10 爆發（OUT! POP!）、P13 安心（收束式），與 storyboard 情緒欄逐頁相符。

### 維度四：品牌與 Registry 合規 — 通過
- **品牌三條線**：①旁白零對聽眾出題——P07／P08 疑問句均為角色內心／台詞（"What was that?" whispered Sunny；「這麼小一隻，能拔得動嗎？」＝眾人心聲），無「小朋友你說」句式。②旁白零總結道理——en-US 3-5 P11 "They'd pulled together, and now they ate together" 為具體前後行為描述（round3 R3-13 已裁非說教），全書無教訓句。③收尾回到大家在一起——六版全部以全員分湯＋全員奔赴收束。
- **結尾四件套**：收束式「後來呀……」／"And from that day on…" 六版全數在場（含 2-3 兩語，滿足 F10 低齡收束式必備）；結尾情緒安定、無開放懸疑。
- **Registry**：角色名（爺爺／奶奶／小翔／旺旺／嘰嘰＝Grandpa／Grandma／Sunny／Woofy／Pip）與 design §7 提案完全一致、六檔零漂移；共享 registry 尚無 PYO-013 條目，en-US 提案 bundle 已列於 gate4 審包待 Stacy 核可（本審查逐一核對：9 個音效與文本實際出現完全對應、無遺漏無多列）。同一 motif 檔內寫法完全一致（嘿喲嘿喲×5、Heave-ho! Pull, pull, pull—×5 等，linter repeat 偵測佐證）。
- **量化門檻**（locale_lint 實跑，2026-07-20）：en-US 三檔 exit 0（2-3 折計 87.5／上限 88、3-5 202／389、5-6 294／505）；zh-TW 2-3／5-6 exit 0，3-5 P12 句長 32>30 為 gate3 已明確接受的 structural escalation（凍結收束式不可拆句），非新發現。

### 維度五：三檔 × 兩語一致性 — 通過
- **三檔骨架**：beat 序列一致（發現→逐輪邀請→低谷→最小幫手→合力成功→分享→主動再來）；低檔位省略頁（3-5 去 P07、2-3 去 P07/P08/P11）之 beat 由鄰頁承接，主線不變；三檔結尾皆收束式；角色名三檔零漂移。
- **兩語一致**：blind 回譯 35/35 頁偏移標記 0（qa/en-US/backtranslation.md），本輪逐頁複核情緒弧線走向兩語一致；擬聲詞各自遵循母語系統（嘿喲嘿喲↔Heave-ho!、噗——↔POP!），無直譯。
- 微幅檔間差異（en-US 3-5 保留錯咬微拍、zh-TW 3-5 刪除）屬盲稿改編制的合法自由度，beat 與情緒不受影響（見備註 6）。

## 備註（不影響放行）

1. **本 greenlight 是 AI 審稿判定，不取代也不改寫任何人工關卡**：piyo-text-qa round3 `verdict: escalated`（唯一原因＝registry proposal bundle 待人工裁定）依紀律原樣保留；進 TTS 前仍需關卡④ Stacy 親審 gate4 審包並裁定 registry bundle。
2. **gate3 已裁決項**（列出僅為完整性，不重啟）：zh-TW 3-5 P12 句長 32、2-3 電報式收束、5-6 P05「他」（不改「牠」）。
3. **zh-TW 5-6 P08 排版微瑕**：「我……」後有連續兩個半形空格（`我……␣␣我也`）。gate3 已凍結不回改；建議記入重錄／重排版時的清理清單（karaoke 顯示層可能露出多餘空隙）。
4. **en-US 2-3 總量貼線**：折計 87.5／上限 88。後續對 2-3 檔任何加字修改都必須重跑 locale_lint。
5. **zh-TW 擬聲負載差**：storyboard P06（喘息）、P07（葉後動靜）、P12（暖湯輕聲）的擬聲負載，zh-TW 以旁白敘述承接、en-US 以擬聲字兌現（HUFF… PUFF…／rustle… rustle…／Mmm!）。兩語各自成立、gate3 已放行；若未來 zh-TW 重錄，可考慮補齊以強化聲音介面。
6. **語義落差最大頁提示（供 Stacy 證據審聚焦）**：5-6 P12 母本「嘰嘰的那一口，是全世界最好喝的湯」的詩意最高級，en-US 弱化為 "Pip took one little sip. Mmm!"——改編制合法、回譯判無偏移，但屬 35 頁中母本情感濃度削減最明顯的一處，建議人工確認接受。
7. **Registry 回寫勿漏 zh-TW 側**：gate4 bundle 只列 en-US 音效；zh-TW 六個 motif（嘿喲嘿喲、啪嗒啪嗒、汪汪、噗——、咚咚咚、咕嚕嚕，源 design §5）在 `onomatopoeia_map.md` 同樣尚無條目，Green Light 後回寫時應一併登記；2-3 檔的「啪嗒！」單次形建議以「主形啪嗒啪嗒＋低齡短形」備註登記。

## 補充專項：翻譯腔與 locale 語感複核（2026-07-20，應 Stacy 指示加審）

### 檢查機制確認（管線側是否切實檢查過）

- **en-US（模式 B 盲稿改編制）**：翻譯腔防線是結構性的——B1 作家**盲稿**（宣告未讀 zh-TW 母本），從源頭杜絕逐句暗譯；B2 才對源校準語義。之後三輪 QA 每輪都有獨立 blind ESL 獵手全頁掃描＋blind 回譯。**獵手是真獵不是走過場**，有具體戰果：round1 抓 7 筆（`come up`→`come out` 植物語境歧義、`shared together` 贅語、`joined the end` 錯搭配、`All tired.` 非自然 fragment、`Turnip came free!` 缺冠詞等）、round2 再抓 2 筆（`Come!`→`Come on!`、`No calls. All came.` 整句重寫）、round3 掃 35/35 頁收斂至 0。
- **zh-TW（模式 A 母本原創，非翻譯）**：翻譯腔風險向量＝簡中源語料滲漏與課文腔，防線為 locale_lint banned/warn terms（本機重跑 0 命中）＋gate3 三位 blind 人設（蔡主編母語自然度 9-10/10）。

### 本輪獨立複核（不依賴管線結論，逐頁重讀 70 頁）

**en-US 對照 spec R1-R7＋搭配詞獵手：0 筆翻譯腔。**逐項驗證：無中文句法殘留（無主語過度重複、無因果直譯結構、無 topic-comment 語序）；搭配詞全數道地（with all his might、lend a hand、we could use your help、stayed put、burst free、all by themselves）；縮寫合規（wouldn't／They'd／I'll，無僵硬完整式）；母語者天然裝置在場——倒裝（Down went the whole line／came the tiniest little voice）、後置程度（a turnip this stubborn）、所有格省略（around Woofy's）、民間故事正典號子 Heave-ho!；冠詞、介系詞、動詞論元零缺漏；2-3 檔 fragment 全數符合 R7 幼幼語體。register 就是「美國幼稚園老師唸故事」，非 ESL 教材腔。

**zh-TW 對照 spec R2-1~R2-7：0 筆違規，2 筆品味級留意項。**逐項驗證：強調全走「好X好X」（好興奮好興奮、好累好累、好暖好暖），零「非常／十分」書面腔（R2-4）；動作綿延「拔呀拔、搖呀搖」＋說書人「後來呀」（R2-2/R2-4）；口語銜接用「可是」，零「然而／於是／因此」（R2-1）；把字句非「將」字句、無被動堆疊（R2-5）；零兒化、零「咱們／啥／咋」（R2-6）；擬人角色一律「他」、無「妳／牠／它」；2-3 檔電報式合規（R2-7）。「嘿喲嘿喲」直接呼應台灣幼兒園也唱的〈拔蘿蔔〉兒歌傳統，是加分選字。留意項（均 5-6 檔、gate3 已凍結、不擋件）：①P02「使勁拉」——台灣口語更常「用力拉」，「使勁」稍偏陸語感但台灣童書可見，spec 未列 warn；②P09「一條最長的鏈」——裸名詞「鏈」稍書面，口語更自然是「鏈子」。若未來重錄可順手優化。

### 結論

翻譯腔與 locale 語感**已切實檢查**：管線三輪獵手有真實戰果且收斂軌跡可追溯，本輪獨立複核與其結論交叉一致。en-US 0 筆、zh-TW 0 違規＋2 筆品味級留意，不影響 GREENLIGHT 判定。
