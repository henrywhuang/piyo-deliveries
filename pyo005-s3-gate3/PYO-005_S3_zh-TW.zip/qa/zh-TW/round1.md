# QA Report — Round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: a-little-light-in-the-dark
locale: zh-TW
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-29"
step1_lint:
  exit_code: 0
  warnings: 14
step2_checklist:
  pass: 26
  fail: 0
step3_personas:
  - id: zh-TW-teacher
    scores: {年齡適配度: 8, 朗讀口感: 8, 孩子抓得住度: 8}
  - id: zh-TW-parent
    scores: {睡前適讀性: 8, 零說教: 10}
  - id: zh-TW-editor
    scores: {母語自然度: 9, 文字工藝: 9}
step4_triage:
  real: 5
  rejected: 6
  escalated: 0
verdict: fix_required
```

## STEP 1 機檢

| 工具 | exit | warnings |
|---|---|---|
| copy_check.py | 0 | 11 |
| locale_lint 5-6 | 0 | 0 |
| locale_lint 3-5 | 0 | 0 |
| locale_lint 2-3 | 0 | 3 |

超帶上緣頁（警告非紅）：5-6 P01=45 / P04=42 / P09=45；2-3 P01=23 / P09=21。

## STEP 2 checklist 自檢

26 pass / 0 fail。

- A-E 品質清單：D-1/D-2/D-3 = N/A（需美術）；餘項全 pass。
- 對位原則：35 頁逐頁 pass。
- concept fidelity：三檔 pass（主題錨＝害怕不靠工具消除，行動中自己變勇敢）。
- 趣味設計兌現：認知落差 / 握緊才亮 / 三輪遞進 / 疊句變奏 / 不亮=不怕了 reversal——全項兌現。

## STEP 3 人設 blind QA

| persona | 維度 | 5-6 | 3-5 | 2-3 | 最弱 |
|---|---|---|---|---|---|
| 林老師 | 年齡適配度 | 9 | 8 | 8 | 8 |
| 林老師 | 朗讀口感 | 9 | 8 | 9 | 8 |
| 林老師 | 孩子抓得住度 | 9 | 8 | 8 | 8 |
| 沛珊 | 睡前適讀性 | 9 | 9 | 8 | 8 |
| 沛珊 | 零說教 | 10 | 10 | 10 | 10 |
| 蔡主編 | 母語自然度 | 9 | 9 | 10 | 9 |
| 蔡主編 | 文字工藝 | 9 | 9 | 10 | 9 |

12 findings submitted（合併後 11 unique，F5 為 2 路收斂）。

## STEP 4 三分法分診

| # | 檔位 | 頁 | 摘要 | 級 | 裁決 |
|---|---|---|---|---|---|
| F1 | 5-6 | P05 | 「灌木叢」→「草叢」 | 字串級 | ✅ |
| F2 | 3-5 | P01 | 「喔」語氣疑慮 | — | ❌ |
| F3 | 3-5 | P06 | 「不知不覺」→「慢慢」 | 字串級 | ✅ |
| F4 | 3-5 | P08 | 「手，沒有自己捏緊」→「手沒有握緊」 | 字串級 | ✅ |
| F5 | 2-3 | P05 | 黑影未收尾→補「不見了！」橋接 | 創作級 | ✅ |
| F6 | 2-3 | P09 | 高潮頁太沉重 | — | ❌ |
| F7 | 5-6 | P07 | 「來大樹下找我玩」→「來找我玩」 | 字串級 | ✅ |
| F8 | 3-5 | P02 | 句號語氣疑慮 | — | ❌ |
| F9 | 5-6 | P04 | 風溜進來實體層疑慮 | — | ❌ |
| F10 | 5-6 | P12 | 呼——擬聲詞重複疑慮 | — | ❌ |
| F11 | 2-3 | P07 | 刪咕咕台詞後動機不足 | — | ❌ |

verdict = fix_required（✅ 5 / ❌ 6 / ⏸️ 0）。F5 = 創作級 → round 2 為完整輪。
