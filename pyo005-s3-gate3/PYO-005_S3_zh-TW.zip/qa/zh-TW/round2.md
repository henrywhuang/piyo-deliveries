# QA Report — Round 2

```yaml
schema: piyo_text_qa_report/v0.9
slug: a-little-light-in-the-dark
locale: zh-TW
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-29"
step1_lint:
  exit_code: 0
  warnings: 15
step2_checklist:
  pass: 25
  fail: 0
step3_personas:
  - id: zh-TW-teacher
    scores: {年齡適配度: 7, 朗讀口感: 8, 孩子抓得住度: 8}
  - id: zh-TW-parent
    scores: {睡前適讀性: 7, 零說教: 9}
  - id: zh-TW-editor
    scores: {母語自然度: 9, 文字工藝: 9}
step4_triage:
  real: 0
  rejected: 6
  escalated: 1
verdict: escalated
```

## STEP 1 機檢

| 工具 | exit | warnings |
|---|---|---|
| copy_check.py | 0 | 6 |
| locale_lint 5-6 | 0 | 3 |
| locale_lint 3-5 | 0 | 3 |
| locale_lint 2-3 | 0 | 3 |

超帶上緣頁（警告非紅）：5-6 P01=45 / P04=42 / P09=45；2-3 P01=23 / P05=21 / P09=21。

## STEP 2 checklist 自檢

E 主審判定：25 pass / 0 fail（18 checklist + 7 quick scan）。

- A-E 品質清單：D-1/D-2/D-3 = N/A（需美術）；B-1 = N/A（量化歸機檢）。餘項全 pass。
- 對位原則：35 頁逐頁 pass。
- concept fidelity：三檔 pass。
- 趣味設計兌現：全項兌現。

## STEP 3 人設 blind QA

| persona | 維度 | 5-6 | 3-5 | 2-3 | 最弱 |
|---|---|---|---|---|---|
| 林老師 | 年齡適配度 | 9 | 8 | 7 | 7 |
| 林老師 | 朗讀口感 | 9 | 8 | 9 | 8 |
| 林老師 | 孩子抓得住度 | 9 | 8 | 8 | 8 |
| 沛珊 | 睡前適讀性 | 9 | 8 | 7 | 7 |
| 沛珊 | 零說教 | 9 | 9 | 9 | 9 |
| 蔡主編 | 母語自然度 | 9 | 10 | 10 | 9 |
| 蔡主編 | 文字工藝 | 9 | 10 | 10 | 9 |

9 findings submitted（合併後 7 unique，F1/F5 各 2 路收斂）。

2-3 年齡適配度（7）與睡前適讀性（7）低分集中在 P09 否定鏈認知負荷。

## STEP 4 三分法分診

| # | 來源 | 檔位 | 頁 | 摘要 | 收斂 | 裁決 | 依據 |
|---|---|---|---|---|---|---|---|
| F1 | 林老師+蔡主編 | 5-6 | P08 | 「捏緊」vs「握緊」 | 2路 | ❌ | 推翻 2 路收斂：design concept_contract theme_cycles 明文「捏緊」；storyboard P08 同；握力品質分化（握→捏→不握）為刻意設計 |
| F2 | 林老師 | 5-6 | P10 | 「葉縫」書面詞 | 1路 | ❌ | design/storyboard 原樣鎖定；5-6 搭圖可承受；品味級 |
| F3 | 林老師 | 3-5 | P06 | 全頁無新事件 | 1路 | ❌ | design pace_curve 鎖定減速；蟋蟀＋螢火蟲＝新發現事件；手垂下＝握力弧關鍵節點 |
| F4 | 沛珊 | 2-3 | P05 | 「不見了！」主詞不清 | 1路 | ❌ | Round 1 已定裁決；「是蟋蟀呀！」與 P05 畫面實體層衝突；2-3 不展開發現細節 |
| F5 | 沛珊+林老師 | 2-3 | P09 | 三連否定邏輯 2歲難懂 | 2路 | ⏸️ | 問題真實（2歲否定鏈認知困難）但兩方案不相容；傾向：末行→「可是——沒有回頭。」（+3字=24字），是否開預算例外需 Stacy 裁定 |
| F6 | 沛珊 | 2-3 | P11-P13 | 缺 P12 媽媽接應 | 1路 | ❌ | storyboard 設計性省略；P12 功能與 P13 重複 |
| F7 | 沛珊 | 3-5 | P11-P13 | 缺 P12 回家段 | 1路 | ❌ | 同 F6；persona 自評低且承認可保持現狀 |

訊源計量：人設獨有 real 0 / 多路收斂 real 0（F1 ❌ 推翻、F5 ⏸️ 未定）

verdict = escalated（✅ 0 / ❌ 6 / ⏸️ 1）。✅=0 → 修復循環停止。F5 上呈 Stacy 裁定。
