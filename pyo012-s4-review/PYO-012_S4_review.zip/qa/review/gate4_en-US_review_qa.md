# QA 報告：`gate4_en-US_review.md` 審包內容核驗

- 核驗對象：`content/PYO-012_the-lion-and-the-mouse/qa/review/gate4_en-US_review.md`（2026-07-20 17:52:08 生成，make_review.py --gate 4）
- 核驗人：S4 copywriting review session（黃威豪 side，鏡像 checkout）
- 核驗日期：2026-07-20
- 結論：**審包內容可信，可交 Stacy 作關卡④證據審**。逐頁引文、回譯、映射、統計、機檢數字、引用鏈全部核實；發現 3 筆小瑕疵（2 筆偏移標記粒度、1 筆排版），均不影響審讀結論。

## 一、核驗方法與通過項

| 核驗項 | 方法 | 結果 |
|---|---|---|
| zh-TW 母本引文（33 頁） | 逐頁對照 `text/zh-TW/{2-3,3-5,5-6}.json` | ✅ 逐字一致 |
| en-US 改編引文（33 頁） | 逐頁對照 `text/en-US/*.draft.json` | ✅ 逐字一致 |
| 回譯欄（33 頁）＋偏移標記 | 逐頁對照 `qa/en-US/backtranslation.md` | ✅ 完全一致；標記數 5-6:4／3-5:2／2-3:2 與儀表板一致，合計 8 輕微＝回譯檔統計行「25 無／8 輕微／0 中度」 |
| 母版頁映射 | 對照 storyboard 三檔選用表（3-5 跳 P07；2-3 跳 P07/P09） | ✅ 3-5：P07→P08…P11→P12；2-3：P07→P08、P08→P10、P09→P11、P10→P12，全對 |
| 三、QA 摘要 YAML | 對照 `qa/en-US/round3.md` | ✅ 逐字一致（含 verdict: escalated） |
| 四、上呈批次引文 | 對照 round1（T03/E-TRI-001、13 筆）、round2（R2-T01、R2-REG、real 6/rejected 6/escalated 2）、round3（兩筆 ⏸️） | ✅ 全部逐字存在於來源檔對應行 |
| 機檢數字 | 本 session 獨立重跑 `locale_lint.py` 六檔 | ✅ 零違規；en-US 2-3 raw 97→86.5（88）、3-5 248→242、5-6 333→327，與 round3 記錄一致 |
| verdict 紀律 | 檢查 escalated 是否被改寫 | ✅ 原樣保留，符合「AI verdict 與人工授權分離」 |
| 來源 mtime 表 | 表內時序自洽性 | ✅ text 17:46 → backtranslation 17:49 → round3 17:51 → 審包 17:52，邏輯自洽（本鏡像 checkout 的檔案 mtime 為同步時間戳，無法反證原 repo 值） |

## 二、發現（均為小瑕疵，不影響結論）

1. **偏移標記粒度：2-3 P07 標「無」偏寬**。母本首行「吱吱跑來了！」（抵達 beat）在 en-US 被刪、改由圖面（master P08 吱吱已在繩邊）承擔。依同表 2-3 P09/P10 的標記粒度，此頁宜標「輕微：抵達 beat 移交圖面，咬繩因果不變」。圖文分工本身成立，非文字缺陷。
2. **偏移標記粒度：3-5/5-6 P05 標「無」偏寬**。母本已寫「纏住＋越掙越緊」（結果揭示），en-US 停在 "Two more whipped upward—"（結果留到翻頁、更貼分鏡 hook 規格）。時序處理實質不同，宜標「輕微」並註記方向為 en-US 較貼分鏡；實益是提醒 Gate 4 這是刻意改良而非漏譯。
3. **排版：「ESL 獵手發現（原文引用）」為空標題段**。round3 無新 ESL 發現時，產生器仍輸出空節後直接接「同源復核」。建議 make_review.py 在無內容時省略該節或補「（本輪無）」。

## 三、建議處置

- 三筆發現均不需回修文本；1、2 可在下次跑 `make_review.py` 前由 E 刷新 `backtranslation.md` 標記，3 為產生器小修，可併入 piyo-text-qa skill 待辦。
- 審包中兩筆 ⏸️（2-3 hook 核准、Leo/Pip＋擬聲 registry 登記）為 Gate 4 裁決項，與本核驗結論並列呈報。
