# S4 R1 微修指令單：《獅子與老鼠》（隨 Greenlight 附帶，非阻斷）

## 定性
- 繪本編號：PYO-012／slug：the-lion-and-the-mouse
- 審稿輪次：R1（2026-07-20）；依據 skill-s4-copywriting-review v0.9
- **判定：GREENLIGHT 維持不變**——五維度全部通過，以下修改**不是**不通過項，而是建議在 TTS 生成前順手落地的微修（TTS 一旦生成音檔即凍結，此時改字成本最低）。
- 修改範圍極小：en-US 兩處單點替換，零結構變動；落地後只需重跑 `locale_lint.py`（預期仍零違規），**不需**重跑 QA 全輪。

## 建議落地（en-US draft，2 筆）

| 語言 | 檔位 | 頁碼 | 現行 | 改為 | 理由 |
|---|---|---|---|---|---|
| en-US | 5-6 | P04 | `"Thank you, Leo!" Pip cried.` | `"Thank you, Leo!" Pip cheered.` | `cried` 不在 en-US spec R3 的 golden tag 集合（spec 明注無 cried 用例），且對幼兒有「哭了」歧義；該拍情緒是感激興奮，`cheered` 在 golden 集合內且情緒對位。次選 `said`。 |
| en-US | 2-3 | P10 | `And from that day on.` | `And from that day on…` | 句號斷片朗讀語調偏硬；省略號版與 en-US spec R6 明文的三故事共用收束句式 `And from that day on…` 逐字同形。零字數影響。 |

## 僅供 Stacy 裁量（不建議自動執行，1 筆）

| 語言 | 檔位 | 頁碼 | 現行 | 可改為 | 說明 |
|---|---|---|---|---|---|
| zh-TW | 5-6 | P05 | 幾天後，威威在**林子**裡散步。 | 幾天後，威威在**樹林**裡散步。 | 「林子」偏北方口語，台灣口語較常說「樹林」。此條在 `qa/zh-TW/round1.md` #10 已被獵手提出、judge 裁定誤報（非紅線詞），且 **zh-TW 為 gate3 凍結物**——僅在你親審同感時授權替換，否則維持原文。字數 33→34，遠低於上限 85。 |

## 不動文字、留給下游站別（備忘）
- en-US 2-3 P09 兩句引語無說話者標注（依母版 P11 屬 Leo 的變奏＋感謝）：顯示文本不動，S6 TTS 腳本分聲時明確指定 Leo 聲線即可。

## 與 Gate 4 的關係
- 本單與兩筆 ⏸️ 上呈項（2-3 hook 的 tier-adapted 核准、Leo/Pip＋三組 en-US 擬聲登 registry「提案」）並行，互不阻塞；⏸️ 為 Stacy 的 Gate 4 裁決項。
- `qa/en-US/round3.md` 的 AI `verdict: escalated` 依紀律原樣保留，本單不改寫之。

## 修改後的品牌紅線提醒
1. 旁白從不對聽眾出題
2. 旁白從不總結道理
3. 收尾永遠回到「大家在一起」
4. 角色名和擬聲詞必須和 registry／凍結 design 一致，不得自行更改（refrain 逐字一致不得動）

## 落地後驗證
1. `python3 knowledge_base/tools/locale_lint.py --locale en-US --band 5-6 --pages-file content/PYO-012_the-lion-and-the-mouse/text/en-US/5-6.draft.json`（及 2-3 同款）→ 預期 exit 0
2. 同步 `copy/en-US.md` 總表對應格（copy/draft 同源紀律）
3. `qa/en-US/backtranslation.md` 受修頁（5-6 P04、2-3 P10）由回譯員同步刷新
