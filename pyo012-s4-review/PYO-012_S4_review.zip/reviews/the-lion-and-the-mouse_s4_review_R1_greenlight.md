# S4 Greenlight：《獅子與老鼠》

## 審稿識別
- 繪本編號：PYO-012
- 繪本 Slug：the-lion-and-the-mouse
- 書名（zh-TW）：《獅子與老鼠》
- 審稿輪次：R1（首輪）
- 審稿日期：2026-07-20
- 審稿依據：skill-s4-copywriting-review v0.9（piyo-copywriting-review，五維度框架）
- 審稿對象檔案：
  - `text/zh-TW/2-3.json`、`text/zh-TW/3-5.json`、`text/zh-TW/5-6.json`（gate3 已凍結）
  - `text/en-US/2-3.draft.json`、`text/en-US/3-5.draft.json`、`text/en-US/5-6.draft.json`
- 本報告檔名：the-lion-and-the-mouse_s4_review_R1_greenlight.md
- 判定：**GREENLIGHT — 五維度全部通過**（TTS 起跑仍以關卡④ Stacy Green Light 為準，見備註「上呈事項」）

## 來源文件核對
- S2 storyboard：`PYO-012_storyboard.md`（schema piyo_storyboard/v0.10；5-6 母版 12 頁、3-5 選 11 頁跳 P07、2-3 選 10 頁跳 P07/P09）
- Storyboard greenlit：是（book.yaml `status: zh-TW_text_frozen`，關卡②③已過；gate2/gate3 審包在 `qa/review/`）
- 提案卡（book_slate.md PYO-012）：社交能力／互助；「小老鼠幫大獅子解開麻煩，證明小小的幫忙也很重要」；問題解決型；風險註記＝陷阱降壓成「被繩子纏住」
- 設計契約（PYO-012_design.md）：疊句「小小手，幫大忙！」beats P04/P08/P11（P11 變奏）；page-turn hooks P05/P09（動作中斷型）；擬聲 motif 呼嚕呼嚕／嚓嚓嚓／啪！；收束式「後來呀……」；en-US 角色名 Leo／Pip（提案）

## 五維度判定
| 維度 | 判定 |
|---|---|
| 朗讀自然度 | 通過 |
| 幼兒可理解性 | 通過 |
| 圖文配合度 | 通過 |
| 品牌與 Registry 合規 | 通過 |
| 三檔 × 兩語一致性 | 通過 |

## 逐維度審查紀錄

### 維度一：朗讀自然度 — 通過
- **zh-TW**：三檔逐頁朗讀無卡口。台灣口語語感成立（「好啦好啦，走吧」「我說過的呀！」「救命呀——」）；無簡體語感滲漏（無「進行」「開展」「小朋友們」式用語）。節奏有蓄力—爆發—收束：P05-P06 收緊、P08-P10 三連咬繩加速、P11-P12 放慢收溫。擬聲有力道（嚓嚓嚓…… 啪！位於句節奏的重拍上）。
- **en-US**：讀感是母語幼稚園老師講故事，非 ESL 教材。口語縮寫自然（won't／that's／I'll）、呼喊與轉折道地（"Easy now," "Well now… that's a very big promise from one tiny mouse."）、動作動詞具體（crept／whipped／planted her feet／sprang apart）。無中文句法直譯痕跡（round1-2 的兩筆 ESL 真問題已於 round3 驗證逐字修復：5-6 P06 落點、P10 "took one deep breath of relief"）。
- **翻頁 hook**：5-6 P05／P09、3-5 P05／P08、2-3 P05 均以破折號動作中斷收尾（"Two more whipped upward—" "Pip opened her jaws—"），朗讀時語調自然懸起。
- **換氣測試**：2-3 每頁一口氣可完；5-6 對話密集頁（P04）約三個氣口，屬對話換角自然分段，不判過長。

### 維度二：幼兒可理解性 — 通過
- **每頁一件事**：三檔均成立；2-3 為純事件拍（睡覺→被抓→放走→承諾→被困→掙不開→咬→全斷→道謝→收束）。
- **概念具體度**：無抽象詞裸奔。互助全程以身體動作承載（鬆爪＝放走、咬繩＝解救、低頭＝道謝），符合 design metaphor_rules；5-6 的 "promise" 有 P04 具體場景支撐。
- **情緒動作化**：吱吱怕＝全身發抖／shook all over；威威敗＝趴地喘氣／dropped to the ground, panting；感謝＝低下大頭到吱吱眼睛高度。無旁白宣告式情緒。
- **因果鏈**：每頁與前頁單步因果；2-3 跳 P07/P09 後由 P06 呼救直接接咬繩，圖面承接抵達（見維度三附註）。
- **三檔質化差異**：真分檔而非刪長補短——2-3 疊字＋擬聲＋電報句（「好緊好緊！」「掙呀掙」）；3-5 短中句混合＋簡單因果（「越掙——越緊！」）；5-6 因果複句＋內心（苦笑、大小懷疑）＋感官細節（ropes hissed over leaves）。en-US 同樣呈現梯度。

### 維度三：圖文配合度 — 通過
- 逐頁對照 storyboard「圖說什麼／文說什麼」負載：12 個母版頁的文字負載（時間標記、心理、擬聲、台詞、進度旁白）逐項兌現；未發現文字重複描述圖面已示資訊——P01 事件起點旁白為 storyboard 明定負載（聽覺主導產品的必要敘事），不算重複。
- 亮點：en-US P05 "One loop caught his paw. Two more whipped upward—" 與分鏡 P05「三繩分離、僅一條觸爪、結果留到翻頁」逐項吻合，比母本更貼 hook 規格。
- 斷繩進度三檔全對位：P08 一條／P09 兩條／P10 三條（2-3 壓縮為 P07 一聲 SNAP!＋P08 兩聲 SNAP!，與選圖 P08→P10 的進度一致）。
- 附註（不扣分）：2-3 en-US P07 刪去母本「吱吱跑來了！」抵達句，由 master P08 圖面（吱吱已在繩邊咬）承擔抵達資訊，圖文分工成立；2-3 P04 兩語均以動詞（笑了／chuckled）取代分鏡的笑聲擬聲負載，屬檔位壓縮之常規取捨。

### 維度四：品牌與 Registry 合規 — 通過
- **品牌三條線**：旁白零出題（所有問句均在角色台詞內）；旁白零總結道理（疊句由角色說出，收尾為具體日常行為敘述，非道德宣告）；收尾回到「大家在一起」（三檔兩語皆是兩個朋友並肩日常）。
- **結尾四件套**：收束式（後來呀……／And from that day on）＋陪伴安心基調＋無開放懸疑＋末頁情緒安定，六份全數成立。
- **Registry**：威威／吱吱、Leo／Pip 與凍結 design §7 一致，全書無別名漂移；擬聲同場景同寫法（linter 重複折計警告即為證據）。Leo／Pip 與三組 en-US 擬聲（Honk-shoo… honk-shoo…／scritch, scritch, scritch!／SNAP!）在共享 registry 尚無 PYO-012 條目，QA 輪已標「提案」上呈 Gate 4（見上呈事項 2）。
- **量化門檻**（本輪獨立重跑 `locale_lint.py`，六檔全數 exit 0 零違規）：en-US 2-3 raw 97→折計 86.5（上限 88）、3-5 248→242（389）、5-6 333→327（505）；zh-TW 2-3 139→136（300）、3-5 無警告（770）、5-6 410→404.75（1000）。與 round3 機檢數字完全一致。

### 維度五：三檔 × 兩語一致性 — 通過
- **三檔骨架**：beat 序列與 storyboard 三檔選用表逐頁對位（3-5 跳 master P07、2-3 跳 P07/P09），主線「被抓→放走→承諾→被困→力竭→咬繩×3→自由→道謝→日常互助」三檔不變；三檔結尾皆收束式；角色名三檔零漂移。
- **兩語一致**：逐頁比對母本與回譯（`qa/en-US/backtranslation.md`，25 無／8 輕微／0 中度），主要 beat 與情緒弧線全對齊；8 筆輕微偏移（求饒承諾補語、安全回應補語、大小懷疑間接化、收尾措辭）均不動因果與情緒方向，屬模式 B「各語自然表達」的合法範圍。
- **疊句對位**：zh-TW「小小手，幫大忙！」與 en-US "Small paws can help in big ways!" 出現頁位兩語一致（5-6 P04/P08/P11、3-5 P04/P07/P10、2-3 P04/P07/P09）；P11 變奏兩語各自成立（「是最大的幫忙」／"you were the biggest help of all"）；2-3 以逐字重複取代變奏，符合 design §6「2-3 疊句重複」取捨並滿足折計預算。

## 備註

### 上呈事項（Gate 4 Stacy 裁決，非文字缺陷；AI verdict 原樣保留）
`qa/en-US/round3.md` verdict: **escalated**（依紀律不得改寫為 pass，本 Greenlight 不覆蓋之）：
1. **2-3 hook 缺口**：design 宣告 hooks P05/P09，凍結 2-3 selection 排除 P09；建議照 judge 傾向明文核准「P04 問句（You can help?／這麼小？）為 tier-adapted hook、master P09 記 tier-N/A」。
2. **Registry 登記**：Green Light 後將 Leo／Pip 與三組 en-US 擬聲依協議寫入共享 registry（標「提案」）。
3. **觀察（zh-TW 凍結物，不重開）**：zh-TW 3-5/5-6 P05 文字已寫「纏住／越掙越緊」，較分鏡 P05「結果留到翻頁」提前揭示結果；en-US 版本已按分鏡執行。若日後 zh-TW 回修再一併校準即可。

### 非阻斷微調建議（可隨下輪順手改，不影響放行）
1. en-US 2-3 P10 "And from that day on." 句號斷片朗讀偏硬，建議改省略號 "And from that day on…"（零字數影響；與 en-US spec R6 明文的三故事共用收束句式 `And from that day on…` 同形）。註：加 "every day" 會使折計總量 86.5→89.5 超上限 88，故不建議補詞。
1b. en-US 5-6 P04 `"Thank you, Leo!" Pip cried.`——cried 不在 en-US spec R3 的 golden tag 集合（spec 明注無 cried 用例），且有「哭了」歧義；建議改 `Pip cheered.` 或 `said`（單詞替換，出處見附錄稽核）。
2. en-US 2-3 P09 兩句引語均無說話者標注（master P11 變奏原屬威威）；顯示文本可不動，S6 TTS 腳本分聲時需明確指定 Leo。
3. Persona 分數（朗讀口感 6／零說教 4 等）為 round 2 修前儀表、round 3 未重跑；現行文本已落地六筆逐字修正，分數低估現況。零說教 4 分主因疊句×3＋收尾互助敘述，均屬 design 凍結結構（lock-in 駁回成立），本審維度四判定不受影響。

### 附錄
- 翻譯腔＋local 語感專項稽核（逐規則證據，含決定性掃描電池結果）：`reviews/the-lion-and-the-mouse_s4_review_R1_addendum_localeness_audit.md`（2026-07-20，應 Stacy 要求出具）。
