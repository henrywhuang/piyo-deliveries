# S4 R1 附錄：翻譯腔＋Local 語感專項稽核（PYO-012）

- 繪本編號：PYO-012《獅子與老鼠》
- 稽核日期：2026-07-20（應 Stacy 要求對 R1 維度一「朗讀自然度」出具逐項證據）
- 稽核依據：`knowledge_base/locale_specs/zh-TW.md`（R2-1～R2-7 語域規則＋用詞對照表＋P5 系正字法）、`knowledge_base/locale_specs/en-US.md`（R1～R7 語域規則＋O1～O5 擬聲規範＋GB 對照表）
- 稽核方法：①決定性掃描電池（紅旗詞 grep 全類別）＋ ②逐頁人工朗讀審（33 頁 × 兩語，逐句對規則編號）
- 結論：**兩語均無翻譯腔；local 語感成立**。zh-TW 是台灣爸媽床邊口吻、en-US 是 GA 美國幼稚園老師口吻。新增 1 筆低風險建議（en-US 5-6 P04 `Pip cried`），3 筆已裁決／邊界條目附判定理由備查。

## 一、決定性掃描結果（零命中即為證據）

| 掃描類別 | 規則依據 | 結果 |
|---|---|---|
| zh 書面連接詞（然而/於是/因此/便/即/卻） | zh R2-1 | 零命中；銜接用「可是」「後來呀」（golden 慣例） |
| zh 書面程度副詞（非常/十分/相當/極為） | zh R2-4 | 零命中；強調全走疊架（好小好小、好緊好緊、大口大口） |
| zh 大陸口語/兒化（啥/咋/俺/咱/玩兒/立馬/進行/開展/小朋友們） | zh R2-6＋用詞對照表 | 零命中 |
| zh 字形鎖定（妳/牠/它/哦） | zh R2-2/R2-3 | 零命中（威威一律「他」，助詞無「哦」） |
| zh 文言殘留（將/之/其/與） | zh R2-5 | 零命中；被字句僅 1 處「被癢醒了」＝台灣口語自然用法，非濫用 |
| en GB 滲漏（mum/biscuit/autumn/jumper/colour/grey…全表） | en 用詞對照表＋banned_terms | 零命中 |
| en ESL 非縮寫（it is/I will/do not/cannot…） | en R2 | 零命中；won't/that's 等縮寫遍佈 |
| 兩語 lint（含 banned_terms/orthography 全量機檢） | spec 第 9 段 YAML | 六檔 exit 0 零違規（R1 主報告已錄） |

## 二、zh-TW 逐規則人工審（三檔 33 頁）

- **R2-1/R2-4 口語體**：旁白全程說書人口吻；「掙呀掙」（V呀V）、「好緊好緊」、「一掌——按住！」節奏疊架全對 golden 型。
- **R2-2 語尾助詞**：「後來呀……」（三檔收束）、「走吧」「好啦好啦」「拜託拜託」「我說過的呀！」——助詞分佈是台灣親子對話的自然密度，無大陸腔堆疊。
- **R2-5 翻譯腔句式**：無「將」字句（處置式全用主動或「把」語感）、無長定語堆疊、無歐化被動；「威威被癢醒了」屬口語慣用單例。
- **R2-7 檔位語體**：2-3 檔電報式（「一掌——按住！」「好緊好緊！」）；5-6 檔完整敘事句＋說書人收尾，分檔語體符合 spec。
- **P5 系正字**：引號「」、刪節號……、破折號——、中文數字（三條/第一條/兩條）、的地得三分（「嚇得發抖」「累得趴下」；P12「走路慢慢的」為狀態判斷句之「的」，非副詞誤寫）——全對。
- **用詞層唯一邊界條目**：5-6 P05「林子」。已於 `qa/zh-TW/round1.md` #10 被獵手提出（[低] 台灣口語稍少見），judge 裁定誤報（「非紅線詞；spec 禁書面連接詞，不禁口語化名詞」）。**本稽核尊重已裁決**；補充參考意見：若 Stacy 親審時仍覺北方腔，「樹林裡」為零成本替換（字數 33→34 仍遠低於 85 上限）。zh-TW 為 gate3 凍結物，未獲指示不動。

## 三、en-US 逐規則人工審（三檔 33 頁）

- **R1 旁白紀律**：全知過去式、零直呼讀者、零旁白祈使。
- **R2 縮寫**：won't ×3、that's ×2 等自然分佈；無「文法正確化」倒退。
- **R3 對話 tag**：said ×6 主力；squeaked/chuckled/roared 各壓在情緒峰值，無 thesaurus 症。**唯一新發現：5-6 P04 `"Thank you, Leo!" Pip cried.`**——cried 不在 golden 實測 tag 集合（spec 明注「無 cried 用例」），且對 5-6 聽者有「哭了」歧義（該拍情緒是感激興奮，非哭）。建議改 golden 集合內的 `Pip cheered.` 或降為 `said`。低風險、單詞替換、不動字數結構。
- **R5 sight words**：功能詞骨架全落 Dolch/Fry 高頻；內容詞具體可畫（rope/paw/nose/jaws）。兩個拉丁語源邊界詞判定：`remained` ×3（敘事慣用動詞、5-6/3-5 檔位內合法）；`relief`（5-6 P10，round2 judge 逐字指定的修正結果，5-6 檔可承載）——均 pass。
- **R6 重複句逐字一致**：refrain 三檔內逐字一致（linter 折計偵測即字節級證據）；收束句式 `And from that day on` 正是 spec R6 明文的三故事共用慣用式——R1 主報告建議的 2-3 P10「句號改省略號」與 spec 慣用式 `And from that day on…` 同形，等於有 spec 依據，維持建議。
- **R7 幼幼 fragment**：2-3 檔「Leo slept.」「Nothing moved.」等片段句為 spec 明文合法語體。
- **O 系擬聲**：`scritch, scritch, scritch!` 完全符合 O3（小寫逗號三連）；`SNAP!` 符合 O1；`Heh, heh` 符合 O5（僅首詞大寫、未用驚嘆號斷開）；`Honk-shoo…` 的連字號屬複合擬聲構詞、非 O2 所禁的「拉長用連字號」——三組均為新造、已在 ⏸️ registry 提案批次內，定案前需過 TTS round-trip。
- **翻譯腔專項（calque 清單）**：主語代詞交替自然（2-3 檔的 Leo 主語重複屬 R7 幼幼句式、非中式主語重複）；無 because…so 直譯結構；搭配詞全母語（planted her feet／held fast／bit down with everything she had／the harder…the tighter…）；介詞冠詞零錯（across his nose／into tiny holes／one deep breath of relief）。
- **GB 語感邊界**：`Off you go.`（3-5/5-6 P03）在 GB 較高頻但屬美國幼師常用語、GB 對照表未列——pass 附註；如要更「教科書 GA」可用 `Run along now.`，非必要。

## 四、與既有 QA 鏈的關係

- 本稽核是對 R1 維度一判定的**證據補強**，不改變 R1 GREENLIGHT 結論；`Pip cried` 一筆併入 R1 主報告「非阻斷微調建議」。
- piyo-text-qa 鏈路中翻譯腔已有三道覆蓋（B1 盲稿禁讀源文、ESL 獵手 round1-2 抓出 2 筆真問題並驗證修復、逐頁回譯 25 無/8 輕微）；本稽核為第四道獨立覆核，結論相互印證。
