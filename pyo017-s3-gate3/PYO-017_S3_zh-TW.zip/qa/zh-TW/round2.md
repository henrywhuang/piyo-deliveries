# QA 報告：my-spots-are-different / zh-TW / round 2

```yaml
schema: piyo_text_qa_report/v0.9
slug: my-spots-are-different
locale: zh-TW
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-29"
step1_lint: {exit_code: 0, warnings: 3}
step2_checklist: {pass: 27, fail: 0}
step3_personas:
  - id: zh-TW-teacher
    scores: {年齡適配度: 8, 朗讀口感: 9, 孩子抓得住度: 9}
  - id: zh-TW-parent
    scores: {睡前適讀性: 8, 零說教: 8}
  - id: zh-TW-editor
    scores: {母語自然度: 8, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 1}
verdict: escalated
```

**本輪性質：復核輪**（round 1 全數 ✅ ∈ {字串級}，具復核輪資格）。人設不重跑，分數沿用 round 1 標註。verdict: escalated 因 round 1 ⏸️ E-1（B-4 對話比例）待 Stacy 裁定。

## STEP 1 機檢

```bash
python3 .claude/skills/piyo-text-writer/scripts/copy_check.py content/PYO-017_my-spots-are-different/copy/zh-TW.md
# exit 0, 警告 3 筆（超帶上緣：5-6 P02 41>40, 3-5 P12 31>25, 2-3 P12 22>20）
# 三頁超帶均為 QA 回修所致（補說話者歸屬＋指代回補＋具象化），均遠在硬上限內

python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-017_my-spots-are-different/text/zh-TW/5-6.draft.json --locale zh-TW --band 5-6
# exit 0, 警告 2（repeat_discount）

python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-017_my-spots-are-different/text/zh-TW/3-5.draft.json --locale zh-TW --band 3-5
# exit 0, 警告 2（repeat_discount）

python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-017_my-spots-are-different/text/zh-TW/2-3.draft.json --locale zh-TW --band 2-3
# exit 0, 警告 0
```

四道機檢全 exit 0。超帶警告理由：

| 頁 | 檔位 | 修前 | 修後 | 帶頂 | 硬上限 | 回修編號 | 理由 |
|---|---|---|---|---|---|---|---|
| P02 | 5-6 | 37 | 41 | 40 | 85 | L-1 | 補「另一隻說。」說話者歸屬，+4字 |
| P12 | 3-5 | 24 | 31 | 25 | 65 | P-2+P-3 | 辨認台詞「那是我的斑斑」復原情感遞進+3＋指代「你的斑點」+4 |
| P12 | 2-3 | 20 | 22 | 20 | 30 | L-4 | 「記號」→「最愛的點點」具象化+2 |

三頁超帶均為 QA 回修驅動，非作家塞字；內容品質優先於帶頂目標。

## STEP 2 checklist 自檢（E-lite）

**主題錨復述**：斑斑的星星斑點是被認出來、被愛的獨一無二標記——不一樣不是需要修好的問題。

受修頁與相鄰頁複審（9 筆字串級修改落地驗證）：

| 編號 | 修改 | draft 落地 | copy 同源 | 語境完整 |
|---|---|---|---|---|
| L-1 | 5-6 P02 加「另一隻說。」 | ✓ | ✓ | P01→P02→P03 語境連貫 |
| L-2 | 5-6 P09 草藤→長長的藤 | ✓ | ✓ | P08→P09→P10 動作鏈完整 |
| L-3 | 3-5 P13 橢圓→長長的 | ✓ | ✓ | P12→P13 收尾流暢 |
| L-4 | 2-3 P12 記號→最愛的點點 | ✓ | ✓ | P11→P12→P13 情感遞進完整 |
| P-1 | 2-3 P02 加「像星星！」 | ✓ | ✓ | P01→P02→P03 緩衝自然 |
| P-2 | 3-5 P12 是斑斑→那是我的斑斑 | ✓ | ✓ | P11「是斑斑！」→P12「那是我的斑斑！」情感遞進恢復 |
| P-3 | 3-5 P12 加「你的斑點，」 | ✓ | ✓ | 指代回補，與P-2同頁 |
| C-1 | 5-6 P04 指頭→手指頭 | ✓ | ✓ | 口語自然，動作鏈不受影響 |
| C-2 | 5-6/3-5 P03 朝→往 | ✓ | ✓ | 兩檔同步修改 |

copy↔draft 同源檢：copy_check exit 0 已驗證（含字數重算＋帶判定＋同源比對）。

B-4（round 1 ⏸️）：維持上呈，本輪不重審（lock-in 衝突未解，待 Stacy gate3 裁定）。

## STEP 3 人設 blind QA

**復核輪：人設不重跑，分數沿用 round 1。**

摘要分（最弱檔位）：林老師 年齡適配度 8／朗讀口感 9／孩子抓得住度 9；沛珊 睡前適讀性 8／零說教 8；蔡主編 母語自然度 8／文字工藝 8。

## STEP 4 三分法分診

**主題錨復述**：斑斑的星星斑點是被認出來的唯一標記——不一樣不是需要修好的問題，而是被愛的記號。

本輪 ✅=0，QA 收斂。round 1 ⏸️ E-1（B-4 對話比例）維持上呈。
