# QA 報告：阿嬤的圍裙口袋 / zh-TW / round 3（復核輪）

```yaml
schema: piyo_text_qa_report/v0.9
slug: grandmas-apron-pockets
locale: zh-TW
tiers: ["2-3", "3-5", "5-6"]
round: 3
date: "2026-07-21"
step1_lint: {exit_code: 0, warnings: 9}
step2_checklist: {pass: 5, fail: 0}
step3_personas:
  - id: zh-TW-teacher
    scores: {年齡適配度: 6, 朗讀口感: 7, 孩子抓得住度: 6}
  - id: zh-TW-parent
    scores: {睡前適讀性: 7, 零說教: 8}
  - id: zh-TW-editor
    scores: {母語自然度: 7, 文字工藝: 7}
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

復核輪依據：R2 全部 5 項 ✅ 修正均為詞級替換（祖孫→角色名、痕跡→印子、加 speaker tag、合併引號），零創意裁量空間。依 SKILL v0.12 復核輪例外，本輪僅執行機檢＋修正驗證，人設分數沿用 R2。

## STEP 1 機檢

R2 修文後重跑，所有機檢通過（exit 0）：

| 工具 | 目標 | 結果 |
|---|---|---|
| copy_check.py | copy/zh-TW.md | ✅ 通過（警告 0） |
| locale_lint | 5-6.draft.json | ✅ 無違規（警告 3：repeat_discount） |
| locale_lint | 3-5.draft.json | ✅ 無違規（警告 3） |
| locale_lint | 2-3.draft.json | ✅ 無違規（警告 3） |

## STEP 2 checklist 自檢

復核輪僅驗證 R2 的 5 項 ✅ 修正是否正確落地：

| R2 # | 修正 | 驗證 |
|---|---|---|
| F-1 | 5-6 P07 合併台詞 | ✅ 小禾台詞完整含疊句 |
| F-2 | 5-6 P09 祖孫→纏住阿嬤和小禾了 | ✅ 已改且字數 38✓ |
| F-3 | 5-6 P13 祖孫→阿嬤和小禾一人一角 | ✅ 已改且字數 40✓ |
| F-4 | 3-5 P03 加阿嬤 speaker tag | ✅「阿嬤：」已加且字數 25✓ |
| F-5 | 2-3 P02/P08 痕跡→印子 | ✅ P02「印子」、P08「印子」已改；P05 保留「痕跡」通過 refrain 機檢 |

copy 表與 draft.json 逐頁逐字同步確認。

## STEP 3 人設 blind QA

復核輪——人設分數沿用 R2（見 round2.md）。R2 各維度最低分 ≥5，無系統性問題。

## STEP 4 三分法分診

✅ 真問題：0
❌ 駁回：0
⏸️ 上呈：0（R1/R2 遺留 ⏸️ 隨 gate3 審包一併上呈，不重複計入本輪）

**收斂確認**：連續一輪 real=0，QA 漏斗收斂。

### 累積 ⏸️ 彙整（R1+R2，交 Stacy 親審）

| 來源 | 檔位 | 頁 | 問題 |
|---|---|---|---|
| R1 F-8 | 5-6 | P13 | ⏸️「兜在一起」vs「圈在一起」——詞選偏好 |
| R1 F-14 | 2-3 | P10 | ⏸️ 口袋主語：「口袋就鼓起來」指新口袋還是整條圍裙？ |
| R2 F-10 | 全檔 | P09/P08/P07 | ⏸️「布鏈」為造詞——蔡主編建議改「長布條」，影響三檔 |
