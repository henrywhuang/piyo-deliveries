# PYO-015 S4 R2 修改摘要

> 依據 Stacy S4 R1 五維審（piyo-copywriting-review v0.9）修改指令。
> Commit: `4b6bad4` | 日期: 2026-07-23

## 一、必改項落地（8 頁）

| 頁位 | 檔位 | 修改 |
|---|---|---|
| P01 | zh-TW 5-6 | 口語化：「我要搶先查出是誰。」→「我一定要先查出來是誰！」 |
| P02 | zh-TW 3-5 | 加線索證據：「小翅膀跟著風飛——是呼呼風帶走的！」 |
| P02 | en-US 3-5 | 同步：「Little wings ride the wind — Breezy carried this seed!」 |
| P02 | en-US 2-3 | 恢復事件+袋子：「Breezy blew it! Spin, spin! / Into the bag!」(14w) |
| P04 | en-US 2-3 | 加 Chomp!：「Chomp! Pip ate berries. Seeds came too!」(14w) |
| P11 | zh-TW 5-6/3-5/2-3 | 台詞標記修正：第二段加「」引號 |
| P11 | en-US 5-6 | 旁白→一人稱：And I buried the acorn myself! |
| P14 | zh-TW 5-6 | 加三友主詞：「三個朋友一起回來看：」 |

## 二、採用的建議

| # | 建議 | 頁位 | 結果 |
|---|---|---|---|
| #2 | P06 pounce causality | en-US 2-3 P06 | 採用：「Hazel jumped — her bag flipped!」 |
| #3 | P08 rhythm reduplication | en-US 2-3 P08 | 採用：「Push, push! Down went the acorn.」 |
| #4 | P01 oral-ify | zh-TW 5-6 P01 | 採用（併入必改 P01） |
| #1 | P04 2-3 加 spin | — | 未採（P04 2-3 是 WHOOSH 頁非 spin 頁；spin 已在 P02） |
| #5 | P14 5-6 名字替回代名詞 | — | 未採（zh-TW 5-6 已有名字「栗栗」保持一致） |

## 三、Registry 回寫結果

- **onomatopoeia_map.md**：`啾啾啄食莓果` en-US 欄更新 → `Chomp!（提案·2026-07-23 Stacy S4 R1 指令採用；2-3 P04，僅 2-3 檔；待 TTS round-trip）`
- **character_names.md**：PYO-015 三角色已在冊，無需修改

## 四、台詞標記驗證結論

zh-TW 三個檔位中發現三處旁白越位（一人稱句子未加引號）：
- P11 全檔位：「我埋了橡實」「只有我在藏！」
- P09 3-5：同類型
- P07 2-3：同類型

**全部已修正**——加「」引號標記為角色台詞。en-US P11 5-6 同步改為 first-person quote。

## 五、機檢結果

| 項目 | 結果 |
|---|---|
| copy_check zh-TW | exit 0（19 警告，結構性超帶） |
| copy_check en-US | exit 0（8 警告） |
| locale_lint zh-TW ×3 | 全通過 |
| locale_lint en-US 5-6 | 通過 |
| locale_lint en-US 3-5 | 通過 |
| locale_lint en-US 2-3 | **2 已知違規** |

### en-US 2-3 已知違規

- P10 page = 18 words > max_page_len 14（+29%）
- total = 103 words > max_total_len 88（+17%）

根因：Stacy 必改「加三個朋友主詞」(+4w) + 品牌凍結單元 "And from that day on"(exempt sentence but counts toward page/total)。P02/P04 已各裁 1 字壓至 14w 極限。P10 與 total 超標為數學必然。

## 六、Process Note #6 回應

**(a)** gate4 round2 無「ESL 獵手」節：round2 為復核輪（E-lite），依規不重跑獵手。
**(b)** 2-3 P02 偏移「裁決 ❌」vs round2 0/0/0：round1 E 標記 P02 中度偏移→triage 裁決 ❌（改編合法差異）。round2 只複審受修頁，P02 未受修不在 scope。兩輪帳面一致。

## 七、本包檔案

```
text/zh-TW/5-6.json, 3-5.json, 2-3.json     -- zh-TW 凍結定稿（含台詞標記修正）
text/en-US/5-6.draft.json, 3-5.draft.json, 2-3.draft.json  -- en-US draft（含 R1 修改）
copy/zh-TW.md, en-US.md                       -- 圖文總表（字數標已重算）
registry/onomatopoeia_chomp_update.txt         -- Chomp! 回寫片段
```
