# Copy Table: Who Hid the Seeds? (PYO-015 / en-US)

> Mode B = locale adaptation (S4A, **adaptation not translation** — re-tell the story natively in en-US after reading design docs;
> zh-TW final text is reference material, not an alignment baseline).
> Page selection **fully inherited** from storyboard three-tier selection table (copied into header selection, no self-selecting/adding/deleting);
> one page one illustration: each tier's each page uses exactly one illustration with strictly increasing illustration numbers; unused illustrations have all three columns filled with "—" (their beats are entirely dropped, bridged by adjacent pages; skip-join self-sufficiency checks and bridging notes in SKILL STEP 2 / W9).
> Text's exclusive payload = sound, dialogue, inner thought, time; do not restate visual facts already shown by illustrations (two-layer text-illustration rules,
> authority in `knowledge_base/story_creation/storyboard_language.md`).
> Word count targets the **middle** of the target band, not the top; if text needs more space -> propose adding pages (formally return to S2 to change storyboard), don't cram.

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: who-hid-the-seeds
locale: en-US
mode: B
storyboard: content/PYO-015_who-hid-the-seeds/PYO-015_storyboard.md
design: content/PYO-015_who-hid-the-seeds/PYO-015_design.md
image_pool: 14
selection:
  "3-5": [P01, P03, P04, P05, P06, P07, P08, P09, P11, P12, P13, P14]
  "2-3": [P01, P03, P04, P06, P08, P09, P11, P12, P13, P14]
commitments:
  refrain: "Find a clue, then guess who!"
  ending: "And from that day on"
  onomatopoeia: [WHOOSH, "Scritch, scratch"]
characters: [Hazel, Breezy, Pip]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Hazel hurried back to her pit under the big oak tree. Right beside her acorn lay a seed she'd never seen — with thin little wings!<br>"Someone is hiding seeds in my spot!" Her tail curled into a big question mark. | 40✓ | 1 | Hazel hurried back to her pit under the oak tree. Beside her acorn was a seed she'd never seen — with little wings!<br>"Who put this here?" | 26⚠ | 1 | Strange seed! Little wings!<br>"Who hid it?" | 7✓ | ✓ | 3-5 scaffolds "little wings" for P02 skip compensation + shorter question; 2-3 telegram-style exclamatory fragments |
| P02 | 2 | She followed the winged seed all the way to the maple slope. More of them lay scattered across the open ground, with no scratch marks and no digging.<br>"It doesn't look like anyone buried these." | 35✓ | — | — | — | — | — | — | ✓ | 5-6 only; 3-5/2-3 skip — P01 "wings" description + P03 refrain bridge the gap |
| P03 | 3 | Hazel looked at the thin wings, then at the leaves swept into a line.<br>"Find a clue, then guess who! The wind carried this seed!"<br>She tucked it into her leaf satchel and chased the breeze. | 36✓ | 2 | "Find a clue, then guess who! Little wings ride the wind — Breezy carried this seed!"<br>Hazel tucked it into her leaf satchel and chased after the wind. | 27⚠ | 2 | "Find a clue, then guess who!"<br>Breezy blew it! Spin, spin!<br>Into the bag! | 14✓ | ✓ | 3-5 adds clue evidence "little wings ride the wind" (Stacy S4 R1); 2-3 restores seed-carried event + bag action per Stacy S4 R1 |
| P04 | 4 | Breezy said, "I just blow wherever I go — I don't pick where seeds land!"<br>WHOOSH! A winged seed spun right back up into the air. Hazel raced after it. | 29✓ | 3 | "I just blow!" said Breezy.<br>WHOOSH! A winged seed spun right up. Hazel chased it! | 15✓ | 3 | "I just blow!"<br>WHOOSH! The seed flew up! | 8✓ | ✓ | All tiers preserve WHOOSH onomatopoeia; 3-5 trims disclaimer; 2-3 telegram action only |
| P05 | 5 | Near the berry bushes, Hazel spotted tiny seeds on a leaf. No wings. Not buried in the ground.<br>"Hmm… who left these here?" | 23✓ | 4 | Near the bushes, tiny seeds sat on a leaf. No wings. Not buried in the ground.<br>"Who left these?" | 19✓ | — | — | — | ✓ | 3-5 shortens; 2-3 skips — P04 WHOOSH closes wind arc, P06 refrain opens berry arc directly |
| P06 | 6 | Pip wiped her beak, but the berry juice just smeared into two little mustache marks.<br>"Find a clue, then guess who! Pip ate berries and brought the seeds along!"<br>"I didn't mean to!" Hazel popped a seed into her satchel. | 40✓ | 5 | "Find a clue, then guess who! Pip ate berries and brought the seeds!"<br>"I didn't mean to!" The seed went into the satchel. | 23✓ | 4 | "Find a clue, then guess who!"<br>Chomp! Pip ate berries. Seeds came too!<br>"Oops!" | 14✓ | ✓ | 5-6 adds mustache visual detail (in illustration); 2-3 adds "Chomp!" onomatopoeia (Stacy S4 R1) + seed event; skip P05 bridge: refrain + "Pip ate berries" self-sufficient |
| P07 | 7 | "Pip just ate berries — she wasn't trying to hide anything." Hazel nodded.<br>Then she spotted an acorn cap and a trail of shallow scratch marks leading toward the oak tree. | 30✓ | 6 | "Pip ate berries — she wasn't hiding on purpose."<br>Hazel followed an acorn cap and shallow scratch marks. | 17✓ | — | — | — | ✓ | 3-5 compresses deduction; 2-3 skips — P06 closes berry arc, P08 opens acorn arc with "Scritch, scratch!" |
| P08 | 8 | Scritch, scratch! Hazel dug through the loose soil.<br>A whole acorn, a row of scratch marks, and one familiar little paw print!<br>"Wait… this is different from the other two." | 30✓ | 7 | Scritch, scratch! Hazel dug into the soil.<br>An acorn, scratch marks, and a familiar paw print!<br>"This one's different." | 19✓ | 5 | Scritch, scratch! An acorn!<br>Little paw prints! "Whose?" | 8✓ | ✓ | All tiers preserve "Scritch, scratch!" onomatopoeia; 2-3 skip P07 bridge: onomatopoeia + "acorn" self-opens arc |
| P09 | 9 | Breezy swirled in with a gust of fall leaves. The scratch marks were about to disappear!<br>"Hold on!" Hazel lunged — but her leaf satchel flipped. The winged seed and the berry seed slid right toward the acorn— | 37✓ | 8 | Fall leaves were about to cover the scratch marks!<br>"Wait!" Hazel lunged — her satchel flipped. The winged seed and berry seed slid toward the acorn— | 25✓ | 6 | Swish! Leaves blew in!<br>Hazel jumped — her bag flipped! | 9✓ | ✓ | 2-3 adds "Swish!" + pounce causality (Stacy S4 R1); cliffhanger preserved across all tiers |
| P10 | 10 | Hazel sorted the three kinds of seeds.<br>"The winged seed has thin wings and lands where the wind blows. The berry seed sits near juice marks. And this acorn…" Her paw hovered above the scratch marks. | 36✓ | — | — | — | — | — | — | ✓ | 5-6 only; 3-5/2-3 skip — sorting/analysis beat; P09 crisis flows directly to P11 reveal |
| P11 | 11 | "Find a clue, then guess who!"<br>"Breezy blew the winged seeds. Pip brought the berry seeds. And I buried the acorn myself!"<br>"There's more than one answer! Only I was really hiding!" | 32✓ | 9 | "Find a clue, then guess who!"<br>"Breezy blew winged seeds. Pip brought berry seeds. I buried the acorn.<br>Only I was hiding!" | 22✓ | 7 | "Find a clue, then guess who!"<br>"Breezy blew. Pip ate. I hid!<br>Only me!" | 14✓ | ✓ | Climax: 5-6 narrator→first-person quote (Stacy S4 R1); three-agent parallel reveal across all tiers; 2-3 maximum compression — 3-word triplet + 2-word conclusion; skip P10 bridge: P09 crisis → P11 refrain self-sufficient |
| P12 | 12 | Breezy said, "I never picked a hiding spot."<br>Pip said, "Me neither!"<br>Hazel pressed her acorn into the soft soil. Her paw landed right on top of the old print.<br>She grinned. "Those are MY paw prints!" | 37✓ | 10 | Breezy said, "I never picked a hiding spot."<br>Pip said, "Me neither!"<br>Hazel looked at the paw prints and smiled. "Those are mine!" | 23✓ | 8 | Push, push! Down went the acorn.<br>Her prints! "Mine!" | 9✓ | ✓ | 5-6 physical action + paw-on-print callback; 3-5 dialogue trio; 2-3 rhythm reduplication (Stacy S4 R1) |
| P13 | 13 | The last warm days of fall slipped by. Hazel left the pit just as it was — she didn't dig anything up.<br>"Let's come back next season and see what happens." The three friends settled in to wait for spring. | 39✓ | 11 | Hazel left the pit just the way it was.<br>"Let's come back next season." The three friends waited for spring together. | 21✓ | 9 | Hazel left the pit alone.<br>The three friends waited for spring. | 11✓ | ✓ | 5-6 time transition + dialogue; 3-5 drops time marker; 2-3 gentle closure (Stacy S4 R1: prohibitive→gentle) |
| P14 | 14 | In spring, they found a tiny green shoot near where a winged seed had landed. Not every seed had sprouted.<br>"Next time, I'll look for clues first."<br>And from that day on, Hazel always looked for clues before she guessed. | 40✓ | 12 | In spring, they all spotted a tiny green shoot!<br>"Next time, I'll look for clues first."<br>And from that day on, Hazel always looked for clues. | 26⚠ | 10 | Spring! The three friends found a tiny green shoot!<br>And from that day on, Hazel looked for clues. | 18✓ | ✓ | All tiers end with "And from that day on" (brand_frozen_units); 5-6 adds "Not every seed" nuance; 2-3 adds "three friends" subject (Stacy S4 R1 brand compliance); P10 page 18>14 inherent to Stacy instruction + frozen unit |
