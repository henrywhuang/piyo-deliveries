# 關卡4整合審閱：誰把種子藏起來？（S4 證據包／en-US）

- 生成時間：2026-07-23 16:50:20 +0800
- 書目錄：`content/PYO-015_who-hid-the-seeds`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：en-US
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-015_storyboard.md` | 2026-07-21 17:08:45 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-23 11:30:22 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-23 11:30:56 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-23 11:30:36 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-23 11:31:02 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-23 11:30:47 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-23 11:33:44 |
| qa/en-US/backtranslation.md | `qa/en-US/backtranslation.md` | 2026-07-23 16:50:12 |
| qa/en-US round | `qa/en-US/round1.md` | 2026-07-22 19:36:48 |
| qa/en-US round | `qa/en-US/round2.md` | 2026-07-22 19:36:48 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | en-US 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 14 | 14 頁有文 | 14 頁有文 | 14/14 | 5 |
| 3-5 | 12 | 12 頁有文 | 12 頁有文 | 12/12 | 2 |
| 2-3 | 10 | 10 頁有文 | 10 頁有文 | 10/10 | 9 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 栗栗回到藏橡實的淺坑，坑邊多了一枚陌生的楓樹翅果。／「有人也在藏種子！我一定要先查出來是誰！」 | Hazel hurried back to her pit under the big oak tree. Right beside her acorn lay a seed she'd never seen — with thin little wings!／"Someone is hiding seeds in my spot!" Her tail curled into a big question mark. | Hazel 匆匆趕回大橡樹下她的坑洞。她的橡實旁邊躺著一顆她從沒見過的種子——帶著細細的小翅膀！「有人在我的地盤藏種子！」她的尾巴捲成了一個大問號。 | 輕微：台詞從「我要查」改為「有人在藏」語氣轉換；加「尾巴問號」身體語言（zh-TW 無）；核心事件（發現陌生翅果）無缺 |
| P02 | P02 | 她照著翅果的樣子，一路找到楓樹坡。種子有薄薄的雙翅，散在空地，旁邊沒有抓痕。／「不像埋進土裡的。」 | She followed the winged seed all the way to the maple slope. More of them lay scattered across the open ground, with no scratch marks and no digging.／"It doesn't look like anyone buried these." | 她追著那顆有翅膀的種子，一路來到楓樹坡。更多同樣的種子散落在空地上，沒有抓痕，也沒有挖掘的痕跡。「看起來不像是誰埋的。」 | 無 |
| P03 | P03 | 栗栗看看翅果的小翅膀，再看看落葉方向。／「看線索，再猜是誰！是呼呼風帶走的。」／她把翅果放進小葉袋，追著風跑了。 | Hazel looked at the thin wings, then at the leaves swept into a line.／"Find a clue, then guess who! The wind carried this seed!"／She tucked it into her leaf satchel and chased the breeze. | Hazel 看了看那對細薄的翅膀，又看了看被掃成一條線的落葉。「找線索，猜猜誰！是風把這顆種子帶來的！」她把種子塞進她的樹葉小包，追著微風跑去。 | 無 |
| P04 | P04 | 呼呼風說：「我只管吹，沒有挑地方喔！」／咻嚕！一枚翅果又飛了起來。栗栗趕快跟上。 | Breezy said, "I just blow wherever I go — I don't pick where seeds land!"／WHOOSH! A winged seed spun right back up into the air. Hazel raced after it. | Breezy 說：「我只是吹到哪就到哪——我才不挑種子落在哪裡！」咻！一顆有翅膀的種子又旋回了半空中。Hazel 追了上去。 | 無 |
| P05 | P05 | 灌木叢旁的葉子上有細小的籽。沒有翅，也沒有埋進土裡。／栗栗想：「這回又是誰？」 | Near the berry bushes, Hazel spotted tiny seeds on a leaf. No wings. Not buried in the ground.／"Hmm… who left these here?" | 在莓果叢旁邊，Hazel 發現一片葉子上有小小的種子。沒有翅膀。也沒有埋在土裡。「嗯……是誰留下這些的？」 | 輕微：「灌木叢」改「莓果叢」更具體，不影響語義 |
| P06 | P06 | 啾啾擦嘴角，果汁越擦越明顯。／「看線索，再猜是誰！啾啾吃莓果，把籽帶來了。」／「不是故意的啦！」小籽也進了袋裡。 | Pip wiped her beak, but the berry juice just smeared into two little mustache marks.／"Find a clue, then guess who! Pip ate berries and brought the seeds along!"／"I didn't mean to!" Hazel popped a seed into her satchel. | Pip 擦了擦她的嘴喙，但莓果汁只是糊成了兩道小鬍子印。「找線索，猜猜誰！Pip 吃了莓果，順便把種子帶來了！」「我不是故意的！」Hazel 把一顆種子放進她的小包裡。 | 輕微：加「兩道小鬍子印」具體視覺喜劇細節（圖面可見），zh-TW 為「越擦越明顯」 |
| P07 | P07 | 「啾啾只是吃了莓果。」栗栗點點頭。／接著，她發現一頂橡實帽和幾道淺淺的抓痕，一路通到大橡樹下。 | "Pip just ate berries — she wasn't trying to hide anything." Hazel nodded.／Then she spotted an acorn cap and a trail of shallow scratch marks leading toward the oak tree. | 「Pip 只是吃了莓果——她並不是想要藏什麼東西。」Hazel 點了點頭。然後她看到一個橡實殼和一串淺淺的抓痕，朝著橡樹的方向延伸。 | 無 |
| P08 | P08 | 沙沙！栗栗飛快地挖開淺土。／一顆完整的橡實、幾道抓痕，還有一枚熟悉的小爪印。／「咦？這次跟前面不一樣。」 | Scritch, scratch! Hazel dug through the loose soil.／A whole acorn, a row of scratch marks, and one familiar little paw print!／"Wait… this is different from the other two." | 嘶嘶、刷刷！Hazel 在鬆軟的土裡挖了起來。一顆完整的橡實、一排抓痕，還有一枚熟悉的小爪印！「等等……這個和前面兩個不一樣。」 | 無 |
| P09 | P09 | 呼呼風捲來秋葉，抓痕快被蓋住了。／「等等！」栗栗一撲，小葉袋卻翻了。翅果和莓果籽往橡實旁滑—— | Breezy swirled in with a gust of fall leaves. The scratch marks were about to disappear!／"Hold on!" Hazel lunged — but her leaf satchel flipped. The winged seed and the berry seed slid right toward the acorn— | Breezy 捲著一陣秋天的落葉飛了進來。抓痕就要被蓋住了！「等一下！」Hazel 撲了過去——但她的樹葉小包翻了。有翅膀的種子和莓果種子朝著橡實滑了過去—— | 無 |
| P10 | P10 | 栗栗把三組種子分開。／「翅果有雙翅，落在風吹得到的空地。莓果籽旁有果汁色的小印子。」／「橡實旁有抓痕……」她的爪子停住了。 | Hazel sorted the three kinds of seeds.／"The winged seed has thin wings and lands where the wind blows. The berry seed sits near juice marks. And this acorn…" Her paw hovered above the scratch marks. | Hazel 把三種種子分開來。「有翅膀的種子有細薄的翅膀，落在風吹到的地方。莓果種子待在果汁痕跡旁邊。而這顆橡實……」她的爪子懸在抓痕上方。 | 無 |
| P11 | P11 | 「看線索，再猜是誰！」／「呼呼風吹來翅果。啾啾帶來莓果籽。我埋了橡實。／種子來的路不一樣，只有我在藏食物！」 | "Find a clue, then guess who!"／"Breezy blew the winged seeds. Pip brought the berry seeds. And I buried the acorn myself!"／"There's more than one answer! Only I was really hiding!" | 「找線索，猜猜誰！」Breezy 吹來了有翅膀的種子。Pip 帶來了莓果種子。而 Hazel——她自己埋了那顆橡實！「不止一個答案！只有我是真正在藏東西！」 | 輕微：zh-TW「種子來的路不一樣」→ en-US「不止一個答案」——語義角度不同但結論一致（三種途徑＝三個答案） |
| P12 | P12 | 呼呼風：「我只管吹，沒有藏。」啾啾：「我也沒有！」／栗栗按橡實進鬆土，一爪疊上舊印。／她笑了：「這是我的爪印！」 | Breezy said, "I never picked a hiding spot."／Pip said, "Me neither!"／Hazel pressed her acorn into the soft soil. Her paw landed right on top of the old print.／She grinned. "Those are MY paw prints!" | Breezy 說：「我從來沒有挑過藏的地方。」Pip 說：「我也沒有！」Hazel 把她的橡實按進鬆軟的泥土裡。她的爪子正好印在原來的爪印上。她笑了。「那些是我的爪印！」 | 無 |
| P13 | P13 | 秋天快過完了，栗栗把淺坑留著，不把種子挖出來。／「下個季節再回來看看。」三個朋友一起等春天。 | The last warm days of fall slipped by. Hazel left the pit just as it was — she didn't dig anything up.／"Let's come back next season and see what happens." The three friends settled in to wait for spring. | 秋天最後幾個溫暖的日子悄悄過去了。Hazel 讓那個坑洞保持原樣——她沒有挖出任何東西。「我們下個季節再回來看看會發生什麼吧。」三個朋友安頓下來，一起等待春天。 | 輕微：加「安頓下來」語感修飾，不影響語義 |
| P14 | P14 | 春天，三個朋友一起回來看：有些種子冒出新芽，有些沒有。／「下次，我先找線索。」／後來呀，栗栗看到種子就先找線索，再猜是誰。 | In spring, they found a tiny green shoot near where a winged seed had landed. Not every seed had sprouted.／"Next time, I'll look for clues first."／And from that day on, Hazel always looked for clues before she guessed. | 春天，他們在一顆有翅膀的種子曾經落下的地方，發現了一株小小的綠芽。不是每顆種子都發芽了。「下次，我要先找線索再猜。」從那天起，Hazel 每次猜之前，都會先找線索。 | 無 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 栗栗回到自己的淺坑，旁邊多了一顆沒看過的種子，長著小翅膀。／「是誰放的？」 | Hazel hurried back to her pit under the oak tree. Beside her acorn was a seed she'd never seen — with little wings!／"Who put this here?" | Hazel 匆匆趕回橡樹下她的坑洞。她的橡實旁邊是一顆她從沒見過的種子——帶著小翅膀！「是誰放在這裡的？」 | 無 |
| P02 | P03 | 「看線索，再猜是誰！小翅膀跟著風飛——是呼呼風帶走的！」／翅果收進小葉袋，追風！ | "Find a clue, then guess who! Little wings ride the wind — Breezy carried this seed!"／Hazel tucked it into her leaf satchel and chased after the wind. | 「找線索，猜猜誰！Breezy 帶來了這顆有翅膀的種子！」Hazel 把種子塞進她的樹葉小包，追著風跑去。 | 無 |
| P03 | P04 | 「我只管吹喔！」／咻嚕！呼呼風一吹，翅果就飛起來了。栗栗快追！ | "I just blow!" said Breezy.／WHOOSH! A winged seed spun right up. Hazel chased it! | 「我只是吹呀吹！」Breezy 說。咻！一顆有翅膀的種子旋了上去。Hazel 追了上去！ | 無 |
| P04 | P05 | 矮樹叢旁有小小的籽。沒有翅，也沒有埋進土裡。／「這回又是誰？」 | Near the bushes, tiny seeds sat on a leaf. No wings. Not buried in the ground.／"Who left these?" | 在灌木叢旁邊，小小的種子待在一片葉子上。沒有翅膀。也沒有埋在土裡。「是誰留下這些的？」 | 無 |
| P05 | P06 | 「看線索，再猜是誰！啾啾吃莓果，帶來了籽。」／「不是故意的！」籽進袋裡。 | "Find a clue, then guess who! Pip ate berries and brought the seeds!"／"I didn't mean to!" The seed went into the satchel. | 「找線索，猜猜誰！Pip 吃了莓果，把種子帶來了！」「我不是故意的！」種子被放進了小包裡。 | 無 |
| P06 | P07 | 「啾啾吃了莓果，不是故意藏的。」／栗栗追著橡實帽和淺淺的抓痕走。 | "Pip ate berries — she wasn't hiding on purpose."／Hazel followed an acorn cap and shallow scratch marks. | 「Pip 吃了莓果——她不是故意要藏的。」Hazel 跟著一個橡實殼和淺淺的抓痕走。 | 無 |
| P07 | P08 | 沙沙！栗栗挖開淺土。／橡實、抓痕，還有熟悉的小爪印！／「這次不一樣。」 | Scritch, scratch! Hazel dug into the soil.／An acorn, scratch marks, and a familiar paw print!／"This one's different." | 嘶嘶、刷刷！Hazel 在土裡挖了起來。一顆橡實、抓痕，還有一個熟悉的爪印！「這個不一樣。」 | 無 |
| P08 | P09 | 秋葉快蓋住抓痕了。／「等等！」栗栗一撲，小葉袋翻了。翅果和莓果籽往橡實旁滑—— | Fall leaves were about to cover the scratch marks!／"Wait!" Hazel lunged — her satchel flipped. The winged seed and berry seed slid toward the acorn— | 秋天的落葉就要蓋住抓痕了！「等一下！」Hazel 撲了過去——她的小包翻了。有翅膀的種子和莓果種子朝著橡實滑了過去—— | 無 |
| P09 | P11 | 「看線索，再猜是誰！」／「呼呼風吹翅果。啾啾帶莓果籽。我埋了橡實。／只有我在藏！」 | "Find a clue, then guess who!"／"Breezy blew winged seeds. Pip brought berry seeds. I buried the acorn.／Only I was hiding!" | 「找線索，猜猜誰！」Breezy 吹來了有翅膀的種子。Pip 帶來了莓果種子。我埋了橡實。只有我是在藏東西！ | 無 |
| P10 | P12 | 呼呼風：「沒有特地藏。」／啾啾：「我也沒有。」／栗栗看著爪印笑了：「是我藏的！」 | Breezy said, "I never picked a hiding spot."／Pip said, "Me neither!"／Hazel looked at the paw prints and smiled. "Those are mine!" | Breezy 說：「我從來沒有挑過藏的地方。」Pip 說：「我也沒有！」Hazel 看著那些爪印，笑了。「那些是我的！」 | 輕微：zh-TW「沒有特地藏」→「沒有挑過藏的地方」語氣角度略不同；「是我藏的」→「那些是我的」從動作轉指涉 |
| P11 | P13 | 栗栗把淺坑留著。／「下個季節再回來看。」三個朋友一起等春天。 | Hazel left the pit just the way it was.／"Let's come back next season." The three friends waited for spring together. | Hazel 讓那個坑洞保持原樣。「我們下個季節再回來吧。」三個朋友一起等待春天。 | 無 |
| P12 | P14 | 春天，大家看到新芽了。／「下次，我先找線索。」／後來呀，栗栗看到種子就先找線索了。 | In spring, they all spotted a tiny green shoot!／"Next time, I'll look for clues first."／And from that day on, Hazel always looked for clues. | 春天，他們都發現了一株小小的綠芽！「下次，我要先找線索再猜。」從那天起，Hazel 每次都會先找線索。 | 輕微：zh-TW「先找線索」→「先找線索再猜」多半句，主旨同 |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 栗栗的淺坑旁，多了一顆種子。有小小的翅膀！／「是誰？」 | Strange seed! Little wings!／"Who hid it?" | 奇怪的種子！小翅膀！「是誰藏的？」 | 輕微：zh-TW「是誰？」→ en-US「是誰藏的？」多了「藏」字；省略「淺坑旁」場景交代（2-3 壓縮合法） |
| P02 | P03 | 「看線索，再猜是誰！」／呼呼風吹來翅果，轉呀轉！栗栗收進小葉袋！ | "Find a clue, then guess who!"／Breezy blew it! Spin, spin!／Into the bag! | 「找線索，猜猜誰！」Breezy 吹來了！轉呀轉！進袋子！ | 輕微：zh-TW「翅果」具名→ en-US「it」代名詞；zh-TW「栗栗收進小葉袋」→ en-US「Into the bag」省略主詞（2-3 壓縮合法）。**R1 後恢復事件＋袋子動作** |
| P03 | P04 | 「我只管吹喔！」／咻嚕！翅果飛起來。／栗栗快追！ | "I just blow!"／WHOOSH! The seed flew up! | 「我只是吹呀吹！」咻！種子飛起來了！ | 輕微：省略「栗栗快追」追趕動作（2-3 字數壓縮合法） |
| P04 | P06 | 「看線索，再猜是誰！」／啊嗚！啾啾吃莓果，帶來小小籽。／「不是故意的！」進袋子囉！ | "Find a clue, then guess who!"／Chomp! Pip ate berries. Seeds came too!／"Oops!" | 「找線索，猜猜誰！」嗷嗚！Pip 吃了莓果。種子也一起來了！「哎呀！」 | 輕微：zh-TW「帶來小小籽」→ en-US「Seeds came too/種子也一起來了」角度略不同（被動帶來 vs 跟來）；zh-TW「進袋子囉」→ en-US 省略（2-3 字數壓縮）。**R1 後加入 Chomp!/嗷嗚 擬聲，與 zh-TW「啊嗚」對齊** |
| P05 | P08 | 沙沙！淺坑裡有橡實。／小爪印！「是誰的？」 | Scritch, scratch! An acorn!／Little paw prints! "Whose?" | 嘶嘶、刷刷！一顆橡實！小爪印！「誰的？」 | 無 |
| P06 | P09 | 唰啦啦！落葉飛來了！／栗栗一撲——／小葉袋翻了！ | Swish! Leaves blew in!／Hazel jumped — her bag flipped! | 刷！葉子吹進來了！Hazel 跳了起來——她的袋子翻了！ | 輕微：zh-TW「唰啦啦」三音節→「Swish/刷」單音節；zh-TW「小葉袋」→「bag/袋子」詞彙簡化。**R1 後加入撲跳動作「jumped」，與 zh-TW「一撲」對齊** |
| P07 | P11 | 「看線索，再猜是誰！」／「呼呼風吹翅果。啾啾帶小籽。我埋橡實。／只有我在藏！」 | "Find a clue, then guess who!"／"Breezy blew. Pip ate. I hid!／Only me!" | 「找線索，猜猜誰！」Breezy 吹。Pip 吃。我藏！只有我！ | 輕微：zh-TW 三句各有受詞「翅果/小籽/橡實」，en-US 省略受詞為動詞三連擊（2-3 極簡壓縮） |
| P08 | P12 | 栗栗把橡實按呀按，按進土裡。／她看著爪印笑了：「是我藏的！」 | Push, push! Down went the acorn.／Her prints! "Mine!" | 推呀推！橡實按下去了。她的爪印！「是我的！」 | 輕微：zh-TW「她看著爪印笑了」→ en-US 省略微笑動作；zh-TW「是我藏的」→「Mine/是我的」從動作轉指涉（2-3 壓縮合法）。**R1 後加入「Push, push!/推呀推」節奏疊字，與 zh-TW「按呀按」對齊** |
| P09 | P13 | 栗栗把淺坑留著。／三個朋友一起等春天再回來看看。 | Hazel left the pit alone.／The three friends waited for spring. | Hazel 讓那個坑洞靜靜留著。三個朋友等待春天。 | 輕微：zh-TW「再回來看看」→ en-US 省略（2-3 壓縮合法）。**R1 後從禁止語「No digging」改為溫和陳述「left the pit alone」，與 zh-TW「把淺坑留著」對齊** |
| P10 | P14 | 春天，一起看小小的新芽。／後來呀，栗栗看到種子就找線索。 | Spring! The three friends found a tiny green shoot!／And from that day on, Hazel looked for clues. | 春天！三個朋友發現了一株小小的綠芽！從那天起，Hazel 都會先找線索。 | 輕微：zh-TW「一起看」泛指→ en-US「三個朋友發現」具名（**R1 Stacy 品牌合規指令：加三友主詞**） |

## 三、QA 摘要（qa/en-US）

- `qa/en-US/round1.md`：round 1／verdict fix_required
- `qa/en-US/round2.md`：round 2／verdict pass

最新 round：`qa/en-US/round2.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: who-hid-the-seeds
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-22"
step1_lint: {exit_code: 0, warnings: 3}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 5, 朗讀口感: 7, 孩子抓得住度: 6}
  - id: en-US-parent
    scores: {睡前適讀性: 6, 零說教: 4}
  - id: en-US-editor
    scores: {母語自然度: 7, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 0}
low_score_waivers:
  - {persona: en-US-parent, dimension: 零說教, reason: "brand_frozen_units lock-in（同 round 1）"}
verdict: pass
```

### ESL 獵手發現（原文引用）

（缺）最新 round 無「ESL」標題節——確認漏斗是否執行 ESL 獵手維度。

## 四、⏸️ 上呈批次

無——各輪未見 ⏸️ 標記行。

