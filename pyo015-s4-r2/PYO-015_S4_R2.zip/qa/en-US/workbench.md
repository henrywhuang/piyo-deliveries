# 關卡WB整合審閱：誰把種子藏起來？（E 對位底稿／en-US）

- 生成時間：2026-07-23 16:47:37 +0800
- 書目錄：`content/PYO-015_who-hid-the-seeds`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate WB`（決定性腳本，純解析＋排版）
- locale：en-US
- 用途：E 主審與裁決 agent 的單檔輸入 bundle——文字＝QA 對象本體逐字轉錄；可疑頁保留開原檔抽驗權

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-015_storyboard.md` | 2026-07-21 17:08:45 |
| copy | `copy/en-US.md` | 2026-07-23 11:42:43 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-23 11:30:22 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-23 11:30:56 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-23 11:30:36 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-23 11:31:02 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-23 11:30:47 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-23 11:33:44 |
| qa/en-US/backtranslation.md | `qa/en-US/backtranslation.md` | 2026-07-22 19:36:48 |

## 檔頭 commitments 逐字轉錄（兌現比對用）

```yaml
schema: piyo_copy/v0.9
slug: who-hid-the-seeds
locale: en-US
mode: B
storyboard: content/PYO-015_who-hid-the-seeds/PYO-015_storyboard.md
design: content/PYO-015_who-hid-the-seeds/PYO-015_design.md
image_pool: 14
selection:
  "3-5": [P01, P03, P04, P05, P06, P07, P08, P09, P11, P12, P13, P14]
  "2-3": [P01, P03, P04, P06, P08, P09, P11, P12, P13, P14]
commitments:
  refrain: "Find a clue, then guess who!"
  ending: "And from that day on"
  onomatopoeia: [WHOOSH, "Scritch, scratch"]
characters: [Hazel, Breezy, Pip]
```

## 檔位 5-6（14 頁）

### 5-6｜P01（母版 P01）

- 圖說什麼：秋日大橡樹根全貌；栗栗佔前景約三分之一，彎腰盯著鬆土淺坑 ×1，坑邊有陌生楓樹翅果 ×1，自己的橡實露出一角；她瞪圓眼、尾巴初彎成問號；呼呼風：未入畫；背景只留粗樹根與稀疏落葉，主體為栗栗＋坑邊證物兩個焦點；構圖裝置：樹根框中框
- 文說什麼：旁白：回到藏點與發現陌生翅果的事件<br>內心：神祕藏家與搶先查明的猜想
- 鉤子：—
- 選圖與提純說明：3-5 scaffolds "little wings" for P02 skip compensation + shorter question; 2-3 telegram-style exclamatory fragments
- 匹配欄：✓

【zh-TW】
栗栗回到藏橡實的淺坑，坑邊多了一枚陌生的楓樹翅果。
「有人也在藏種子！我一定要先查出來是誰！」

【en-US】
Hazel hurried back to her pit under the big oak tree. Right beside her acorn lay a seed she'd never seen — with thin little wings!
"Someone is hiding seeds in my spot!" Her tail curled into a big question mark.

【回譯】
Hazel 匆匆趕回大橡樹下她的坑洞。她的橡實旁邊躺著一顆她從沒見過的種子——帶著細細的小翅膀！「有人在我的地盤藏種子！」她的尾巴捲成了一個大問號。
【偏移標記】輕微：台詞從「我要查」改為「有人在藏」語氣轉換；加「尾巴問號」身體語言（zh-TW 無）；核心事件（發現陌生翅果）無缺

### 5-6｜P02（母版 P02）

- 圖說什麼：栗栗的眼睛與前爪特寫，爪中楓樹翅果 ×1 清楚露出輕薄雙翅；後景失焦但可辨楓樹坡草尖上的翅果一小群、敞開落點 ×1 與無土堆的地面；呼呼風：展開1.4x，以淡藍乳白氣流橫過後景；背景細節層：瓢蟲 ×1 緊抓一片被吹起的落葉背面；構圖裝置：前景證物遮幅
- 文說什麼：旁白：循相同外形抵達楓樹坡的事件<br>內心：雙翅、敞開落點與無爪痕的比較
- 鉤子：—
- 選圖與提純說明：5-6 only; 3-5/2-3 skip — P01 "wings" description + P03 refrain bridge the gap
- 匹配欄：✓

【zh-TW】
她照著翅果的樣子，一路找到楓樹坡。種子有薄薄的雙翅，散在空地，旁邊沒有抓痕。
「不像埋進土裡的。」

【en-US】
She followed the winged seed all the way to the maple slope. More of them lay scattered across the open ground, with no scratch marks and no digging.
"It doesn't look like anyone buried these."

【回譯】
她追著那顆有翅膀的種子，一路來到楓樹坡。更多同樣的種子散落在空地上，沒有抓痕，也沒有挖掘的痕跡。「看起來不像是誰埋的。」
【偏移標記】無

### 5-6｜P03（母版 P03）

- 圖說什麼：栗栗佔畫面中央偏下，左爪托楓樹翅果 ×1，右爪指向敞開落點 ×1，背後被掃成一線的落葉 ×1；她自信揚眉，把樣本滑入敞開的小葉袋；呼呼風：展開1.4x，氣流從楓樹端掠向坡下但不遮證物；2-3 主體以栗栗＋三項緊靠線索為一群、呼呼風為第二群，背景簡化；背景細節層：同一隻瓢蟲躲到落葉線的背風側；構圖裝置：偵探三角舞台
- 文說什麼：台詞：第一次招牌疊句與風移動翅果的判斷<br>擬聲：葉片輕響的環境聲<br>旁白：留下翅果樣本並改追風向的事件
- 鉤子：—
- 選圖與提純說明：3-5 adds clue evidence "little wings ride the wind" (Stacy S4 R1); 2-3 restores seed-carried event + bag action per Stacy S4 R1
- 匹配欄：✓

【zh-TW】
栗栗看看翅果的小翅膀，再看看落葉方向。
「看線索，再猜是誰！是呼呼風帶走的。」
她把翅果放進小葉袋，追著風跑了。

【en-US】
Hazel looked at the thin wings, then at the leaves swept into a line.
"Find a clue, then guess who! The wind carried this seed!"
She tucked it into her leaf satchel and chased the breeze.

【回譯】
Hazel 看了看那對細薄的翅膀，又看了看被掃成一條線的落葉。「找線索，猜猜誰！是風把這顆種子帶來的！」她把種子塞進她的樹葉小包，追著微風跑去。
【偏移標記】無

### 5-6｜P04（母版 P04）

- 圖說什麼：外緣草地的開闊單一瞬間；呼呼風：展開1.4x，形成大弧氣流，把楓樹翅果 ×1 從草尖帶起；栗栗在左下大步追向右側，眼睛發亮，問號尾巴彎得比 P01 更大；翅果、氣流與栗栗奔跑輪廓清楚，角色與動作佔主要畫幅，背景灌木只作低矮色塊；構圖裝置：旋風螺旋動線
- 文說什麼：台詞：呼呼風未選藏點的說明<br>擬聲：咻嚕，楓樹翅果被風帶起<br>旁白：栗栗跟進外緣草地的事件
- 鉤子：—
- 選圖與提純說明：All tiers preserve WHOOSH onomatopoeia; 3-5 trims disclaimer; 2-3 telegram action only
- 匹配欄：✓

【zh-TW】
呼呼風說：「我只管吹，沒有挑地方喔！」
咻嚕！一枚翅果又飛了起來。栗栗趕快跟上。

【en-US】
Breezy said, "I just blow wherever I go — I don't pick where seeds land!"
WHOOSH! A winged seed spun right back up into the air. Hazel raced after it.

【回譯】
Breezy 說：「我只是吹到哪就到哪——我才不挑種子落在哪裡！」咻！一顆有翅膀的種子又旋回了半空中。Hazel 追了上去。
【偏移標記】無

### 5-6｜P05（母版 P05）

- 圖說什麼：大留白中以葉面局部特寫呈現細小莓果籽一小撮；栗栗的鼻尖、放大的圓眼與一爪從左側入框，另一爪捏著無翅的籽 ×1 比對；遠處一小段灌木與風向彎草只作位置提示；呼呼風：停風0.7x，縮在栗栗肩旁低頭看；構圖裝置：葉面聚焦放射
- 文說什麼：旁白：發現無翅、未入土莓果籽的事件<br>內心：新謎團與外形差異
- 鉤子：—
- 選圖與提純說明：3-5 shortens; 2-3 skips — P04 WHOOSH closes wind arc, P06 refrain opens berry arc directly
- 匹配欄：✓

【zh-TW】
灌木叢旁的葉子上有細小的籽。沒有翅，也沒有埋進土裡。
栗栗想：「這回又是誰？」

【en-US】
Near the berry bushes, Hazel spotted tiny seeds on a leaf. No wings. Not buried in the ground.
"Hmm… who left these here?"

【回譯】
在莓果叢旁邊，Hazel 發現一片葉子上有小小的種子。沒有翅膀。也沒有埋在土裡。「嗯……是誰留下這些的？」
【偏移標記】輕微：「灌木叢」改「莓果叢」更具體，不影響語義

### 5-6｜P06（母版 P06）

- 圖說什麼：啾啾以大而清楚的側面輪廓正跨過灌木缺口：尾羽仍在結莓果的灌木一側，身體橫越缺口，雙腳正落向外緣低枝，短喙攜著咬開莓果 ×1，果肉內可見籽；一側翅膀向後展開標出跨越方向，另一側翅尖正碰嘴角擦拭，紫紅果汁形成兩撇小鬍子；落腳枝下的大葉是明確落點，上有含莓果籽 ×3 的果汁色小便便痕 ×1；栗栗在外緣枝下指向啾啾帶來的莓果與落點，笑意憋在臉頰，把莓果籽樣本 ×1 收進小葉袋；呼呼風：未入畫；2-3 主體為「啾啾＋喙中莓果＋外緣落枝」一個大焦點、栗栗一個焦點，微小籽與小痕只作第二層證據，背景灌木降成兩側柔色塊；構圖裝置：偵探三角舞台
- 文說什麼：台詞：第二次招牌疊句與鳥帶遠莓果籽的判斷<br>台詞：啾啾害羞回應與非故意藏籽的說明<br>旁白：留下莓果籽樣本的事件
- 鉤子：—
- 選圖與提純說明：5-6 adds mustache visual detail (in illustration); 2-3 adds "Chomp!" onomatopoeia (Stacy S4 R1) + seed event; skip P05 bridge: refrain + "Pip ate berries" self-sufficient
- 匹配欄：✓

【zh-TW】
啾啾擦嘴角，果汁越擦越明顯。
「看線索，再猜是誰！啾啾吃莓果，把籽帶來了。」
「不是故意的啦！」小籽也進了袋裡。

【en-US】
Pip wiped her beak, but the berry juice just smeared into two little mustache marks.
"Find a clue, then guess who! Pip ate berries and brought the seeds along!"
"I didn't mean to!" Hazel popped a seed into her satchel.

【回譯】
Pip 擦了擦她的嘴喙，但莓果汁只是糊成了兩道小鬍子印。「找線索，猜猜誰！Pip 吃了莓果，順便把種子帶來了！」「我不是故意的！」Hazel 把一顆種子放進她的小包裡。
【偏移標記】輕微：加「兩道小鬍子印」具體視覺喜劇細節（圖面可見），zh-TW 為「越擦越明顯」

### 5-6｜P07（母版 P07）

- 圖說什麼：栗栗蹲在灌木下，神情由好笑轉為認真；左後方啾啾停在外側枝頭，嘴邊已擦淡；前景橡實帽 ×1 與淺爪痕 ×3 串成朝右方橡樹的地面路徑，栗栗一爪懸在第一道痕前、不碰亂線索；呼呼風：未入畫；構圖裝置：地面線索S形
- 文說什麼：台詞：鳥非刻意藏籽的修正判斷<br>旁白：發現橡實帽與轉追地面線索的事件
- 鉤子：—
- 選圖與提純說明：3-5 compresses deduction; 2-3 skips — P06 closes berry arc, P08 opens acorn arc with "Scritch, scratch!"
- 匹配欄：✓

【zh-TW】
「啾啾只是吃了莓果。」栗栗點點頭。
接著，她發現一頂橡實帽和幾道淺淺的抓痕，一路通到大橡樹下。

【en-US】
"Pip just ate berries — she wasn't trying to hide anything." Hazel nodded.
Then she spotted an acorn cap and a trail of shallow scratch marks leading toward the oak tree.

【回譯】
「Pip 只是吃了莓果——她並不是想要藏什麼東西。」Hazel 點了點頭。然後她看到一個橡實殼和一串淺淺的抓痕，朝著橡樹的方向延伸。
【偏移標記】無

### 5-6｜P08（母版 P08）

- 圖說什麼：栗栗快速刨開淺土的單一瞬間，一雙前爪把鬆土推向兩側，坑內完整橡實 ×1 露出大半；坑邊淺抓痕 ×3 與熟悉小爪印 ×1 清楚，栗栗耳朵微垂、嘴角心虛；呼呼風：未入畫；2-3 畫幅由栗栗大前爪＋淺坑證物構成一個主焦點，臉為第二焦點，背景只留少量落葉；構圖裝置：坑洞同心圓
- 文說什麼：擬聲：沙沙，栗栗快速刨開淺土<br>旁白：發現完整橡實、抓痕與熟悉爪印的事件<br>內心：與前兩站敞開落點的差異
- 鉤子：—
- 選圖與提純說明：All tiers preserve "Scritch, scratch!" onomatopoeia; 2-3 skip P07 bridge: onomatopoeia + "acorn" self-opens arc
- 匹配欄：✓

【zh-TW】
沙沙！栗栗飛快地挖開淺土。
一顆完整的橡實、幾道抓痕，還有一枚熟悉的小爪印。
「咦？這次跟前面不一樣。」

【en-US】
Scritch, scratch! Hazel dug through the loose soil.
A whole acorn, a row of scratch marks, and one familiar little paw print!
"Wait… this is different from the other two."

【回譯】
嘶嘶、刷刷！Hazel 在鬆軟的土裡挖了起來。一顆完整的橡實、一排抓痕，還有一枚熟悉的小爪印！「等等……這個和前面兩個不一樣。」
【偏移標記】無

### 5-6｜P09（母版 P09）

- 圖說什麼：呼呼風：展開1.4x，從左上捲來秋葉一小群，葉緣開始遮到淺抓痕；栗栗橫身護住坑邊痕跡，焦急張嘴，小葉袋倒轉；楓樹翅果 ×1 與莓果籽 ×1 正從袋口滑向手邊橡實 ×1，停在尚未落地相碰的頂點；2-3 主體為栗栗＋袋口樣本一群、呼呼風＋落葉一群，背景空地簡化；構圖裝置：翻袋斜切
- 文說什麼：旁白：落葉將蓋痕跡與小葉袋翻倒的事件<br>內心：證物將混在一起的著急<br>時間：樣本落地前的動作停頓
- 鉤子：動作中斷型：栗栗撲向抓痕時小葉袋翻起，兩枚樣本正滑出袋口
- 選圖與提純說明：2-3 adds "Swish!" + pounce causality (Stacy S4 R1); cliffhanger preserved across all tiers
- 匹配欄：✓

【zh-TW】
呼呼風捲來秋葉，抓痕快被蓋住了。
「等等！」栗栗一撲，小葉袋卻翻了。翅果和莓果籽往橡實旁滑——

【en-US】
Breezy swirled in with a gust of fall leaves. The scratch marks were about to disappear!
"Hold on!" Hazel lunged — but her leaf satchel flipped. The winged seed and the berry seed slid right toward the acorn—

【回譯】
Breezy 捲著一陣秋天的落葉飛了進來。抓痕就要被蓋住了！「等一下！」Hazel 撲了過去——但她的樹葉小包翻了。有翅膀的種子和莓果種子朝著橡實滑了過去——
【偏移標記】無

### 5-6｜P10（母版 P10）

- 圖說什麼：大留白中的俯近平面特寫；栗栗兩爪與臉佔上半，地面僅見楓樹翅果 ×1、莓果籽 ×1、橡實 ×1 排成三組，旁邊淺坑抓痕 ×3；最後一爪懸在橡實上方，眼神沿三組移動；呼呼風：未入畫；畫內不出現迎風落點、鳥痕、遠端背景、分格或回憶影像；構圖裝置：三欄秤盤
- 文說什麼：台詞：前兩站迎風落點與鳥痕的口述回憶<br>內心：三種外形、落點與痕跡的逐組比對<br>旁白：三組實體樣本分開的事件
- 鉤子：動作中斷型：栗栗最後一爪懸在橡實與抓痕之間，三組尚待說出答案
- 選圖與提純說明：5-6 only; 3-5/2-3 skip — sorting/analysis beat; P09 crisis flows directly to P11 reveal
- 匹配欄：✓

【zh-TW】
栗栗把三組種子分開。
「翅果有雙翅，落在風吹得到的空地。莓果籽旁有果汁色的小印子。」
「橡實旁有抓痕……」她的爪子停住了。

【en-US】
Hazel sorted the three kinds of seeds.
"The winged seed has thin wings and lands where the wind blows. The berry seed sits near juice marks. And this acorn…" Her paw hovered above the scratch marks.

【回譯】
Hazel 把三種種子分開來。「有翅膀的種子有細薄的翅膀，落在風吹到的地方。莓果種子待在果汁痕跡旁邊。而這顆橡實……」她的爪子懸在抓痕上方。
【偏移標記】無

### 5-6｜P11（母版 P11）

- 圖說什麼：同一落葉角落的滿版第三變奏；栗栗比 P03、P06 更大，站在中心高光處，呼呼風：停風0.7x，與啾啾緊靠栗栗兩側成一個角色焦點群；前景楓樹翅果 ×1、莓果籽 ×1、橡實 ×1 與淺坑抓痕 ×3 排成放大的三角證物群；呼呼風靠翅果、啾啾靠莓果籽、栗栗靠橡實，三位表情同時亮起，栗栗尾巴圈住三角；畫內不出現迎風落點、鳥痕、遠端背景、分格或回憶影像；2-3 背景僅留落葉色面，角色群與證物群合計兩個焦點；構圖裝置：偵探三角舞台
- 文說什麼：台詞：第三次更大的招牌疊句<br>台詞：風、鳥、松鼠三種移動方式與答案不只一個的判斷<br>台詞：只有松鼠有意藏食的揭示
- 鉤子：懸念型：三個答案已揭開，栗栗卻低頭看向橡實旁那枚熟悉爪印
- 選圖與提純說明：Climax: 5-6 narrator→first-person quote (Stacy S4 R1); three-agent parallel reveal across all tiers; 2-3 maximum compression — 3-word triplet + 2-word conclusion; skip P10 bridge: P09 crisis → P11 refrain self-sufficient
- 匹配欄：✓

【zh-TW】
「看線索，再猜是誰！」
「呼呼風吹來翅果。啾啾帶來莓果籽。我埋了橡實。
種子來的路不一樣，只有我在藏食物！」

【en-US】
"Find a clue, then guess who!"
"Breezy blew the winged seeds. Pip brought the berry seeds. And I buried the acorn myself!"
"There's more than one answer! Only I was really hiding!"

【回譯】
「找線索，猜猜誰！」Breezy 吹來了有翅膀的種子。Pip 帶來了莓果種子。而 Hazel——她自己埋了那顆橡實！「不止一個答案！只有我是真正在藏東西！」
【偏移標記】輕微：zh-TW「種子來的路不一樣」→ en-US「不止一個答案」——語義角度不同但結論一致（三種途徑＝三個答案）

### 5-6｜P12（母版 P12）

- 圖說什麼：回到大橡樹根；栗栗一爪正把橡實 ×1 按入鬆土淺坑 ×1，另一爪落在坑旁，與舊小爪印 ×1 完全重合；她低頭瞪大眼、臉頰發熱、尾巴變成短短驚嘆號，認出是自己的印；呼呼風：停風0.7x，與啾啾緊靠在後方相視微笑；2-3 主體為栗栗＋埋橡實與爪印一群、兩位朋友一群，背景樹根乾淨；構圖裝置：爪印鏡像對照
- 文說什麼：台詞：呼呼風與啾啾未挑藏點的說明<br>台詞：栗栗認出自己爪印與不再抓壞人的轉念<br>旁白：回到起點並記住種子位置的事件
- 鉤子：—
- 選圖與提純說明：5-6 physical action + paw-on-print callback; 3-5 dialogue trio; 2-3 rhythm reduplication (Stacy S4 R1)
- 匹配欄：✓

【zh-TW】
呼呼風：「我只管吹，沒有藏。」啾啾：「我也沒有！」
栗栗按橡實進鬆土，一爪疊上舊印。
她笑了：「這是我的爪印！」

【en-US】
Breezy said, "I never picked a hiding spot."
Pip said, "Me neither!"
Hazel pressed her acorn into the soft soil. Her paw landed right on top of the old print.
She grinned. "Those are MY paw prints!"

【回譯】
Breezy 說：「我從來沒有挑過藏的地方。」Pip 說：「我也沒有！」Hazel 把她的橡實按進鬆軟的泥土裡。她的爪子正好印在原來的爪印上。她笑了。「那些是我的爪印！」
【偏移標記】無

### 5-6｜P13（母版 P13）

- 圖說什麼：秋日大橡樹根的開闊全景；栗栗、啾啾與呼呼風：停風0.7x，三位緊靠成一群圍在保留原狀的淺坑 ×1 旁，小葉袋 ×1 已闔起，沒有再挖其他落處；栗栗尾巴鬆鬆環住大家，三位共同望向林間柔光；2-3 角色群夠大、坑為第二焦點，背景落葉稀疏不搶戲；背景細節層：同一隻瓢蟲鑽進樹根旁落葉縫過冬；構圖裝置：環抱圓形收束
- 文說什麼：台詞：下一個季節再查看的約定<br>旁白：保留淺坑、不挖出每顆種子的事件<br>時間：秋日結束前的等待起點
- 鉤子：—
- 選圖與提純說明：5-6 time transition + dialogue; 3-5 drops time marker; 2-3 gentle closure (Stacy S4 R1: prohibitive→gentle)
- 匹配欄：✓

【zh-TW】
秋天快過完了，栗栗把淺坑留著，不把種子挖出來。
「下個季節再回來看看。」三個朋友一起等春天。

【en-US】
The last warm days of fall slipped by. Hazel left the pit just as it was — she didn't dig anything up.
"Let's come back next season and see what happens." The three friends settled in to wait for spring.

【回譯】
秋天最後幾個溫暖的日子悄悄過去了。Hazel 讓那個坑洞保持原樣——她沒有挖出任何東西。「我們下個季節再回來看看會發生什麼吧。」三個朋友安頓下來，一起等待春天。
【偏移標記】輕微：加「安頓下來」語感修飾，不影響語義

### 5-6｜P14（母版 P14）

- 圖說什麼：春日楓樹坡的開闊全景；低齡主體層只有一個緊靠焦點群：栗栗、啾啾與呼呼風：停風0.7x，三位佔前景大幅、共同蹲向正中央單株新芽 ×1，動作輪廓是一起回來、一起看見，栗栗微笑，尾巴先彎成溫柔問號、眼睛落在線索上；5-6 細節層：較遠處另一株新芽 ×1 靠舊楓樹翅果殼 ×1，低對比空土淺落處 ×3 融入背景，3-5／2-3 完全忽略仍讀得懂結尾；背景只留淡淡楓樹與草坡；背景細節層：過冬的瓢蟲 ×1 爬到前景新芽葉片背側，不形成新焦點；構圖裝置：開闊地平線
- 文說什麼：時間：三檔共同的下一季春日回訪<br>旁白：5-6 檔部分淺落處出芽的驗證事件<br>台詞：5-6／3-5 檔先找線索再判斷的第一人稱意願<br>旁白：3-5／2-3 檔共同回訪、看新芽與安心收束<br>旁白：三檔固定收束式
- 鉤子：—
- 選圖與提純說明：All tiers end with "And from that day on" (brand_frozen_units); 5-6 adds "Not every seed" nuance; 2-3 adds "three friends" subject (Stacy S4 R1 brand compliance); P10 page 18>14 inherent to Stacy instruction + frozen unit
- 匹配欄：✓

【zh-TW】
春天，三個朋友一起回來看：有些種子冒出新芽，有些沒有。
「下次，我先找線索。」
後來呀，栗栗看到種子就先找線索，再猜是誰。

【en-US】
In spring, they found a tiny green shoot near where a winged seed had landed. Not every seed had sprouted.
"Next time, I'll look for clues first."
And from that day on, Hazel always looked for clues before she guessed.

【回譯】
春天，他們在一顆有翅膀的種子曾經落下的地方，發現了一株小小的綠芽。不是每顆種子都發芽了。「下次，我要先找線索再猜。」從那天起，Hazel 每次猜之前，都會先找線索。
【偏移標記】無

## 檔位 3-5（12 頁）

### 3-5｜P01（母版 P01）

- 圖說什麼：秋日大橡樹根全貌；栗栗佔前景約三分之一，彎腰盯著鬆土淺坑 ×1，坑邊有陌生楓樹翅果 ×1，自己的橡實露出一角；她瞪圓眼、尾巴初彎成問號；呼呼風：未入畫；背景只留粗樹根與稀疏落葉，主體為栗栗＋坑邊證物兩個焦點；構圖裝置：樹根框中框
- 文說什麼：旁白：回到藏點與發現陌生翅果的事件<br>內心：神祕藏家與搶先查明的猜想
- 鉤子：—
- 選圖與提純說明：3-5 scaffolds "little wings" for P02 skip compensation + shorter question; 2-3 telegram-style exclamatory fragments
- 匹配欄：✓

【zh-TW】
栗栗回到自己的淺坑，旁邊多了一顆沒看過的種子，長著小翅膀。
「是誰放的？」

【en-US】
Hazel hurried back to her pit under the oak tree. Beside her acorn was a seed she'd never seen — with little wings!
"Who put this here?"

【回譯】
Hazel 匆匆趕回橡樹下她的坑洞。她的橡實旁邊是一顆她從沒見過的種子——帶著小翅膀！「是誰放在這裡的？」
【偏移標記】無

### 3-5｜P02（母版 P03）

- 圖說什麼：栗栗佔畫面中央偏下，左爪托楓樹翅果 ×1，右爪指向敞開落點 ×1，背後被掃成一線的落葉 ×1；她自信揚眉，把樣本滑入敞開的小葉袋；呼呼風：展開1.4x，氣流從楓樹端掠向坡下但不遮證物；2-3 主體以栗栗＋三項緊靠線索為一群、呼呼風為第二群，背景簡化；背景細節層：同一隻瓢蟲躲到落葉線的背風側；構圖裝置：偵探三角舞台
- 文說什麼：台詞：第一次招牌疊句與風移動翅果的判斷<br>擬聲：葉片輕響的環境聲<br>旁白：留下翅果樣本並改追風向的事件
- 鉤子：—
- 選圖與提純說明：3-5 adds clue evidence "little wings ride the wind" (Stacy S4 R1); 2-3 restores seed-carried event + bag action per Stacy S4 R1
- 匹配欄：✓

【zh-TW】
「看線索，再猜是誰！小翅膀跟著風飛——是呼呼風帶走的！」
翅果收進小葉袋，追風！

【en-US】
"Find a clue, then guess who! Little wings ride the wind — Breezy carried this seed!"
Hazel tucked it into her leaf satchel and chased after the wind.

【回譯】
「找線索，猜猜誰！Breezy 帶來了這顆有翅膀的種子！」Hazel 把種子塞進她的樹葉小包，追著風跑去。
【偏移標記】無

### 3-5｜P03（母版 P04）

- 圖說什麼：外緣草地的開闊單一瞬間；呼呼風：展開1.4x，形成大弧氣流，把楓樹翅果 ×1 從草尖帶起；栗栗在左下大步追向右側，眼睛發亮，問號尾巴彎得比 P01 更大；翅果、氣流與栗栗奔跑輪廓清楚，角色與動作佔主要畫幅，背景灌木只作低矮色塊；構圖裝置：旋風螺旋動線
- 文說什麼：台詞：呼呼風未選藏點的說明<br>擬聲：咻嚕，楓樹翅果被風帶起<br>旁白：栗栗跟進外緣草地的事件
- 鉤子：—
- 選圖與提純說明：All tiers preserve WHOOSH onomatopoeia; 3-5 trims disclaimer; 2-3 telegram action only
- 匹配欄：✓

【zh-TW】
「我只管吹喔！」
咻嚕！呼呼風一吹，翅果就飛起來了。栗栗快追！

【en-US】
"I just blow!" said Breezy.
WHOOSH! A winged seed spun right up. Hazel chased it!

【回譯】
「我只是吹呀吹！」Breezy 說。咻！一顆有翅膀的種子旋了上去。Hazel 追了上去！
【偏移標記】無

### 3-5｜P04（母版 P05）

- 圖說什麼：大留白中以葉面局部特寫呈現細小莓果籽一小撮；栗栗的鼻尖、放大的圓眼與一爪從左側入框，另一爪捏著無翅的籽 ×1 比對；遠處一小段灌木與風向彎草只作位置提示；呼呼風：停風0.7x，縮在栗栗肩旁低頭看；構圖裝置：葉面聚焦放射
- 文說什麼：旁白：發現無翅、未入土莓果籽的事件<br>內心：新謎團與外形差異
- 鉤子：—
- 選圖與提純說明：3-5 shortens; 2-3 skips — P04 WHOOSH closes wind arc, P06 refrain opens berry arc directly
- 匹配欄：✓

【zh-TW】
矮樹叢旁有小小的籽。沒有翅，也沒有埋進土裡。
「這回又是誰？」

【en-US】
Near the bushes, tiny seeds sat on a leaf. No wings. Not buried in the ground.
"Who left these?"

【回譯】
在灌木叢旁邊，小小的種子待在一片葉子上。沒有翅膀。也沒有埋在土裡。「是誰留下這些的？」
【偏移標記】無

### 3-5｜P05（母版 P06）

- 圖說什麼：啾啾以大而清楚的側面輪廓正跨過灌木缺口：尾羽仍在結莓果的灌木一側，身體橫越缺口，雙腳正落向外緣低枝，短喙攜著咬開莓果 ×1，果肉內可見籽；一側翅膀向後展開標出跨越方向，另一側翅尖正碰嘴角擦拭，紫紅果汁形成兩撇小鬍子；落腳枝下的大葉是明確落點，上有含莓果籽 ×3 的果汁色小便便痕 ×1；栗栗在外緣枝下指向啾啾帶來的莓果與落點，笑意憋在臉頰，把莓果籽樣本 ×1 收進小葉袋；呼呼風：未入畫；2-3 主體為「啾啾＋喙中莓果＋外緣落枝」一個大焦點、栗栗一個焦點，微小籽與小痕只作第二層證據，背景灌木降成兩側柔色塊；構圖裝置：偵探三角舞台
- 文說什麼：台詞：第二次招牌疊句與鳥帶遠莓果籽的判斷<br>台詞：啾啾害羞回應與非故意藏籽的說明<br>旁白：留下莓果籽樣本的事件
- 鉤子：—
- 選圖與提純說明：5-6 adds mustache visual detail (in illustration); 2-3 adds "Chomp!" onomatopoeia (Stacy S4 R1) + seed event; skip P05 bridge: refrain + "Pip ate berries" self-sufficient
- 匹配欄：✓

【zh-TW】
「看線索，再猜是誰！啾啾吃莓果，帶來了籽。」
「不是故意的！」籽進袋裡。

【en-US】
"Find a clue, then guess who! Pip ate berries and brought the seeds!"
"I didn't mean to!" The seed went into the satchel.

【回譯】
「找線索，猜猜誰！Pip 吃了莓果，把種子帶來了！」「我不是故意的！」種子被放進了小包裡。
【偏移標記】無

### 3-5｜P06（母版 P07）

- 圖說什麼：栗栗蹲在灌木下，神情由好笑轉為認真；左後方啾啾停在外側枝頭，嘴邊已擦淡；前景橡實帽 ×1 與淺爪痕 ×3 串成朝右方橡樹的地面路徑，栗栗一爪懸在第一道痕前、不碰亂線索；呼呼風：未入畫；構圖裝置：地面線索S形
- 文說什麼：台詞：鳥非刻意藏籽的修正判斷<br>旁白：發現橡實帽與轉追地面線索的事件
- 鉤子：—
- 選圖與提純說明：3-5 compresses deduction; 2-3 skips — P06 closes berry arc, P08 opens acorn arc with "Scritch, scratch!"
- 匹配欄：✓

【zh-TW】
「啾啾吃了莓果，不是故意藏的。」
栗栗追著橡實帽和淺淺的抓痕走。

【en-US】
"Pip ate berries — she wasn't hiding on purpose."
Hazel followed an acorn cap and shallow scratch marks.

【回譯】
「Pip 吃了莓果——她不是故意要藏的。」Hazel 跟著一個橡實殼和淺淺的抓痕走。
【偏移標記】無

### 3-5｜P07（母版 P08）

- 圖說什麼：栗栗快速刨開淺土的單一瞬間，一雙前爪把鬆土推向兩側，坑內完整橡實 ×1 露出大半；坑邊淺抓痕 ×3 與熟悉小爪印 ×1 清楚，栗栗耳朵微垂、嘴角心虛；呼呼風：未入畫；2-3 畫幅由栗栗大前爪＋淺坑證物構成一個主焦點，臉為第二焦點，背景只留少量落葉；構圖裝置：坑洞同心圓
- 文說什麼：擬聲：沙沙，栗栗快速刨開淺土<br>旁白：發現完整橡實、抓痕與熟悉爪印的事件<br>內心：與前兩站敞開落點的差異
- 鉤子：—
- 選圖與提純說明：All tiers preserve "Scritch, scratch!" onomatopoeia; 2-3 skip P07 bridge: onomatopoeia + "acorn" self-opens arc
- 匹配欄：✓

【zh-TW】
沙沙！栗栗挖開淺土。
橡實、抓痕，還有熟悉的小爪印！
「這次不一樣。」

【en-US】
Scritch, scratch! Hazel dug into the soil.
An acorn, scratch marks, and a familiar paw print!
"This one's different."

【回譯】
嘶嘶、刷刷！Hazel 在土裡挖了起來。一顆橡實、抓痕，還有一個熟悉的爪印！「這個不一樣。」
【偏移標記】無

### 3-5｜P08（母版 P09）

- 圖說什麼：呼呼風：展開1.4x，從左上捲來秋葉一小群，葉緣開始遮到淺抓痕；栗栗橫身護住坑邊痕跡，焦急張嘴，小葉袋倒轉；楓樹翅果 ×1 與莓果籽 ×1 正從袋口滑向手邊橡實 ×1，停在尚未落地相碰的頂點；2-3 主體為栗栗＋袋口樣本一群、呼呼風＋落葉一群，背景空地簡化；構圖裝置：翻袋斜切
- 文說什麼：旁白：落葉將蓋痕跡與小葉袋翻倒的事件<br>內心：證物將混在一起的著急<br>時間：樣本落地前的動作停頓
- 鉤子：動作中斷型：栗栗撲向抓痕時小葉袋翻起，兩枚樣本正滑出袋口
- 選圖與提純說明：2-3 adds "Swish!" + pounce causality (Stacy S4 R1); cliffhanger preserved across all tiers
- 匹配欄：✓

【zh-TW】
秋葉快蓋住抓痕了。
「等等！」栗栗一撲，小葉袋翻了。翅果和莓果籽往橡實旁滑——

【en-US】
Fall leaves were about to cover the scratch marks!
"Wait!" Hazel lunged — her satchel flipped. The winged seed and berry seed slid toward the acorn—

【回譯】
秋天的落葉就要蓋住抓痕了！「等一下！」Hazel 撲了過去——她的小包翻了。有翅膀的種子和莓果種子朝著橡實滑了過去——
【偏移標記】無

### 3-5｜P09（母版 P11）

- 圖說什麼：同一落葉角落的滿版第三變奏；栗栗比 P03、P06 更大，站在中心高光處，呼呼風：停風0.7x，與啾啾緊靠栗栗兩側成一個角色焦點群；前景楓樹翅果 ×1、莓果籽 ×1、橡實 ×1 與淺坑抓痕 ×3 排成放大的三角證物群；呼呼風靠翅果、啾啾靠莓果籽、栗栗靠橡實，三位表情同時亮起，栗栗尾巴圈住三角；畫內不出現迎風落點、鳥痕、遠端背景、分格或回憶影像；2-3 背景僅留落葉色面，角色群與證物群合計兩個焦點；構圖裝置：偵探三角舞台
- 文說什麼：台詞：第三次更大的招牌疊句<br>台詞：風、鳥、松鼠三種移動方式與答案不只一個的判斷<br>台詞：只有松鼠有意藏食的揭示
- 鉤子：懸念型：三個答案已揭開，栗栗卻低頭看向橡實旁那枚熟悉爪印
- 選圖與提純說明：Climax: 5-6 narrator→first-person quote (Stacy S4 R1); three-agent parallel reveal across all tiers; 2-3 maximum compression — 3-word triplet + 2-word conclusion; skip P10 bridge: P09 crisis → P11 refrain self-sufficient
- 匹配欄：✓

【zh-TW】
「看線索，再猜是誰！」
「呼呼風吹翅果。啾啾帶莓果籽。我埋了橡實。
只有我在藏！」

【en-US】
"Find a clue, then guess who!"
"Breezy blew winged seeds. Pip brought berry seeds. I buried the acorn.
Only I was hiding!"

【回譯】
「找線索，猜猜誰！」Breezy 吹來了有翅膀的種子。Pip 帶來了莓果種子。我埋了橡實。只有我是在藏東西！
【偏移標記】無

### 3-5｜P10（母版 P12）

- 圖說什麼：回到大橡樹根；栗栗一爪正把橡實 ×1 按入鬆土淺坑 ×1，另一爪落在坑旁，與舊小爪印 ×1 完全重合；她低頭瞪大眼、臉頰發熱、尾巴變成短短驚嘆號，認出是自己的印；呼呼風：停風0.7x，與啾啾緊靠在後方相視微笑；2-3 主體為栗栗＋埋橡實與爪印一群、兩位朋友一群，背景樹根乾淨；構圖裝置：爪印鏡像對照
- 文說什麼：台詞：呼呼風與啾啾未挑藏點的說明<br>台詞：栗栗認出自己爪印與不再抓壞人的轉念<br>旁白：回到起點並記住種子位置的事件
- 鉤子：—
- 選圖與提純說明：5-6 physical action + paw-on-print callback; 3-5 dialogue trio; 2-3 rhythm reduplication (Stacy S4 R1)
- 匹配欄：✓

【zh-TW】
呼呼風：「沒有特地藏。」
啾啾：「我也沒有。」
栗栗看著爪印笑了：「是我藏的！」

【en-US】
Breezy said, "I never picked a hiding spot."
Pip said, "Me neither!"
Hazel looked at the paw prints and smiled. "Those are mine!"

【回譯】
Breezy 說：「我從來沒有挑過藏的地方。」Pip 說：「我也沒有！」Hazel 看著那些爪印，笑了。「那些是我的！」
【偏移標記】輕微：zh-TW「沒有特地藏」→「沒有挑過藏的地方」語氣角度略不同；「是我藏的」→「那些是我的」從動作轉指涉

### 3-5｜P11（母版 P13）

- 圖說什麼：秋日大橡樹根的開闊全景；栗栗、啾啾與呼呼風：停風0.7x，三位緊靠成一群圍在保留原狀的淺坑 ×1 旁，小葉袋 ×1 已闔起，沒有再挖其他落處；栗栗尾巴鬆鬆環住大家，三位共同望向林間柔光；2-3 角色群夠大、坑為第二焦點，背景落葉稀疏不搶戲；背景細節層：同一隻瓢蟲鑽進樹根旁落葉縫過冬；構圖裝置：環抱圓形收束
- 文說什麼：台詞：下一個季節再查看的約定<br>旁白：保留淺坑、不挖出每顆種子的事件<br>時間：秋日結束前的等待起點
- 鉤子：—
- 選圖與提純說明：5-6 time transition + dialogue; 3-5 drops time marker; 2-3 gentle closure (Stacy S4 R1: prohibitive→gentle)
- 匹配欄：✓

【zh-TW】
栗栗把淺坑留著。
「下個季節再回來看。」三個朋友一起等春天。

【en-US】
Hazel left the pit just the way it was.
"Let's come back next season." The three friends waited for spring together.

【回譯】
Hazel 讓那個坑洞保持原樣。「我們下個季節再回來吧。」三個朋友一起等待春天。
【偏移標記】無

### 3-5｜P12（母版 P14）

- 圖說什麼：春日楓樹坡的開闊全景；低齡主體層只有一個緊靠焦點群：栗栗、啾啾與呼呼風：停風0.7x，三位佔前景大幅、共同蹲向正中央單株新芽 ×1，動作輪廓是一起回來、一起看見，栗栗微笑，尾巴先彎成溫柔問號、眼睛落在線索上；5-6 細節層：較遠處另一株新芽 ×1 靠舊楓樹翅果殼 ×1，低對比空土淺落處 ×3 融入背景，3-5／2-3 完全忽略仍讀得懂結尾；背景只留淡淡楓樹與草坡；背景細節層：過冬的瓢蟲 ×1 爬到前景新芽葉片背側，不形成新焦點；構圖裝置：開闊地平線
- 文說什麼：時間：三檔共同的下一季春日回訪<br>旁白：5-6 檔部分淺落處出芽的驗證事件<br>台詞：5-6／3-5 檔先找線索再判斷的第一人稱意願<br>旁白：3-5／2-3 檔共同回訪、看新芽與安心收束<br>旁白：三檔固定收束式
- 鉤子：—
- 選圖與提純說明：All tiers end with "And from that day on" (brand_frozen_units); 5-6 adds "Not every seed" nuance; 2-3 adds "three friends" subject (Stacy S4 R1 brand compliance); P10 page 18>14 inherent to Stacy instruction + frozen unit
- 匹配欄：✓

【zh-TW】
春天，大家看到新芽了。
「下次，我先找線索。」
後來呀，栗栗看到種子就先找線索了。

【en-US】
In spring, they all spotted a tiny green shoot!
"Next time, I'll look for clues first."
And from that day on, Hazel always looked for clues.

【回譯】
春天，他們都發現了一株小小的綠芽！「下次，我要先找線索再猜。」從那天起，Hazel 每次都會先找線索。
【偏移標記】輕微：zh-TW「先找線索」→「先找線索再猜」多半句，主旨同

## 檔位 2-3（10 頁）

### 2-3｜P01（母版 P01）

- 圖說什麼：秋日大橡樹根全貌；栗栗佔前景約三分之一，彎腰盯著鬆土淺坑 ×1，坑邊有陌生楓樹翅果 ×1，自己的橡實露出一角；她瞪圓眼、尾巴初彎成問號；呼呼風：未入畫；背景只留粗樹根與稀疏落葉，主體為栗栗＋坑邊證物兩個焦點；構圖裝置：樹根框中框
- 文說什麼：旁白：回到藏點與發現陌生翅果的事件<br>內心：神祕藏家與搶先查明的猜想
- 鉤子：—
- 選圖與提純說明：3-5 scaffolds "little wings" for P02 skip compensation + shorter question; 2-3 telegram-style exclamatory fragments
- 匹配欄：✓

【zh-TW】
栗栗的淺坑旁，多了一顆種子。有小小的翅膀！
「是誰？」

【en-US】
Strange seed! Little wings!
"Who hid it?"

【回譯】
奇怪的種子！小翅膀！「是誰藏的？」
【偏移標記】輕微：zh-TW「是誰？」→ en-US「是誰藏的？」多了「藏」字；省略「淺坑旁」場景交代（2-3 壓縮合法）

### 2-3｜P02（母版 P03）

- 圖說什麼：栗栗佔畫面中央偏下，左爪托楓樹翅果 ×1，右爪指向敞開落點 ×1，背後被掃成一線的落葉 ×1；她自信揚眉，把樣本滑入敞開的小葉袋；呼呼風：展開1.4x，氣流從楓樹端掠向坡下但不遮證物；2-3 主體以栗栗＋三項緊靠線索為一群、呼呼風為第二群，背景簡化；背景細節層：同一隻瓢蟲躲到落葉線的背風側；構圖裝置：偵探三角舞台
- 文說什麼：台詞：第一次招牌疊句與風移動翅果的判斷<br>擬聲：葉片輕響的環境聲<br>旁白：留下翅果樣本並改追風向的事件
- 鉤子：—
- 選圖與提純說明：3-5 adds clue evidence "little wings ride the wind" (Stacy S4 R1); 2-3 restores seed-carried event + bag action per Stacy S4 R1
- 匹配欄：✓

【zh-TW】
「看線索，再猜是誰！」
呼呼風吹來翅果，轉呀轉！栗栗收進小葉袋！

【en-US】
"Find a clue, then guess who!"
Breezy blew it! Spin, spin!
Into the bag!

【回譯】
「找線索，猜猜誰！」Breezy！轉呀轉！
【偏移標記】輕微：zh-TW「呼呼風吹來翅果，轉呀轉！栗栗收進小葉袋！」→ en-US 省略事件子句與收集動作，只留角色＋擬聲（E 觀察已列，裁決 ❌）

### 2-3｜P03（母版 P04）

- 圖說什麼：外緣草地的開闊單一瞬間；呼呼風：展開1.4x，形成大弧氣流，把楓樹翅果 ×1 從草尖帶起；栗栗在左下大步追向右側，眼睛發亮，問號尾巴彎得比 P01 更大；翅果、氣流與栗栗奔跑輪廓清楚，角色與動作佔主要畫幅，背景灌木只作低矮色塊；構圖裝置：旋風螺旋動線
- 文說什麼：台詞：呼呼風未選藏點的說明<br>擬聲：咻嚕，楓樹翅果被風帶起<br>旁白：栗栗跟進外緣草地的事件
- 鉤子：—
- 選圖與提純說明：All tiers preserve WHOOSH onomatopoeia; 3-5 trims disclaimer; 2-3 telegram action only
- 匹配欄：✓

【zh-TW】
「我只管吹喔！」
咻嚕！翅果飛起來。
栗栗快追！

【en-US】
"I just blow!"
WHOOSH! The seed flew up!

【回譯】
「我只是吹呀吹！」咻！種子飛起來了！
【偏移標記】輕微：省略「栗栗快追」追趕動作（2-3 字數壓縮合法）

### 2-3｜P04（母版 P06）

- 圖說什麼：啾啾以大而清楚的側面輪廓正跨過灌木缺口：尾羽仍在結莓果的灌木一側，身體橫越缺口，雙腳正落向外緣低枝，短喙攜著咬開莓果 ×1，果肉內可見籽；一側翅膀向後展開標出跨越方向，另一側翅尖正碰嘴角擦拭，紫紅果汁形成兩撇小鬍子；落腳枝下的大葉是明確落點，上有含莓果籽 ×3 的果汁色小便便痕 ×1；栗栗在外緣枝下指向啾啾帶來的莓果與落點，笑意憋在臉頰，把莓果籽樣本 ×1 收進小葉袋；呼呼風：未入畫；2-3 主體為「啾啾＋喙中莓果＋外緣落枝」一個大焦點、栗栗一個焦點，微小籽與小痕只作第二層證據，背景灌木降成兩側柔色塊；構圖裝置：偵探三角舞台
- 文說什麼：台詞：第二次招牌疊句與鳥帶遠莓果籽的判斷<br>台詞：啾啾害羞回應與非故意藏籽的說明<br>旁白：留下莓果籽樣本的事件
- 鉤子：—
- 選圖與提純說明：5-6 adds mustache visual detail (in illustration); 2-3 adds "Chomp!" onomatopoeia (Stacy S4 R1) + seed event; skip P05 bridge: refrain + "Pip ate berries" self-sufficient
- 匹配欄：✓

【zh-TW】
「看線索，再猜是誰！」
啊嗚！啾啾吃莓果，帶來小小籽。
「不是故意的！」進袋子囉！

【en-US】
"Find a clue, then guess who!"
Chomp! Pip ate berries. Seeds came too!
"Oops!"

【回譯】
「找線索，猜猜誰！」Pip 吃了莓果——種子！「哎呀！」
【偏移標記】輕微：zh-TW 有擬聲「啊嗚」，en-US 省略（copy_process 記錄因字數預算省略）；「不是故意的」→「Oops/哎呀」語氣轉換

### 2-3｜P05（母版 P08）

- 圖說什麼：栗栗快速刨開淺土的單一瞬間，一雙前爪把鬆土推向兩側，坑內完整橡實 ×1 露出大半；坑邊淺抓痕 ×3 與熟悉小爪印 ×1 清楚，栗栗耳朵微垂、嘴角心虛；呼呼風：未入畫；2-3 畫幅由栗栗大前爪＋淺坑證物構成一個主焦點，臉為第二焦點，背景只留少量落葉；構圖裝置：坑洞同心圓
- 文說什麼：擬聲：沙沙，栗栗快速刨開淺土<br>旁白：發現完整橡實、抓痕與熟悉爪印的事件<br>內心：與前兩站敞開落點的差異
- 鉤子：—
- 選圖與提純說明：All tiers preserve "Scritch, scratch!" onomatopoeia; 2-3 skip P07 bridge: onomatopoeia + "acorn" self-opens arc
- 匹配欄：✓

【zh-TW】
沙沙！淺坑裡有橡實。
小爪印！「是誰的？」

【en-US】
Scritch, scratch! An acorn!
Little paw prints! "Whose?"

【回譯】
嘶嘶、刷刷！一顆橡實！小爪印！「誰的？」
【偏移標記】無

### 2-3｜P06（母版 P09）

- 圖說什麼：呼呼風：展開1.4x，從左上捲來秋葉一小群，葉緣開始遮到淺抓痕；栗栗橫身護住坑邊痕跡，焦急張嘴，小葉袋倒轉；楓樹翅果 ×1 與莓果籽 ×1 正從袋口滑向手邊橡實 ×1，停在尚未落地相碰的頂點；2-3 主體為栗栗＋袋口樣本一群、呼呼風＋落葉一群，背景空地簡化；構圖裝置：翻袋斜切
- 文說什麼：旁白：落葉將蓋痕跡與小葉袋翻倒的事件<br>內心：證物將混在一起的著急<br>時間：樣本落地前的動作停頓
- 鉤子：動作中斷型：栗栗撲向抓痕時小葉袋翻起，兩枚樣本正滑出袋口
- 選圖與提純說明：2-3 adds "Swish!" + pounce causality (Stacy S4 R1); cliffhanger preserved across all tiers
- 匹配欄：✓

【zh-TW】
唰啦啦！落葉飛來了！
栗栗一撲——
小葉袋翻了！

【en-US】
Swish! Leaves blew in!
Hazel jumped — her bag flipped!

【回譯】
刷！葉子吹進來了！Hazel 的袋子翻了！
【偏移標記】輕微：zh-TW「栗栗一撲」動作省略（2-3 壓縮）；「唰啦啦」三音節→「Swish」單音節；「小葉袋」→「bag/袋子」詞彙簡化

### 2-3｜P07（母版 P11）

- 圖說什麼：同一落葉角落的滿版第三變奏；栗栗比 P03、P06 更大，站在中心高光處，呼呼風：停風0.7x，與啾啾緊靠栗栗兩側成一個角色焦點群；前景楓樹翅果 ×1、莓果籽 ×1、橡實 ×1 與淺坑抓痕 ×3 排成放大的三角證物群；呼呼風靠翅果、啾啾靠莓果籽、栗栗靠橡實，三位表情同時亮起，栗栗尾巴圈住三角；畫內不出現迎風落點、鳥痕、遠端背景、分格或回憶影像；2-3 背景僅留落葉色面，角色群與證物群合計兩個焦點；構圖裝置：偵探三角舞台
- 文說什麼：台詞：第三次更大的招牌疊句<br>台詞：風、鳥、松鼠三種移動方式與答案不只一個的判斷<br>台詞：只有松鼠有意藏食的揭示
- 鉤子：懸念型：三個答案已揭開，栗栗卻低頭看向橡實旁那枚熟悉爪印
- 選圖與提純說明：Climax: 5-6 narrator→first-person quote (Stacy S4 R1); three-agent parallel reveal across all tiers; 2-3 maximum compression — 3-word triplet + 2-word conclusion; skip P10 bridge: P09 crisis → P11 refrain self-sufficient
- 匹配欄：✓

【zh-TW】
「看線索，再猜是誰！」
「呼呼風吹翅果。啾啾帶小籽。我埋橡實。
只有我在藏！」

【en-US】
"Find a clue, then guess who!"
"Breezy blew. Pip ate. I hid!
Only me!"

【回譯】
「找線索，猜猜誰！」Breezy 吹。Pip 吃。我藏！只有我！
【偏移標記】輕微：zh-TW 三句各有受詞「翅果/小籽/橡實」，en-US 省略受詞為動詞三連擊（2-3 極簡壓縮）

### 2-3｜P08（母版 P12）

- 圖說什麼：回到大橡樹根；栗栗一爪正把橡實 ×1 按入鬆土淺坑 ×1，另一爪落在坑旁，與舊小爪印 ×1 完全重合；她低頭瞪大眼、臉頰發熱、尾巴變成短短驚嘆號，認出是自己的印；呼呼風：停風0.7x，與啾啾緊靠在後方相視微笑；2-3 主體為栗栗＋埋橡實與爪印一群、兩位朋友一群，背景樹根乾淨；構圖裝置：爪印鏡像對照
- 文說什麼：台詞：呼呼風與啾啾未挑藏點的說明<br>台詞：栗栗認出自己爪印與不再抓壞人的轉念<br>旁白：回到起點並記住種子位置的事件
- 鉤子：—
- 選圖與提純說明：5-6 physical action + paw-on-print callback; 3-5 dialogue trio; 2-3 rhythm reduplication (Stacy S4 R1)
- 匹配欄：✓

【zh-TW】
栗栗把橡實按呀按，按進土裡。
她看著爪印笑了：「是我藏的！」

【en-US】
Push, push! Down went the acorn.
Her prints! "Mine!"

【回譯】
Hazel 把橡實按了下去。她的爪印！「是我的！」
【偏移標記】輕微：zh-TW「按呀按，按進土裡」重複動作→ en-US「pushed down」簡化；「是我藏的」→「Mine/是我的」從動作轉指涉

### 2-3｜P09（母版 P13）

- 圖說什麼：秋日大橡樹根的開闊全景；栗栗、啾啾與呼呼風：停風0.7x，三位緊靠成一群圍在保留原狀的淺坑 ×1 旁，小葉袋 ×1 已闔起，沒有再挖其他落處；栗栗尾巴鬆鬆環住大家，三位共同望向林間柔光；2-3 角色群夠大、坑為第二焦點，背景落葉稀疏不搶戲；背景細節層：同一隻瓢蟲鑽進樹根旁落葉縫過冬；構圖裝置：環抱圓形收束
- 文說什麼：台詞：下一個季節再查看的約定<br>旁白：保留淺坑、不挖出每顆種子的事件<br>時間：秋日結束前的等待起點
- 鉤子：—
- 選圖與提純說明：5-6 time transition + dialogue; 3-5 drops time marker; 2-3 gentle closure (Stacy S4 R1: prohibitive→gentle)
- 匹配欄：✓

【zh-TW】
栗栗把淺坑留著。
三個朋友一起等春天再回來看看。

【en-US】
Hazel left the pit alone.
The three friends waited for spring.

【回譯】
不挖了。那三個朋友等待春天。
【偏移標記】輕微：zh-TW「栗栗把淺坑留著」→「No digging」語體轉換（陳述→禁止式片語）；省略「再回來看看」；加定冠詞「那」

### 2-3｜P10（母版 P14）

- 圖說什麼：春日楓樹坡的開闊全景；低齡主體層只有一個緊靠焦點群：栗栗、啾啾與呼呼風：停風0.7x，三位佔前景大幅、共同蹲向正中央單株新芽 ×1，動作輪廓是一起回來、一起看見，栗栗微笑，尾巴先彎成溫柔問號、眼睛落在線索上；5-6 細節層：較遠處另一株新芽 ×1 靠舊楓樹翅果殼 ×1，低對比空土淺落處 ×3 融入背景，3-5／2-3 完全忽略仍讀得懂結尾；背景只留淡淡楓樹與草坡；背景細節層：過冬的瓢蟲 ×1 爬到前景新芽葉片背側，不形成新焦點；構圖裝置：開闊地平線
- 文說什麼：時間：三檔共同的下一季春日回訪<br>旁白：5-6 檔部分淺落處出芽的驗證事件<br>台詞：5-6／3-5 檔先找線索再判斷的第一人稱意願<br>旁白：3-5／2-3 檔共同回訪、看新芽與安心收束<br>旁白：三檔固定收束式
- 鉤子：—
- 選圖與提純說明：All tiers end with "And from that day on" (brand_frozen_units); 5-6 adds "Not every seed" nuance; 2-3 adds "three friends" subject (Stacy S4 R1 brand compliance); P10 page 18>14 inherent to Stacy instruction + frozen unit
- 匹配欄：✓

【zh-TW】
春天，一起看小小的新芽。
後來呀，栗栗看到種子就找線索。

【en-US】
Spring! The three friends found a tiny green shoot!
And from that day on, Hazel looked for clues.

【回譯】
春天！小小的綠芽！從那天起，Hazel 都會先找線索。
【偏移標記】無

