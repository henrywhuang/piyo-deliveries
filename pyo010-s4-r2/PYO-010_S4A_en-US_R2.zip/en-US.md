<!-- piyo-text-writer 模板 v0.9 — 圖文總表 copy/{locale}.md（模式 B＝S4 locale 改編）
     章節標題、檔頭 YAML 欄位與表格欄位是機檢契約（scripts/copy_check.py），不得增刪改名。
     本檔依 2026-07-19 盲稿改編制（B0-B3）產出：B0 語感基建卡已過母語編輯快審＋編排裁定；
     B1 盲稿（未開啟任何 zh-TW 文本檔）；B2 對源校準改動逐頁記入「選圖與提純說明」欄（標【B2】）。 -->

# 圖文總表：Different Spots（different-spots / en-US）

> 模式 B＝locale 改編（S4，**改編不是翻譯**——讀設計文件後用該語言重新講一次故事；
> zh-TW 定稿是參考素材、不是對位基準）。
> 頁面選用**完全繼承** storyboard 三檔選用表（照抄進檔頭 selection，不得自選、自增、自刪）；
> 一頁一圖：每檔每頁恰用一張圖、用圖序號嚴格遞增；未用圖三欄一律填「—」。
> 文字的專屬負載＝聲音、台詞、內心、時間；不重述圖已明示的視覺事實。
> 字數瞄準目標帶中值；2-3 多頁低於帶下緣（88 字總量極緊＋電報式語體）逐頁在說明欄附理由。
>
> B0 快審裁定注記：
> ①疊句 `Spots, spots, go away!` 回聲 "Rain, rain, go away" 美式童謠——幼兒可接、可跟唸、4 字短韻。
> ②反轉 `Spots, spots — here to stay!` 與核心句押韻，功能轉折完整（藏→被看見）。
> ③擬聲組：SWISH!（唰啦 motif P03/P12）、drip, drop, drip!（滴答 P06）、crinkle, crinkle, crinkle!（沙沙沙 P08）、SNAP!（啪 P11）。
> ④角色名 Dotty／Roundy 沿用 design.md §7 提案。

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: different-spots
locale: en-US
mode: B
storyboard: content/PYO-010_different-spots/PYO-010_storyboard.md
design: content/PYO-010_different-spots/PYO-010_design.md
image_pool: 15
selection:
  "3-5": [P01, P02, P03, P05, P06, P08, P09, P10, P11, P12, P13, P14, P15]
  "2-3": [P01, P03, P06, P08, P09, P10, P12, P13, P14, P15]
commitments:
  refrain: "Spots, spots, go away!"
  ending: "And from that day on"
  onomatopoeia: [SWISH!, "drip, drop, drip!", "crinkle, crinkle, crinkle!", SNAP!]
characters: [Dotty, Roundy]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Dotty looked down at her seven pearly spots. They caught the evening sun and shimmered — not like Roundy's six neat black ones at all.<br>Nobody said a word.<br>But Dotty wanted to hide them. | 34✓ | 1 | Dotty looked down at her seven pearly spots — they shimmered in the sun.<br>Roundy's six black spots were neat and round.<br>Dotty wanted to hide hers. | 26⚠ | 1 | Dotty's spots were different.<br>Roundy was right there. | 8✓ | ✓ | R1 past tense narrator; 3-5 condensed setup; 2-3 telegraph setup【B2: condensed P01 to free budget for P03 refrain embedding, zh-TW 2-3 同策略】【S4 R1: 3-5 "didn't shine at all"→"were neat and round"（觸提案卡風險「差異≠缺陷」；中性描述對齊 5-6 "neat"；26/25 超帶 +1：三句 setup 需完整建立「點點珍珠色 vs 圓圓黑色」對比，不可砍句）】 |
| P02 | 2 | She draped three big petals over her back like a shawl.<br>"Spots, spots, go away!" she whispered.<br>Then she took one step forward. | 23✓ | 2 | She tucked three big petals over her back like a cape.<br>"Spots, spots, go away!" | 15✓ | — | — | — | ✓ | 2-3 skips; P03 image carries petal-hat result |
| P03 | 3 | SWISH!<br>The breeze flipped the petals into a big, silly flower hat!<br>Seven spots popped right back out.<br>Roundy walked right to Dotty's side, smiling. | 25✓ | 3 | SWISH!<br>The breeze flipped the petals into a flower hat!<br>Her spots popped right back out.<br>Roundy walked right to Dotty's side. | 22✓ | 2 | "Spots, spots, go away!"<br>SWISH!<br>The petals blew into a silly hat!<br>Roundy giggled. | 14✓ | ✓ | 2-3 跳接 P01→P03: refrain bridges hiding intent; SWISH + hat = result; self-sufficient ✓【B2: zh-TW 2-3 同頁嵌疊句，照搬曝光策略；替換 "Spots came back out" 交圖】【R1 QA: F07 3-5 "Her spots"限定詞; F11 三檔 "walked back"→"walked right"; F12 2-3 引號一致】【S4 R1: 2-3 P02 補 "Roundy giggled."（朋友 beat；zh 有「圓圓在旁邊笑」；分鏡文載明列）】 |
| P04 | 4 | Down by the berry brook, Dotty spotted a drop of red juice on a round leaf.<br>She reached out one little leg… | 22✓ | — | — | — | — | — | — | ✓ | 3-5/2-3 skip; P05 (3-5) bridges "found berry juice" |
| P05 | 5 | Dotty dabbed berry juice over every spot.<br>"Spots, spots, go away!" she said.<br>The juice dried. Her back got tighter… and tighter… and stickier. | 24✓ | 4 | This time, Dotty found berry juice and dabbed it over every spot.<br>"Spots, spots, go away!"<br>Her back got tighter and stickier. | 22✓ | — | — | — | ✓ | 3-5 跳接 P03→P05: "This time" bridges from petal fail; "found berry juice" bridges skipped P04; self-sufficient ✓; 2-3 skips |
| P06 | 6 | drip, drop, drip!<br>Dew washed the red right off.<br>Dotty wiped her back and stretched. Her own back actually felt… much better. | 22✓ | 5 | drip, drop, drip!<br>Dew washed the red off.<br>Dotty stretched. Her own back felt much better. | 16✓ | 3 | Sticky, sticky back!<br>drip, drop, drip!<br>All washed off!<br>Much better! | 11✓ | ✓ | 2-3 跳接 P03→P06: dew washes away; image authority; self-sufficient ✓【B2: zh-TW 不描寫鬍子→對位原則→三檔刪 mustache，改 internal "much better"（同 zh-TW "比較舒服"）】【R1 QA: F01 2-3 "Red"→"All"】【S4 R1: 5-6 "spots"→"back"（主詞邏輯：斑點不會感覺，與 3-5 統一）；補黏黏前因 "Sticky, sticky back!"（2-3 跳過莓汁頁, 純聽覺需前因橋接；zh 有「身上黏黏的」）】 |
| P07 | 7 | The sky grew dim. Dotty found a big dry leaf and a soft grass rope.<br>She tied the leaf tight around herself — back, spots, and all six legs. | 28✓ | — | — | — | — | — | — | ✓ | 3-5/2-3 skip; P08 bridges "hid inside a big dry leaf tied with grass rope" (3-5) / "hid inside a leaf" (2-3) |
| P08 | 8 | crinkle, crinkle, crinkle!<br>The leaf bundle spun in a circle.<br>"Spots, spots, go away!" she said.<br>It worked — her spots were completely hidden.<br>But Dotty looked down… and she couldn't even see her own feet. | 35✓ | 6 | Dotty hid inside a big dry leaf tied with grass rope.<br>"Spots, spots, go away!"<br>crinkle, crinkle! The leaf bundle spun.<br>She couldn't see her own feet. | 27⚠ | 4 | Dotty hid inside a leaf.<br>"Spots, spots, go away!"<br>No feet! | 11✓ | ✓ | 3-5 跳接 P06→P08: "hid inside a big dry leaf tied with grass rope" self-bridges P07; self-sufficient ✓; 3-5 above band (27/25): P07 bridge + refrain + ono + consequence all needed; 2-3 跳接 P06→P08: "hid inside a leaf" + refrain + "No feet!"; self-sufficient ✓ |
| P09 | 9 | Thin mist drifted across three paths.<br>Roundy couldn't tell which way led home.<br>One little leg hovered over the wrong turn.<br>Inside the leaf bundle, Dotty held her breath. That was the wrong way! | 34✓ | 7 | Mist covered three paths.<br>Roundy couldn't tell which way was home.<br>Inside the leaf bundle, Dotty saw her. | 18✓ | 5 | Mist came.<br>Roundy couldn't find home. | 6✓ | ✓ | 2-3 below band: crisis page, minimal text + image authority for mist/paths/wrong turn【R1 QA: F02 3-5 "find"→"tell"】【S4 R1: 刪領巾句（圖文重複）＋"saw it all"→"held her breath. That was the wrong way!"（承載擔心負載）】 |
| P10 | 10 | Dotty pushed the leaf bundle forward and held one leg steady on the rope knot.<br>"Spots, spots — here to stay!" she said, clear and sure. | 25✓ | 8 | Dotty pushed the leaf bundle forward and placed one leg on the rope knot.<br>"Spots, spots — here to stay!" | 19✓ | 6 | No more hiding!<br>"Spots, spots — here to stay!" | 8✓ | ✓ | Refrain reversal F02; 2-3 below band: reversal + declaration only, tight budget【R1 QA: F08 5-6 "placed"→"held"（搭配修正）; F10 2-3 "Dotty grabbed the rope."→"No more hiding!"（繩未在 2-3 出現, 跟隨 zh-TW 宣告策略）】 |
| P11 | 11 | Dotty pulled hard with both front legs.<br>SNAP!<br>The grass rope gave way. One corner of the dry leaf popped open. | 21✓ | 9 | SNAP!<br>Dotty pulled the grass rope hard. The dry leaf popped open — just one corner. | 15✓ | — | — | — | ✓ | 2-3 skips; P10→P12 causal chain intact (P10 refrain reversal → P12 spots emerge) |
| P12 | 12 | SWISH!<br>The evening breeze lifted the leaf and carried it away.<br>All seven pearly spots shone in the open air. | 20✓ | 10 | SWISH!<br>The breeze lifted the leaf and carried it away.<br>All seven spots shone bright. | 15✓ | 7 | SWISH!<br>Spots came out! | 4✓ | ✓ | 2-3 跳接 P10→P12: P10 established rope action; result (leaf away + spots) clear; self-sufficient ✓; 2-3 below band: extreme telegraph reveal, image carries |
| P13 | 13 | Dotty landed on a wet leaf nearby. Dew touched her spots, and the moonlight bounced off — a soft, close glow.<br>Roundy's eyes went wide. "I see you!" | 27✓ | 11 | Dotty landed on a wet leaf. Dew touched her spots — moonlight bounced off.<br>"I see you!" said Roundy. | 18✓ | 8 | Spots caught moonlight.<br>"I see you!" said Roundy. | 8✓ | ✓ | 2-3 below band: moonlight reflection + Roundy's dialogue; image carries mechanism |
| P14 | 14 | Dotty hopped to the next leaf, even closer to home. Her spots caught the moonlight once more.<br>Roundy followed the glow — one step, then another — all the way to the clover door.<br>They were home. | 35✓ | 12 | Dotty hopped to the next leaf. Her spots caught the moonlight again.<br>Roundy followed the glow all the way to the clover door. | 23✓ | 9 | Roundy followed the glow.<br>Step, step.<br>Home! | 7✓ | ✓ | 2-3 below band: "followed the glow" + "Home!" = telegraph climax【S4 R1: 補步伐重複拍 "Step, step."（zh「一步，一步」；2-3 檔位重複句式特徵，服務 STORY_SEQUENCING）】 |
| P15 | 15 | And from that day on, Dotty danced in the evening breeze with all seven spots shining.<br>No one to guide. Nothing to hide.<br>Roundy danced right beside her. | 28✓ | 13 | And from that day on, Dotty danced with all seven spots shining.<br>Roundy danced right beside her. | 17✓ | 10 | And from that day on, Dotty danced with her spots.<br>Roundy danced beside her. | 14✓ | ✓ | Brand frozen unit "And from that day on" exempt max_sentence_len; 5-6 adds rhyme pair ("No one to guide. Nothing to hide."); 2-3 distills to core |
