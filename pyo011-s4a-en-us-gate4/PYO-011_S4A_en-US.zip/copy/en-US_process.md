# Mode B Process Record: en-US（PYO-011 your-turn-my-turn）

## 折計預算表（B1 起草前驗算）

### en-US 硬上限（spec YAML）

| 檔位 | max_page_len | max_total_len | max_sentence_len |
|---|---|---|---|
| 5-6 | 60 | 505 | 24 |
| 3-5 | 46 | 389 | 18 |
| 2-3 | 14 | 88 | 8 |

### 疊句重複折計

疊句核心句："Your turn, my turn!" = 4 words
出現次數：4（P09, P10, P11, P12）
repeat_discount = 0.25

| 出現 | 原始 | 折計後 |
|---|---|---|
| 第 1 次 (P09) | 4 | 4 |
| 第 2 次 (P10) | 4 | 1 |
| 第 3 次 (P11) | 4 | 1 |
| 第 4 次 (P12) | 4 | 1 |
| 合計 | 16 | 7 |
| 折計節省 | — | 9 words |

### 擬聲固定重複折計

無設計性遞進系列（此書擬聲詞均為固定形式，無字母遞進）。
"creak, creak" 出現多次但非逐字相同行（有 "creak, creak!" vs "Creak… creak…" 等變體），不適用 repeat_discount。
"shh, shh, shh" 出現 2-3 次，第 2 次起折計：節省 ≈ 2-3 words。

### 預算驗算

| 檔位 | 頁數 | 估計原始總字數 | 疊句折計節省 | 調整後總字數 | max_total_len | 餘裕 |
|---|---|---|---|---|---|---|
| 5-6 | 12 | ~407 | -9 | ~398 | 505 | ~107 ✓ |
| 3-5 | 10 | ~234 | -9 | ~225 | 389 | ~164 ✓ |
| 2-3 | 9 | ~97 | -9 | ~88 | 88 | ~0 ⚠ 極限 |

### 2-3 特別預算策略

2-3 檔預算極度緊張（餘裕接近 0）。策略：
- 每頁控制在 10-13 words（留 1-2 word 緩衝於含疊句的頁面）
- P04 接受 9 words（⚠ 低於 target 下緣 10，但 "Stuck!" 電報式足夠承載喜劇負載）
- 疊句頁（P09-P12）每頁含 4 words 疊句 → 非疊句部分控制在 6-9 words
- P08 橋接句 "Dash walked to the sandbox." 為場景銜接，佔 5 words

## B0 快審結果

**PASS**（母語編輯一輪通過，無修改建議）

- 疊句 "Your turn, my turn!" — PASS（trochaic 雙拍 playground chant 天然節奏；P11 meaning reversal = genuine picture book craft）
- 擬聲詞凍結表 — PASS（ZIP!/shh,shh,shh/creak,creak/CREEAK! 全部原生；"waddled" 動詞融入 = 正確決策）
- 角色口癖卡 — PASS（Dash 短促 vs Waddle 完整句式對比鮮明、零翻譯腔）
- 收束式 — PASS（brand frozen formula 正確使用；"sang their song" 動詞選擇精準）

B0 機檢 probe: locale_lint --pages-file 凍結字串 --locale en-US --band 5-6 → ✅ 無違規

## 讀序聲明

B1 盲稿期間未開啟任何 zh-TW 文本檔（`text/zh-TW/*.json`、`copy/zh-TW.md`）。
盲稿材料來源：design.md + storyboard.md「文說什麼」欄 + en-US spec + B0 語感基建卡。
