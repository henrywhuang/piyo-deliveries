# QA 報告：PYO-005 a-little-light-in-the-dark / en-US（Round 2 復核輪）

```yaml
schema: piyo_text_qa_report/v0.9
slug: a-little-light-in-the-dark
locale: en-US
tiers: ["5-6", "3-5", "2-3"]
round: 2
date: "2026-07-29"
step1_lint: {exit_code: 0, warnings: 0}
step2_checklist: {pass: 57, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 7, 朗讀口感: 7, 孩子抓得住度: 8}
  - id: en-US-parent
    scores: {睡前適讀性: 7, 零說教: 7}
  - id: en-US-editor
    scores: {母語自然度: 9, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 2}
verdict: escalated
```

**復核輪性質聲明**：本輪為 Round 1 的復核輪（v0.14 復核輪資格：R1 ✅ 全數 ∈ {字串級}）。人設不重跑，分數沿用 R1 標註。

## STEP 1 機檢

三檔 locale_lint 重跑全過（exit 0）：

- 5-6: total 421→415.75w（repeat discount），P12 31→32w（F1 fix +1w），all under limits
- 3-5: total 212→206.75w，P08 14→15w（F2 +1w），P09 18→19w（F10 +1w），P06 16w（F6 ±0），all under limits
- 2-3: total 91→85.75w，P08 7→6w（F13 -1w），all under limits

copy_check.py exit 0（7 筆 pre-existing 警告不變）。

## STEP 2 checklist 自檢

**E-lite 復核**（主 session 合併審查制，v0.15）：受修頁＋相鄰頁逐一覆核。

主題錨復述：本書教孩子透過身體訊號認識恐懼，經三夜漸進暴露發現勇氣來自內在——石頭不亮了但我不怕了。

### 逐筆回修落地驗證

| # | 頁/檔 | R1 裁決 | 落地內容 | draft↔copy 同源 | 鄰頁影響 | 結果 |
|---|---|---|---|---|---|---|
| F1 | P12 5-6 | "cool and nice"→ sensory | "cool against his quills" 32w✓ | ✅ | P11/P13 無 | ✅ |
| F2 | P08 3-5 | bare noun → possessive | "His hand didn't squeeze tight" 15w✓ | ✅ | P07/P09 無 | ✅ |
| F6 | P06 3-5 | 缺受詞 → intransitive | "A cricket, singing." 16w✓ | ✅ | P05/P07 無 | ✅ |
| F10 | P09 3-5 | bare noun → possessive | "his hand not squeezing" 19w✓ | ✅ | P08/P10 無 | ✅ |
| F13 | P08 2-3 | 抽象詞 → 具象 | "Tiny glow." 6w✓ | ✅ | P07/P09 無 | ✅ |

5/5 落地正確，0 新問題。

### 受修頁回譯同步

P12 5-6、P08 2-3 回譯已更新（F2/F6/F10 的 possessive/"singing" 在中文回譯中無語義變化，無需更新）。

## STEP 3 人設 blind QA

復核輪不重跑人設。分數沿用 R1：

| 人設 | 維度 | 報告值 |
|---|---|---|
| en-US-teacher | 年齡適配度 / 朗讀口感 / 孩子抓得住度 | 7 / 7 / 8 |
| en-US-parent | 睡前適讀性 / 零說教 | 7 / 7 |
| en-US-editor | 母語自然度 / 文字工藝 | 9 / 8 |

## STEP 4 三分法分診

復核輪分診：R1 的 5 筆 ✅ 全數落地＝real 清零。R1 的 6 筆 ❌ 不重議。R1 的 2 筆 ⏸️ 原樣保留待 Stacy 裁決。

本輪新 ✅=0, 新 ❌=0, ⏸️=2（R1 carry）

### ⏸️ 上呈批次（en-US, PYO-005）——沿用 R1

| 發現 | 頁 | 說明 | 裁決傾向 |
|---|---|---|---|
| F3 | P10 5-6 | style_guide 3.4 超規律平行 vs storyboard 設計列舉；單訊源 | lean ✅（溫和語法變化） |
| F8 | P01 2-3 | spec R3 said-tag vs R7 標籤式＋字數極限；2路收斂 | lean ❌（保留冒號） |

**Verdict: `escalated`**（⏸️=2 待 Stacy 裁決）
