# 關卡WB整合審閱：黑夜裡的小燈（E 對位底稿／en-US）

- 生成時間：2026-07-29 19:21:48 +0800
- 書目錄：`content/PYO-005_a-little-light-in-the-dark`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate WB`（決定性腳本，純解析＋排版）
- locale：en-US
- 用途：E 主審與裁決 agent 的單檔輸入 bundle——文字＝QA 對象本體逐字轉錄；可疑頁保留開原檔抽驗權

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-005_storyboard.md` | 2026-07-28 19:48:01 |
| copy | `copy/en-US.md` | 2026-07-29 19:14:54 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-29 17:37:01 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-29 19:03:40 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-29 17:37:01 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-29 19:04:53 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-29 17:37:01 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-29 19:13:40 |
| qa/en-US/backtranslation.md | （缺） | — |

## 檔頭 commitments 逐字轉錄（兌現比對用）

```yaml
schema: piyo_copy/v0.9
slug: a-little-light-in-the-dark
locale: en-US
mode: B
storyboard: content/PYO-005_a-little-light-in-the-dark/PYO-005_storyboard.md
design: content/PYO-005_a-little-light-in-the-dark/PYO-005_design.md
image_pool: 13
selection:
  "3-5": [P01, P02, P03, P04, P05, P06, P07, P08, P09, P10, P11, P13]
  "2-3": [P01, P02, P03, P04, P05, P07, P08, P09, P11, P13]
commitments:
  refrain: "Little light, little light, shine so bright!"
  ending: "And from that day on"
  onomatopoeia: [FWIP!, fwoom, "chirp, chirp", "rustle, rustle", whoooosh]
characters: [Dot, Mama, Coo]
```

## 檔位 5-6（13 頁）

### 5-6｜P01（母版 P01）

- 圖說什麼：晴天午後開闊草地，蝴蝶和果子散落一地。天邊暖金褪成橙紫，影子拉得好長。草地中央，圓滾滾的淺棕色小刺蝟點點，刺全豎直、整隻縮成一顆球。咕咕的小身影正飛向遠方森林。
- 文說什麼：敘述白天場景與咕咕邀約台詞，刺豎起的『刷』和縮成球的恐懼反應
- 鉤子：懸念型：點點突然刺全豎縮成球，什麼事這麼可怕？
- 選圖與提純說明：5-6: full scene + Coo invitation + cognitive gap (hedgehogs = nocturnal). 3-5: trimmed invitation. 2-3: telegram — action + invite + FWIP, picture carries emotional coloring.
- 匹配欄：✓

【zh-TW】
點點追蝴蝶，開心得不得了。
咕咕飛過來：「晚上來玩嘛——刺蝟不是晚上才出來嗎？」
太陽往下掉了。
刷——
點點縮成一顆球。

【en-US】
Dot chased butterflies — so, so happy!
Coo flapped by. "Come find me tonight! You hedgehogs come out at night, right?"
The sun slipped down… shadows got longer…
FWIP! Dot curled into a tight little ball.

### 5-6｜P02（母版 P02）

- 圖說什麼：暖色小房間，媽媽把縮成球的點點抱在懷裡，從圍裙大口袋掏出一顆圓滾滾的小石頭遞到點點手心。點點刺還豎著，大眼睛盯住石頭。
- 文說什麼：媽媽簡短台詞交代石頭功能，石頭亮起的『噗』
- 鉤子：視覺引導型：石頭第一次發出暖光，它有什麼祕密？
- 選圖與提純說明：5-6: apron pocket detail + scooping action. 3-5: condensed. 2-3: telegram — fwoom alone conveys the glow.
- 匹配欄：✓

【zh-TW】
媽媽把點點抱在懷裡，從圍裙口袋掏出一顆小石頭。
「怕黑的時候，握緊它。」
點點握緊——
噗！
石頭亮了。

【en-US】
Mama scooped up the prickly little ball and carried him inside.
She reached into her big apron pocket and pulled out a round, smooth stone.
"When you're scared," Mama said, "hold on tight."
Dot squeezed — fwoom! The stone glowed.

### 5-6｜P03（母版 P03）

- 圖說什麼：關燈的房間，牆上映出一個尖尖會動的大影子。點點整個縮緊，雙手把石頭握得死死的。石頭綻放明亮橘光照亮半個房間，點點的刺全部豎直。
- 文說什麼：疊句第一次，恐懼場景短句加速節奏
- 鉤子：懸念型：石頭照亮了半個房間，但牆上那個大影子到底是什麼？
- 選圖與提純說明：Refrain #1. Ends on refrain —翻頁 hook: what is the shadow? P04 reveals.
- 匹配欄：✓

【zh-TW】
關燈了。
牆上有一個大影子！
點點把石頭握得死死的。
「小燈小燈，亮起來！」

【en-US】
Lights off.
A big shadow on the wall!
Dot squeezed the stone tight tight tight —
"Little light, little light, shine so bright!"

### 5-6｜P04（母版 P04）

- 圖說什麼：橘色光下，大影子的真面目——點點自己豎起的刺加上飄動的窗簾。刺一根根慢慢貼回去，瞇眼帶笑。手指偷偷鬆開了一點點，窗外夜風吹動窗簾。
- 文說什麼：揭曉影子真相的敘述句，手指鬆開和夜風的身體感受
- 鉤子：視覺引導型：手指鬆了、夜風吹進來涼涼的，點點踏出第一步了
- 選圖與提純說明：Shadow reveal + body relaxation. 5-6: curtain + breeze per zh-TW. 3-5: trimmed to quills + body. 2-3: telegram.
- 匹配欄：✓

【zh-TW】
石頭一亮——原來是自己的刺和窗簾呀！
點點的刺慢慢貼回去。
手指頭偷偷鬆開了一點點。
風溜進來，涼涼的。

【en-US】
The stone lit up — just Dot's own quills sticking straight up, and the curtain fluttering!
His quills settled down, one by one. His fingers loosened, just a tiny bit.
A cool breeze drifted in through the window.

### 5-6｜P05（母版 P05）

- 圖說什麼：夜晚花園，灌木叢裡沙沙響，草地上晃過一團黑影。點點握著石頭——沒上次那麼緊。石頭亮起來了，光比房間裡弱了些。刺半豎著。
- 文說什麼：蟋蟀的『唧唧』與草叢的『沙沙』，疊句第二次
- 鉤子：懸念型：光比上次弱了，灌木叢裡的黑影到底是什麼？
- 選圖與提純說明：Refrain #2. 2-3: "Night." + picture change bridges time; "Gone!" bridges P06 skip (zh-TW 2-3 has 「不見了！」).
- 匹配欄：✓

【zh-TW】
隔天晚上，點點帶著石頭走到花園。
唧唧、沙沙——到處都在響！
草叢一晃——有個黑影！
「小燈小燈，亮起來！」

【en-US】
The next night, Dot carried the stone to the garden.
chirp, chirp — rustle, rustle — sounds everywhere!
The bushes shook — a shadow!
"Little light, little light, shine so bright!"

### 5-6｜P06（母版 P06）

- 圖說什麼：石頭光照出去——蟋蟀在草葉上拉琴，露珠掛在蜘蛛網上閃閃發亮，一隻螢火蟲慢慢飄過點點鼻子前面。點點的手不知不覺垂到身側，石頭只靠指尖碰著。
- 文說什麼：逐一描述花園夜景發現的事件句，觀察手部動作的敘述
- 鉤子：視覺引導型：手垂到身側石頭快要放開了，下一個晚上呢？
- 選圖與提純說明：5-6: violin metaphor + concert + hand observation. 3-5: trimmed metaphors. 2-3: skipped.
- 匹配欄：✓

【zh-TW】
蟋蟀在拉琴。
螢火蟲飄過鼻子前面。
花園的夜晚呀，好像一場音樂會。
點點的手不知不覺垂到了身邊。

【en-US】
A cricket was playing its tiny violin on a blade of grass. A firefly drifted slowly past Dot's nose.
The garden at night was like a tiny little concert.
Dot's hand dropped to his side, and he didn't even notice.

### 5-6｜P07（母版 P07）

- 圖說什麼：森林邊小徑口，高大樹影遮住整片天空，裡頭黑漆漆看不見底。小小的點點站在邊邊，石頭握在手心，一隻腳踏出去、另一隻還釘在原地。
- 文說什麼：回扣咕咕邀請點出第三個晚上，猶豫蓄勢的短句
- 鉤子：懸念型：一腳踏出去又縮回來，點點會不會真的走進森林？
- 選圖與提純說明：Hook page — will Dot enter? 2-3: "Forest." + picture carries setting; minimal hesitation beat.
- 匹配欄：✓

【zh-TW】
第三個晚上。
咕咕說過：「來找我玩！」
點點站在森林邊邊，一隻腳踏出去……
又縮回來。

【en-US】
Night three.
Coo lived in the forest — "Come find me!" he'd said.
Dot stood at the very edge. One foot out… pulled right back.

### 5-6｜P08（母版 P08）

- 圖說什麼：點點的手伸向口袋裡的石頭——可是手沒有像以前那樣自己捏緊。石頭只冒出一丁點微光，像快要睡著的螢火蟲。四周樹影搖搖晃晃。
- 文說什麼：落葉的『沙——沙——』，石頭微光和手沒握緊的敘述
- 鉤子：懸念型：石頭快要熄了而手卻沒握緊，接下來怎麼辦？
- 選圖與提純說明：Crisis — stone fading, hand not gripping. 2-3: stripped to action + stone.
- 匹配欄：✓

【zh-TW】
深吸一口氣——踏進去了。
沙——沙——
點點伸手要握石頭——
手，沒有自己捏緊。
石頭只冒出一丁點微光。

【en-US】
Deep breath — stepped in.
rustle, rustle.
Dot reached for the stone — but his hand… didn't squeeze tight. Not like before.
The stone gave off the tiniest flicker.

### 5-6｜P09（母版 P09）

- 圖說什麼：點點停下來，低頭看自己的手——沒有握緊，手指鬆鬆的。刺也平平的。石頭安靜躺在掌心，沒有亮。點點沒有回頭。
- 文說什麼：自我覺察的身體發現句，疊句第三次變奏，「沒有回頭」的關鍵動作句
- 鉤子：視覺引導型：石頭沒亮但點點沒有回頭，前方會有什麼？
- 選圖與提純說明：Climax — self-awareness. Refrain #3 variation (whispered, period). 5-6: full body discovery chain (hand + quills + heart). 2-3: opens directly with refrain attempt; hand observation carried from P08.
- 匹配欄：✓

【zh-TW】
點點停下來。
低頭看自己的手——沒有握緊耶。
心跳呢？也沒有很快。
「小燈小燈…… 亮起來。」
石頭沒有亮。
但是點點，沒有回頭。

【en-US】
Dot stopped.
He looked down at his hand — it wasn't squeezing. Fingers loose.
His quills? Flat. His heart? Not even racing.
"Little light, little light… shine so bright."
The stone didn't glow.
But Dot didn't turn back.

### 5-6｜P10（母版 P10）

- 圖說什麼：黑暗中眼睛慢慢適應了。螢火蟲一閃一閃飄在半空，星光從葉縫灑下來，腳邊小蘑菇發著微微綠光。森林小路上到處都是小小的、亮亮的光。
- 文說什麼：逐一描述眼睛適應後看見的各種自然光源
- 鉤子：視覺引導型：森林裡到處是光，咕咕一定就在前面
- 選圖與提純說明：5-6: three light sources. 3-5: compressed to fireflies + summary. 2-3: skipped.
- 匹配欄：✓

【zh-TW】
眼睛慢慢習慣了。
螢火蟲一閃一閃。
葉縫灑下星光。
小蘑菇發著綠光。
到處都是小小的、亮亮的光。

【en-US】
Dot's eyes got used to the dark.
Fireflies, blinking in the air. Starlight, dripping through the leaves. Tiny mushrooms, glowing green.
The forest path was full of little lights. Everywhere.

### 5-6｜P11（母版 P11）

- 圖說什麼：大樹下，毛茸茸的咕咕歪著圓腦袋蹲在樹枝上，金色大眼睛眨呀眨。點點站在樹下掏出暗暗的石頭，笑得瞇起眼睛。月亮從樹梢後慢慢爬上來。
- 文說什麼：咕咕與點點的對話台詞，月亮升起的時間句
- 鉤子：視覺引導型：月亮爬上了樹梢，夜晚正美好
- 選圖與提純說明：Friend reunion + payoff. 5-6: moon time sentence + play invitation. 3-5: core payoff dialogue. 2-3: shortest payoff — "alone" captures zh-TW 自己走來.
- 匹配欄：✓

【zh-TW】
咕咕：「你自己走過來的？」
點點笑了：「石頭不亮了——可是我不怕了。」
咕咕：「那我們玩嘛！」
月亮爬上了樹梢。

【en-US】
"You came all by yourself?"
Dot smiled. "The stone stopped glowing… but I stopped being scared."
"Then let's play!"
The moon slowly climbed above the treetops.

### 5-6｜P12（母版 P12）

- 圖說什麼：月光照著小路，小小的點點搖搖晃晃往家走。花園口，媽媽的身影在等著。媽媽笑笑摸摸點點的刺——一根都沒有豎起來。石頭在口袋裡晃呀晃。
- 文說什麼：歸途動作描寫和夜風的『呼——』，媽媽等候與摸刺的動作句
- 鉤子：視覺引導型：家的方向透出暖暖的光
- 選圖與提純說明：5-6 only: breathing page — moonlit return, Mama waiting, quills flat.
- 匹配欄：✓

【zh-TW】
點點搖搖晃晃往家走。
呼——
夜風涼涼的，好舒服。
媽媽在花園口等著，摸摸他的刺——
一根都沒有豎起來。

【en-US】
Dot wobbled all the way home.
whoooosh — the night breeze, cool and nice.
Mama was waiting by the garden gate. She patted his quills — not a single one was standing up.

### 5-6｜P13（母版 P13）

- 圖說什麼：暖暖的小床上，點點側身伸手碰了碰床頭那顆小石頭，石頭微微亮了一下。刺軟軟貼平，眼睛瞇著笑。門口透進一道窄窄的暖光——是媽媽輕輕把門帶上。
- 文說什麼：石頭握一握亮一下的動作句，媽媽關門描寫，固定收束語
- 鉤子：—
- 選圖與提純說明：Closing: ending formula + stone + sleep. 5-6 P13 over band top (44>40): ending page carries four-piece formula per style_guide, zh-TW mandated — cannot split without losing closing rhythm.
- 匹配欄：✓

【zh-TW】
後來呀，小石頭還在床頭。
點點伸手握一握——
噗！亮了一下下。
媽媽輕輕把門帶上了。
點點翻個身，睡著了。

【en-US】
And from that day on, Dot's little stone sat right there on the bedside table.
Sometimes, he'd reach over and give it a squeeze — fwoom! It glowed, just for a moment.
Mama gently pulled the door shut.
Dot rolled over, and fell fast asleep.

## 檔位 3-5（12 頁）

### 3-5｜P01（母版 P01）

- 圖說什麼：晴天午後開闊草地，蝴蝶和果子散落一地。天邊暖金褪成橙紫，影子拉得好長。草地中央，圓滾滾的淺棕色小刺蝟點點，刺全豎直、整隻縮成一顆球。咕咕的小身影正飛向遠方森林。
- 文說什麼：敘述白天場景與咕咕邀約台詞，刺豎起的『刷』和縮成球的恐懼反應
- 鉤子：懸念型：點點突然刺全豎縮成球，什麼事這麼可怕？
- 選圖與提純說明：5-6: full scene + Coo invitation + cognitive gap (hedgehogs = nocturnal). 3-5: trimmed invitation. 2-3: telegram — action + invite + FWIP, picture carries emotional coloring.
- 匹配欄：✓

【zh-TW】
點點追蝴蝶，好開心！
咕咕：「晚上來玩喔！」
天黑了。
刷——
點點縮成球。

【en-US】
Dot chased butterflies — so happy!
Coo flapped by. "Come play tonight!"
Sun went down.
FWIP! Dot curled into a ball.

### 3-5｜P02（母版 P02）

- 圖說什麼：暖色小房間，媽媽把縮成球的點點抱在懷裡，從圍裙大口袋掏出一顆圓滾滾的小石頭遞到點點手心。點點刺還豎著，大眼睛盯住石頭。
- 文說什麼：媽媽簡短台詞交代石頭功能，石頭亮起的『噗』
- 鉤子：視覺引導型：石頭第一次發出暖光，它有什麼祕密？
- 選圖與提純說明：5-6: apron pocket detail + scooping action. 3-5: condensed. 2-3: telegram — fwoom alone conveys the glow.
- 匹配欄：✓

【zh-TW】
媽媽拿出小石頭。
「怕黑的時候，握緊它。」
點點握緊——噗！
石頭亮了。

【en-US】
Mama pulled out a little stone.
"When you're scared, hold on tight."
Dot squeezed — fwoom! The stone glowed.

### 3-5｜P03（母版 P03）

- 圖說什麼：關燈的房間，牆上映出一個尖尖會動的大影子。點點整個縮緊，雙手把石頭握得死死的。石頭綻放明亮橘光照亮半個房間，點點的刺全部豎直。
- 文說什麼：疊句第一次，恐懼場景短句加速節奏
- 鉤子：懸念型：石頭照亮了半個房間，但牆上那個大影子到底是什麼？
- 選圖與提純說明：Refrain #1. Ends on refrain —翻頁 hook: what is the shadow? P04 reveals.
- 匹配欄：✓

【zh-TW】
關燈了。
牆上有大影子！
點點把石頭握好緊。
「小燈小燈，亮起來！」

【en-US】
Lights off.
Big shadow on the wall!
Dot squeezed tight tight tight.
"Little light, little light, shine so bright!"

### 3-5｜P04（母版 P04）

- 圖說什麼：橘色光下，大影子的真面目——點點自己豎起的刺加上飄動的窗簾。刺一根根慢慢貼回去，瞇眼帶笑。手指偷偷鬆開了一點點，窗外夜風吹動窗簾。
- 文說什麼：揭曉影子真相的敘述句，手指鬆開和夜風的身體感受
- 鉤子：視覺引導型：手指鬆了、夜風吹進來涼涼的，點點踏出第一步了
- 選圖與提純說明：Shadow reveal + body relaxation. 5-6: curtain + breeze per zh-TW. 3-5: trimmed to quills + body. 2-3: telegram.
- 匹配欄：✓

【zh-TW】
石頭一亮——是自己的刺呀！
刺慢慢貼回去。
手指頭鬆了一點點。

【en-US】
The stone lit up — just Dot's own quills!
Quills settled down. Fingers loosened, just a tiny bit.

### 3-5｜P05（母版 P05）

- 圖說什麼：夜晚花園，灌木叢裡沙沙響，草地上晃過一團黑影。點點握著石頭——沒上次那麼緊。石頭亮起來了，光比房間裡弱了些。刺半豎著。
- 文說什麼：蟋蟀的『唧唧』與草叢的『沙沙』，疊句第二次
- 鉤子：懸念型：光比上次弱了，灌木叢裡的黑影到底是什麼？
- 選圖與提純說明：Refrain #2. 2-3: "Night." + picture change bridges time; "Gone!" bridges P06 skip (zh-TW 2-3 has 「不見了！」).
- 匹配欄：✓

【zh-TW】
隔天晚上，花園裡到處響。
唧唧、沙沙——有黑影！
「小燈小燈，亮起來！」

【en-US】
Next night, the garden was full of sounds.
chirp, chirp — rustle, rustle — a shadow!
"Little light, little light, shine so bright!"

### 3-5｜P06（母版 P06）

- 圖說什麼：石頭光照出去——蟋蟀在草葉上拉琴，露珠掛在蜘蛛網上閃閃發亮，一隻螢火蟲慢慢飄過點點鼻子前面。點點的手不知不覺垂到身側，石頭只靠指尖碰著。
- 文說什麼：逐一描述花園夜景發現的事件句，觀察手部動作的敘述
- 鉤子：視覺引導型：手垂到身側石頭快要放開了，下一個晚上呢？
- 選圖與提純說明：5-6: violin metaphor + concert + hand observation. 3-5: trimmed metaphors. 2-3: skipped.
- 匹配欄：✓

【zh-TW】
蟋蟀在拉琴。螢火蟲飄過鼻子。
點點的手慢慢垂下來了。

【en-US】
A cricket, playing. A firefly drifted past Dot's nose.
Dot's hand slowly dropped to his side.

### 3-5｜P07（母版 P07）

- 圖說什麼：森林邊小徑口，高大樹影遮住整片天空，裡頭黑漆漆看不見底。小小的點點站在邊邊，石頭握在手心，一隻腳踏出去、另一隻還釘在原地。
- 文說什麼：回扣咕咕邀請點出第三個晚上，猶豫蓄勢的短句
- 鉤子：懸念型：一腳踏出去又縮回來，點點會不會真的走進森林？
- 選圖與提純說明：Hook page — will Dot enter? 2-3: "Forest." + picture carries setting; minimal hesitation beat.
- 匹配欄：✓

【zh-TW】
第三個晚上。森林邊邊。
咕咕說過：「來找我玩！」
踏出去…… 又縮回來。

【en-US】
Night three. Edge of the forest.
"Come find me!" Coo had said.
One foot out… pulled right back.

### 3-5｜P08（母版 P08）

- 圖說什麼：點點的手伸向口袋裡的石頭——可是手沒有像以前那樣自己捏緊。石頭只冒出一丁點微光，像快要睡著的螢火蟲。四周樹影搖搖晃晃。
- 文說什麼：落葉的『沙——沙——』，石頭微光和手沒握緊的敘述
- 鉤子：懸念型：石頭快要熄了而手卻沒握緊，接下來怎麼辦？
- 選圖與提純說明：Crisis — stone fading, hand not gripping. 2-3: stripped to action + stone.
- 匹配欄：✓

【zh-TW】
深吸一口氣——踏進去了。
沙——沙——
石頭只亮一點點。
手沒有握緊。

【en-US】
Deep breath — stepped in.
rustle, rustle.
The stone flickered, barely. Hand didn't squeeze tight.

### 3-5｜P09（母版 P09）

- 圖說什麼：點點停下來，低頭看自己的手——沒有握緊，手指鬆鬆的。刺也平平的。石頭安靜躺在掌心，沒有亮。點點沒有回頭。
- 文說什麼：自我覺察的身體發現句，疊句第三次變奏，「沒有回頭」的關鍵動作句
- 鉤子：視覺引導型：石頭沒亮但點點沒有回頭，前方會有什麼？
- 選圖與提純說明：Climax — self-awareness. Refrain #3 variation (whispered, period). 5-6: full body discovery chain (hand + quills + heart). 2-3: opens directly with refrain attempt; hand observation carried from P08.
- 匹配欄：✓

【zh-TW】
低頭看——手沒有握緊。
「小燈小燈…… 亮起來。」
石頭沒有亮。
沒有回頭。

【en-US】
Looked down — hand not squeezing.
"Little light, little light… shine so bright."
Stone didn't glow.
Didn't turn back.

### 3-5｜P10（母版 P10）

- 圖說什麼：黑暗中眼睛慢慢適應了。螢火蟲一閃一閃飄在半空，星光從葉縫灑下來，腳邊小蘑菇發著微微綠光。森林小路上到處都是小小的、亮亮的光。
- 文說什麼：逐一描述眼睛適應後看見的各種自然光源
- 鉤子：視覺引導型：森林裡到處是光，咕咕一定就在前面
- 選圖與提純說明：5-6: three light sources. 3-5: compressed to fireflies + summary. 2-3: skipped.
- 匹配欄：✓

【zh-TW】
眼睛慢慢習慣了。
螢火蟲一閃一閃。
到處都是小小的、亮亮的光。

【en-US】
Eyes got used to the dark.
Fireflies, blinking.
Little lights, everywhere.

### 3-5｜P11（母版 P11）

- 圖說什麼：大樹下，毛茸茸的咕咕歪著圓腦袋蹲在樹枝上，金色大眼睛眨呀眨。點點站在樹下掏出暗暗的石頭，笑得瞇起眼睛。月亮從樹梢後慢慢爬上來。
- 文說什麼：咕咕與點點的對話台詞，月亮升起的時間句
- 鉤子：視覺引導型：月亮爬上了樹梢，夜晚正美好
- 選圖與提純說明：Friend reunion + payoff. 5-6: moon time sentence + play invitation. 3-5: core payoff dialogue. 2-3: shortest payoff — "alone" captures zh-TW 自己走來.
- 匹配欄：✓

【zh-TW】
咕咕：「你自己走來的？」
點點笑了：「石頭不亮了——可是我不怕了！」

【en-US】
"You came by yourself?"
Dot smiled. "The stone stopped glowing… but I'm not scared anymore!"

### 3-5｜P12（母版 P13）

- 圖說什麼：暖暖的小床上，點點側身伸手碰了碰床頭那顆小石頭，石頭微微亮了一下。刺軟軟貼平，眼睛瞇著笑。門口透進一道窄窄的暖光——是媽媽輕輕把門帶上。
- 文說什麼：石頭握一握亮一下的動作句，媽媽關門描寫，固定收束語
- 鉤子：—
- 選圖與提純說明：Closing: ending formula + stone + sleep. 5-6 P13 over band top (44>40): ending page carries four-piece formula per style_guide, zh-TW mandated — cannot split without losing closing rhythm.
- 匹配欄：✓

【zh-TW】
後來呀，小石頭還在床頭。
點點握一握——噗！亮一下下。
睡著了。

【en-US】
And from that day on, the stone sat by the bed.
Dot gave it a squeeze — fwoom! Glowed, just for a moment.
Asleep.

## 檔位 2-3（10 頁）

### 2-3｜P01（母版 P01）

- 圖說什麼：晴天午後開闊草地，蝴蝶和果子散落一地。天邊暖金褪成橙紫，影子拉得好長。草地中央，圓滾滾的淺棕色小刺蝟點點，刺全豎直、整隻縮成一顆球。咕咕的小身影正飛向遠方森林。
- 文說什麼：敘述白天場景與咕咕邀約台詞，刺豎起的『刷』和縮成球的恐懼反應
- 鉤子：懸念型：點點突然刺全豎縮成球，什麼事這麼可怕？
- 選圖與提純說明：5-6: full scene + Coo invitation + cognitive gap (hedgehogs = nocturnal). 3-5: trimmed invitation. 2-3: telegram — action + invite + FWIP, picture carries emotional coloring.
- 匹配欄：✓

【zh-TW】
點點追蝴蝶。好開心！
咕咕：「晚上來玩！」
天黑了。
刷——
點點縮成球。

【en-US】
Dot chased butterflies!
Coo: "Play tonight!"
Dark. FWIP! Curled up.

### 2-3｜P02（母版 P02）

- 圖說什麼：暖色小房間，媽媽把縮成球的點點抱在懷裡，從圍裙大口袋掏出一顆圓滾滾的小石頭遞到點點手心。點點刺還豎著，大眼睛盯住石頭。
- 文說什麼：媽媽簡短台詞交代石頭功能，石頭亮起的『噗』
- 鉤子：視覺引導型：石頭第一次發出暖光，它有什麼祕密？
- 選圖與提純說明：5-6: apron pocket detail + scooping action. 3-5: condensed. 2-3: telegram — fwoom alone conveys the glow.
- 匹配欄：✓

【zh-TW】
媽媽給點點一顆小石頭。
「怕黑，握緊它。」
噗！
石頭亮了！

【en-US】
Mama held out a stone.
"Hold tight."
Fwoom!

### 2-3｜P03（母版 P03）

- 圖說什麼：關燈的房間，牆上映出一個尖尖會動的大影子。點點整個縮緊，雙手把石頭握得死死的。石頭綻放明亮橘光照亮半個房間，點點的刺全部豎直。
- 文說什麼：疊句第一次，恐懼場景短句加速節奏
- 鉤子：懸念型：石頭照亮了半個房間，但牆上那個大影子到底是什麼？
- 選圖與提純說明：Refrain #1. Ends on refrain —翻頁 hook: what is the shadow? P04 reveals.
- 匹配欄：✓

【zh-TW】
關燈了。
大影子！
「小燈小燈，亮起來！」

【en-US】
Dark! Big shadow!
"Little light, little light, shine so bright!"

### 2-3｜P04（母版 P04）

- 圖說什麼：橘色光下，大影子的真面目——點點自己豎起的刺加上飄動的窗簾。刺一根根慢慢貼回去，瞇眼帶笑。手指偷偷鬆開了一點點，窗外夜風吹動窗簾。
- 文說什麼：揭曉影子真相的敘述句，手指鬆開和夜風的身體感受
- 鉤子：視覺引導型：手指鬆了、夜風吹進來涼涼的，點點踏出第一步了
- 選圖與提純說明：Shadow reveal + body relaxation. 5-6: curtain + breeze per zh-TW. 3-5: trimmed to quills + body. 2-3: telegram.
- 匹配欄：✓

【zh-TW】
亮了——是自己的刺呀！
刺慢慢貼回去。
手指頭鬆開了。

【en-US】
Just his own quills!
Quills down. Fingers loose.

### 2-3｜P05（母版 P05）

- 圖說什麼：夜晚花園，灌木叢裡沙沙響，草地上晃過一團黑影。點點握著石頭——沒上次那麼緊。石頭亮起來了，光比房間裡弱了些。刺半豎著。
- 文說什麼：蟋蟀的『唧唧』與草叢的『沙沙』，疊句第二次
- 鉤子：懸念型：光比上次弱了，灌木叢裡的黑影到底是什麼？
- 選圖與提純說明：Refrain #2. 2-3: "Night." + picture change bridges time; "Gone!" bridges P06 skip (zh-TW 2-3 has 「不見了！」).
- 匹配欄：✓

【zh-TW】
隔天晚上。
唧唧、沙沙——有黑影！
「小燈小燈，亮起來！」
不見了！

【en-US】
Night.
chirp, chirp — shadow!
"Little light, little light, shine so bright!"
Gone!

### 2-3｜P06（母版 P07）

- 圖說什麼：森林邊小徑口，高大樹影遮住整片天空，裡頭黑漆漆看不見底。小小的點點站在邊邊，石頭握在手心，一隻腳踏出去、另一隻還釘在原地。
- 文說什麼：回扣咕咕邀請點出第三個晚上，猶豫蓄勢的短句
- 鉤子：懸念型：一腳踏出去又縮回來，點點會不會真的走進森林？
- 選圖與提純說明：Hook page — will Dot enter? 2-3: "Forest." + picture carries setting; minimal hesitation beat.
- 匹配欄：✓

【zh-TW】
第三個晚上。
點點站在森林邊邊。
踏出去…… 又縮回來。

【en-US】
Night three. Forest.
One foot out… back.

### 2-3｜P07（母版 P08）

- 圖說什麼：點點的手伸向口袋裡的石頭——可是手沒有像以前那樣自己捏緊。石頭只冒出一丁點微光，像快要睡著的螢火蟲。四周樹影搖搖晃晃。
- 文說什麼：落葉的『沙——沙——』，石頭微光和手沒握緊的敘述
- 鉤子：懸念型：石頭快要熄了而手卻沒握緊，接下來怎麼辦？
- 選圖與提純說明：Crisis — stone fading, hand not gripping. 2-3: stripped to action + stone.
- 匹配欄：✓

【zh-TW】
踏進去了！
沙——沙——
石頭不太亮了。

【en-US】
Stepped in!
rustle, rustle.
Stone barely glowed.

### 2-3｜P08（母版 P09）

- 圖說什麼：點點停下來，低頭看自己的手——沒有握緊，手指鬆鬆的。刺也平平的。石頭安靜躺在掌心，沒有亮。點點沒有回頭。
- 文說什麼：自我覺察的身體發現句，疊句第三次變奏，「沒有回頭」的關鍵動作句
- 鉤子：視覺引導型：石頭沒亮但點點沒有回頭，前方會有什麼？
- 選圖與提純說明：Climax — self-awareness. Refrain #3 variation (whispered, period). 5-6: full body discovery chain (hand + quills + heart). 2-3: opens directly with refrain attempt; hand observation carried from P08.
- 匹配欄：✓

【zh-TW】
手沒有握緊。
「小燈小燈…… 亮起來。」
石頭沒有亮。
沒有回頭。

【en-US】
"Little light, little light… shine so bright."
No glow. Walked on.

### 2-3｜P09（母版 P11）

- 圖說什麼：大樹下，毛茸茸的咕咕歪著圓腦袋蹲在樹枝上，金色大眼睛眨呀眨。點點站在樹下掏出暗暗的石頭，笑得瞇起眼睛。月亮從樹梢後慢慢爬上來。
- 文說什麼：咕咕與點點的對話台詞，月亮升起的時間句
- 鉤子：視覺引導型：月亮爬上了樹梢，夜晚正美好
- 選圖與提純說明：Friend reunion + payoff. 5-6: moon time sentence + play invitation. 3-5: core payoff dialogue. 2-3: shortest payoff — "alone" captures zh-TW 自己走來.
- 匹配欄：✓

【zh-TW】
咕咕：「你自己走來的？」
點點笑了：「不怕了！」

【en-US】
"You came alone?"
Dot smiled. "Not scared!"

### 2-3｜P10（母版 P13）

- 圖說什麼：暖暖的小床上，點點側身伸手碰了碰床頭那顆小石頭，石頭微微亮了一下。刺軟軟貼平，眼睛瞇著笑。門口透進一道窄窄的暖光——是媽媽輕輕把門帶上。
- 文說什麼：石頭握一握亮一下的動作句，媽媽關門描寫，固定收束語
- 鉤子：—
- 選圖與提純說明：Closing: ending formula + stone + sleep. 5-6 P13 over band top (44>40): ending page carries four-piece formula per style_guide, zh-TW mandated — cannot split without losing closing rhythm.
- 匹配欄：✓

【zh-TW】
後來呀，小石頭在床頭。
握一握——噗！亮一下下。
睡著了。

【en-US】
And from that day on — stone by the bed.
Squeeze, fwoom!
Asleep.

