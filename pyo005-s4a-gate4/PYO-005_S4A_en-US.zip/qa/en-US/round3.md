# QA 報告：PYO-005 a-little-light-in-the-dark / en-US（Round 3 — Stacy R1 回修）

```yaml
schema: piyo_text_qa_report/v0.9
slug: a-little-light-in-the-dark
locale: en-US
tiers: ["5-6", "3-5", "2-3"]
round: 3
date: "2026-07-30"
step1_lint: {exit_code: 1, warnings: 3}
step2_checklist: {pass: 57, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 7, 朗讀口感: 7, 孩子抓得住度: 8}
  - id: en-US-parent
    scores: {睡前適讀性: 7, 零說教: 7}
  - id: en-US-editor
    scores: {母語自然度: 9, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 2}
verdict: escalated
```

**本輪性質**：Stacy R1 修改指令回修（2026-07-29 審回，判定：不通過 — 需修改後重審）。僅落地指定修改，5-6 / 3-5 未動。

## Stacy R1 修改指令摘要

| 檔位 | 頁碼（Stacy 序號→SB 頁） | 錯型 | 修改內容 |
|---|---|---|---|
| 2-3 | P08→P09 | beat 掉落 | 原文前補 `Hand not tight.` — 還原手感知拍點於疊句前 |

Registry 補登：3 角色名 + 5 擬聲詞均已作為「提案」存在於 `character_names.md` / `onomatopoeia_map.md`（commit 0e1bdb8），無新增動作。

## STEP 1 機檢

**copy_check**: exit 0（7 筆 pre-existing 警告不變）

**locale_lint**:
- 5-6: exit 0（未動）
- 3-5: exit 0（未動）
- 2-3: **exit 1** — 1 violation, 3 warnings

2-3 詳細：

| 類型 | 內容 |
|---|---|
| ⚠ warning | P13 max_sentence_len 9 > 8（品牌凍結單元豁免：`And from that day on — stone by the bed.`） |
| ⚠ warning | repeat_discount x2（P03, P05 各 7w）第 2 次 ×0.25 |
| ⚠ warning | 折計後總量 94 → 88.75 |
| ✗ violation | **max_total_len 88.75 > 88**（超 0.75w） |

**超限分析**：P09 修改前 11w → 14w（+3w "Hand not tight."）。折計前總量 91→94；折計後 85.75→88.75。超限 0.75w 是 repeat_discount 公式的小數殘差（7w × 0.75 = 5.25w 折讓），實際新增 3w 中僅 0.75w 溢出硬上限。

**處置依據**：Stacy R1 指令「只改本表列出的內容，未列出的頁面一律不動」——無法透過縮減其他頁面消化溢出。P09 文案為 Stacy 逐字指定。此為 Stacy 指令與機檢硬上限的衝突，升級待裁決。

## STEP 2 checklist 自檢

**R1 回修落地驗證**（主 session 合併審查制）：

主題錨復述：本書教孩子透過身體訊號認識恐懼，經三夜漸進暴露發現勇氣來自內在——石頭不亮了但我不怕了。

| 指令 | 頁/檔 | 落地內容 | draft↔copy 同源 | 字數 | 結果 |
|---|---|---|---|---|---|
| R1-1 | P09 2-3 | `Hand not tight.\n"Little light, little light… shine so bright."\nNo glow. Walked on.` | ✅ | 14✓（= max_page_len） | ✅ 落地正確 |

回譯已同步更新（P09 2-3: 補回「手沒有握緊。」）。

1/1 落地正確，0 新問題。pass=57（沿用 R2，修改僅涉 1 頁），fail=0。

## STEP 3 人設 blind QA

Stacy R1 回修不重跑人設。分數沿用 R1：

| 人設 | 維度 | 報告值 |
|---|---|---|
| en-US-teacher | 年齡適配度 / 朗讀口感 / 孩子抓得住度 | 7 / 7 / 8 |
| en-US-parent | 睡前適讀性 / 零說教 | 7 / 7 |
| en-US-editor | 母語自然度 / 文字工藝 | 9 / 8 |

## STEP 4 三分法分診

R2 carry 的 ⏸️=2 項（F3, F8）+ 新增 1 項字數衝突：

| # | 頁/檔 | 說明 | 裁決 | 狀態 |
|---|---|---|---|---|
| F3 | P10 5-6 | style_guide 3.4 超規律平行 vs storyboard 設計列舉 | ⏸️ | carry（R1 未裁決） |
| F8 | P01 2-3 | spec R3 said-tag vs R7 標籤式＋字數極限 | ⏸️ | carry（R1 未裁決） |
| WC-1 | 全書 2-3 | max_total_len 88.75 > 88（+0.75w），Stacy R1 mandated change 導致 | ⏸️ | 新（Stacy 裁決） |

**Verdict: `escalated`**（⏸️=3，其中 WC-1 需 Stacy 確認接受 2-3 總量超限 0.75w 或指示進一步調整）
