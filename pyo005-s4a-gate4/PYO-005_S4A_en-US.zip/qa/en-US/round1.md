# QA 報告：PYO-005 a-little-light-in-the-dark / en-US（Round 1）

```yaml
schema: piyo_text_qa_report/v0.9
slug: a-little-light-in-the-dark
locale: en-US
tiers: ["5-6", "3-5", "2-3"]
round: 1
date: "2026-07-29"
step1_lint: {exit_code: 0, warnings: 0}
step2_checklist: {pass: 57, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 7, 朗讀口感: 7, 孩子抓得住度: 8}
  - id: en-US-parent
    scores: {睡前適讀性: 7, 零說教: 7}
  - id: en-US-editor
    scores: {母語自然度: 9, 文字工藝: 8}
step4_triage: {real: 5, rejected: 6, escalated: 2}
verdict: fix_required
```

## STEP 1 機檢

三檔 locale_lint 全過（exit 0, 0 warnings）：

- 5-6: 13 頁，total ~414.75w（repeat discount 後），max page P13=44w（under hard max 60）
- 3-5: 12 頁，total ~204.75w，all under max_page 46w
- 2-3: 10 頁，total ~86.75w（under max 88），all under max_page 14w

copy_check.py exit 0（結構＋選用＋字數＋兌現＋同源全過）。

## STEP 2 checklist 自檢

**繪本編輯 E**（Opus sub-agent，非作者）。

主題錨復述：「本書教孩子透過身體訊號（刺豎起＝害怕、手放鬆＝不怕了）認識與克服怕黑，高潮翻轉＝石頭不亮了但自己不怕了——勇氣來自內在而非外在依賴物。」

- **quality_criteria checklist**：57/57 適用項 PASS（A-E 節 ×3 檔，stage-N/A 項不計）
- **趣味設計兌現**：15/15 宣告全兌現（疊句三變奏、石頭握感七級、身體訊號暗寫、石頭翻轉 P09、結尾四件套——逐項附頁碼）
- **對位原則**：35/35 頁全過（無重述視覺事實、無圖外實體；P09 5-6 展開身體訊號鏈＝心智狀態合法）
- **concept fidelity**：3/3 檔全過（三檔帶走的都是「勇氣來自內在」訊息）
- **轉分診項**：0（無）

### 回譯偏移

回譯覆蓋 35 頁全量。偏移標記：23 無 / 12 輕微 / 0 中度。
主要輕微項：疊句在地化（小燈→little light, 亮起來→shine so bright）、結尾式在地化（後來呀→And from that day on）、P09 5-6 展開身體檢查鏈（母本僅心跳，en-US 加手指＋刺＋心跳，符合 design theme_cycles）。
無語義漂移，0 項進 STEP 4。

### ESL 獵手

- 翻譯腔 2 筆：F1 P12 5-6 "cool and nice"（calque）、F2 P08 3-5 bare noun "Hand"
- AI 機械句 1 筆：F3 P10 5-6 三連平行（borderline）
- 盲稿讀序：PASS（無翻譯順序痕跡）
- 3 筆全進 STEP 4 分診

## STEP 3 人設 blind QA

### en-US-teacher（Ms. Rivera）

| 維度 | 5-6 | 3-5 | 2-3 | 報告值 |
|---|---|---|---|---|
| 年齡適配度 | 9 | 7 | 8 | 7 |
| 朗讀口感 | 9 | 7 | 7 | 7 |
| 孩子抓得住度 | 9 | 8 | 8 | 8 |

發現：P08 3-5 bare noun ×2（中）、P01 2-3 Coo: 格式（中）、P08 3-5 inverted（低）、P06 3-5 fragment（低）、P05 2-3 "Gone!" 指涉（低）、P08 2-3 "barely"（低）、P06 5-6 "tiny little"（低）、P01 5-6 "You hedgehogs"（低）。

### en-US-parent（Jessica）

| 維度 | 5-6 | 3-5 | 2-3 | 報告值 |
|---|---|---|---|---|
| 睡前適讀性 | 8 | 7 | 8 | 7 |
| 零說教 | 7 | 7 | 8 | 7 |

發現：P11 all tiers "I stopped being scared" tell（中）、P06 3-5 fragment（中）、P13 3-5 "Asleep." 突兀（中）、P05 2-3 "Gone!"（中）、P01 5-6 "You hedgehogs"（低）、P06 5-6 "tiny little"（低）、P12 5-6 "cool and nice"（低）。

### en-US-editor（Margaret）

| 維度 | 5-6 | 3-5 | 2-3 | 報告值 |
|---|---|---|---|---|
| 母語自然度 | 9 | 9 | 9 | 9 |
| 文字工藝 | 9 | 8 | 8 | 8 |

發現：P06 5-6 "tiny little"（低）、P12 5-6 "cool and nice"（低）、P01 2-3 Coo: 格式（低）。

## STEP 4 三分法分診

裁決 agent（Opus，≠作者≠E≠人設）。
主題錨復述：「本書教孩子透過身體訊號認識恐懼，經三夜漸進暴露發現勇氣來自內在——石頭不亮了但我不怕了。」

### 裁決表

| # | 頁/檔 | 現象 | 裁決 | 收斂 | 修改級別 | 依據與動作 |
|---|---|---|---|---|---|---|
| F1 | P12 5-6 | "cool and nice" 平板 | ✅ | 3路 | 字串級 | spec R5 具體感官詞優先；"nice" 零感官；→ sensory rewrite |
| F2 | P08 3-5 | "Hand didn't squeeze tight" bare noun | ✅ | 2路 | 字串級 | 英文文法要求 body part 主語加 possessive；→ "His hand" |
| F3 | P10 5-6 | 三連 [Noun, participle] 平行 | ⏸️ | 1路 | — | style_guide 3.4 超規律平行 borderline vs storyboard 設計列舉；lean ✅ |
| F4 | P06 5-6 | "tiny little" double diminutive | ❌ | 3路 | — | 推翻 3路收斂：en-US 兒語暖標準 "tiny little" 常見於 picture book 口語 |
| F5 | P11 all | "I stopped being scared" tell | ❌ | 1路 | — | zh-TW 同型；style_guide §5 角色第一人稱意願句合規；climax payoff 設計 |
| F6 | P06 3-5 | "A cricket, playing." 缺受詞 | ✅ | 2路 | 字串級 | zh-TW「蟋蟀在拉琴」有受詞；3-5 非 2-3 電報式；→ "A cricket, singing." |
| F7 | P13 3-5 | "Asleep." 突兀 | ❌ | 1路 | — | zh-TW 3-5 同為「睡著了。」；ending formula 齊備 |
| F8 | P01 2-3 | "Coo:" 冒號格式 | ⏸️ | 2路 | — | spec R3 said-tag vs R7 2-3 標籤式＋極端字數壓力；lean ❌（保留） |
| F9 | P05 2-3 | "Gone!" 指涉 | ❌ | 2路 | — | 推翻 2路收斂：copy 說明明示為 P06 跳接橋接；zh-TW 同型「不見了！」 |
| F10 | P09 3-5 | "hand not squeezing" bare noun | ✅ | 1路+F2同型 | 字串級 | 同 F2 文法；→ "his hand not squeezing" |
| F11 | P01 5-6 | "You hedgehogs" 說教 | ❌ | 2路 | — | 推翻 2路收斂：concept_contract selling_points 鎖定認知落差裝置 |
| F12 | P08 3-5 | "flickered, barely." 倒序 | ❌ | 1路 | — | postpositive adverb 合法；節奏匹配 P08 情緒拍 |
| F13 | P08 2-3 | "barely" 非幼兒詞彙 | ✅ | 1路 | 字串級 | spec R5 拉丁語源抽象詞紅旗；2-3 目標 2-4 歲；→ concrete word |

### 統計

✅=5（F1, F2, F6, F10, F13）全字串級 → 復核輪資格
❌=6（F4, F5, F7, F9, F11, F12）
⏸️=2（F3, F8）

獨有訊源分佈：獵手獨有 real 0｜回譯獨有 real 0｜人設獨有 real 2（F10, F13）｜多路收斂 real 3（F1, F2, F6）

### ⏸️ 上呈批次（en-US, PYO-005）

| 發現 | 頁 | 無法裁決原因 | 傾向 |
|---|---|---|---|
| F3 | P10 5-6 | style_guide 3.4 vs storyboard 設計列舉衝突；單訊源 | lean ✅（溫和語法變化） |
| F8 | P01 2-3 | spec R3 said-tag vs R7 標籤式＋字數極限衝突 | lean ❌（保留冒號） |
