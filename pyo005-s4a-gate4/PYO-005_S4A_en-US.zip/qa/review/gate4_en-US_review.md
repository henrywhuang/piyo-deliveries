# 關卡4整合審閱：黑夜裡的小燈（S4 證據包／en-US）

- 生成時間：2026-07-30 10:10:08 +0800
- 書目錄：`content/PYO-005_a-little-light-in-the-dark`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：en-US
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-005_storyboard.md` | 2026-07-28 19:48:01 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-29 17:37:01 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-29 19:58:11 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-29 17:37:01 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-29 19:58:11 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-29 17:37:01 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-30 10:07:59 |
| qa/en-US/backtranslation.md | `qa/en-US/backtranslation.md` | 2026-07-30 10:07:59 |
| qa/en-US round | `qa/en-US/round1.md` | 2026-07-29 19:58:11 |
| qa/en-US round | `qa/en-US/round2.md` | 2026-07-29 19:59:47 |
| qa/en-US round | `qa/en-US/round3.md` | 2026-07-30 10:09:59 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | en-US 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 13 | 13 頁有文 | 13 頁有文 | 13/13 | 8 |
| 3-5 | 12 | 12 頁有文 | 12 頁有文 | 12/12 | 4 |
| 2-3 | 10 | 10 頁有文 | 10 頁有文 | 10/10 | 4 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 點點追蝴蝶，開心得不得了。／咕咕飛過來：「晚上來玩嘛——刺蝟不是晚上才出來嗎？」／太陽往下掉了。／刷——／點點縮成一顆球。 | Dot chased butterflies — so, so happy!／Coo flapped by. "Come find me tonight! You hedgehogs come out at night, right?"／The sun slipped down… shadows got longer…／FWIP! Dot curled into a tight little ball. | 點點追著蝴蝶——好開心、好開心！<br>咕咕拍著翅膀飛過來。「今晚來找我！你們刺蝟晚上才出來，對吧？」<br>太陽慢慢沉下去……影子越來越長……<br>刷！點點縮成一顆緊緊的小球。 | 輕微：邀約措辭重塑＋新增「影子越來越長」視覺句，語義負載同 |
| P02 | P02 | 媽媽把點點抱在懷裡，從圍裙口袋掏出一顆小石頭。／「怕黑的時候，握緊它。」／點點握緊——／噗！／石頭亮了。 | Mama scooped up the prickly little ball and carried him inside.／She reached into her big apron pocket and pulled out a round, smooth stone.／"When you're scared," Mama said, "hold on tight."／Dot squeezed — fwoom! The stone glowed. | 媽媽把那顆刺刺的小球撈起來，抱進屋裡。<br>她伸手探進大圍裙口袋，掏出一顆圓圓、滑滑的石頭。<br>「害怕的時候，」媽媽說，「緊緊握住。」<br>點點用力一握——噗！石頭亮了。 | 輕微：展開「撈起刺球」觸覺＋石頭「圓滑」質感，語義負載同 |
| P03 | P03 | 關燈了。／牆上有一個大影子！／點點把石頭握得死死的。／「小燈小燈，亮起來！」 | Lights off.／A big shadow on the wall!／Dot squeezed the stone tight tight tight —／"Little light, little light, shine so bright!" | 燈關了。<br>牆上有一個大影子！<br>點點把石頭握緊緊緊——<br>「小光小光，亮晶晶！」 | 輕微：疊句在地化（小燈→小光，亮起來→亮晶晶），功能對等 |
| P04 | P04 | 石頭一亮——原來是自己的刺和窗簾呀！／點點的刺慢慢貼回去。／手指頭偷偷鬆開了一點點。／風溜進來，涼涼的。 | The stone lit up — just Dot's own quills sticking straight up, and the curtain fluttering!／His quills settled down, one by one. His fingers loosened, just a tiny bit.／A cool breeze drifted in through the window. | 石頭亮了——只是點點自己的刺豎得直直的，還有窗簾在飄！<br>他的刺一根一根地放下來。手指鬆了，鬆了一點點。<br>一陣涼風從窗戶飄進來。 | 無 |
| P05 | P05 | 隔天晚上，點點帶著石頭走到花園。／唧唧、沙沙——到處都在響！／草叢一晃——有個黑影！／「小燈小燈，亮起來！」 | The next night, Dot carried the stone to the garden.／chirp, chirp — rustle, rustle — sounds everywhere!／The bushes shook — a shadow!／"Little light, little light, shine so bright!" | 隔天晚上，點點帶著石頭走到花園。<br>唧唧——沙沙——到處都是聲音！<br>灌木叢搖了搖——一個影子！<br>「小光小光，亮晶晶！」 | 無 |
| P06 | P06 | 蟋蟀在拉琴。／螢火蟲飄過鼻子前面。／花園的夜晚呀，好像一場音樂會。／點點的手不知不覺垂到了身邊。 | A cricket was playing its tiny violin on a blade of grass. A firefly drifted slowly past Dot's nose.／The garden at night was like a tiny little concert.／Dot's hand dropped to his side, and he didn't even notice. | 一隻蟋蟀在草葉上拉著小小的提琴。一隻螢火蟲慢慢飄過點點的鼻尖。<br>夜晚的花園就像一場小小的音樂會。<br>點點的手垂到了身邊，他自己都沒注意到。 | 輕微：展開「草葉上小提琴」細節，語義負載同 |
| P07 | P07 | 第三個晚上。／咕咕說過：「來找我玩！」／點點站在森林邊邊，一隻腳踏出去……／又縮回來。 | Night three.／Coo lived in the forest — "Come find me!" he'd said.／Dot stood at the very edge. One foot out… pulled right back. | 第三個晚上。<br>咕咕住在森林裡——「來找我！」他說過。<br>點點站在最邊邊。一隻腳踏出去……又縮回來。 | 輕微：新增「咕咕住在森林裡」提示語境，語義負載同 |
| P08 | P08 | 深吸一口氣——踏進去了。／沙——沙——／點點伸手要握石頭——／手，沒有自己捏緊。／石頭只冒出一丁點微光。 | Deep breath — stepped in.／rustle, rustle.／Dot reached for the stone — but his hand… didn't squeeze tight. Not like before.／The stone gave off the tiniest flicker. | 深呼吸——踏進去了。<br>沙沙。<br>點點伸手去摸石頭——但他的手……沒有握緊。不像以前那樣了。<br>石頭發出最微弱的一閃。 | 無 |
| P09 | P09 | 點點停下來。／低頭看自己的手——沒有握緊耶。／心跳呢？也沒有很快。／「小燈小燈…… 亮起來。」／石頭沒有亮。／但是點點，沒有回頭。 | Dot stopped.／He looked down at his hand — it wasn't squeezing. Fingers loose.／His quills? Flat. His heart? Not even racing.／"Little light, little light… shine so bright."／The stone didn't glow.／But Dot didn't turn back. | 點點停了下來。<br>他低頭看著自己的手——沒有在握。手指鬆鬆的。<br>他的刺呢？平平的。他的心呢？連跳快都沒有。<br>「小光小光……亮晶晶。」<br>石頭沒有亮。<br>但點點沒有回頭。 | 輕微：母本僅有「心跳」，en-US 展開為手指＋刺＋心跳三連檢，符合 design theme_cycles |
| P10 | P10 | 眼睛慢慢習慣了。／螢火蟲一閃一閃。／葉縫灑下星光。／小蘑菇發著綠光。／到處都是小小的、亮亮的光。 | Dot's eyes got used to the dark.／Fireflies, blinking in the air. Starlight, dripping through the leaves. Tiny mushrooms, glowing green.／The forest path was full of little lights. Everywhere. | 點點的眼睛習慣了黑暗。<br>螢火蟲，在空中閃啊閃。星光，從葉子間滴下來。小小的蘑菇，發著綠光。<br>森林小路上到處都是小小的光。到處都是。 | 無 |
| P11 | P11 | 咕咕：「你自己走過來的？」／點點笑了：「石頭不亮了——可是我不怕了。」／咕咕：「那我們玩嘛！」／月亮爬上了樹梢。 | "You came all by yourself?"／Dot smiled. "The stone stopped glowing… but I stopped being scared."／"Then let's play!"／The moon slowly climbed above the treetops. | 「你自己一個人來的？」<br>點點笑了。「石頭不亮了……但我也不怕了。」<br>「那我們來玩吧！」<br>月亮慢慢爬上了樹頂。 | 無 |
| P12 | P12 | 點點搖搖晃晃往家走。／呼——／夜風涼涼的，好舒服。／媽媽在花園口等著，摸摸他的刺——／一根都沒有豎起來。 | Dot wobbled all the way home.／whoooosh — the night breeze, cool against his quills.／Mama was waiting by the garden gate. She patted his quills — not a single one was standing up. | 點點搖搖晃晃走回家。<br>呼——夜風，涼涼的，貼著他的刺。<br>媽媽在花園門口等著。她拍拍他的刺——一根都沒有豎起來。 | 輕微：「涼涼的，好舒服」→「涼涼的，貼著刺」身體感官化（R1 回修） |
| P13 | P13 | 後來呀，小石頭還在床頭。／點點伸手握一握——／噗！亮了一下下。／媽媽輕輕把門帶上了。／點點翻個身，睡著了。 | And from that day on, Dot's little stone sat right there on the bedside table.／Sometimes, he'd reach over and give it a squeeze — fwoom! It glowed, just for a moment.／Mama gently pulled the door shut.／Dot rolled over, and fell fast asleep. | 從那天起，點點的小石頭就放在床頭桌上。<br>有時候，他會伸手過去握一握——噗！亮了一下下。<br>媽媽輕輕把門拉上。<br>點點翻個身，沉沉睡著了。 | 輕微：結尾式「後來呀」→「從那天起」在地化 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 點點追蝴蝶，好開心！／咕咕：「晚上來玩喔！」／天黑了。／刷——／點點縮成球。 | Dot chased butterflies — so happy!／Coo flapped by. "Come play tonight!"／Sun went down.／FWIP! Dot curled into a ball. | 點點追著蝴蝶——好開心！<br>咕咕拍著翅膀飛過來。「今晚來玩！」<br>太陽下山了。<br>刷！點點縮成一顆球。 | 輕微：咕咕動作展開＋「太陽下山」替「天黑了」，負載同 |
| P02 | P02 | 媽媽拿出小石頭。／「怕黑的時候，握緊它。」／點點握緊——噗！／石頭亮了。 | Mama pulled out a little stone.／"When you're scared, hold on tight."／Dot squeezed — fwoom! The stone glowed. | 媽媽掏出一顆小石頭。<br>「害怕的時候，緊緊握住。」<br>點點用力一握——噗！石頭亮了。 | 無 |
| P03 | P03 | 關燈了。／牆上有大影子！／點點把石頭握好緊。／「小燈小燈，亮起來！」 | Lights off.／Big shadow on the wall!／Dot squeezed tight tight tight.／"Little light, little light, shine so bright!" | 燈關了。<br>牆上大大的影子！<br>點點握緊緊緊。<br>「小光小光，亮晶晶！」 | 輕微：疊句在地化 |
| P04 | P04 | 石頭一亮——是自己的刺呀！／刺慢慢貼回去。／手指頭鬆了一點點。 | The stone lit up — just Dot's own quills!／Quills settled down. Fingers loosened, just a tiny bit. | 石頭亮了——只是點點自己的刺！<br>刺慢慢放下來。手指鬆了，鬆了一點點。 | 無 |
| P05 | P05 | 隔天晚上，花園裡到處響。／唧唧、沙沙——有黑影！／「小燈小燈，亮起來！」 | Next night, the garden was full of sounds.／chirp, chirp — rustle, rustle — a shadow!／"Little light, little light, shine so bright!" | 隔天晚上，花園裡到處都是聲音。<br>唧唧——沙沙——一個影子！<br>「小光小光，亮晶晶！」 | 無 |
| P06 | P06 | 蟋蟀在拉琴。螢火蟲飄過鼻子。／點點的手慢慢垂下來了。 | A cricket, singing. A firefly drifted past Dot's nose.／Dot's hand slowly dropped to his side. | 蟋蟀在唱歌。螢火蟲飄過點點的鼻尖。<br>點點的手慢慢垂到身邊。 | 輕微：「拉琴」→「唱歌」隱喻簡化 |
| P07 | P07 | 第三個晚上。森林邊邊。／咕咕說過：「來找我玩！」／踏出去…… 又縮回來。 | Night three. Edge of the forest.／"Come find me!" Coo had said.／One foot out… pulled right back. | 第三個晚上。森林邊邊。<br>「來找我！」咕咕說過。<br>一隻腳踏出去……又縮回來。 | 無 |
| P08 | P08 | 深吸一口氣——踏進去了。／沙——沙——／石頭只亮一點點。／手沒有握緊。 | Deep breath — stepped in.／rustle, rustle.／The stone flickered, barely. His hand didn't squeeze tight. | 深呼吸——踏進去了。<br>沙沙。<br>石頭微微閃了一下，幾乎看不到。手沒有握緊。 | 無 |
| P09 | P09 | 低頭看——手沒有握緊。／「小燈小燈…… 亮起來。」／石頭沒有亮。／沒有回頭。 | Looked down — his hand not squeezing.／"Little light, little light… shine so bright."／Stone didn't glow.／Didn't turn back. | 低頭看——手沒有在握。<br>「小光小光……亮晶晶。」<br>石頭沒有亮。<br>沒有回頭。 | 無 |
| P10 | P10 | 眼睛慢慢習慣了。／螢火蟲一閃一閃。／到處都是小小的、亮亮的光。 | Eyes got used to the dark.／Fireflies, blinking.／Little lights, everywhere. | 眼睛習慣了黑暗。<br>螢火蟲，一閃一閃。<br>小小的光，到處都是。 | 無 |
| P11 | P11 | 咕咕：「你自己走來的？」／點點笑了：「石頭不亮了——可是我不怕了！」 | "You came by yourself?"／Dot smiled. "The stone stopped glowing… but I'm not scared anymore!" | 「你自己來的？」<br>點點笑了。「石頭不亮了……但我不怕了！」 | 無 |
| P12 | P13 | 後來呀，小石頭還在床頭。／點點握一握——噗！亮一下下。／睡著了。 | And from that day on, the stone sat by the bed.／Dot gave it a squeeze — fwoom! Glowed, just for a moment.／Asleep. | （缺） | — |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 點點追蝴蝶。好開心！／咕咕：「晚上來玩！」／天黑了。／刷——／點點縮成球。 | Dot chased butterflies!／Coo: "Play tonight!"／Dark. FWIP! Curled up. | 點點追蝴蝶！<br>咕咕：「今晚來玩！」<br>天黑了。刷！縮起來。 | 無 |
| P02 | P02 | 媽媽給點點一顆小石頭。／「怕黑，握緊它。」／噗！／石頭亮了！ | Mama held out a stone.／"Hold tight."／Fwoom! | 媽媽拿出一顆石頭。<br>「握緊。」<br>噗！ | 輕微：省略「怕黑」前提＋「石頭亮了」，2-3 壓縮正常 |
| P03 | P03 | 關燈了。／大影子！／「小燈小燈，亮起來！」 | Dark! Big shadow!／"Little light, little light, shine so bright!" | 黑黑的！大影子！<br>「小光小光，亮晶晶！」 | 無 |
| P04 | P04 | 亮了——是自己的刺呀！／刺慢慢貼回去。／手指頭鬆開了。 | Just his own quills!／Quills down. Fingers loose. | 只是他自己的刺！<br>刺放下來了。手指鬆了。 | 無 |
| P05 | P05 | 隔天晚上。／唧唧、沙沙——有黑影！／「小燈小燈，亮起來！」／不見了！ | Night.／chirp, chirp — shadow!／"Little light, little light, shine so bright!"／Gone! | 晚上。<br>唧唧——影子！<br>「小光小光，亮晶晶！」<br>不見了！ | 無 |
| P06 | P07 | 第三個晚上。／點點站在森林邊邊。／踏出去…… 又縮回來。 | Night three. Forest.／One foot out… back. | （缺） | — |
| P07 | P08 | 踏進去了！／沙——沙——／石頭不太亮了。 | Stepped in!／rustle, rustle.／Tiny glow. | 第三個晚上。森林。<br>一隻腳出去……縮回來。 | 無 |
| P08 | P09 | 手沒有握緊。／「小燈小燈…… 亮起來。」／石頭沒有亮。／沒有回頭。 | Hand not tight.／"Little light, little light… shine so bright."／No glow. Walked on. | 踏進去了！<br>沙沙。<br>小小的光。 | 輕微：「石頭幾乎不亮了」→「小小的光」具象化（R1 回修） |
| P09 | P11 | 咕咕：「你自己走來的？」／點點笑了：「不怕了！」 | "You came alone?"／Dot smiled. "Not scared!" | 手沒有握緊。<br>「小光小光……亮晶晶。」<br>沒有亮。繼續走。 | 輕微：「沒有回頭」→「繼續走」方向同（Stacy R1 補回 hand beat） |
| P10 | P13 | 後來呀，小石頭在床頭。／握一握——噗！亮一下下。／睡著了。 | And from that day on — stone by the bed.／Squeeze, fwoom!／Asleep. | （缺） | — |

## 三、QA 摘要（qa/en-US）

- `qa/en-US/round1.md`：round 1／verdict fix_required
- `qa/en-US/round2.md`：round 2／verdict escalated
- `qa/en-US/round3.md`：round 3／verdict escalated

最新 round：`qa/en-US/round3.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: a-little-light-in-the-dark
locale: en-US
tiers: ["5-6", "3-5", "2-3"]
round: 3
date: "2026-07-30"
step1_lint: {exit_code: 1, warnings: 3}
step2_checklist: {pass: 57, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 7, 朗讀口感: 7, 孩子抓得住度: 8}
  - id: en-US-parent
    scores: {睡前適讀性: 7, 零說教: 7}
  - id: en-US-editor
    scores: {母語自然度: 9, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 2}
verdict: escalated
```

### ESL 獵手發現（原文引用）

（缺）最新 round 無「ESL」標題節——確認漏斗是否執行 ESL 獵手維度。

## 四、⏸️ 上呈批次

- （`qa/en-US/round1.md`）| F3 | P10 5-6 | 三連 [Noun, participle] 平行 | ⏸️ | 1路 | — | style_guide 3.4 超規律平行 borderline vs storyboard 設計列舉；lean ✅ |
- （`qa/en-US/round1.md`）| F8 | P01 2-3 | "Coo:" 冒號格式 | ⏸️ | 2路 | — | spec R3 said-tag vs R7 2-3 標籤式＋極端字數壓力；lean ❌（保留） |
- （`qa/en-US/round1.md`）⏸️=2（F3, F8）
- （`qa/en-US/round1.md`）### ⏸️ 上呈批次（en-US, PYO-005）
- （`qa/en-US/round2.md`）復核輪分診：R1 的 5 筆 ✅ 全數落地＝real 清零。R1 的 6 筆 ❌ 不重議。R1 的 2 筆 ⏸️ 原樣保留待 Stacy 裁決。
- （`qa/en-US/round2.md`）本輪新 ✅=0, 新 ❌=0, ⏸️=2（R1 carry）
- （`qa/en-US/round2.md`）### ⏸️ 上呈批次（en-US, PYO-005）——沿用 R1
- （`qa/en-US/round2.md`）**Verdict: `escalated`**（⏸️=2 待 Stacy 裁決）
- （`qa/en-US/round3.md`）R2 carry 的 ⏸️=2 項（F3, F8）+ 新增 1 項字數衝突：
- （`qa/en-US/round3.md`）| F3 | P10 5-6 | style_guide 3.4 超規律平行 vs storyboard 設計列舉 | ⏸️ | carry（R1 未裁決） |
- （`qa/en-US/round3.md`）| F8 | P01 2-3 | spec R3 said-tag vs R7 標籤式＋字數極限 | ⏸️ | carry（R1 未裁決） |
- （`qa/en-US/round3.md`）| WC-1 | 全書 2-3 | max_total_len 88.75 > 88（+0.75w），Stacy R1 mandated change 導致 | ⏸️ | 新（Stacy 裁決） |
- （`qa/en-US/round3.md`）**Verdict: `escalated`**（⏸️=3，其中 WC-1 需 Stacy 確認接受 2-3 總量超限 0.75w 或指示進一步調整）

