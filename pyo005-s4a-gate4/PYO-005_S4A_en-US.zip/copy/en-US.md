# A Little Light in the Dark (a-little-light-in-the-dark / en-US)

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: a-little-light-in-the-dark
locale: en-US
mode: B
storyboard: content/PYO-005_a-little-light-in-the-dark/PYO-005_storyboard.md
design: content/PYO-005_a-little-light-in-the-dark/PYO-005_design.md
image_pool: 13
selection:
  "3-5": [P01, P02, P03, P04, P05, P06, P07, P08, P09, P10, P11, P13]
  "2-3": [P01, P02, P03, P04, P05, P07, P08, P09, P11, P13]
commitments:
  refrain: "Little light, little light, shine so bright!"
  ending: "And from that day on"
  onomatopoeia: [FWIP!, fwoom, "chirp, chirp", "rustle, rustle", whoooosh]
characters: [Dot, Mama, Coo]
```

### B0 語感基建

**疊句三變奏**：
- P03 / P05：`"Little light, little light, shine so bright!"`（shouted, scared grip）
- P09 變奏：`"Little light, little light… shine so bright."`（whispered, stone doesn't respond; period replaces exclamation）

**擬聲詞凍結字串表**：

| # | 動作 | 凍結字串 | O-rule |
|---|---|---|---|
| O-1 | quills bristle up | `FWIP!` | O1 全大寫＋感嘆號 |
| O-2 | stone glows warm | `fwoom` | 小寫融入敘述 |
| O-3 | crickets chirping | `chirp, chirp` | O3 小寫逗號雙連 |
| O-4 | leaves/rustling | `rustle, rustle` | O3 小寫逗號雙連 |
| O-5 | night wind | `whoooosh` | O2 字母重複拉長 |

**角色口癖卡**：

| canonical key | en-US 名 | 口癖 |
|---|---|---|
| dian_dian | Dot | Excited bursts when curious; scared = refrain + short gasps; discovering = slow wonder sentences |
| mama_hedgehog | Mama | Minimal words, warm, no lectures; tag = "Mama said" or action-first |
| gu_gu | Coo | Cheerful, oblivious to fear, inviting; tag = head-tilt/blink paired with speech |

**角色名碰撞備註**：design 提案 Pip 與 PYO-013 the-giant-turnip `pip | Pip (定案)` 碰撞，改提 Dot（點點語義＝dot，一音節，光主題契合）。

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Dot chased butterflies — so, so happy!<br>Coo flapped by. "Come find me tonight! You hedgehogs come out at night, right?"<br>The sun slipped down… shadows got longer…<br>FWIP! Dot curled into a tight little ball. | 35✓ | 1 | Dot chased butterflies — so happy!<br>Coo flapped by. "Come play tonight!"<br>Sun went down.<br>FWIP! Dot curled into a ball. | 20✓ | 1 | Dot chased butterflies!<br>Coo: "Play tonight!"<br>Dark. FWIP! Curled up. | 10✓ | ✓ | 5-6: full scene + Coo invitation + cognitive gap (hedgehogs = nocturnal). 3-5: trimmed invitation. 2-3: telegram — action + invite + FWIP, picture carries emotional coloring. |
| P02 | 2 | Mama scooped up the prickly little ball and carried him inside.<br>She reached into her big apron pocket and pulled out a round, smooth stone.<br>"When you're scared," Mama said, "hold on tight."<br>Dot squeezed — fwoom! The stone glowed. | 39✓ | 2 | Mama pulled out a little stone.<br>"When you're scared, hold on tight."<br>Dot squeezed — fwoom! The stone glowed. | 18✓ | 2 | Mama held out a stone.<br>"Hold tight."<br>Fwoom! | 8✓ | ✓ | 5-6: apron pocket detail + scooping action. 3-5: condensed. 2-3: telegram — fwoom alone conveys the glow. |
| P03 | 3 | Lights off.<br>A big shadow on the wall!<br>Dot squeezed the stone tight tight tight —<br>"Little light, little light, shine so bright!" | 22✓ | 3 | Lights off.<br>Big shadow on the wall!<br>Dot squeezed tight tight tight.<br>"Little light, little light, shine so bright!" | 19✓ | 3 | Dark! Big shadow!<br>"Little light, little light, shine so bright!" | 10✓ | ✓ | Refrain #1. Ends on refrain —翻頁 hook: what is the shadow? P04 reveals. |
| P04 | 4 | The stone lit up — just Dot's own quills sticking straight up, and the curtain fluttering!<br>His quills settled down, one by one. His fingers loosened, just a tiny bit.<br>A cool breeze drifted in through the window. | 37✓ | 4 | The stone lit up — just Dot's own quills!<br>Quills settled down. Fingers loosened, just a tiny bit. | 17✓ | 4 | Just his own quills!<br>Quills down. Fingers loose. | 8✓ | ✓ | Shadow reveal + body relaxation. 5-6: curtain + breeze per zh-TW. 3-5: trimmed to quills + body. 2-3: telegram. |
| P05 | 5 | The next night, Dot carried the stone to the garden.<br>chirp, chirp — rustle, rustle — sounds everywhere!<br>The bushes shook — a shadow!<br>"Little light, little light, shine so bright!" | 28✓ | 5 | Next night, the garden was full of sounds.<br>chirp, chirp — rustle, rustle — a shadow!<br>"Little light, little light, shine so bright!" | 21✓ | 5 | Night.<br>chirp, chirp — shadow!<br>"Little light, little light, shine so bright!"<br>Gone! | 12✓ | ✓ | Refrain #2. 2-3: "Night." + picture change bridges time; "Gone!" bridges P06 skip (zh-TW 2-3 has 「不見了！」). |
| P06 | 6 | A cricket was playing its tiny violin on a blade of grass. A firefly drifted slowly past Dot's nose.<br>The garden at night was like a tiny little concert.<br>Dot's hand dropped to his side, and he didn't even notice. | 40✓ | 6 | A cricket, singing. A firefly drifted past Dot's nose.<br>Dot's hand slowly dropped to his side. | 16✓ | — | — | — | ✓ | 5-6: violin metaphor + concert + hand observation. 3-5: trimmed metaphors. 2-3: skipped. |
| P07 | 7 | Night three.<br>Coo lived in the forest — "Come find me!" he'd said.<br>Dot stood at the very edge. One foot out… pulled right back. | 24✓ | 7 | Night three. Edge of the forest.<br>"Come find me!" Coo had said.<br>One foot out… pulled right back. | 18✓ | 6 | Night three. Forest.<br>One foot out… back. | 7✓ | ✓ | Hook page — will Dot enter? 2-3: "Forest." + picture carries setting; minimal hesitation beat. |
| P08 | 8 | Deep breath — stepped in.<br>rustle, rustle.<br>Dot reached for the stone — but his hand… didn't squeeze tight. Not like before.<br>The stone gave off the tiniest flicker. | 27✓ | 8 | Deep breath — stepped in.<br>rustle, rustle.<br>The stone flickered, barely. His hand didn't squeeze tight. | 15✓ | 7 | Stepped in!<br>rustle, rustle.<br>Tiny glow. | 6✓ | ✓ | Crisis — stone fading, hand not gripping. 2-3: stripped to action + stone. |
| P09 | 9 | Dot stopped.<br>He looked down at his hand — it wasn't squeezing. Fingers loose.<br>His quills? Flat. His heart? Not even racing.<br>"Little light, little light… shine so bright."<br>The stone didn't glow.<br>But Dot didn't turn back. | 37✓ | 9 | Looked down — his hand not squeezing.<br>"Little light, little light… shine so bright."<br>Stone didn't glow.<br>Didn't turn back. | 19✓ | 8 | Hand not tight.<br>"Little light, little light… shine so bright."<br>No glow. Walked on. | 14✓ | ✓ | Climax — self-awareness. Refrain #3 variation (whispered, period). 5-6: full body discovery chain (hand + quills + heart). 2-3: beat 補回 hand awareness before refrain (Stacy R1); opens with body discovery → refrain attempt. |
| P10 | 10 | Dot's eyes got used to the dark.<br>Fireflies, blinking in the air. Starlight, dripping through the leaves. Tiny mushrooms, glowing green.<br>The forest path was full of little lights. Everywhere. | 30✓ | 10 | Eyes got used to the dark.<br>Fireflies, blinking.<br>Little lights, everywhere. | 11✓ | — | — | — | ✓ | 5-6: three light sources. 3-5: compressed to fireflies + summary. 2-3: skipped. |
| P11 | 11 | "You came all by yourself?"<br>Dot smiled. "The stone stopped glowing… but I stopped being scared."<br>"Then let's play!"<br>The moon slowly climbed above the treetops. | 26✓ | 11 | "You came by yourself?"<br>Dot smiled. "The stone stopped glowing… but I'm not scared anymore!" | 15✓ | 9 | "You came alone?"<br>Dot smiled. "Not scared!" | 7✓ | ✓ | Friend reunion + payoff. 5-6: moon time sentence + play invitation. 3-5: core payoff dialogue. 2-3: shortest payoff — "alone" captures zh-TW 自己走來. |
| P12 | 12 | Dot wobbled all the way home.<br>whoooosh — the night breeze, cool against his quills.<br>Mama was waiting by the garden gate. She patted his quills — not a single one was standing up. | 32✓ | — | — | — | — | — | — | ✓ | 5-6 only: breathing page — moonlit return, Mama waiting, quills flat. |
| P13 | 13 | And from that day on, Dot's little stone sat right there on the bedside table.<br>Sometimes, he'd reach over and give it a squeeze — fwoom! It glowed, just for a moment.<br>Mama gently pulled the door shut.<br>Dot rolled over, and fell fast asleep. | 44⚠ | 12 | And from that day on, the stone sat by the bed.<br>Dot gave it a squeeze — fwoom! Glowed, just for a moment.<br>Asleep. | 23✓ | 10 | And from that day on — stone by the bed.<br>Squeeze, fwoom!<br>Asleep. | 12✓ | ✓ | Closing: ending formula + stone + sleep. 5-6 P13 over band top (44>40): ending page carries four-piece formula per style_guide, zh-TW mandated — cannot split without losing closing rhythm. |
