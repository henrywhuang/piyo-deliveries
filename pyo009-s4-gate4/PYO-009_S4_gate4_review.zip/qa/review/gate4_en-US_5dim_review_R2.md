# Gate 4 五維審查 R2：我有我的小光（PYO-009 / en-US）

## 審稿識別

- 繪本編號：PYO-009
- 繪本 Slug：my-little-glow
- 書名（zh-TW）：《我有我的小光》
- 審稿輪次：R2（針對五維審稿回修版）
- 審稿日期：2026-07-21
- 審稿依據：piyo-copywriting-review v0.9
- 審稿來源：`gate4_en-US_review-PYO-009.md`（2026-07-20 23:24:02 生成，五維審稿回修版）
- 上輪報告：`gate4_en-US_5dim_review.md`（R1）
- 判定：**文本品質 PASS — H01-H05 品牌/Registry 裁定待 Stacy 決議後即可凍結**

## 來源文件核對

- S2 storyboard：`PYO-009_storyboard.md`（greenlit）
- 核心訊息：小光始終沒變大，Glim 自己辨認線索主動使用小光
- en-US 模式：Mode B 盲稿改編制
- Gate 3 decision：Green Light（2026-07-20）
- 回修版 copy_check：exit 0（11 advisory）
- 回修版 locale_lint：exit 0（三檔）
- 字量：5-6 折計 450.75；3-5 折計 262.25；2-3 折計 85.25 ≤ hard 88 ✓

## 一、R1 發現 vs R2 驗證

### R1 六項回修需求（gate4_en-US_5dim_review.md §五–§九）

| # | R1 發現 | R2 回修內容 | R2 判定 |
|---|---|---|---|
| 1 | 5-6 P05 翻譯腔：`stopped looking up and looked` 雙重 look + `had reached` 過去完成式 | → `He looked down—right where his glow fell.` 單一動詞，簡單過去式 | ✅ 修復 |
| 2 | 5-6 P11 缺語義閉合：`"Still small"` 未回應「就是這麼小的光走完了路」 | → `"Still small—but it lit my way home"` 反事實閉合具體化 | ✅ 修復 |
| 3 | 3-5 P09 同上缺閉合 | → `"Still small—but it lit my way home"` | ✅ 修復 |
| 4 | 2-3 P02 see→act→result 缺 action：只有 `clomp!` | → `Step—clomp!` 補入踩步動作詞 | ✅ 修復 |
| 5 | 2-3 P03 擠過動作被過度壓縮：`Through—clomp!` | → `Squeeze through—clomp!` 明確側身擠過 | ✅ 修復 |
| 6 | 2-3 P06 高潮缺完成結果：`home I go` 未交付抵達 | → 壓縮首句 + `Home!` 明確到家 | ✅ 修復 |

### R1 三項結構問題（證據包本身）

| # | R1 發現 | R2 狀態 |
|---|---|---|
| A | §四 截斷：H01-H05 只有標題無展開 | ✅ 修復——§四完整展開 H01-H05 含 Stable IDs 與待裁內容 |
| B | P11 偏移標記引用已刪文 `It had been enough` | ✅ 修復——fresh blind 回譯已同步，舊偏移說明移除 |
| C | Step2 fail 三項無根源說明 | ✅ 修復——§三新增 Round 3 三項 fail 展開表 |

**小結：R1 所有 6 項文本問題 + 3 項結構問題均已修復。**

## 二、五維度 R2 判定

### 維度一（致命級）：朗讀自然度 — ✅ 通過

逐頁朗讀六受修頁：

| 頁 | 修改後文本 | 朗讀評語 |
|---|---|---|
| 5-6 P05 | `He looked down—right where his glow fell.` | em-dash 製造讀者暫停，節奏自然；`glow fell` 是標準英文用法（where light falls）。 |
| 5-6 P11 | `"Still small—but it lit my way home," he whispered.` | 反轉結構（still X—but Y）讀起來有情感蓄力與釋放；whispered 語氣温柔收束。 |
| 3-5 P09 | `"Still small—but it lit my way home," Glim said.` | 同上，`said` 替代 `whispered` 適合 3-5 檔更直白的語感。 |
| 2-3 P02 | `Step—clomp!` | 動作詞＋聲效，一口氣爆出，邀請幼兒跺腳模仿。 |
| 2-3 P03 | `Squeeze through—clomp!` | 音節略密（3 詞），但 squeeze 本身是物理動詞，家長可配合捏手動作朗讀。專家評分 4/5，在容差內。 |
| 2-3 P06 | `Home!` | 單字感嘆詞，讀起來是全書最有力的著陸點。 |

翻譯腔掃描：R1 唯一中度翻譯腔（5-6 P05 double look + past perfect）已修復。全 30 頁重掃無新翻譯腔。

### 維度二（致命級）：幼兒可理解性 — ✅ 通過

- `He looked down—right where his glow fell`：動作具體（往下看），5-6 歲可理解。
- `but it lit my way home`：語義直白（光照亮回家的路），3-5 歲可理解。
- `Step—clomp!` / `Squeeze through—clomp!`：動作＋聲效，2-3 歲可理解。
- `Home!`：最基礎詞彙，2 歲即可理解。
- 各頁仍維持「一頁一件事」原則，無概念超載。

### 維度三（重要級）：圖文配合度 — ✅ 通過

- 5-6 P05：圖為草縫光線穿透，文字交付 Glim 選擇看向光落處（圖畫不出的主動決定）。
- 5-6 P11：圖為 Glim 坐在媽媽旁，文字交付反事實感悟（光沒變但照完了路）。
- 2-3 P02/P03：文字動作詞配合圖中踩石/擠縫動作，無重述。
- 2-3 P06：`Home!` 配合圖中苔蘚門到達，為圖畫不出的宣告。

### 維度四（合規級）：品牌與 Registry 合規 — ⏸️ 待 H01-H05 裁定

品牌三條線：
- ✅ 旁白從不對聽眾出題
- ✅ 旁白從不總結道理
- ✅ 收尾回到「大家在一起」（三檔末頁均有 Mama waited）

結尾四件套：
- ✅ 收束式段落（三檔 P12/P10/P08）
- ✅ 陪伴安心基調
- ✅ 不做開放式懸疑
- ✅ 最後一頁情緒安定

Registry 鎖定：
- ⏸️ H02：refrain `My little glow, then off I go!` + 變體尚未正式寫入 registry
- ⏸️ H03：`clomp` / `swish` 擬聲詞尚未正式寫入 onomatopoeia map
- ⏸️ H04：`Glim` / `Mama Firefly` 角色名尚未寫入 locale-character-names

以上三項是新書新增元素需 Stacy 核可並寫入共享 registry 的正常流程，非文本品質缺陷。

### 維度五（跨版本級）：三檔 × 兩語一致性 — ✅ 通過

三檔一致性：
- ✅ 主線 beat 一致：受阻→發現線索→使用小光（refrain）→逐段前進→到家→光沒變大
- ✅ 閉合語義三檔貫穿：5-6/3-5 `Still small—but it lit my way home`；2-3 以 P06 `Home!` + P07 `His glow stayed small` 分頁交付
- ✅ 角色名三檔一致（Glim / Mama Firefly）
- ✅ 擬聲詞三檔一致（clomp / swish，2-3 無 swish 為設計選擇）

兩語一致性（zh-TW vs en-US）：
- ✅ 情緒弧線對齊（困頓→發現→逐步前行→到達→反思）
- ✅ 核心概念不變（光沒變大、Glim 主動使用）
- ✅ 偏移均為「輕微」或 R2 待判——無「中度」以上偏移殘留
- ✅ 回譯 vs 母本語義差異均在 Mode B 盲稿改編容許範圍內

## 三、回譯偏移 R2 重判

六受修頁已由 fresh blind 回譯員重譯（見 gate4 review 三欄對照），舊偏移標記清除。

| 頁 | 新偏移標記 | R2 判定 |
|---|---|---|
| 5-6 P05 | 待 R2 QA | ✅ 回譯「他往下看——正是他的光芒落下的地方」忠實反映新文本；線索辨識與主動選擇功能保留。 |
| 5-6 P11 | 待 R2 QA | ✅ 回譯「還是很小——但它照亮了我回家的路」準確交付反事實閉合。 |
| 3-5 P09 | 待 R2 QA | ✅ 同 5-6 P11。 |
| 2-3 P02 | 待 R2 QA | ✅ 回譯「踏步——咚！」完整 see→act→result 鏈。刪 `dry` 與 zh-TW 2-3 母本一致（母本亦無「乾乾的」）。 |
| 2-3 P03 | 待 R2 QA | ✅ 回譯「擠過去——咚！」明確側身擠過動作。 |
| 2-3 P06 | 待 R2 QA | ✅ 回譯「到家了！」明確交付高潮完成。 |

**六頁偏移全部降至可接受，無中度以上殘留。**

## 四、專家獨立判讀（Opus Expert Agent）

委託 Opus 模型以幼兒繪本編輯角色獨立評審六受修頁（朗讀自然度 1-5 分、翻譯腔、新問題）：

| 頁 | 朗讀分 | 修復完成 | 翻譯腔 | 新問題 |
|---|---|---|---|---|
| 5-6 P05 | 5/5 | ✅ | 無 | 無 |
| 5-6 P11 | 5/5 | ✅ | 無 | 無 |
| 3-5 P09 | 5/5 | ✅ | 無 | 無 |
| 2-3 P02 | 5/5 | ✅ | 無 | 無 |
| 2-3 P03 | 4/5 | ✅ | 無 | `Squeeze through—clomp!` 音節略密，但在 2-3 檔容差內（家長會自然拉長 squeeze 發音） |
| 2-3 P06 | 5/5 | ✅ | 無 | 無 |

專家結論：「All six revisions are acceptable. Each one resolves its original complaint without introducing new problems.」

## 五、H01-H05 現狀（Stacy 裁定項，非文本修改項）

以下五項維持 `verdict: escalated` 狀態，不由 QA 代行裁定：

| Hold | 待裁內容 | 文本品質影響 |
|---|---|---|
| H01 | B-4 對話比例：目前不灌對話，旁白搭台/台詞收拍的品牌解讀 | 無——現有對話比例已通過朗讀測試 |
| H02 | 核可 refrain 三變體寫入 registry | 無——文本中使用一致；需寫入共享 registry |
| H03 | 核可 clomp/swish 寫入 onomatopoeia map + TTS round-trip 決定 | 無——聲效在文本中功能完備；需確認 TTS 相容性 |
| H04 | 核可 Glim / Mama Firefly 寫入 character names registry | 無——名稱在文本中使用一致 |
| H05 | 接受 copy_check 11 + locale_lint 10 advisory set | 無——全部 exit 0，advisory 非 error |

## 六、檔案同步提醒

⚠️ 本機 `.draft.json` 檔案仍為回修前版本（例如 5-6 P05 仍為 `He stopped looking up and looked...`），與 gate4 review 三欄對照中的新版文本不一致。`backtranslation.md` 同樣為回修前版本。

回修後的正確文本以 gate4 review `gate4_en-US_review-PYO-009.md` 三欄對照欄為準。建議 Stacy 確認來源機器上 `.draft.json` 已同步。

## 七、總結判定

| 項目 | 判定 |
|---|---|
| 六項 R1 文本修改 | ✅ 全部修復驗證通過 |
| 三項 R1 結構問題 | ✅ 全部修復 |
| 五維度審查 | D1–D3、D5 通過；D4 品牌合規項 H01-H05 待 Stacy 裁定 |
| 翻譯腔 | ✅ 無殘留 |
| 回譯偏移 | ✅ 六頁均降至可接受 |
| 專家獨立判讀 | ✅ 六頁 4-5/5 分，全部通過 |

**R2 QA 結論：文本品質通過五維度審查。Gate 4 整體 verdict 維持 `escalated`，唯一阻塞為 H01-H05 品牌/Registry 裁定（Stacy 必到）。H01-H05 核可後可執行 en-US 凍結並進入 S4B 多語放量。**

---

*報告路徑：`content/PYO-009_my-little-glow/qa/review/gate4_en-US_5dim_review_R2.md`*
