# 圖文總表：Monkeys Fishing for the Moon（monkeys-fishing-for-the-moon / en-US）

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: monkeys-fishing-for-the-moon
locale: en-US
mode: B
storyboard: content/PYO-034_monkeys-fishing-for-the-moon/PYO-034_storyboard.md
design: content/PYO-034_monkeys-fishing-for-the-moon/PYO-034_design.md
image_pool: 12
selection:
  "3-5": [P01, P02, P03, P05, P07, P08, P09, P10, P11, P12]
  "2-3": [P01, P02, P03, P07, P08, P10, P11, P12]
commitments:
  refrain: "Scoop, scoop, scoop the moon—SPLASH! It broke!"
  ending:
    "5-6": "And from that day on, every full-moon night, the monkeys watched the moon together. And the best moon-watcher of all was Teeny."
    "3-5": "And from that day on, the monkeys watched the moon together. The best moon-watcher of all was Teeny."
    "2-3": "And from that day on, they watched the moon."
  onomatopoeia: [SPLASH!, SPLOOSH!, chitter-chatter, "swing and sway", "Hee-hee!"]
characters: [Pip, Teeny, the monkeys]
voice_cards:
  Pip: "Action-first leader. Short exclamations. 'Come on!' / 'I know!' / 'Not enough!' He = impulsive, always has a plan."
  Teeny: "Quiet observer. Short sentences with wonder. She = looks up, notices what others miss."
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | One full-moon night, the forest was so quiet, so still.<br>Pip ran to the pond for a drink. He looked down and—<br>"Whoa! The moon is in the water!" | 29✓ | 1 | One full-moon night, Pip ran to the pond. He looked down—<br>"Whoa! The moon is in the water!" | 18✓ | 1 | Full-moon night!<br>Pip looked in the pond—<br>"Whoa! The moon!" | 10✓ | ✓ | 母版；3-5 砍 forest 場景鋪陳；2-3 電報式重述 |
| P02 | 2 | "The moon fell in the water!" Pip shouted. "Quick, everybody, come help me scoop it out!"<br>The monkeys came running, chitter-chatter, chitter-chatter.<br>But not Teeny. She stayed way up high, looking at the stars. | 34✓ | 2 | "The moon fell in!" Pip shouted. "Let's scoop it out!"<br>The monkeys came running, chitter-chatter, chitter-chatter.<br>Teeny stayed up high, looking at the stars. | 24✓ | 2 | "Moon fell in! Let's scoop it out!"<br>The monkeys came running. | 11✓ | ✓ | 母版；3-5 砍 the water、rally 對話簡化、But not 句式；2-3 砍 chitter-chatter 與 Teeny 伏筆 |
| P03 | 3 | Pip leaned over and reached into the water—<br>Scoop, scoop, scoop the moon—SPLASH! It broke!<br>"Oh no! I broke the moon!" | 21✓ | 3 | Pip reached into the water—<br>Scoop, scoop, scoop the moon—SPLASH! It broke!<br>"Oh no! I broke the moon!" | 18✓ | 3 | Pip reached in—<br>Scoop, scoop, scoop the moon—SPLASH! It broke! | 10✓ | ✓ | 疊句第一次，三檔共核心句；3-5 砍 leaned over；2-3 砍驚叫 |
| P04 | 4 | The water got still again… and the moon came back!<br>Pip scratched his head. "Too rough! We need more hands—everybody, gently!" | 21✓ | — | — | — | — | — | — | ✓ | 反思過渡頁；3-5/2-3 跳——策略升級由 P05 橋接 |
| P05 | 5 | This time, three monkeys leaned in, ever so gently—<br>Scoop, scoop, scoop the moon—SPLASH! It broke!<br>"It broke again! What do we do?" | 23✓ | 4 | The moon came back… but Pip had a new idea.<br>Three monkeys leaned in, ever so gently—<br>Scoop, scoop, scoop the moon—SPLASH! It broke!<br>"It broke again! What do we do?" | 31✓ | — | — | — | ✓ | 疊句第二次；3-5 橋接 P04（月亮回來了＋新策略句）故字數偏高；2-3 跳——壓縮為兩次嘗試 |
| P06 | 6 | Pip jumped up and shouted,<br>"Not long enough! Every monkey, get over here!"<br>"We'll make a chain—the longest chain—all the way down to the moon!" | 25✓ | — | — | — | — | — | — | ✓ | 號召全員頁；3-5/2-3 跳——全員長鏈由 P07 鏈條畫面與對話承接 |
| P07 | 7 | One by one, the monkeys hung from the big branch, all the way down to the water.<br>Swing and sway, swing and sway…<br>Teeny sat at the very top. "You're the lightest—don't move!" | 33✓ | 5 | "Everybody, come! We'll make the longest chain!" said Pip.<br>One by one, the monkeys hung from the big branch.<br>Swing and sway, swing and sway…<br>Teeny sat at the top. "You're the lightest—don't move!" | 34✓ | 4 | All the monkeys made a long, long chain!<br>Swing and sway, swing and sway… | 14✓ | ✓ | 長鏈＋搖擺＋小不點位置；3-5 橋接 P06（rallying 句）故字數偏高；2-3 砍 Teeny 位置 |
| P08 | 8 | The monkey at the very bottom reached down—<br>Scoop, scoop, scoop the moon—SPLASH! It broke!<br>It broke into a thousand tiny, shimmery pieces!<br>SPLOOSH! SPLOOSH! The monkeys all tumbled into the water! | 32✓ | 6 | The bottom monkey reached down—<br>Scoop, scoop, scoop the moon—SPLASH! It broke!<br>It broke into a thousand pieces!<br>SPLOOSH! SPLOOSH! Everyone fell in! | 23✓ | 5 | Scoop, scoop, scoop the moon—SPLASH! It broke!<br>SPLOOSH! Everyone fell in! | 11✓ | ✓ | 疊句第三次變奏＋高潮；3-5 砍碎片修飾詞；2-3 砍動作起始與碎片句 |
| P09 | 9 | The monkeys sat by the pond, dripping wet.<br>Pip hung his head. He didn't say a word. | 17✓ | 7 | The monkeys sat by the pond, dripping wet.<br>Pip hung his head. He didn't say a word. | 17✓ | — | — | — | ✓ | 情緒低谷刻意短（craft C1）；2-3 跳——由 P08 失敗直接接 P10 啊哈時刻 |
| P10 | 10 | Teeny was still up in the big tree, looking here, looking there.<br>She looked up and—<br>"Whoa! Look! The moon is in the sky!" | 24✓ | 8 | Teeny was still up in the tree, looking here, looking there.<br>She looked up—<br>"Look! The moon is in the sky!" | 21✓ | 6 | Teeny looked up.<br>"Look! The moon! Up in the sky!" | 10✓ | ✓ | 啊哈時刻；3-5 砍 big、Whoa；2-3 電報式保留核心發現 |
| P11 | 11 | All the monkeys looked up—the moon was right there, big and bright, hanging in the sky.<br>"It was up there the whole time!"<br>They looked at the pond… the water was still, and the moon was back. | 37✓ | 9 | The monkeys looked up—the moon was in the sky!<br>"Up there the whole time!"<br>They looked at the pond… the moon was back. | 23✓ | 7 | Everybody looked up.<br>"The moon! It was there the whole time!" | 11✓ | ✓ | 雙重揭示；3-5 砍修飾語與池塘細節；2-3 砍池塘回來 |
| P12 | 12 | The monkeys sat together on the big branch, watching the moon.<br>Pip laughed. "Teeny, thank you! Next time, I'll look up first."<br>"Hee-hee!"<br>And from that day on, every full-moon night, the monkeys watched the moon together. And the best moon-watcher of all was Teeny. | 45✓ | 10 | The monkeys sat together, watching the moon.<br>Pip laughed. "Teeny, thank you! Next time, I'll look up first."<br>"Hee-hee!"<br>And from that day on, the monkeys watched the moon together. The best moon-watcher of all was Teeny. | 37✓ | 8 | The monkeys sat together. "Hee-hee!"<br>And from that day on, they watched the moon. | 14✓ | ✓ | 結尾四件套；5-6 全件（同框＋感謝＋前瞻意願＋收束）；3-5 砍 on the big branch、every full-moon night；2-3 保留同框＋Hee-hee＋收束式（golden 先例：幼幼版感謝可省） |
