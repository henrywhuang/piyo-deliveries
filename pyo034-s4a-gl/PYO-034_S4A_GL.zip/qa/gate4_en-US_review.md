# 關卡4整合審閱：猴子撈月（S4 證據包／en-US）

- 生成時間：2026-07-31 17:33:34 +0800
- 書目錄：`content/PYO-034_monkeys-fishing-for-the-moon`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：en-US
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-034_storyboard.md` | 2026-07-30 14:01:12 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-31 12:02:23 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-31 16:49:33 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-31 12:02:23 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-31 16:49:34 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-31 12:02:23 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-31 13:58:30 |
| qa/en-US/backtranslation.md | `qa/en-US/backtranslation.md` | 2026-07-31 14:11:35 |
| qa/en-US round | `qa/en-US/round1.md` | 2026-07-31 14:06:12 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | en-US 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 12 | 12 頁有文 | 12 頁有文 | 12/12 | 9 |
| 3-5 | 10 | 10 頁有文 | 10 頁有文 | 10/10 | 7 |
| 2-3 | 8 | 8 頁有文 | 8 頁有文 | 8/8 | 4 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 月圓的晚上，森林裡好安靜好安靜。／皮皮跑到池塘邊喝水，低頭一看——／「哇！月亮掉到水裡了！」 | One full-moon night, the forest was so quiet, so still.／Pip ran to the pond for a drink. He looked down and—／"Whoa! The moon is in the water!" | 一個月圓的夜晚，森林好安靜、好安靜。<br>皮皮跑到池塘邊喝水。他往下一看——<br>「哇！月亮在水裡面！」 | 輕微：en-US 用「在水裡」（觀察）vs zh-TW「掉到水裡了」（判斷），語感適配 |
| P02 | P02 | 皮皮喊：／「月亮掉到水裡了！快來，一起撈月亮！」／猴子們嘰嘰喳喳跑過來。／小不點沒下來，抬頭看星星呢。 | "The moon fell in the water!" Pip shouted. "Quick, everybody, come help me scoop it out!"／The monkeys came running, chitter-chatter, chitter-chatter.／But not Teeny. She stayed way up high, looking at the stars. | 「月亮掉進水裡了！」皮皮大喊。「快，大家來幫我把它撈出來！」<br>猴子們跑過來了，嘰嘰喳喳、嘰嘰喳喳。<br>但小不點沒來。她待在高高的上面，看著星星。 | 輕微：en-US 展開 rally 句並加 Teeny 位置細節 |
| P03 | P03 | 皮皮伸手往水裡一撈——／撈呀撈，撈月亮——嘩啦！碎了！／「啊！月亮碎掉了！」 | Pip leaned over and reached into the water—／Scoop, scoop, scoop the moon—SPLASH! It broke!／"Oh no! I broke the moon!" | 皮皮探出身子，把手伸進水裡——<br>撈呀、撈呀、撈月亮——嘩啦！碎掉了！<br>「糟糕！我把月亮弄碎了！」 | 輕微：en-US 展開動作（leaned over）＋Pip 自承破壞 |
| P04 | P04 | 水面慢慢平靜下來…… 月亮又回來了。／皮皮想了想：「太粗魯了！要輕一點。」／「大家一起來，很多隻手，輕輕撈！」 | The water got still again… and the moon came back!／Pip scratched his head. "Too rough! We need more hands—everybody, gently!" | 水面又平靜下來……月亮又回來了！<br>皮皮抓了抓頭。「太粗魯了！我們需要更多手——大家，輕一點！」 | 輕微：en-US 用「抓頭」替代「想了想」（視覺化），策略句精簡 |
| P05 | P05 | 這次，三隻猴子一起，輕輕碰了碰水面——／撈呀撈，撈月亮——嘩啦！碎了！／「又碎了！怎麼辦！」 | This time, three monkeys leaned in, ever so gently—／Scoop, scoop, scoop the moon—SPLASH! It broke!／"It broke again! What do we do?" | 這次，三隻猴子探過身去，輕輕地、輕輕地——<br>撈呀、撈呀、撈月亮——嘩啦！又碎了！<br>「又碎了！怎麼辦？」 | 無 |
| P06 | P06 | 皮皮跳起來喊：／「不夠長！所有猴子都來！」／「排成一條好長好長的鏈子，一定撈得到！」 | Pip jumped up and shouted,／"Not long enough! Every monkey, get over here!"／"We'll make a chain—the longest chain—all the way down to the moon!" | 皮皮跳起來大喊：<br>「不夠長！所有猴子，都過來！」<br>「我們來搭一條鏈——最長的鏈——一路連到月亮那裡！」 | 輕微：en-US 用 em dash 修辭強調「最長」，語感差異 |
| P07 | P07 | 猴子們一隻接一隻掛下去，排成好長好長的鏈子。／晃呀晃，晃呀晃……／小不點在最上面——「你最輕，別動喔！」 | One by one, the monkeys hung from the big branch, all the way down to the water.／Swing and sway, swing and sway…／Teeny sat at the very top. "You're the lightest—don't move!" | 猴子們一個接一個，從大樹枝上掛下來，一路垂到水面。<br>晃呀晃、晃呀晃……<br>小不點坐在最上面。「你最輕——不要動！」 | 輕微：en-US 加空間細節（big branch→water） |
| P08 | P08 | 最下面的猴子伸出手——／撈呀撈，撈月亮——嘩啦！碎了！／碎成好多好多碎片！／撲通！撲通！猴子們全掉進水裡了！ | The monkey at the very bottom reached down—／Scoop, scoop, scoop the moon—SPLASH! It broke!／It broke into a thousand tiny, shimmery pieces!／SPLOOSH! SPLOOSH! The monkeys all tumbled into the water! | 最底下的猴子伸手下去——<br>撈呀、撈呀、撈月亮——嘩啦！碎掉了！<br>碎成一千個亮晶晶的小碎片！<br>撲通！撲通！猴子們全掉進水裡了！ | 輕微：en-US「一千個亮晶晶的小碎片」取代「好多好多碎片」 |
| P09 | P09 | 猴子們濕答答地坐在池塘邊。／皮皮低著頭，一句話都不說。 | The monkeys sat by the pond, dripping wet.／Pip hung his head. He didn't say a word. | 猴子們坐在池塘邊，渾身濕淋淋的。<br>皮皮垂下了頭。他一句話也沒說。 | 無 |
| P10 | P10 | 小不點一直坐在大樹上，東看看，西看看。／一抬頭——／「哇！你們看！月亮在天上！」 | Teeny was still up in the big tree, looking here, looking there.／She looked up and—／"Whoa! Look! The moon is in the sky!" | 小不點還在大樹上面，東看看、西看看。<br>她抬頭一看——<br>「哇！你們看！月亮在天上！」 | 無 |
| P11 | P11 | 猴子們抬頭看——月亮好好地掛在天上呢。／「原來月亮一直都在呀！」／再看看池塘…… 水靜了，月亮也回來了。 | All the monkeys looked up—the moon was right there, big and bright, hanging in the sky.／"It was up there the whole time!"／They looked at the pond… the water was still, and the moon was back. | 所有猴子都抬起頭——月亮就在那裡，又大又亮，掛在天上。<br>「月亮一直都在上面！」<br>他們看看池塘……水面平靜了，月亮又回來了。 | 輕微：en-US 加視覺修飾「又大又亮」（啟示放大） |
| P12 | P12 | 猴子們一起看月亮。／皮皮笑了：「多虧小不點！下次我也要先抬頭看一看。」／「嘻嘻！」／後來呀，每到月圓的晚上，猴子們都會一起坐在大樹上看月亮。那個最會看的，就是小不點。 | The monkeys sat together on the big branch, watching the moon.／Pip laughed. "Teeny, thank you! Next time, I'll look up first."／"Hee-hee!"／And from that day on, every full-moon night, the monkeys watched the moon together. And the best moon-watcher of all was Teeny. | 猴子們一起坐在大樹枝上，看著月亮。<br>皮皮笑了。「小不點，謝謝你！下次，我會先抬頭看。」<br>「嘻嘻！」<br>後來呀，每個月圓的夜晚，猴子們都一起看月亮。最會看月亮的是誰呢？就是小不點。 | 輕微：展開場景、感謝方式改直呼、收束句用反問修辭 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 月圓的晚上，好安靜好安靜。／皮皮低頭一看——／「哇！月亮掉到水裡了！」 | One full-moon night, Pip ran to the pond. He looked down—／"Whoa! The moon is in the water!" | 一個月圓的夜晚，皮皮跑到池塘邊。他往下一看——<br>「哇！月亮在水裡面！」 | 輕微：en-US 砍安靜鋪陳、加動作，核心發現保留 |
| P02 | P02 | 「快來撈月亮！」／猴子們嘰嘰喳喳跑過來。／小不點沒下來呢。 | "The moon fell in!" Pip shouted. "Let's scoop it out!"／The monkeys came running, chitter-chatter, chitter-chatter.／Teeny stayed up high, looking at the stars. | 「月亮掉下來了！」皮皮大喊。「我們把它撈出來！」<br>猴子們跑過來了，嘰嘰喳喳、嘰嘰喳喳。<br>小不點待在高高的上面，看著星星。 | 輕微：en-US 保留較多 rally 細節與 Teeny 伏筆 |
| P03 | P03 | 皮皮伸手往水裡一撈——／撈呀撈，撈月亮——嘩啦！碎了！／「啊！碎掉了！」 | Pip reached into the water—／Scoop, scoop, scoop the moon—SPLASH! It broke!／"Oh no! I broke the moon!" | 皮皮把手伸進水裡——<br>撈呀、撈呀、撈月亮——嘩啦！碎掉了！<br>「糟糕！我把月亮弄碎了！」 | 無 |
| P04 | P05 | 月亮回來了。「大家一起，輕輕撈！」／撈呀撈，撈月亮——嘩啦！碎了！ | The moon came back… but Pip had a new idea.／Three monkeys leaned in, ever so gently—／Scoop, scoop, scoop the moon—SPLASH! It broke!／"It broke again! What do we do?" | 「大家，過來！我們來搭最長的鏈！」皮皮說。<br>猴子們一個接一個，從大樹枝上掛下來。<br>晃呀晃、晃呀晃……<br>小不點坐在最上面。「你最輕——不要動！」 | 輕微：en-US 橋接 P06 跳接，加 rallying 句與對話 |
| P05 | P07 | 猴子們排成好長好長的鏈子。／晃呀晃，晃呀晃……／小不點在最上面。 | "Everybody, come! We'll make the longest chain!" said Pip.／One by one, the monkeys hung from the big branch.／Swing and sway, swing and sway…／Teeny sat at the top. "You're the lightest—don't move!" | 猴子們坐在池塘邊，渾身濕淋淋的。<br>皮皮垂下了頭。他一句話也沒說。 | 無 |
| P06 | P08 | 撈呀撈，撈月亮——嘩啦！碎了！／撲通！撲通！猴子們全掉進水裡了！ | The bottom monkey reached down—／Scoop, scoop, scoop the moon—SPLASH! It broke!／It broke into a thousand pieces!／SPLOOSH! SPLOOSH! Everyone fell in! | 小不點還在樹上面，東看看、西看看。<br>她抬頭一看——<br>「你們看！月亮在天上！」 | 無 |
| P07 | P09 | 猴子們濕答答地坐在池塘邊。／皮皮低著頭，一句話都不說。 | The monkeys sat by the pond, dripping wet.／Pip hung his head. He didn't say a word. | 猴子們抬頭一看——月亮在天上！<br>「一直都在上面！」<br>他們看看池塘……月亮又回來了。 | 輕微：en-US 保留池塘月影回來句（zh-TW 3-5 砍此句） |
| P08 | P10 | 小不點坐在大樹上，東看看，西看看。／一抬頭——／「哇！月亮在天上！」 | Teeny was still up in the tree, looking here, looking there.／She looked up—／"Look! The moon is in the sky!" | 猴子們一起坐著，看著月亮。<br>皮皮笑了。「小不點，謝謝你！下次，我會先抬頭看。」<br>「嘻嘻！」<br>後來呀，猴子們都一起看月亮。最會看月亮的是誰呢？就是小不點。 | 輕微：感謝方式改直呼、收束句用反問修辭 |
| P09 | P11 | 猴子們抬頭看——月亮好好地掛在天上呢。／「原來月亮一直都在呀！」 | The monkeys looked up—the moon was in the sky!／"Up there the whole time!"／They looked at the pond… the moon was back. | （缺） | — |
| P10 | P12 | 猴子們一起看月亮。／「多虧小不點！」「嘻嘻！」／「下次我也要先抬頭看一看。」／後來呀，猴子們都會坐在大樹上看月亮。最會看的，就是小不點。 | The monkeys sat together, watching the moon.／Pip laughed. "Teeny, thank you! Next time, I'll look up first."／"Hee-hee!"／And from that day on, the monkeys watched the moon together. The best moon-watcher of all was Teeny. | （缺） | — |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 月亮好圓好圓。／「月亮掉到水裡了！」皮皮喊。 | Full-moon night!／Pip looked in the pond—／"Whoa! The moon!" | 月圓的晚上！<br>皮皮看看池塘——<br>「哇！月亮！」 | 輕微：2-3 電報式改編各走各路，核心「發現月亮」保留 |
| P02 | P02 | 「快來撈月亮！」／猴子們跑過來。嘰嘰喳喳！ | "Moon fell in! Let's scoop it out!"／The monkeys came running. | 「月亮掉下來了！我們把它撈出來！」<br>猴子們跑過來了。 | 輕微：en-US 加「Moon fell in!」、砍嘰嘰喳喳 |
| P03 | P03 | 皮皮伸手一撈——／撈呀撈，撈月亮——嘩啦！碎了！ | Pip reached in—／Scoop, scoop, scoop the moon—SPLASH! It broke! | 皮皮伸手進去——<br>撈呀、撈呀、撈月亮——嘩啦！碎掉了！ | 無 |
| P04 | P07 | 猴子們排成好長好長的鏈子。／晃呀晃，晃呀晃…… | All the monkeys made a long, long chain!／Swing and sway, swing and sway… | 大家都抬頭看。<br>「月亮！一直都在那裡！」 | 無 |
| P05 | P08 | 撈呀撈，撈月亮——嘩啦！碎了！／撲通！撲通！掉進水裡了！ | Scoop, scoop, scoop the moon—SPLASH! It broke!／SPLOOSH! Everyone fell in! | 猴子們坐在一起。「嘻嘻！」<br>後來呀，他們都一起看月亮。 | 輕微：en-US 加「猴子們坐在一起」同框句 |
| P06 | P10 | 小不點抬頭一看——／「月亮在天上！」 | Teeny looked up.／"Look! The moon! Up in the sky!" | （缺） | — |
| P07 | P11 | 猴子們抬頭看——／月亮在天上呢！／「原來月亮在天上呀！」 | Everybody looked up.／"The moon! It was there the whole time!" | （缺） | — |
| P08 | P12 | 嘻嘻！／後來呀，猴子們都坐在大樹上看月亮。 | The monkeys sat together. "Hee-hee!"／And from that day on, they watched the moon. | （缺） | — |

## 三、QA 摘要（qa/en-US）

- `qa/en-US/round1.md`：round 1／verdict pass

最新 round：`qa/en-US/round1.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: monkeys-fishing-for-the-moon
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-31"
step1_lint: {exit_code: 0, warnings: 10}
step2_checklist: {pass: 28, fail: 0}
step3_mode: consolidated
step3_personas: []
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

### ESL 獵手發現（原文引用）

### ESL 獵手

逐頁全量掃描（en-US spec 雷區 + style_guide §3.4 四型）：

| 頁 | ESL calque | AI 機械句 | 判定 |
|---|---|---|---|
| 5-6 全 12 頁 | 無 | 無 | ✓ |
| 3-5 全 10 頁 | 無 | 無 | ✓ |
| 2-3 全 8 頁 | 無 | 2-3 電報式在合法邊界內（R2-7） | ✓ |

零 ESL 痕跡：無中文語序直譯、無 measure word 滲漏、無 of-pile-up、無 Chinese-pattern conjunctions。§3.4 四型零命中。

## 四、⏸️ 上呈批次

- （`qa/en-US/round1.md`）零發現。✅=0 ❌=0 ⏸️=0。
- （`qa/en-US/round1.md`）S4A v0.15：見 STEP 2 合併審查。✅=0 ❌=0 ⏸️=0。一輪收斂。

