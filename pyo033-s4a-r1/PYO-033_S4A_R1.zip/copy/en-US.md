# Copy Table: Who Hid the Seeds? (who-hid-the-seeds / en-US)

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: who-hid-the-seeds
locale: en-US
mode: B
storyboard: content/PYO-033_who-hid-the-seeds/PYO-033_storyboard.md
design: content/PYO-033_who-hid-the-seeds/PYO-033_design.md
image_pool: 14
selection:
  "3-5": [P01, P02, P03, P04, P05, P06, P07, P08, P11, P12, P13, P14]
  "2-3": [P01, P02, P04, P06, P08, P11, P13, P14]
commitments:
  refrain: "Not here, not here!"
  refrain_variation: "Right here!"
  ending: "And from that day on"
  onomatopoeia: [ACHOO!, THWIP!, "swish, swish, swish!", SPLAT!, "scritch, scritch, scritch"]
  brand_line: "Who's been hiding seeds around here?!"
characters: [Tuck, the little girl]
```

### B0 Frozen String Table

| # | Action | en-US frozen string | Type | Pages |
|---|---|---|---|---|
| O1 | sneeze | `ACHOO!` | O1 independent | 5-6 P04, 3-5 P04, 2-3 P03 |
| O2 | bur into mud | `THWIP!` | O1 independent | 5-6 P06, 3-5 P06 |
| O3 | tail shaking | `swish, swish, swish!` | O3 rhythm | 5-6 P06, 3-5 P06, 2-3 P04 |
| O4 | bird dropping | `SPLAT!` | O1 independent | 5-6 P08, 3-5 P08, 2-3 P05 |
| O5 | digging | `scritch, scritch, scritch` | O3 rhythm | 5-6 P13, 3-5 P11, 2-3 P07 |

### B0 Refrain Design

- **Negative**: `Not here, not here!` — two-beat denial, 3-year-old singalong rhythm. Appears at P04, P06, P08 (all tiers). In 5-6/3-5: quoted as Tuck's dialogue. In 2-3: unquoted rhythmic statement.
- **Positive variation**: `Right here!` with escalation. 5-6 P12: `"Right here! And here! And over there too!"` (three-station callback). 3-5 P12: `"Right here! And here too!"`. 2-3 P11: `Right here, right here!` (two-beat mirror).

### B0 Character Voice Cards

- **Tuck** (squirrel): Energetic, breathless, lots of exclamations. Confidence at P01 collapses through body comedy (P04-P08). Self-deprecating warmth at ending. Short sentences, action-heavy. Hallmark: physical reactions before verbal ones (rubs nose THEN says refrain).
- **The little girl** (5-6 only, P10): Cheerful, matter-of-fact. One line about planting flowers — a mirror to Tuck's unconscious seed-hiding.

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | It was fall, and Tuck had a very big job.<br>He hid acorns all over the forest — one under a rock, one by a bush, one inside a log.<br>"I'll remember every single one!" he said. | 36✓ | 1 | Tuck hid acorns all over the forest.<br>One here, one there, one everywhere.<br>"I'll remember every one!" he said. | 19✓ | 1 | Tuck hid acorns all over the forest.<br>One here. One there. | 11✓ | ✓ | 5-6: Fall opener + three-location list builds the hiding montage + confident promise sets up irony. 3-5: Drops season frame, keeps three-beat list ("one here, one there, one everywhere") + shortened promise. 2-3: Two-beat fragments only, no dialogue (irony setup unnecessary for age band). |
| P02 | 2 | Spring came, and Tuck poked his head out of his big cozy tree.<br>He stretched out a biiiiig yawn and rubbed his eyes.<br>"Hmm… where did I put my acorns?"<br>He couldn't remember. Not a single one. | 37✓ | 2 | Spring came, and Tuck poked his head out of his tree.<br>He yawned a biiiiig yawn.<br>"Where did I put my acorns?"<br>He couldn't remember. | 25✓ | 2 | Spring!<br>Where are Tuck's acorns?<br>He forgot. He forgot them all. | 11✓ | ✓ | 5-6: Slow wake-up (cozy tree, stretch, rub eyes) + "biiiiig" vowel stretch (O2) + double "not a single one" echo from P01. 3-5: Keeps "biiiiig" for continuity, drops eye-rubbing and final echo. 2-3 (jump P02→P04): Telegram style, "He forgot. He forgot them all." = two-beat revelation. Jump self-sufficient: "forgot" directly connects to P04 sneeze comedy. |
| P03 | 3 | Tuck ran to the meadow and dug and dug.<br>White dandelion fluff floated all around, drifting right into his nose.<br>"Ah… ah… ah—" | 23✓ | 3 | Tuck ran to the meadow and dug and dug.<br>Dandelion fluff floated right into his nose.<br>"Ah… ah… ah—" | 19✓ | — | — | — | ✓ | Buildup page: search action + dandelion-in-nose sensory setup + frozen sneeze buildup. 5-6: "White" + "all around, drifting" adds visual detail. 3-5: Trims sensory detail, keeps core buildup. 2-3 skips this page. |
| P04 | 4 | ACHOO!<br>Dandelion seeds burst into the air like tiny fireworks.<br>Tuck rubbed his red, red nose.<br>"Not here, not here!" | 20✓ | 4 | ACHOO!<br>Tuck rubbed his red, red nose.<br>"Not here, not here!" | 11✓ | 3 | ACHOO!<br>Tuck rubbed his red, red nose.<br>Not here, not here! | 11✓ | ✓ | Refrain first appearance. 5-6: Firework simile for dandelion burst. 3-5: Drops simile, straight to refrain. 2-3 (jump P02→P04): Telegram, sneeze→rub→refrain three-beat self-sufficient. Refrain unquoted in 2-3 (rhythmic echo, not dialogue). |
| P05 | 5 | Tuck crawled into the bushes and searched all around.<br>Prickly little burs crept onto his big fluffy tail, one by one.<br>"Hey… why does my tail feel so tickly?" | 29✓ | 5 | Tuck crawled into the bushes and searched.<br>Prickly burs crept onto his big fluffy tail.<br>"Why does my tail feel so tickly?" | 22✓ | — | — | — | ✓ | Buildup page: bur-on-tail tactile setup + tickle awareness. 5-6: "one by one" builds creeping suspense + "Hey…" interjection shows dawning realization. 3-5: Shorter, drops "one by one" and interjection. 2-3 skips this page. |
| P06 | 6 | swish, swish, swish! Tuck shook and spun like a top that wouldn't stop.<br>A few burs flew off — THWIP! — and stuck right in the mud.<br>His tail still had a whole bunch left.<br>"Not here, not here!" | 37✓ | 6 | swish, swish, swish! Tuck shook and spun like a top.<br>The burs flew off — THWIP! — into the mud.<br>"Not here, not here!" | 22✓ | 4 | swish, swish, swish!<br>Tuck shook and shook.<br>Not here, not here! | 11✓ | ✓ | Refrain second appearance. 5-6: Spinning-top simile extended ("wouldn't stop") + residual burs for humor. 3-5: Keeps simile core, drops residual detail. 2-3 (jump P04→P06): Telegram, onomatopoeia→futile shaking→refrain. Jump self-sufficient: "swish, swish, swish!" sound-leads directly. |
| P07 | 7 | Tuck ran to the big fruit tree and looked up.<br>A little bird sat on a branch, tilting its head at him.<br>Above Tuck's head, something gooey was falling down—<br>It was about to land! | 35✓ | 7 | Tuck ran to the big fruit tree and looked up.<br>Above his head, something was falling down—<br>It was about to land! | 22✓ | — | — | — | ✓ | Buildup page: action-freeze page-turn hook. 5-6: Bird witness + "gooey" tactile foreshadowing. 3-5: Drops bird, keeps suspense hook. 2-3 skips this page. |
| P08 | 8 | SPLAT!<br>Tuck rubbed the top of his head, grumbling. So sticky.<br>He opened his paw — inside was one tiny little seed.<br>"Who's been hiding seeds around here?!"<br>"Not here, not here!" | 31✓ | 8 | SPLAT!<br>Tuck rubbed his head, grumbling. So sticky.<br>In his paw — one tiny little seed.<br>"Who's been hiding seeds around here?!"<br>"Not here, not here!" | 25✓ | 5 | SPLAT!<br>"Who's been hiding seeds around here?!"<br>Not here, not here! | 11✓ | ✓ | Refrain third (most frustrated). Brand line "Who's been hiding seeds around here?!" echoes title — must be quoted as Tuck's speech (gate2 brand red line). 5-6: Full discovery sequence (rub→sticky→open paw→seed). 3-5: Compressed dash rhythm. 2-3 (jump P06→P08): Telegram, drops sticky/seed detail (image carries it), SPLAT→brand line→refrain. 21⚠ rationale for zh-TW; en-US within band at 11. |
| P09 | 9 | Tuck sat by the path, his tail drooping.<br>Sticky stuff on his head, burs still on his tail — what a mess.<br>Far away, a little girl knelt by a garden, digging and digging.<br>Tuck tilted his head: What is she doing? | 41⚠ | — | — | — | — | — | — | ✓ | 5-6 only. Deflation + mirror-character introduction. "What is she doing?" = character-perspective inner thought (not narrator question). 41⚠: Must establish deflated state + mess recap + girl introduction + curiosity in one page since 3-5/2-3 skip entirely. |
| P10 | 10 | The little girl patted her hands and stood up.<br>"Next year, this spot will be full of flowers!"<br>Tuck tilted his head: Is she hiding seeds too? Just like me? | 30✓ | — | — | — | — | — | — | ✓ | 5-6 only. Cross-species mirror: girl plants flowers consciously, Tuck hides acorns unconsciously. Suspense hook: unresolved question carries to P11. |
| P11 | 11 | Tuck ran back to the old oak tree.<br>Right by his feet, a row of tiny green sprouts poked out of the ground.<br>He crouched down and pressed his nose close—<br>It smelled like acorns! | 35✓ | 9 | Tuck ran back to the old oak tree.<br>A row of tiny sprouts poked out by his feet.<br>He sniffed — it smelled like acorns! | 24✓ | 6 | Tuck ran back.<br>Little sprouts popped up!<br>Right here, right here! | 11✓ | ✓ | Climax page. 5-6: Full sensory discovery (crouched + pressed nose + smell). 3-5: Compressed to "sniffed" but keeps olfactory payoff. 2-3 (jump P08→P11): Telegram, "Tuck ran back" bridges frustration→discovery; refrain variation "Right here, right here!" flips negative to positive (zh-TW "就是這裡" moved here since P12 skipped). |
| P12 | 12 | Tuck stood up and looked back the way he came.<br>The meadow, the bushes, the big fruit tree — every single spot had little oak saplings swaying in the breeze.<br>"Right here! And here! And over there too!"<br>Oh… everyone had been hiding seeds all along. | 45⚠ | 10 | Tuck looked back.<br>Every spot had little oak saplings swaying in the breeze.<br>"Right here! And here too!"<br>Everyone had been hiding seeds all along. | 25✓ | — | — | — | ✓ | Refrain variation (negative→positive flip). 5-6: Three-station named callback (meadow/bushes/fruit tree) + three-part escalation + thematic revelation. 45⚠: Three-station callback + refrain variation + revelation = structural requirements. 3-5: Drops station names, keeps variation + revelation. 2-3 skips (variation moved to P11). |
| P13 | 13 | Tuck hugged the nearest little sapling.<br>The sapling swayed its leaves and brushed his nose.<br>He pulled out one last acorn and dug a tiny hole.<br>scritch, scritch, scritch — he covered it gently with dirt.<br>"This time… well, I'll probably forget again!" | 42⚠ | 11 | Tuck hugged the little sapling.<br>It brushed his nose with a leaf.<br>He buried his last acorn. scritch, scritch, scritch.<br>"I'll probably… forget again!" | 24✓ | 7 | The sapling brushed Tuck's nose.<br>scritch, scritch, scritch.<br>"I'll forget again!" | 11✓ | ✓ | Ending ② gentle exchange (nose-brush) + ending ③ forward-intent (self-deprecating "forget again"). 5-6: Full sequence — hug + sapling response + dig + onomatopoeia + self-deprecation. 42⚠: Five-beat emotional closure (hug/touch/bury/sound/quip) all structural. 3-5: Compressed to four beats. 2-3: Telegram three-beat — nose-brush→dig sound→quip. |
| P14 | 14 | And from that day on, Tuck still couldn't remember where he'd hidden his acorns.<br>But every spring, little oak trees sprouted everywhere he'd been.<br>The wind blew softly through the forest. Everyone was hiding seeds. | 35✓ | 12 | And from that day on, Tuck still couldn't remember.<br>But every spring, little oak trees sprouted everywhere he'd been. | 19✓ | 8 | And from that day on—<br>Little trees grew everywhere! | 9✓ | ✓ | Ending ④ fixed closure "And from that day on" (brand_frozen_unit, exempt max_sentence_len). 5-6: Three-sentence closure — ironic echo (still can't remember) + hopeful consequence + universal echo. 3-5: Two-sentence closure, drops wind/universal echo (P12 "everyone" already said). 2-3: Telegram closure, em dash bridges formula to image. |
