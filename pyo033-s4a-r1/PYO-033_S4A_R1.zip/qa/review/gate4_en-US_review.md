# 關卡4整合審閱：誰把種子藏起來？（S4 證據包／en-US）

- 生成時間：2026-07-31 13:53:09 +0800
- 書目錄：`content/PYO-033_who-hid-the-seeds`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：en-US
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-033_storyboard.md` | 2026-07-30 11:43:00 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-31 12:02:23 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-31 13:38:23 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-31 12:02:23 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-31 13:38:32 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-31 12:02:23 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-31 13:38:36 |
| qa/en-US/backtranslation.md | `qa/en-US/backtranslation.md` | 2026-07-31 13:52:54 |
| qa/en-US round | `qa/en-US/round1.md` | 2026-07-31 13:49:00 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | en-US 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 14 | 14 頁有文 | 14 頁有文 | 14/14 | 9 |
| 3-5 | 12 | 12 頁有文 | 12 頁有文 | 12/12 | 5 |
| 2-3 | 8 | 8 頁有文 | 8 頁有文 | 8/8 | 5 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 秋天到了，咚咚忙得不得了。／他抱著橡實跑呀跑，這邊塞一顆，那邊埋一顆。／「我一定記得！每一顆，都記得！」 | It was fall, and Tuck had a very big job.／He hid acorns all over the forest — one under a rock, one by a bush, one inside a log.／"I'll remember every single one!" he said. | 秋天到了，塔克有一個很重要的工作。<br>他把橡果藏遍了整座森林——一顆在石頭下面、一顆在灌木旁邊、一顆塞進樹洞裡。<br>「我會記住每一顆的！」他說。 | 輕微：en-US 列三處具體藏點（rock/bush/log），zh-TW 用「這邊/那邊」泛指；「很重要的工作」vs「忙得不得了」敘述角度不同但語義到位；角色名 Tuck/塔克 為設計改編 |
| P02 | P02 | 春天來了，咚咚從大大的樹洞裡探出頭。／他打了一個大大的哈欠，伸了一個長長的懶腰。／「嗯……我的橡實藏在哪裡呢？」／想不起來了。一顆也想不起來。 | Spring came, and Tuck poked his head out of his big cozy tree.／He stretched out a biiiiig yawn and rubbed his eyes.／"Hmm… where did I put my acorns?"／He couldn't remember. Not a single one. | 春天來了，塔克從他又大又舒服的樹洞裡探出頭來。<br>他伸了一個大～～～懶腰，打了個好大的哈欠，揉揉眼睛。<br>「嗯……我把橡果放哪裡了？」<br>他想不起來了。一顆都想不起來。 | 輕微：en-US 加「cozy/舒服」感官詞、「rubbed his eyes/揉揉眼睛」動作（zh-TW 用「長長的懶腰」替代）；醒來＋遺忘核心到位 |
| P03 | P03 | 咚咚跑到草地上，翻呀翻，挖呀挖。／蒲公英白白的飛絮飄呀飄，飄進他的鼻子裡。／「哈、哈、哈——」 | Tuck ran to the meadow and dug and dug.／White dandelion fluff floated all around, drifting right into his nose.／"Ah… ah… ah—" | 塔克跑到草地上，拼命挖呀挖。<br>白色的蒲公英絨毛到處飄，一路飄進了他的鼻子裡。<br>「啊……啊……啊——」 | 無 |
| P04 | P04 | 「哈啾！」／蒲公英的種子像煙火，漫天飛。／咚咚揉著紅紅的鼻子：／「不是這裡，不是這裡！」 | ACHOO!／Dandelion seeds burst into the air like tiny fireworks.／Tuck rubbed his red, red nose.／"Not here, not here!" | 哈啾！<br>蒲公英的種子像小小的煙火一樣炸開在空中。<br>塔克揉了揉他紅通通的鼻子。<br>「不在這裡，不在這裡！」 | 輕微：疊句回譯「不在這裡」vs 母本「不是這裡」——動詞選擇不同（在/是），均為合法否定位置表述，屬改編非翻譯的必然現象 |
| P05 | P05 | 咚咚鑽進灌木叢裡，翻呀翻，找呀找。／毛茸茸的蒼耳子，一顆一顆悄悄黏上他蓬蓬的大尾巴。／「咦？尾巴怎麼癢癢的？」 | Tuck crawled into the bushes and searched all around.／Prickly little burs crept onto his big fluffy tail, one by one.／"Hey… why does my tail feel so tickly?" | 塔克鑽進灌木叢裡到處翻找。<br>帶刺的小毛球一顆一顆悄悄爬上了他蓬鬆的大尾巴。<br>「奇怪……我的尾巴怎麼癢癢的？」 | 無 |
| P06 | P06 | 唰唰唰！咚咚甩呀甩，轉呀轉，像陀螺停不下來。／幾顆蒼耳掉了——咻！扎進泥巴裡。／尾巴上還掛著一串呢。／「不是這裡，不是這裡！」 | swish, swish, swish! Tuck shook and spun like a top that wouldn't stop.／A few burs flew off — THWIP! — and stuck right in the mud.／His tail still had a whole bunch left.／"Not here, not here!" | 唰唰唰！塔克像陀螺一樣又甩又轉，停都停不下來。<br>幾顆毛球飛了出去——咻！——直接黏在泥巴上。<br>他的尾巴上還剩下一大堆。<br>「不在這裡，不在這裡！」 | 輕微：同 P04 疊句偏移（不在/不是） |
| P07 | P07 | 咚咚跑到大果樹下，抬起頭翻找。／一隻小鳥在枝頭歪著頭看他。／頭頂上，一坨黏答答的東西正在往下掉——／快砸到了！ | Tuck ran to the big fruit tree and looked up.／A little bird sat on a branch, tilting its head at him.／Above Tuck's head, something gooey was falling down—／It was about to land! | 塔克跑到大果樹下，抬頭往上看。<br>一隻小鳥坐在樹枝上，歪著頭看著他。<br>在塔克的頭頂上方，有個黏糊糊的東西正在掉下來——<br>就要砸到了！ | 無 |
| P08 | P08 | 啪嗒！／咚咚氣呼呼地擦頭頂。黏黏的，擦不掉。／他攤開手掌——裡面有一顆小小的種子。／「到底是誰把種子藏起來了！」／「不是這裡，不是這裡！」 | SPLAT!／Tuck rubbed the top of his head, grumbling. So sticky.／He opened his paw — inside was one tiny little seed.／"Who's been hiding seeds around here?!"／"Not here, not here!" | 啪嗒！<br>塔克摸著頭頂，嘟嘟囔囔。好黏喔。<br>他打開手掌——裡面是一顆小小的種子。<br>「到底是誰在這裡藏種子啊？！」<br>「不在這裡，不在這裡！」 | 輕微：品牌紅線回譯「到底是誰在這裡藏種子啊？！」vs 母本「到底是誰把種子藏起來了！」——句式不同但書名呼應到位；疊句同 P04 |
| P09 | P09 | 咚咚垂著尾巴，坐在路邊。／頭上黏著東西，尾巴掛著蒼耳，好累好累。／遠遠的，有一個小妹妹蹲在花圃旁邊，挖呀挖。／咚咚歪著頭看：她在做什麼呀？ | Tuck sat by the path, his tail drooping.／Sticky stuff on his head, burs still on his tail — what a mess.／Far away, a little girl knelt by a garden, digging and digging.／Tuck tilted his head: What is she doing? | 塔克坐在路邊，尾巴耷拉著。<br>頭上黏黏的，尾巴上還掛著毛球——真是一團糟。<br>遠遠的地方，一個小女孩蹲在花園旁邊，挖呀挖。<br>塔克歪著頭：她在做什麼呢？ | 輕微：en-US "what a mess/真是一團糟" vs zh-TW "好累好累"——物理狀態描述 vs 疲憊感受，均指向洩氣情緒；小女孩介紹＋好奇到位 |
| P10 | P10 | 小妹妹拍拍手，站了起來。／「明年呀，這裡會開好多好多花喔！」／咚咚歪著頭：她也在藏種子嗎？跟我一樣？ | The little girl patted her hands and stood up.／"Next year, this spot will be full of flowers!"／Tuck tilted his head: Is she hiding seeds too? Just like me? | 小女孩拍拍手站了起來。<br>「明年，這裡就會開滿花了！」<br>塔克歪著頭：她也在藏種子嗎？跟我一樣？ | 輕微：「開滿花」vs zh-TW「好多好多花喔」——程度表達不同，語義到位 |
| P11 | P11 | 咚咚跑回老橡樹下。／腳邊冒出了一排小小的嫩芽。／他蹲下來，把鼻子湊得近近的——／是橡實的味道！ | Tuck ran back to the old oak tree.／Right by his feet, a row of tiny green sprouts poked out of the ground.／He crouched down and pressed his nose close—／It smelled like acorns! | 塔克跑回那棵老橡樹旁。<br>就在他的腳邊，一排小小的綠色嫩芽從泥土裡探了出來。<br>他蹲下來，把鼻子湊近——<br>聞起來像橡果！ | 無 |
| P12 | P12 | 咚咚站起來，轉身回望。／草地上、灌木叢邊、大果樹旁——／每一站，都有小小的橡樹苗，在風裡搖呀搖。／「就是這裡！這裡也是！那裡也是！」／原來呀，大家都在藏種子呢。 | Tuck stood up and looked back the way he came.／The meadow, the bushes, the big fruit tree — every single spot had little oak saplings swaying in the breeze.／"Right here! And here! And over there too!"／Oh… everyone had been hiding seeds all along. | 塔克站起來，回頭看看他一路走來的地方。<br>草地上、灌木叢裡、大果樹旁——每一個地方都有小小的橡樹苗在微風中搖啊搖。<br>「在這裡！還有這裡！那邊也是！」<br>噢……原來大家一直都在藏種子啊。 | 輕微：疊句變奏「在這裡」vs 母本「就是這裡」——到位；「一直都在」vs zh-TW 無此詞組（en-US "all along" 增加時間強調），語義到位 |
| P13 | P13 | 咚咚摟了一下最近的小樹苗。／小樹苗搖著葉子，碰了碰他的鼻子。／他掏出最後一顆橡實，挖了一個小小的洞。／沙沙沙，把土輕輕蓋上。／「這次嘛……嗯，我大概還是會忘記吧！」 | Tuck hugged the nearest little sapling.／The sapling swayed its leaves and brushed his nose.／He pulled out one last acorn and dug a tiny hole.／scritch, scritch, scritch — he covered it gently with dirt.／"This time… well, I'll probably forget again!" | 塔克抱住了最近的那棵小樹苗。<br>小樹苗搖搖葉子，刷了一下他的鼻子。<br>他拿出最後一顆橡果，挖了一個小小的洞。<br>沙沙沙——他輕輕用泥土蓋好。<br>「這一次嘛……嗯，我大概還是會忘記吧！」 | 無 |
| P14 | P14 | 後來呀，咚咚還是記不住橡實藏在哪裡。／可是每年春天，他跑過的地方，都會長出新的小樹。／風輕輕吹過森林，大家都在藏種子呢。 | And from that day on, Tuck still couldn't remember where he'd hidden his acorns.／But every spring, little oak trees sprouted everywhere he'd been.／The wind blew softly through the forest. Everyone was hiding seeds. | 從那天起，塔克還是記不住他把橡果藏在哪裡。<br>但是每到春天，他走過的每個地方都會冒出小小的橡樹。<br>風輕輕吹過森林。大家都在藏種子。 | 輕微：收束式「從那天起」vs zh-TW「後來呀」——各 locale 獨立收束式設計（en-US "And from that day on" 為 brand frozen unit） |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 咚咚抱著小果子跑呀跑。／這邊塞一顆，那邊埋一顆。／「我一定記得！」 | Tuck hid acorns all over the forest.／One here, one there, one everywhere.／"I'll remember every one!" he said. | 塔克把橡果藏遍了整座森林。<br>這裡一顆，那裡一顆，到處都是。<br>「我會記住每一顆的！」他說。 | 無 |
| P02 | P02 | 春天來了，咚咚從樹洞裡探出頭。／他打了一個大大的哈欠。／「我的小果子藏在哪裡呢？」／想不起來了。 | Spring came, and Tuck poked his head out of his tree.／He yawned a biiiiig yawn.／"Where did I put my acorns?"／He couldn't remember. | 春天來了，塔克從樹洞裡探出頭來。<br>他打了一個大～～～哈欠。<br>「我把橡果放哪裡了？」<br>他想不起來了。 | 無 |
| P03 | P03 | 咚咚跑到草地上，翻呀翻，挖呀挖。／蒲公英的毛毛飄進他的鼻子裡。／「哈、哈、哈——」 | Tuck ran to the meadow and dug and dug.／Dandelion fluff floated right into his nose.／"Ah… ah… ah—" | 塔克跑到草地上，挖呀挖。<br>蒲公英的絨毛飄進了他的鼻子裡。<br>「啊……啊……啊——」 | 無 |
| P04 | P04 | 「哈啾！」／咚咚揉著紅紅的鼻子：／「不是這裡，不是這裡！」 | ACHOO!／Tuck rubbed his red, red nose.／"Not here, not here!" | 哈啾！<br>塔克揉了揉他紅通通的鼻子。<br>「不在這裡，不在這裡！」 | 輕微：同 5-6 P04 疊句偏移 |
| P05 | P05 | 咚咚鑽進矮樹叢裡翻找。／刺刺的小球球悄悄黏上他大大的尾巴。／「尾巴怎麼癢癢的？」 | Tuck crawled into the bushes and searched.／Prickly burs crept onto his big fluffy tail.／"Why does my tail feel so tickly?" | 塔克鑽進灌木叢裡到處找。<br>帶刺的毛球爬上了他蓬鬆的大尾巴。<br>「我的尾巴怎麼癢癢的？」 | 無 |
| P06 | P06 | 唰唰唰！咚咚甩呀甩，像陀螺停不下來。／蒼耳掉了——咻！扎進泥巴裡。／「不是這裡，不是這裡！」 | swish, swish, swish! Tuck shook and spun like a top.／The burs flew off — THWIP! — into the mud.／"Not here, not here!" | 唰唰唰！塔克像陀螺一樣又甩又轉。<br>毛球飛了出去——咻！——飛進泥巴裡。<br>「不在這裡，不在這裡！」 | 輕微：同 5-6 P04 疊句偏移 |
| P07 | P07 | 咚咚跑到大果樹下，抬起頭翻找。／頭頂上，有東西正在往下掉——／快砸到了！ | Tuck ran to the big fruit tree and looked up.／Above his head, something was falling down—／It was about to land! | 塔克跑到大果樹下，抬頭往上看。<br>在他的頭頂上方，有個東西正在掉下來——<br>就要砸到了！ | 無 |
| P08 | P08 | 啪嗒！／咚咚氣呼呼地擦頭頂，黏黏的。／手掌裡——一顆小小的種子。／「到底是誰把種子藏起來了！」／「不是這裡，不是這裡！」 | SPLAT!／Tuck rubbed his head, grumbling. So sticky.／In his paw — one tiny little seed.／"Who's been hiding seeds around here?!"／"Not here, not here!" | 啪嗒！<br>塔克摸著頭頂，嘟嘟囔囔。好黏喔。<br>他的手掌裡——一顆小小的種子。<br>「到底是誰在這裡藏種子啊？！」<br>「不在這裡，不在這裡！」 | 輕微：同 5-6 P08 品牌紅線＋疊句偏移 |
| P09 | P11 | 咚咚跑回老橡樹下。／腳邊冒出了一排小小的嫩芽。／他蹲下來聞了聞——／是小果子的味道！ | Tuck ran back to the old oak tree.／A row of tiny sprouts poked out by his feet.／He sniffed — it smelled like acorns! | 塔克抱住了小樹苗。<br>小樹苗用葉子刷了一下他的鼻子。<br>他把最後一顆橡果埋進土裡。沙沙沙。<br>「我大概……還是會忘記吧！」 | 無 |
| P10 | P12 | 咚咚轉身回望。／每一站，都有小小的橡樹苗在搖。／「就是這裡！這裡也是！」／原來呀，大家都在藏種子呢。 | Tuck looked back.／Every spot had little oak saplings swaying in the breeze.／"Right here! And here too!"／Everyone had been hiding seeds all along. | 從那天起，塔克還是記不住。<br>但是每到春天，他走過的每個地方都會冒出小小的橡樹。 | 輕微：同 5-6 P14 收束式偏移 |
| P11 | P13 | 咚咚摟了一下小樹苗。／小樹苗碰了碰他的鼻子。／他把最後一顆小果子埋進土裡。沙沙沙。／「我大概……還是會忘記吧！」 | Tuck hugged the little sapling.／It brushed his nose with a leaf.／He buried his last acorn. scritch, scritch, scritch.／"I'll probably… forget again!" | （缺） | — |
| P12 | P14 | 後來呀，咚咚還是記不住。／可是每年春天，他跑過的地方，都會長出新的小樹。 | And from that day on, Tuck still couldn't remember.／But every spring, little oak trees sprouted everywhere he'd been. | （缺） | — |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 咚咚抱著小果子跑呀跑。／這邊塞一顆，那邊埋一顆。 | Tuck hid acorns all over the forest.／One here. One there. | 塔克把橡果藏遍了整座森林。<br>這裡一顆。那裡一顆。 | 無 |
| P02 | P02 | 春天來了！／咚咚的小果子呢？／忘記了。全部忘記了。 | Spring!／Where are Tuck's acorns?／He forgot. He forgot them all. | 春天！<br>塔克的橡果在哪裡？<br>他忘了。全部都忘了。 | 無 |
| P03 | P04 | 哈啾！／咚咚揉著紅紅的鼻子。／不是這裡，不是這裡！ | ACHOO!／Tuck rubbed his red, red nose.／Not here, not here! | 唰唰唰！<br>塔克甩呀甩呀甩。<br>不在這裡，不在這裡！ | 輕微：同上 |
| P04 | P06 | 唰唰唰！／咚咚甩呀甩，甩不掉。／不是這裡，不是這裡！ | swish, swish, swish!／Tuck shook and shook.／Not here, not here! | 塔克跑回來。<br>小嫩芽冒出來了！<br>在這裡，在這裡！ | 輕微：疊句變奏「在這裡」vs 母本「就是這裡」 |
| P05 | P08 | 啪嗒！／「到底是誰把種子藏起來了！」／不是這裡，不是這裡！ | SPLAT!／"Who's been hiding seeds around here?!"／Not here, not here! | 從那天起——<br>到處都長出了小樹！ | 輕微：同 5-6 P14 收束式偏移 |
| P06 | P11 | 咚咚跑回來了。／小芽芽冒出來了！／就是這裡，就是這裡！ | Tuck ran back.／Little sprouts popped up!／Right here, right here! | （缺） | — |
| P07 | P13 | 小樹苗碰了碰咚咚的鼻子。／沙沙沙，埋好了。／「還是會忘記吧！」 | The sapling brushed Tuck's nose.／scritch, scritch, scritch.／"I'll forget again!" | （缺） | — |
| P08 | P14 | 後來呀——／到處長出了小樹！ | And from that day on—／Little trees grew everywhere! | （缺） | — |

## 三、QA 摘要（qa/en-US）

- `qa/en-US/round1.md`：round 1／verdict pass

最新 round：`qa/en-US/round1.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: who-hid-the-seeds
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-31"
step1_lint: {exit_code: 0, warnings: 7}
step2_checklist: {pass: 25, fail: 0}
step3_mode: consolidated
step3_personas: []
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

### ESL 獵手發現（原文引用）

#### ④ ESL 獵手

靶區＝en-US spec 雷區（ESL calque / 搭配 / 語序）＋style_guide §3.4 AI 機械句五型。

| 頁 | 掃描結果 | 說明 |
|---|---|---|
| 全 14 頁 | 無 ESL calque | 無中文語序滲漏；句法為原生 SVO；無 *"He is very happy" 型裸形容詞* |
| 全 14 頁 | 無 AI 機械句 | 無電報式裸動詞堆疊（2-3 電報式為 R7 合法設計）、無成分懸空、無超規律平行（P01 三段 parallel 為設計型列舉）、無無語氣詞乾句（interjections: "Hey…" "Hmm…" "Oh…"）、無詞組層過度壓縮 |
| 全 14 頁 | 無 banned BrE | 無 colour/favourite/grey/mum/tummy 等 |

## 四、⏸️ 上呈批次

- （`qa/en-US/round1.md`）本輪零發現。✅=0, ❌=0, ⏸️=0。一輪收斂。
- （`qa/en-US/round1.md`）S4A v0.15：見 STEP 2 合併審查（inline 分診第 7 步）。✅=0, ❌=0, ⏸️=0。

