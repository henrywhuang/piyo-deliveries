# 關卡WB整合審閱：誰把種子藏起來？（E 對位底稿／en-US）

- 生成時間：2026-07-31 13:45:26 +0800
- 書目錄：`content/PYO-033_who-hid-the-seeds`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate WB`（決定性腳本，純解析＋排版）
- locale：en-US
- 用途：E 主審與裁決 agent 的單檔輸入 bundle——文字＝QA 對象本體逐字轉錄；可疑頁保留開原檔抽驗權

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-033_storyboard.md` | 2026-07-30 11:43:00 |
| copy | `copy/en-US.md` | 2026-07-31 13:41:26 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-31 12:02:23 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-31 13:38:23 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-31 12:02:23 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-31 13:38:32 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-31 12:02:23 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-31 13:38:36 |
| qa/en-US/backtranslation.md | （缺） | — |

## 檔頭 commitments 逐字轉錄（兌現比對用）

```yaml
schema: piyo_copy/v0.9
slug: who-hid-the-seeds
locale: en-US
mode: B
storyboard: content/PYO-033_who-hid-the-seeds/PYO-033_storyboard.md
design: content/PYO-033_who-hid-the-seeds/PYO-033_design.md
image_pool: 14
selection:
  "3-5": [P01, P02, P03, P04, P05, P06, P07, P08, P11, P12, P13, P14]
  "2-3": [P01, P02, P04, P06, P08, P11, P13, P14]
commitments:
  refrain: "Not here, not here!"
  refrain_variation: "Right here!"
  ending: "And from that day on"
  onomatopoeia: [ACHOO!, THWIP!, "swish, swish, swish!", SPLAT!, "scritch, scritch, scritch"]
  brand_line: "Who's been hiding seeds around here?!"
characters: [Tuck, the little girl]
```

## 檔位 5-6（14 頁）

### 5-6｜P01（母版 P01）

- 圖說什麼：秋天金色的大森林，滿地落葉和橡實。咚咚抱著橡實跑來跑去，這邊塞一顆那邊埋一顆，蓬鬆大尾巴翹得比身體還高，得意洋洋。
- 文說什麼：交代秋天松鼠忙著把橡實藏遍森林，他信誓旦旦「一定記得」，為之後的全忘光埋反諷。
- 鉤子：視覺引導型：松鼠的動線和蓬鬆大尾巴帶向右方下一個藏寶點
- 選圖與提純說明：5-6: Fall opener + three-location list builds the hiding montage + confident promise sets up irony. 3-5: Drops season frame, keeps three-beat list ("one here, one there, one everywhere") + shortened promise. 2-3: Two-beat fragments only, no dialogue (irony setup unnecessary for age band).
- 匹配欄：✓

【zh-TW】
秋天到了，咚咚忙得不得了。
他抱著橡實跑呀跑，這邊塞一顆，那邊埋一顆。
「我一定記得！每一顆，都記得！」

【en-US】
It was fall, and Tuck had a very big job.
He hid acorns all over the forest — one under a rock, one by a bush, one inside a log.
"I'll remember every single one!" he said.

### 5-6｜P02（母版 P02）

- 圖說什麼：春天嫩芽冒出來了，咚咚從大橡樹的小樹洞探出頭，打個大哈欠伸懶腰。他歪著頭皺起眉，兩隻手空空的——完全想不起橡實藏在哪。
- 文說什麼：冬去春來的時間跳轉，松鼠醒來想吃橡實卻全忘了，決心出發先去草地找。
- 鉤子：懸念型：橡實全忘了，到底藏在哪裡？
- 選圖與提純說明：5-6: Slow wake-up (cozy tree, stretch, rub eyes) + "biiiiig" vowel stretch (O2) + double "not a single one" echo from P01. 3-5: Keeps "biiiiig" for continuity, drops eye-rubbing and final echo. 2-3 (jump P02→P04): Telegram style, "He forgot. He forgot them all." = two-beat revelation. Jump self-sufficient: "forgot" directly connects to P04 sneeze comedy.
- 匹配欄：✓

【zh-TW】
春天來了，咚咚從大大的樹洞裡探出頭。
他打了一個大大的哈欠，伸了一個長長的懶腰。
「嗯……我的橡實藏在哪裡呢？」
想不起來了。一顆也想不起來。

【en-US】
Spring came, and Tuck poked his head out of his big cozy tree.
He stretched out a biiiiig yawn and rubbed his eyes.
"Hmm… where did I put my acorns?"
He couldn't remember. Not a single one.

### 5-6｜P03（母版 P03）

- 圖說什麼：開闊春天草地，蒲公英白絮飄得滿天。咚咚趴在地上撅著屁股翻啊挖，臉都貼到草皮了。草地角落悄悄冒出小橡樹苗，他完全沒看到。
- 文說什麼：松鼠在草地翻找橡實的動作與落空，蒲公英白絮飄進鼻子的蓄勢描述。
- 鉤子：動作中斷型：蒲公英飛絮飄進鼻子，噴嚏蓄勢的瞬間凍結
- 選圖與提純說明：Buildup page: search action + dandelion-in-nose sensory setup + frozen sneeze buildup. 5-6: "White" + "all around, drifting" adds visual detail. 3-5: Trims sensory detail, keeps core buildup. 2-3 skips this page.
- 匹配欄：✓

【zh-TW】
咚咚跑到草地上，翻呀翻，挖呀挖。
蒲公英白白的飛絮飄呀飄，飄進他的鼻子裡。
「哈、哈、哈——」

【en-US】
Tuck ran to the meadow and dug and dug.
White dandelion fluff floated all around, drifting right into his nose.
"Ah… ah… ah—"

### 5-6｜P04（母版 P04）

- 圖說什麼：哈啾！一個炸開的大噴嚏把咚咚整隻彈起來，蒲公英種子像煙火漫天飛。他揉著通紅的鼻子瞇起眼，又嗆又狼狽。
- 文說什麼：噴嚏爆發的擬聲詞「哈啾」，揉鼻子斷定沒有橡實。疊句「不是這裡，不是這裡！」首次登場。
- 鉤子：視覺引導型：松鼠跑向灌木叢方向，飛散的蒲公英絮帶向頁緣
- 選圖與提純說明：Refrain first appearance. 5-6: Firework simile for dandelion burst. 3-5: Drops simile, straight to refrain. 2-3 (jump P02→P04): Telegram, sneeze→rub→refrain three-beat self-sufficient. Refrain unquoted in 2-3 (rhythmic echo, not dialogue).
- 匹配欄：✓

【zh-TW】
「哈啾！」
蒲公英的種子像煙火，漫天飛。
咚咚揉著紅紅的鼻子：
「不是這裡，不是這裡！」

【en-US】
ACHOO!
Dandelion seeds burst into the air like tiny fireworks.
Tuck rubbed his red, red nose.
"Not here, not here!"

### 5-6｜P05（母版 P05）

- 圖說什麼：光線斑駁的灌木叢裡，咚咚整個人鑽進去翻找，卡在枝條間。一堆毛茸茸的蒼耳子正悄悄黏上他的大尾巴。灌木根部也冒出小橡樹苗。
- 文說什麼：鑽進灌木叢翻找落空，蒼耳子悄悄黏上尾巴的觸感描述，蓄勢甩不掉的掙扎。
- 鉤子：動作中斷型：蒼耳子剛黏上大尾巴，松鼠驚覺但還沒開始甩
- 選圖與提純說明：Buildup page: bur-on-tail tactile setup + tickle awareness. 5-6: "one by one" builds creeping suspense + "Hey…" interjection shows dawning realization. 3-5: Shorter, drops "one by one" and interjection. 2-3 skips this page.
- 匹配欄：✓

【zh-TW】
咚咚鑽進灌木叢裡，翻呀翻，找呀找。
毛茸茸的蒼耳子，一顆一顆悄悄黏上他蓬蓬的大尾巴。
「咦？尾巴怎麼癢癢的？」

【en-US】
Tuck crawled into the bushes and searched all around.
Prickly little burs crept onto his big fluffy tail, one by one.
"Hey… why does my tail feel so tickly?"

### 5-6｜P06（母版 P06）

- 圖說什麼：咚咚拼命甩尾巴想把蒼耳甩掉，整隻松鼠轉圈圈像陀螺停不下來。幾顆蒼耳掉了紮進泥土，尾巴上還掛著一串。他氣鼓鼓的。
- 文說什麼：甩尾巴的擬聲詞「唰唰唰」與蒼耳黏上的「咻」。疊句「不是這裡，不是這裡！」第二次，氣得決定去大果樹下。
- 鉤子：視覺引導型：松鼠氣沖沖朝大果樹方向跑去
- 選圖與提純說明：Refrain second appearance. 5-6: Spinning-top simile extended ("wouldn't stop") + residual burs for humor. 3-5: Keeps simile core, drops residual detail. 2-3 (jump P04→P06): Telegram, onomatopoeia→futile shaking→refrain. Jump self-sufficient: "swish, swish, swish!" sound-leads directly.
- 匹配欄：✓

【zh-TW】
唰唰唰！咚咚甩呀甩，轉呀轉，像陀螺停不下來。
幾顆蒼耳掉了——咻！扎進泥巴裡。
尾巴上還掛著一串呢。
「不是這裡，不是這裡！」

【en-US】
swish, swish, swish! Tuck shook and spun like a top that wouldn't stop.
A few burs flew off — THWIP! — and stuck right in the mud.
His tail still had a whole bunch left.
"Not here, not here!"

### 5-6｜P07（母版 P07）

- 圖說什麼：果樹抽著新葉，枝上還掛著幾顆去年的乾果，一隻小鳥歪著頭看。咚咚在樹下抬頭翻找，尾巴上還掛著蒼耳。一坨黏呼呼的東西從天上掉下來，凍結在快砸到他頭頂的瞬間。
- 文說什麼：大果樹下翻找橡實落空，頭頂有東西掉下來的蓄勢——蓄到最高點，不揭示砸中。
- 鉤子：動作中斷型：黏呼呼的東西凍結在半空，快砸到松鼠頭頂
- 選圖與提純說明：Buildup page: action-freeze page-turn hook. 5-6: Bird witness + "gooey" tactile foreshadowing. 3-5: Drops bird, keeps suspense hook. 2-3 skips this page.
- 匹配欄：✓

【zh-TW】
咚咚跑到大果樹下，抬起頭翻找。
一隻小鳥在枝頭歪著頭看他。
頭頂上，一坨黏答答的東西正在往下掉——
快砸到了！

【en-US】
Tuck ran to the big fruit tree and looked up.
A little bird sat on a branch, tilting its head at him.
Above Tuck's head, something gooey was falling down—
It was about to land!

### 5-6｜P08（母版 P08）

- 圖說什麼：咚咚氣呼呼地擦頭頂，黏黏的東西沾在頭毛上弄不掉，尾巴的蒼耳還在。他攤開手掌，裡面有一顆小小的種子。他張嘴大叫，又氣又困惑。
- 文說什麼：被砸頭的「啪嗒」與擦頭狼狽，發現種子的困惑，大喊回扣書名。疊句第三次最激動。
- 鉤子：問句型：到底是誰把種子藏起來了？松鼠的困惑懸而未解
- 選圖與提純說明：Refrain third (most frustrated). Brand line "Who's been hiding seeds around here?!" echoes title — must be quoted as Tuck's speech (gate2 brand red line). 5-6: Full discovery sequence (rub→sticky→open paw→seed). 3-5: Compressed dash rhythm. 2-3 (jump P06→P08): Telegram, drops sticky/seed detail (image carries it), SPLAT→brand line→refrain. 21⚠ rationale for zh-TW; en-US within band at 11.
- 匹配欄：✓

【zh-TW】
啪嗒！
咚咚氣呼呼地擦頭頂。黏黏的，擦不掉。
他攤開手掌——裡面有一顆小小的種子。
「到底是誰把種子藏起來了！」
「不是這裡，不是這裡！」

【en-US】
SPLAT!
Tuck rubbed the top of his head, grumbling. So sticky.
He opened his paw — inside was one tiny little seed.
"Who's been hiding seeds around here?!"
"Not here, not here!"

### 5-6｜P09（母版 P09）

- 圖說什麼：森林邊緣的小花圃旁，木柵欄和翻好的春泥。咚咚耷拉著尾巴坐在路邊，頭上還黏著東西，尾巴掛著蒼耳。遠處一個扎辮子的小妹妹蹲著挖洞。
- 文說什麼：松鼠的洩氣與疲憊，注意到遠處小妹妹在泥巴裡挖洞——她在做什麼？
- 鉤子：視覺引導型：松鼠歪頭的視線引向遠處蹲著的小妹妹
- 選圖與提純說明：5-6 only. Deflation + mirror-character introduction. "What is she doing?" = character-perspective inner thought (not narrator question). 41⚠: Must establish deflated state + mess recap + girl introduction + curiosity in one page since 3-5/2-3 skip entirely.
- 匹配欄：✓

【zh-TW】
咚咚垂著尾巴，坐在路邊。
頭上黏著東西，尾巴掛著蒼耳，好累好累。
遠遠的，有一個小妹妹蹲在花圃旁邊，挖呀挖。
咚咚歪著頭看：她在做什麼呀？

【en-US】
Tuck sat by the path, his tail drooping.
Sticky stuff on his head, burs still on his tail — what a mess.
Far away, a little girl knelt by a garden, digging and digging.
Tuck tilted his head: What is she doing?

### 5-6｜P10（母版 P10）

- 圖說什麼：小妹妹拍拍手站起來，碎花洋裝沾著春泥，紅緞帶辮子晃啊晃。面前的小坑剛蓋好土。咚咚歪著頭蹲在一旁，瞪大眼睛盯著她看。
- 文說什麼：小妹妹說明年這裡會開花，松鼠的內心疑問——她在藏種子嗎？跟我一樣？
- 鉤子：懸念型：她在藏種子嗎？跟我一樣？松鼠的疑問未解
- 選圖與提純說明：5-6 only. Cross-species mirror: girl plants flowers consciously, Tuck hides acorns unconsciously. Suspense hook: unresolved question carries to P11.
- 匹配欄：✓

【zh-TW】
小妹妹拍拍手，站了起來。
「明年呀，這裡會開好多好多花喔！」
咚咚歪著頭：她也在藏種子嗎？跟我一樣？

【en-US】
The little girl patted her hands and stood up.
"Next year, this spot will be full of flowers!"
Tuck tilted his head: Is she hiding seeds too? Just like me?

### 5-6｜P11（母版 P11）

- 圖說什麼：咚咚跑回老橡樹下，腳邊冒出一整排小小的嫩芽。他蹲下來把鼻子湊近嫩芽，眼睛睜得圓圓的，尾巴僵在半空。嫩芽的葉子在春風裡輕輕搖。
- 文說什麼：松鼠聞到橡實的味道，驚訝地發現嫩芽——這些就是他忘掉的橡實長出來的。2-3 檔在本頁承接疊句變奏，從「不是這裡」翻轉為「就是這裡！」（5-6／3-5 仍在 P12）。
- 鉤子：視覺引導型：松鼠的視線從腳邊嫩芽向遠方森林展開
- 選圖與提純說明：Climax page. 5-6: Full sensory discovery (crouched + pressed nose + smell). 3-5: Compressed to "sniffed" but keeps olfactory payoff. 2-3 (jump P08→P11): Telegram, "Tuck ran back" bridges frustration→discovery; refrain variation "Right here, right here!" flips negative to positive (zh-TW "就是這裡" moved here since P12 skipped).
- 匹配欄：✓

【zh-TW】
咚咚跑回老橡樹下。
腳邊冒出了一排小小的嫩芽。
他蹲下來，把鼻子湊得近近的——
是橡實的味道！

【en-US】
Tuck ran back to the old oak tree.
Right by his feet, a row of tiny green sprouts poked out of the ground.
He crouched down and pressed his nose close—
It smelled like acorns!

### 5-6｜P12（母版 P12）

- 圖說什麼：咚咚站起來轉身回望。草地遠處、灌木叢邊、大果樹旁，每一站都有小橡樹苗和各種新芽並肩長著。他張開雙臂，嘴巴笑成半月形。
- 文說什麼：認出每一站都在長新芽的頓悟。疊句變奏「就是這裡！」從否定翻轉為肯定，「原來大家都在藏種子」。
- 鉤子：視覺引導型：松鼠張開雙臂轉向最近的小樹苗
- 選圖與提純說明：Refrain variation (negative→positive flip). 5-6: Three-station named callback (meadow/bushes/fruit tree) + three-part escalation + thematic revelation. 45⚠: Three-station callback + refrain variation + revelation = structural requirements. 3-5: Drops station names, keeps variation + revelation. 2-3 skips (variation moved to P11).
- 匹配欄：✓

【zh-TW】
咚咚站起來，轉身回望。
草地上、灌木叢邊、大果樹旁——
每一站，都有小小的橡樹苗，在風裡搖呀搖。
「就是這裡！這裡也是！那裡也是！」
原來呀，大家都在藏種子呢。

【en-US】
Tuck stood up and looked back the way he came.
The meadow, the bushes, the big fruit tree — every single spot had little oak saplings swaying in the breeze.
"Right here! And here! And over there too!"
Oh… everyone had been hiding seeds all along.

### 5-6｜P13（母版 P13）

- 圖說什麼：咚咚一隻手摟著最近的小樹苗，小樹苗搖著葉子碰了碰他的鼻子，他笑瞇瞇的。腳邊的泥地上剛挖好一個小洞，最後一顆橡實躺在洞裡。
- 文說什麼：松鼠和小樹苗的溫柔互動，把土蓋回橡實上的「沙沙沙」，自嘲「大概還是會忘記」的意願句。
- 鉤子：視覺引導型：新埋的橡實和旁邊搖晃的小樹苗連成一條暖線
- 選圖與提純說明：Ending ② gentle exchange (nose-brush) + ending ③ forward-intent (self-deprecating "forget again"). 5-6: Full sequence — hug + sapling response + dig + onomatopoeia + self-deprecation. 42⚠: Five-beat emotional closure (hug/touch/bury/sound/quip) all structural. 3-5: Compressed to four beats. 2-3: Telegram three-beat — nose-brush→dig sound→quip.
- 匹配欄：✓

【zh-TW】
咚咚摟了一下最近的小樹苗。
小樹苗搖著葉子，碰了碰他的鼻子。
他掏出最後一顆橡實，挖了一個小小的洞。
沙沙沙，把土輕輕蓋上。
「這次嘛……嗯，我大概還是會忘記吧！」

【en-US】
Tuck hugged the nearest little sapling.
The sapling swayed its leaves and brushed his nose.
He pulled out one last acorn and dug a tiny hole.
scritch, scritch, scritch — he covered it gently with dirt.
"This time… well, I'll probably forget again!"

### 5-6｜P14（母版 P14）

- 圖說什麼：春天的老橡樹下開闊又溫暖，小橡樹苗排成一列搖著嫩葉。咚咚站在苗旁，小鳥停在新芽上。遠處花園邊小妹妹的花圃也冒出新芽。風輕輕吹過。
- 文說什麼：固定收束語「後來呀」，松鼠還是記不住但每年春天跑過的地方都長新樹，全員同框的溫暖收束。
- 鉤子：—
- 選圖與提純說明：Ending ④ fixed closure "And from that day on" (brand_frozen_unit, exempt max_sentence_len). 5-6: Three-sentence closure — ironic echo (still can't remember) + hopeful consequence + universal echo. 3-5: Two-sentence closure, drops wind/universal echo (P12 "everyone" already said). 2-3: Telegram closure, em dash bridges formula to image.
- 匹配欄：✓

【zh-TW】
後來呀，咚咚還是記不住橡實藏在哪裡。
可是每年春天，他跑過的地方，都會長出新的小樹。
風輕輕吹過森林，大家都在藏種子呢。

【en-US】
And from that day on, Tuck still couldn't remember where he'd hidden his acorns.
But every spring, little oak trees sprouted everywhere he'd been.
The wind blew softly through the forest. Everyone was hiding seeds.

## 檔位 3-5（12 頁）

### 3-5｜P01（母版 P01）

- 圖說什麼：秋天金色的大森林，滿地落葉和橡實。咚咚抱著橡實跑來跑去，這邊塞一顆那邊埋一顆，蓬鬆大尾巴翹得比身體還高，得意洋洋。
- 文說什麼：交代秋天松鼠忙著把橡實藏遍森林，他信誓旦旦「一定記得」，為之後的全忘光埋反諷。
- 鉤子：視覺引導型：松鼠的動線和蓬鬆大尾巴帶向右方下一個藏寶點
- 選圖與提純說明：5-6: Fall opener + three-location list builds the hiding montage + confident promise sets up irony. 3-5: Drops season frame, keeps three-beat list ("one here, one there, one everywhere") + shortened promise. 2-3: Two-beat fragments only, no dialogue (irony setup unnecessary for age band).
- 匹配欄：✓

【zh-TW】
咚咚抱著小果子跑呀跑。
這邊塞一顆，那邊埋一顆。
「我一定記得！」

【en-US】
Tuck hid acorns all over the forest.
One here, one there, one everywhere.
"I'll remember every one!" he said.

### 3-5｜P02（母版 P02）

- 圖說什麼：春天嫩芽冒出來了，咚咚從大橡樹的小樹洞探出頭，打個大哈欠伸懶腰。他歪著頭皺起眉，兩隻手空空的——完全想不起橡實藏在哪。
- 文說什麼：冬去春來的時間跳轉，松鼠醒來想吃橡實卻全忘了，決心出發先去草地找。
- 鉤子：懸念型：橡實全忘了，到底藏在哪裡？
- 選圖與提純說明：5-6: Slow wake-up (cozy tree, stretch, rub eyes) + "biiiiig" vowel stretch (O2) + double "not a single one" echo from P01. 3-5: Keeps "biiiiig" for continuity, drops eye-rubbing and final echo. 2-3 (jump P02→P04): Telegram style, "He forgot. He forgot them all." = two-beat revelation. Jump self-sufficient: "forgot" directly connects to P04 sneeze comedy.
- 匹配欄：✓

【zh-TW】
春天來了，咚咚從樹洞裡探出頭。
他打了一個大大的哈欠。
「我的小果子藏在哪裡呢？」
想不起來了。

【en-US】
Spring came, and Tuck poked his head out of his tree.
He yawned a biiiiig yawn.
"Where did I put my acorns?"
He couldn't remember.

### 3-5｜P03（母版 P03）

- 圖說什麼：開闊春天草地，蒲公英白絮飄得滿天。咚咚趴在地上撅著屁股翻啊挖，臉都貼到草皮了。草地角落悄悄冒出小橡樹苗，他完全沒看到。
- 文說什麼：松鼠在草地翻找橡實的動作與落空，蒲公英白絮飄進鼻子的蓄勢描述。
- 鉤子：動作中斷型：蒲公英飛絮飄進鼻子，噴嚏蓄勢的瞬間凍結
- 選圖與提純說明：Buildup page: search action + dandelion-in-nose sensory setup + frozen sneeze buildup. 5-6: "White" + "all around, drifting" adds visual detail. 3-5: Trims sensory detail, keeps core buildup. 2-3 skips this page.
- 匹配欄：✓

【zh-TW】
咚咚跑到草地上，翻呀翻，挖呀挖。
蒲公英的毛毛飄進他的鼻子裡。
「哈、哈、哈——」

【en-US】
Tuck ran to the meadow and dug and dug.
Dandelion fluff floated right into his nose.
"Ah… ah… ah—"

### 3-5｜P04（母版 P04）

- 圖說什麼：哈啾！一個炸開的大噴嚏把咚咚整隻彈起來，蒲公英種子像煙火漫天飛。他揉著通紅的鼻子瞇起眼，又嗆又狼狽。
- 文說什麼：噴嚏爆發的擬聲詞「哈啾」，揉鼻子斷定沒有橡實。疊句「不是這裡，不是這裡！」首次登場。
- 鉤子：視覺引導型：松鼠跑向灌木叢方向，飛散的蒲公英絮帶向頁緣
- 選圖與提純說明：Refrain first appearance. 5-6: Firework simile for dandelion burst. 3-5: Drops simile, straight to refrain. 2-3 (jump P02→P04): Telegram, sneeze→rub→refrain three-beat self-sufficient. Refrain unquoted in 2-3 (rhythmic echo, not dialogue).
- 匹配欄：✓

【zh-TW】
「哈啾！」
咚咚揉著紅紅的鼻子：
「不是這裡，不是這裡！」

【en-US】
ACHOO!
Tuck rubbed his red, red nose.
"Not here, not here!"

### 3-5｜P05（母版 P05）

- 圖說什麼：光線斑駁的灌木叢裡，咚咚整個人鑽進去翻找，卡在枝條間。一堆毛茸茸的蒼耳子正悄悄黏上他的大尾巴。灌木根部也冒出小橡樹苗。
- 文說什麼：鑽進灌木叢翻找落空，蒼耳子悄悄黏上尾巴的觸感描述，蓄勢甩不掉的掙扎。
- 鉤子：動作中斷型：蒼耳子剛黏上大尾巴，松鼠驚覺但還沒開始甩
- 選圖與提純說明：Buildup page: bur-on-tail tactile setup + tickle awareness. 5-6: "one by one" builds creeping suspense + "Hey…" interjection shows dawning realization. 3-5: Shorter, drops "one by one" and interjection. 2-3 skips this page.
- 匹配欄：✓

【zh-TW】
咚咚鑽進矮樹叢裡翻找。
刺刺的小球球悄悄黏上他大大的尾巴。
「尾巴怎麼癢癢的？」

【en-US】
Tuck crawled into the bushes and searched.
Prickly burs crept onto his big fluffy tail.
"Why does my tail feel so tickly?"

### 3-5｜P06（母版 P06）

- 圖說什麼：咚咚拼命甩尾巴想把蒼耳甩掉，整隻松鼠轉圈圈像陀螺停不下來。幾顆蒼耳掉了紮進泥土，尾巴上還掛著一串。他氣鼓鼓的。
- 文說什麼：甩尾巴的擬聲詞「唰唰唰」與蒼耳黏上的「咻」。疊句「不是這裡，不是這裡！」第二次，氣得決定去大果樹下。
- 鉤子：視覺引導型：松鼠氣沖沖朝大果樹方向跑去
- 選圖與提純說明：Refrain second appearance. 5-6: Spinning-top simile extended ("wouldn't stop") + residual burs for humor. 3-5: Keeps simile core, drops residual detail. 2-3 (jump P04→P06): Telegram, onomatopoeia→futile shaking→refrain. Jump self-sufficient: "swish, swish, swish!" sound-leads directly.
- 匹配欄：✓

【zh-TW】
唰唰唰！咚咚甩呀甩，像陀螺停不下來。
蒼耳掉了——咻！扎進泥巴裡。
「不是這裡，不是這裡！」

【en-US】
swish, swish, swish! Tuck shook and spun like a top.
The burs flew off — THWIP! — into the mud.
"Not here, not here!"

### 3-5｜P07（母版 P07）

- 圖說什麼：果樹抽著新葉，枝上還掛著幾顆去年的乾果，一隻小鳥歪著頭看。咚咚在樹下抬頭翻找，尾巴上還掛著蒼耳。一坨黏呼呼的東西從天上掉下來，凍結在快砸到他頭頂的瞬間。
- 文說什麼：大果樹下翻找橡實落空，頭頂有東西掉下來的蓄勢——蓄到最高點，不揭示砸中。
- 鉤子：動作中斷型：黏呼呼的東西凍結在半空，快砸到松鼠頭頂
- 選圖與提純說明：Buildup page: action-freeze page-turn hook. 5-6: Bird witness + "gooey" tactile foreshadowing. 3-5: Drops bird, keeps suspense hook. 2-3 skips this page.
- 匹配欄：✓

【zh-TW】
咚咚跑到大果樹下，抬起頭翻找。
頭頂上，有東西正在往下掉——
快砸到了！

【en-US】
Tuck ran to the big fruit tree and looked up.
Above his head, something was falling down—
It was about to land!

### 3-5｜P08（母版 P08）

- 圖說什麼：咚咚氣呼呼地擦頭頂，黏黏的東西沾在頭毛上弄不掉，尾巴的蒼耳還在。他攤開手掌，裡面有一顆小小的種子。他張嘴大叫，又氣又困惑。
- 文說什麼：被砸頭的「啪嗒」與擦頭狼狽，發現種子的困惑，大喊回扣書名。疊句第三次最激動。
- 鉤子：問句型：到底是誰把種子藏起來了？松鼠的困惑懸而未解
- 選圖與提純說明：Refrain third (most frustrated). Brand line "Who's been hiding seeds around here?!" echoes title — must be quoted as Tuck's speech (gate2 brand red line). 5-6: Full discovery sequence (rub→sticky→open paw→seed). 3-5: Compressed dash rhythm. 2-3 (jump P06→P08): Telegram, drops sticky/seed detail (image carries it), SPLAT→brand line→refrain. 21⚠ rationale for zh-TW; en-US within band at 11.
- 匹配欄：✓

【zh-TW】
啪嗒！
咚咚氣呼呼地擦頭頂，黏黏的。
手掌裡——一顆小小的種子。
「到底是誰把種子藏起來了！」
「不是這裡，不是這裡！」

【en-US】
SPLAT!
Tuck rubbed his head, grumbling. So sticky.
In his paw — one tiny little seed.
"Who's been hiding seeds around here?!"
"Not here, not here!"

### 3-5｜P09（母版 P11）

- 圖說什麼：咚咚跑回老橡樹下，腳邊冒出一整排小小的嫩芽。他蹲下來把鼻子湊近嫩芽，眼睛睜得圓圓的，尾巴僵在半空。嫩芽的葉子在春風裡輕輕搖。
- 文說什麼：松鼠聞到橡實的味道，驚訝地發現嫩芽——這些就是他忘掉的橡實長出來的。2-3 檔在本頁承接疊句變奏，從「不是這裡」翻轉為「就是這裡！」（5-6／3-5 仍在 P12）。
- 鉤子：視覺引導型：松鼠的視線從腳邊嫩芽向遠方森林展開
- 選圖與提純說明：Climax page. 5-6: Full sensory discovery (crouched + pressed nose + smell). 3-5: Compressed to "sniffed" but keeps olfactory payoff. 2-3 (jump P08→P11): Telegram, "Tuck ran back" bridges frustration→discovery; refrain variation "Right here, right here!" flips negative to positive (zh-TW "就是這裡" moved here since P12 skipped).
- 匹配欄：✓

【zh-TW】
咚咚跑回老橡樹下。
腳邊冒出了一排小小的嫩芽。
他蹲下來聞了聞——
是小果子的味道！

【en-US】
Tuck ran back to the old oak tree.
A row of tiny sprouts poked out by his feet.
He sniffed — it smelled like acorns!

### 3-5｜P10（母版 P12）

- 圖說什麼：咚咚站起來轉身回望。草地遠處、灌木叢邊、大果樹旁，每一站都有小橡樹苗和各種新芽並肩長著。他張開雙臂，嘴巴笑成半月形。
- 文說什麼：認出每一站都在長新芽的頓悟。疊句變奏「就是這裡！」從否定翻轉為肯定，「原來大家都在藏種子」。
- 鉤子：視覺引導型：松鼠張開雙臂轉向最近的小樹苗
- 選圖與提純說明：Refrain variation (negative→positive flip). 5-6: Three-station named callback (meadow/bushes/fruit tree) + three-part escalation + thematic revelation. 45⚠: Three-station callback + refrain variation + revelation = structural requirements. 3-5: Drops station names, keeps variation + revelation. 2-3 skips (variation moved to P11).
- 匹配欄：✓

【zh-TW】
咚咚轉身回望。
每一站，都有小小的橡樹苗在搖。
「就是這裡！這裡也是！」
原來呀，大家都在藏種子呢。

【en-US】
Tuck looked back.
Every spot had little oak saplings swaying in the breeze.
"Right here! And here too!"
Everyone had been hiding seeds all along.

### 3-5｜P11（母版 P13）

- 圖說什麼：咚咚一隻手摟著最近的小樹苗，小樹苗搖著葉子碰了碰他的鼻子，他笑瞇瞇的。腳邊的泥地上剛挖好一個小洞，最後一顆橡實躺在洞裡。
- 文說什麼：松鼠和小樹苗的溫柔互動，把土蓋回橡實上的「沙沙沙」，自嘲「大概還是會忘記」的意願句。
- 鉤子：視覺引導型：新埋的橡實和旁邊搖晃的小樹苗連成一條暖線
- 選圖與提純說明：Ending ② gentle exchange (nose-brush) + ending ③ forward-intent (self-deprecating "forget again"). 5-6: Full sequence — hug + sapling response + dig + onomatopoeia + self-deprecation. 42⚠: Five-beat emotional closure (hug/touch/bury/sound/quip) all structural. 3-5: Compressed to four beats. 2-3: Telegram three-beat — nose-brush→dig sound→quip.
- 匹配欄：✓

【zh-TW】
咚咚摟了一下小樹苗。
小樹苗碰了碰他的鼻子。
他把最後一顆小果子埋進土裡。沙沙沙。
「我大概……還是會忘記吧！」

【en-US】
Tuck hugged the little sapling.
It brushed his nose with a leaf.
He buried his last acorn. scritch, scritch, scritch.
"I'll probably… forget again!"

### 3-5｜P12（母版 P14）

- 圖說什麼：春天的老橡樹下開闊又溫暖，小橡樹苗排成一列搖著嫩葉。咚咚站在苗旁，小鳥停在新芽上。遠處花園邊小妹妹的花圃也冒出新芽。風輕輕吹過。
- 文說什麼：固定收束語「後來呀」，松鼠還是記不住但每年春天跑過的地方都長新樹，全員同框的溫暖收束。
- 鉤子：—
- 選圖與提純說明：Ending ④ fixed closure "And from that day on" (brand_frozen_unit, exempt max_sentence_len). 5-6: Three-sentence closure — ironic echo (still can't remember) + hopeful consequence + universal echo. 3-5: Two-sentence closure, drops wind/universal echo (P12 "everyone" already said). 2-3: Telegram closure, em dash bridges formula to image.
- 匹配欄：✓

【zh-TW】
後來呀，咚咚還是記不住。
可是每年春天，他跑過的地方，都會長出新的小樹。

【en-US】
And from that day on, Tuck still couldn't remember.
But every spring, little oak trees sprouted everywhere he'd been.

## 檔位 2-3（8 頁）

### 2-3｜P01（母版 P01）

- 圖說什麼：秋天金色的大森林，滿地落葉和橡實。咚咚抱著橡實跑來跑去，這邊塞一顆那邊埋一顆，蓬鬆大尾巴翹得比身體還高，得意洋洋。
- 文說什麼：交代秋天松鼠忙著把橡實藏遍森林，他信誓旦旦「一定記得」，為之後的全忘光埋反諷。
- 鉤子：視覺引導型：松鼠的動線和蓬鬆大尾巴帶向右方下一個藏寶點
- 選圖與提純說明：5-6: Fall opener + three-location list builds the hiding montage + confident promise sets up irony. 3-5: Drops season frame, keeps three-beat list ("one here, one there, one everywhere") + shortened promise. 2-3: Two-beat fragments only, no dialogue (irony setup unnecessary for age band).
- 匹配欄：✓

【zh-TW】
咚咚抱著小果子跑呀跑。
這邊塞一顆，那邊埋一顆。

【en-US】
Tuck hid acorns all over the forest.
One here. One there.

### 2-3｜P02（母版 P02）

- 圖說什麼：春天嫩芽冒出來了，咚咚從大橡樹的小樹洞探出頭，打個大哈欠伸懶腰。他歪著頭皺起眉，兩隻手空空的——完全想不起橡實藏在哪。
- 文說什麼：冬去春來的時間跳轉，松鼠醒來想吃橡實卻全忘了，決心出發先去草地找。
- 鉤子：懸念型：橡實全忘了，到底藏在哪裡？
- 選圖與提純說明：5-6: Slow wake-up (cozy tree, stretch, rub eyes) + "biiiiig" vowel stretch (O2) + double "not a single one" echo from P01. 3-5: Keeps "biiiiig" for continuity, drops eye-rubbing and final echo. 2-3 (jump P02→P04): Telegram style, "He forgot. He forgot them all." = two-beat revelation. Jump self-sufficient: "forgot" directly connects to P04 sneeze comedy.
- 匹配欄：✓

【zh-TW】
春天來了！
咚咚的小果子呢？
忘記了。全部忘記了。

【en-US】
Spring!
Where are Tuck's acorns?
He forgot. He forgot them all.

### 2-3｜P03（母版 P04）

- 圖說什麼：哈啾！一個炸開的大噴嚏把咚咚整隻彈起來，蒲公英種子像煙火漫天飛。他揉著通紅的鼻子瞇起眼，又嗆又狼狽。
- 文說什麼：噴嚏爆發的擬聲詞「哈啾」，揉鼻子斷定沒有橡實。疊句「不是這裡，不是這裡！」首次登場。
- 鉤子：視覺引導型：松鼠跑向灌木叢方向，飛散的蒲公英絮帶向頁緣
- 選圖與提純說明：Refrain first appearance. 5-6: Firework simile for dandelion burst. 3-5: Drops simile, straight to refrain. 2-3 (jump P02→P04): Telegram, sneeze→rub→refrain three-beat self-sufficient. Refrain unquoted in 2-3 (rhythmic echo, not dialogue).
- 匹配欄：✓

【zh-TW】
哈啾！
咚咚揉著紅紅的鼻子。
不是這裡，不是這裡！

【en-US】
ACHOO!
Tuck rubbed his red, red nose.
Not here, not here!

### 2-3｜P04（母版 P06）

- 圖說什麼：咚咚拼命甩尾巴想把蒼耳甩掉，整隻松鼠轉圈圈像陀螺停不下來。幾顆蒼耳掉了紮進泥土，尾巴上還掛著一串。他氣鼓鼓的。
- 文說什麼：甩尾巴的擬聲詞「唰唰唰」與蒼耳黏上的「咻」。疊句「不是這裡，不是這裡！」第二次，氣得決定去大果樹下。
- 鉤子：視覺引導型：松鼠氣沖沖朝大果樹方向跑去
- 選圖與提純說明：Refrain second appearance. 5-6: Spinning-top simile extended ("wouldn't stop") + residual burs for humor. 3-5: Keeps simile core, drops residual detail. 2-3 (jump P04→P06): Telegram, onomatopoeia→futile shaking→refrain. Jump self-sufficient: "swish, swish, swish!" sound-leads directly.
- 匹配欄：✓

【zh-TW】
唰唰唰！
咚咚甩呀甩，甩不掉。
不是這裡，不是這裡！

【en-US】
swish, swish, swish!
Tuck shook and shook.
Not here, not here!

### 2-3｜P05（母版 P08）

- 圖說什麼：咚咚氣呼呼地擦頭頂，黏黏的東西沾在頭毛上弄不掉，尾巴的蒼耳還在。他攤開手掌，裡面有一顆小小的種子。他張嘴大叫，又氣又困惑。
- 文說什麼：被砸頭的「啪嗒」與擦頭狼狽，發現種子的困惑，大喊回扣書名。疊句第三次最激動。
- 鉤子：問句型：到底是誰把種子藏起來了？松鼠的困惑懸而未解
- 選圖與提純說明：Refrain third (most frustrated). Brand line "Who's been hiding seeds around here?!" echoes title — must be quoted as Tuck's speech (gate2 brand red line). 5-6: Full discovery sequence (rub→sticky→open paw→seed). 3-5: Compressed dash rhythm. 2-3 (jump P06→P08): Telegram, drops sticky/seed detail (image carries it), SPLAT→brand line→refrain. 21⚠ rationale for zh-TW; en-US within band at 11.
- 匹配欄：✓

【zh-TW】
啪嗒！
「到底是誰把種子藏起來了！」
不是這裡，不是這裡！

【en-US】
SPLAT!
"Who's been hiding seeds around here?!"
Not here, not here!

### 2-3｜P06（母版 P11）

- 圖說什麼：咚咚跑回老橡樹下，腳邊冒出一整排小小的嫩芽。他蹲下來把鼻子湊近嫩芽，眼睛睜得圓圓的，尾巴僵在半空。嫩芽的葉子在春風裡輕輕搖。
- 文說什麼：松鼠聞到橡實的味道，驚訝地發現嫩芽——這些就是他忘掉的橡實長出來的。2-3 檔在本頁承接疊句變奏，從「不是這裡」翻轉為「就是這裡！」（5-6／3-5 仍在 P12）。
- 鉤子：視覺引導型：松鼠的視線從腳邊嫩芽向遠方森林展開
- 選圖與提純說明：Climax page. 5-6: Full sensory discovery (crouched + pressed nose + smell). 3-5: Compressed to "sniffed" but keeps olfactory payoff. 2-3 (jump P08→P11): Telegram, "Tuck ran back" bridges frustration→discovery; refrain variation "Right here, right here!" flips negative to positive (zh-TW "就是這裡" moved here since P12 skipped).
- 匹配欄：✓

【zh-TW】
咚咚跑回來了。
小芽芽冒出來了！
就是這裡，就是這裡！

【en-US】
Tuck ran back.
Little sprouts popped up!
Right here, right here!

### 2-3｜P07（母版 P13）

- 圖說什麼：咚咚一隻手摟著最近的小樹苗，小樹苗搖著葉子碰了碰他的鼻子，他笑瞇瞇的。腳邊的泥地上剛挖好一個小洞，最後一顆橡實躺在洞裡。
- 文說什麼：松鼠和小樹苗的溫柔互動，把土蓋回橡實上的「沙沙沙」，自嘲「大概還是會忘記」的意願句。
- 鉤子：視覺引導型：新埋的橡實和旁邊搖晃的小樹苗連成一條暖線
- 選圖與提純說明：Ending ② gentle exchange (nose-brush) + ending ③ forward-intent (self-deprecating "forget again"). 5-6: Full sequence — hug + sapling response + dig + onomatopoeia + self-deprecation. 42⚠: Five-beat emotional closure (hug/touch/bury/sound/quip) all structural. 3-5: Compressed to four beats. 2-3: Telegram three-beat — nose-brush→dig sound→quip.
- 匹配欄：✓

【zh-TW】
小樹苗碰了碰咚咚的鼻子。
沙沙沙，埋好了。
「還是會忘記吧！」

【en-US】
The sapling brushed Tuck's nose.
scritch, scritch, scritch.
"I'll forget again!"

### 2-3｜P08（母版 P14）

- 圖說什麼：春天的老橡樹下開闊又溫暖，小橡樹苗排成一列搖著嫩葉。咚咚站在苗旁，小鳥停在新芽上。遠處花園邊小妹妹的花圃也冒出新芽。風輕輕吹過。
- 文說什麼：固定收束語「後來呀」，松鼠還是記不住但每年春天跑過的地方都長新樹，全員同框的溫暖收束。
- 鉤子：—
- 選圖與提純說明：Ending ④ fixed closure "And from that day on" (brand_frozen_unit, exempt max_sentence_len). 5-6: Three-sentence closure — ironic echo (still can't remember) + hopeful consequence + universal echo. 3-5: Two-sentence closure, drops wind/universal echo (P12 "everyone" already said). 2-3: Telegram closure, em dash bridges formula to image.
- 匹配欄：✓

【zh-TW】
後來呀——
到處長出了小樹！

【en-US】
And from that day on—
Little trees grew everywhere!

