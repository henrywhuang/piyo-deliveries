# QA 報告：who-hid-the-seeds / en-US / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: who-hid-the-seeds
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-31"
step1_lint: {exit_code: 0, warnings: 7}
step2_checklist: {pass: 25, fail: 0}
step3_mode: consolidated
step3_personas: []
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

## STEP 1 機檢

locale_lint ×3 tier：exit 0，違規 0。

| 檔位 | 違規 | 警告 | 說明 |
|---|---|---|---|
| 5-6 | 0 | 2 | repeat_discount ×3（refrain 4w P04/P06/P08）折計 476→470 |
| 3-5 | 0 | 2 | repeat_discount ×3（refrain 4w P04/P06/P08）折計 257→251 |
| 2-3 | 0 | 3 | repeat_discount ×3（refrain 4w P03/P04/P05）折計 86→80；brand_frozen_unit "And from that day on—" 豁免 max_sentence_len（9w>8w） |

copy_check：exit 0，警告 6 筆——3-5 P04（11w）低於帶底 15（疊句交付頁＝ACHOO+rub+refrain 三拍，合法短頁）；5-6 P09（41w）、P12（45w）、P13（42w）超帶上緣 40（各附結構理由，見 copy 選圖與提純說明）；2-3 P08（9w）低於帶底 10（電報式收束頁，合法）；角色名「the little girl」警告（P10 "The little girl" 大寫T 首字母，視覺出場合法）。

## STEP 2 checklist 自檢

**主題錨**：松鼠忘了藏橡實的地方、焦急找半天全落空，卻驚喜發現橡實已發芽長出小樹——「原來忘記的地方都在長新芽，大家都在藏種子」。核心能力：回頭辨認（跑回來才發現之前經過的地方都長了苗）。

### S4A 合併審查七步

#### ① 主題錨復述

如上。禁止替代：勇氣、記憶力/專注力。

#### ② Checklist A-E

| 項 | 判定 | 證據 |
|---|---|---|
| A1 故事弧 | ✓ | 三幕：P01-02 setup（藏+忘）→P03-08 三站搜索(meadow/bushes/fruit tree)→P09-10 mirror(5-6)→P11 climax→P12-14 resolution |
| A2 翻頁鉤子 | ✓ | P03→P04（sneeze buildup "Ah… ah… ah—"）、P07→P08（action-freeze "about to land!"）、P10→P11（suspense "Just like me?"） |
| A3 結尾四件套 | ✓ | ①同框 P14（圖）②碰鼻 P13 ③前瞻"I'll probably forget again!" P13 ④收束"And from that day on" P14 |
| B1 角色一致 | ✓ | Tuck＝energetic/breathless/physical-first（rubs nose THEN says refrain）；little girl＝cheerful/matter-of-fact |
| B2 角色區分 | ✓ | Tuck 大量短句+exclamation；little girl 只一句台詞 |
| C1 5-6 適齡 | ✓ | 完整句＋比喻（fireworks/spinning top）＋mirror character（P09-P10）＋"biiiiig" vowel stretch |
| C2 3-5 適齡 | ✓ | 刪 P09-P10 mirror、刪比喻保核心動作+refrain+onomatopoeia |
| C3 2-3 適齡 | ✓ | 電報式三拍（sound→action→refrain）、全頁 ≤14w、refrain 去引號為韻律 statement |
| D1 正字法 | ✓ | 省略號＝U+2026、破折號＝U+2014、直引號＝ASCII `"`、serial comma N/A（無 and/or 三項列舉） |
| D2 句長上限 | ✓ | 5-6 max observed 19w（P12 三站回收句）＜24w；3-5 max 14w（P11 sprouts 句）＜18w；2-3 max 9w（P08 brand frozen exempt）≤8w+frozen |
| D3 頁字數上限 | ✓ | 5-6 max 45w（P12）＜60w；3-5 max 25w（P02/P08/P12）＜46w；2-3 max 11w ＜14w |
| D4 總字數上限 | ✓ | 5-6 470w(折)＜505w；3-5 251w(折)＜389w；2-3 80w(折)＜88w |
| E1 疊句兌現 | ✓ | "Not here, not here!" at P04/P06/P08 ×3 檔，逐字一致；P12 variation "Right here!" 5-6/3-5 在場，2-3 移至 P11 |
| E2 擬聲詞兌現 | ✓ | ACHOO!(P04)、swish,swish,swish!(P06)、THWIP!(P06)、SPLAT!(P08)、scritch,scritch,scritch(P13) — 5 音全到 |
| E3 收束式兌現 | ✓ | "And from that day on" 三檔 P14 均在場 |
| E4 品牌紅線 | ✓ | "Who's been hiding seeds around here?!" P08 三檔有引號（Tuck 喊出） |
| E5 翻頁鉤子兌現 | ✓ | design 宣告 P07 動作中斷、P10 懸念、P11 視覺引導——三處均兌現 |
| E6 身體笑話 | ✓ | P04 sneeze＋red nose、P06 spinning+burs、P08 bird poop＝三站各一 |
| E7 高潮 | ✓ | P11 嫩芽發現＋嗅覺驗證 |
| E8 角色主視角 | ✓ | P09 "Tuck tilted his head: What is she doing?" ＝角色內心獨白，非旁白提問 |
| E9 跳接自足 | ✓ | 3-5: P08→P11 由"ran back to the old oak tree"自足。2-3: P02→P04(sneeze即入口)、P04→P06(swish即入口)、P06→P08(SPLAT即入口)、P08→P11(ran back) |

25 pass / 0 fail。

#### ③ 對位逐頁比對

逐頁核對 storyboard「文說什麼」欄 vs en-US 文字。判準：text entities must exist in image + text must not restate visual attributes + audio self-sufficiency（"delete this sentence; would a blind listener miss plot?"）。

所有 14 頁（5-6 母版）：
- 無屬性重述違反——text carries dialogue, onomatopoeia, inner thoughts, narration of events; does not describe visual attributes (color, appearance, position)
- P01: image shows autumn forest + hiding squirrel, text narrates hiding action + promise → ✓
- P04/P06/P08: image shows physical comedy, text carries sound effect + refrain → ✓
- P09: image shows girl by garden, text says "a little girl knelt by a garden" — entity present in image ✓; "digging and digging" is action event not attribute → ✓
- P11: image shows sprouts, text narrates discovery + smell → ✓ (smell is audio-exclusive payload)
- P14: image shows forest scene, text narrates closure → ✓

零對位違反。

#### ④ ESL 獵手

靶區＝en-US spec 雷區（ESL calque / 搭配 / 語序）＋style_guide §3.4 AI 機械句五型。

| 頁 | 掃描結果 | 說明 |
|---|---|---|
| 全 14 頁 | 無 ESL calque | 無中文語序滲漏；句法為原生 SVO；無 *"He is very happy" 型裸形容詞* |
| 全 14 頁 | 無 AI 機械句 | 無電報式裸動詞堆疊（2-3 電報式為 R7 合法設計）、無成分懸空、無超規律平行（P01 三段 parallel 為設計型列舉）、無無語氣詞乾句（interjections: "Hey…" "Hmm…" "Oh…"）、無詞組層過度壓縮 |
| 全 14 頁 | 無 banned BrE | 無 colour/favourite/grey/mum/tummy 等 |

#### ⑤ 原生語感三視角

- **Teacher**：三檔分化乾淨——5-6 有完整 mirror character + 比喻 + 感官細節；3-5 保核心動作+refrain+onomatopoeia 不冗贅；2-3 電報式三拍自足。詞彙均在 sight-word + age-appropriate 範圍。
- **Parent**：唸出來自然——"Not here, not here!" 可跟唸、ACHOO! / SPLAT! 引發笑聲、身體笑話三連遞進(sneeze→burs→bird poop)、"I'll probably forget again!" 是溫暖的自我解嘲。
- **Editor**：pacing good——buildup→release 節奏清晰；P11 climax 用嗅覺(smell like acorns)打開，不靠視覺重述；P12 "Oh…" realization 有情緒空間；ending avoids moralizing。

#### ⑥ Concept fidelity

| 檔位 | 判定 | 證據 |
|---|---|---|
| 5-6 | ✓ | 孩子帶走：忘記藏的東西長出了新芽＝happy accident + everyone hiding seeds。未偏向勇氣或記憶力。Mirror character 強化主題（有意vs無意藏種子）不偏題 |
| 3-5 | ✓ | 同核心教訓，無 mirror 仍完整（三站搜索→發現→自嘲） |
| 2-3 | ✓ | 同核心教訓，refrain flip (Not here→Right here) 承載驚喜發現 |

#### ⑦ Inline 分診

本輪零發現。✅=0, ❌=0, ⏸️=0。一輪收斂。

## STEP 3 人設 blind QA

S4A v0.15：見 STEP 2 合併審查（原生語感三視角）。

## STEP 4 三分法分診

S4A v0.15：見 STEP 2 合併審查（inline 分診第 7 步）。✅=0, ❌=0, ⏸️=0。
