# QA 報告：`gate4_en-US_review.md` 審包內容核驗

- 核驗對象：PYO-008《小天鵝慢慢長大》關卡④ en-US 證據包（2026-07-20 20:27:19 生成，make_review.py --gate 4；由 Stacy 以附件提供，現位於 repo 根目錄 `gate4_en-US_review.md`）
- 核驗人：S4 copywriting review session（黃威豪 side，接手快照 checkout）
- 核驗日期：2026-07-20
- 結論：**審包結構與可驗證內容全部核實，可信，可交 Stacy 作關卡④證據審**。4 項上呈全部合法並各附建議裁決方向；另發現 **4 筆偏移標記覆蓋缺口**（其中 1 筆中度級：5-6 P13 主題錨句在 en-US 消失），建議與上呈批次一併裁決。

## 〇、核驗範圍限制（先讀）

本快照 checkout 中 **PYO-008 的底層來源檔不存在**（`text/en-US/*.draft.json`、`qa/en-US/round1-3.md`、`qa/en-US/backtranslation.md` 均不在包內；book.yaml status 仍為 `zh-TW_text_frozen`）。因此：

- ✅ 可完整核驗：母本欄 vs 本地凍結 zh-TW、母版頁映射 vs storyboard、機檢數字（重建文本獨立重跑）、疊句／擬聲一致性、內容級偏移覆蓋。
- ⚠️ 僅能核驗內部自洽：round1-3 引文、backtranslation 覆蓋宣稱（無來源檔可逐字對照）。
- 正式落地時，S4A 執行 session 必須經 `piyo_deliver_gate.py` 把來源檔與審包一起交付 canonical main；本附件不能替代該交付。

## 一、核驗方法與通過項

| 核驗項 | 方法 | 結果 |
|---|---|---|
| zh-TW 母本引文（36 頁） | 腳本逐頁對照本地凍結 `text/zh-TW/{2-3,3-5,5-6}.json` | ✅ 逐字一致（空白正規化後零差異）——證明審包基於凍結母本 |
| 母版頁映射 | 對照 storyboard 三檔選用表（3-5 跳 P02/P13；2-3 跳 P02/P05/P08/P13） | ✅ 5-6 全 14 頁、3-5 十二頁、2-3 十頁序列全對 |
| 儀表板統計 | 選用頁數 14/12/10、回譯覆蓋 14/14、12/12、10/10、偏移數 1/1/0 | ✅ 與逐頁表逐項相符 |
| 機檢數字 | 從審包重建 en-US 三檔 pages.json，獨立重跑 `locale_lint.py --locale en-US` | ✅ **0 違規、警告 4+5+5=14 筆，與 round3 宣稱 `exit_code: 0, warnings: 14` 完全吻合**；折計後 2-3:81.5／3-5:234／5-6:312 全在帶內 |
| 疊句契約 | 機械計數 | ✅ "Faster, faster—I'll fly right now!" 每檔恰 3 現（合計 9）；變奏 "Steady, steady—I'll swim for now!" 每檔恰 1 現；功能轉折「催促起飛→接納當下游法」符合 design.md 第 7 節（不逐字互譯）✓ |
| 擬聲寫法一致性 | 機械掃描全部變體 | ✅ `flap, flap, flap!`／`PLOP!`／`swish, swish, swish!` 各僅一種寫法零漂移；與 motif 對位（試飛×3、落水×3、水紋）正確；2-3 無 swish 與凍結 zh-TW 同形（見上呈③） |
| 品牌三條線＋結尾四件套 | 逐頁掃描 en-US 欄 | ✅ 旁白零出題（所有問句都是安安台詞／內心）、零總結道理；收束式安定、回家收尾。附註：en-US 收束式拆成三短句，天然避開 zh-TW 2-3 的 W1 句長 waiver（25>15），無同款問題 |
| 角色名 | 對照 design.md 第 7 節 | ✅ An-An 與設計提案一致，三檔零漂移（惟 registry 未回填，見發現 F5） |
| verdict 紀律 | 檢查三輪 verdict | ✅ round1-3 均 `escalated` 原樣保留，符合「AI verdict 與人工授權分離」；Green Light 權在 Stacy |
| 三檔質化分檔 | 逐檔語言風格比對 | ✅ 2-3 電報式（折計 81.5 words）、3-5 短中句混合、5-6 因果句＋內心辨認，非同稿刪長補短 |

## 二、發現：偏移標記覆蓋缺口（審包標「無」但實有偏移，建議補標並交 Gate 4 一併裁決）

已有的 2 筆中度標記（5-6 P10、3-5 P09「完整 V 早於高潮交付」）**判斷準確且是全包最重要的戲劇性問題**——但它們只落在逐頁表，未進入上呈批次清單；裁決時請勿遺漏。以下 4 筆為審包漏標：

| # | 位置 | 等級 | 內容 |
|---|---|---|---|
| F1 | 5-6 P13 | **中度** | 母本主題錨句「天空有天空的快，水面有水面的慢」在 en-US 整句消失（en-US P13 只剩外觀不變＋朋友仍在）。此句是提案卡核心訊息「每個生命都有自己的時間表」在全書唯一的文字載體，也是 storyboard P13 指定負載（天空與水面各以自身速度並行）。10 項真問題與 4 項上呈均未涵蓋。建議：en-US P13 補對應句（如 "The sky has its fast. The water has its slow."，遣詞由 S4A 定），或由 Stacy 明示接受由圖面（雙速帶構圖）單獨承載。 |
| F2 | 2-3 P01 | 輕微-中度 | 母本「天空飛過人字隊！」的 V 隊形 setup 在 en-US 縮成 "Birds flew above."，V 首次出現延後到 P09 payoff（"Their V crossed the lake. Birds made one above!"）——指涉憑空出現。ESL 獵手 H3-02 抓到的 P09 指涉不自然，其病根在此頁。2-3 字量餘裕充足（81.5 折計，遠低於帶上限），建議 P01 補 V 意象（如 "Birds flew above in a V!"）。 |
| F3 | 5-6 P11 | 輕微 | 母本「看看腳掌，看看翅膀」的能力辨認拍（三輪辨認的總收束、storyboard P11 內心負載）在 en-US 被刪，只剩朋友位置辨認。變奏疊句仍承載「選擇」，主線不斷，但辨認→選擇的鋪墊變薄。 |
| F4 | P14 全檔 | 輕微 | 收束式「只要…也會跟著…」的「跟著」呼應結構在 "One V flew. One V swam." 中變成純並列，天空領游、湖面跟隨的陪伴迴聲弱化；5-6 另把旁白時間標記改成安安台詞 "Time to go home."（敘事模式移位，黃昏標記由 "By evening" 保留）。並列版短促有力且 karaoke 友善，可接受——建議標輕微並記錄為刻意取捨，而非漏譯。 |

## 三、對 4 項上呈的核驗與建議裁決方向

| 上呈 | 合法性 | 建議方向（僅供裁決參考，決定權在 Stacy） |
|---|---|---|
| ① 整包三輪未收斂（R3 仍 10 項真問題） | ✅ 符合 skill 三輪上限、禁開 R4 的收斂制 | 10 項多為語言工藝級（H3-03 自語冗餘、H3-04 vocative、H3-05 搭配詞）；若接受範圍明確，可授權「修語言不動結構」的定向回修 |
| ② 2-3 因果鏈 vs frozen zh-TW | ✅ 跨語結構問題，單語不可自修 | zh 2-3 砍 P05/P08 是 copy 總表記錄在案、gate3 帶過的「本就自足」決策；en-US 盲稿同形。建議維持凍結、不跨語補回，除非裁定 2-3 聽覺自足性實測不足（屬解凍級變更） |
| ③ 2-3 `swish` motif 契約衝突 | ✅ design 宣告 vs 檔位取捨的真衝突 | gate3 已實質接受 zh 2-3 省略沙啦（copy 總表附理由）。建議裁定「低齡豁免」與 gate3 先例一致，並在 design/copy 補註 per-tier 適用範圍，免得之後 6 個 locale 每語都重新上呈一次 |
| ④ Display title 改 `The Little Swan Grows in Her Own Time` | ✅ shared metadata，需人裁 | 支持：*in her own time* 是 GA 慣用語，且更貼核心訊息；影響 book.yaml `title.en-US`（en-GB 派生連動），slug／目錄名不動 |

## 四、其他發現與處置建議

- **F5（registry 回填缺口）**：`character_names.md` swan_anan 的 en-US 欄、`onomatopoeia_map.md` 三個 motif 的 en-US 欄均為空白。An-An／flap／PLOP／swish 目前全是「提案」狀態。Gate 4 Green Light 時需連帶回填 registry（skill 維度四鐵律），否則後續 locale 無對照錨點。
- **F6（TTS 前瞻，非本關卡阻斷）**:en-US 稿大量把母本旁白改寫為台詞（Mode B 合法選擇，利於 TTS 演繹），但 5-6/3-5 P12 "One down here!"／"One up there!" 說話者不明——S5/S6 的 TTS 分角前需明確歸屬（安安或朋友）。
- 本報告與根目錄附件的關係：附件保持 Stacy 放置的原位不動；正式歸檔位 `qa/review/gate4_en-US_review.md` 應由 S4A 執行 session 連同來源檔一起經交付腳本落地。

## 五、結論

審包可信、可送關卡④證據審。裁決清單建議合併為：**4 項上呈 ＋ 2 筆既有中度偏移（5-6 P10／3-5 P09 早交 V）＋ F1（5-6 P13 主題錨句缺失）**共 7 個決定點；F2-F4 可併入①的定向回修範圍一次處理。
