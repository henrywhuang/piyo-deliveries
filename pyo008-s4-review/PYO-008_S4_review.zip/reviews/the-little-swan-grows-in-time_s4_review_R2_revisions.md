# S4 修改指令：《小天鵝慢慢長大》

## 審稿識別
- 繪本編號：PYO-008
- 繪本 Slug：the-little-swan-grows-in-time
- 書名（zh-TW）：《小天鵝慢慢長大》
- 審稿輪次：R2（R1＝2026-07-20 材料不齊判退；本輪六檔齊備補審 en-US 側）
- 審稿日期：2026-07-20
- 審稿依據：piyo-copywriting-review v0.9（docs/skill/skill-s4-copywriting-review.md）
- 審稿對象檔案：
  - zh-TW 三檔：`text/zh-TW/{2-3,3-5,5-6}.json`（gate3 凍結版）
  - en-US 三檔：取自 Stacy 提供的關卡④證據包 `gate4_en-US_review.md`（repo 根目錄）逐頁表重建；已驗證與凍結母本逐字對位。**注意：本快照無 `text/en-US/*.draft.json` 原檔，若 draft 與審包有出入，以 draft 為準並需重核。**
- 本報告檔名：the-little-swan-grows-in-time_s4_review_R2_revisions.md
- 判定：**不通過 — 需修改後重審**（en-US 側；zh-TW 側維持 R1 全過結論、保持凍結不動）
- 關聯報告：R1（`reviews/…_R1_revisions.md`）、審包核驗（`qa/review/gate4_en-US_review_qa.md`）

## 來源文件核對
- S2 storyboard：`PYO-008_storyboard.md`（greenlit）
- 核心訊息（提案卡）：一隻長得不一樣的小鳥慢慢長大，發現每個生命都有自己的時間表。
- 前置 QA：piyo-text-qa en-US 三輪 `verdict: escalated`（10 項真問題＋4 項上呈，禁開 R4，整包待 Stacy 裁決）——本報告的修改指令與該上呈**並行不牴觸**：指令只動 en-US、不動凍結 zh-TW、不碰待裁決的 shared metadata。

## 五維度判定總覽

| 維度 | 判定 |
|---|---|
| 朗讀自然度 | zh-TW 通過／**en-US 需修改**（語言工藝 5 處＋5-6 P10 超長） |
| 幼兒可理解性 | zh-TW 通過／**en-US 需修改**（2-3 V 指涉鏈斷裂） |
| 圖文配合度 | zh-TW 通過／**en-US 需修改**（P13 負載遺漏；P10／P09 早交 V） |
| 品牌與 Registry 合規 | 通過（品牌三條線＋結尾四件套零違規；lint 0 違規；附 registry 回填待辦） |
| 三檔 × 兩語一致性 | 三檔一致性通過／**兩語一致性 需修改**（高潮結構偏移，同圖文配合度兩項） |

en-US 整體評價先說在前：Mode B 盲稿的骨架是好的——疊句「Faster, faster—I'll fly right now!」→「Steady, steady—I'll swim for now!」的功能轉折漂亮、口語縮寫與呼喊自然、擬聲三 motif 零漂移、三檔質化分檔成立。以下修改都是定向手術，不是重寫。

## 必須修改的項目（全部只動 en-US，不觸凍結 zh-TW）

### 圖文配合度／兩語一致性 — 需修改（最優先：高潮結構）

**問題**：en-US 5-6 P10 與 3-5 P09 把「完整水面 V」提前成形並喊出（"three wakes spreading into a V… 'A V!'"），高潮 P12「朋友沿水紋排開成 V」被提前劇透，P10 辨認→P11 選擇→P12 成形的四拍因果塌掉（審包已標中度偏移）。且 5-6 P10 因此膨脹到 7 行 44 words，唸讀需三口氣以上。

**修改指令**：
1. en-US 5-6 P10：刪 "A V!" 一行；"three wakes spreading into a V behind them" 改回母本語義「水紋很大、尚未成形」（例如 "her wide wake trailing long behind them"）；順勢把全頁收進兩口氣內（可併 "Then she felt…" 與 "I'm not flying…" 兩拍）。
2. en-US 3-5 P09："three wakes forming a V behind them" 同樣改為未成形的大水紋（例如 "three long wakes trailing behind them"）。
3. P12 不動（"their three wakes opening into a V" 正是成形時刻，保留）。

### 圖文配合度 — 需修改（主題錨句）

**問題**：5-6 P13 母本「天空有天空的快，水面有水面的慢」在 en-US 整句消失。這是核心訊息「每個生命都有自己的時間表」全書唯一文字載體，也是 storyboard P13 指定負載（天空與水面各自速度並行）。

**修改指令**：
4. en-US 5-6 P13 補一句對應表達（方向示例："The sky has its fast. The water has its slow."；遣詞由撰寫 agent 以 GA 語感定稿），接在 "An-An was still the same young swan…" 之後。

### 幼兒可理解性 — 需修改（2-3 V 指涉鏈）

**問題**：2-3 P01 把母本「天空飛過人字隊！」縮成 "Birds flew above."，V 意象未建立；P09 "Their V crossed the lake. Birds made one above!" 的 V 憑空出現（ESL 獵手 H3-02 的病根）。2-3 字量餘裕充足（折計 81.5，帶內寬鬆）。

**修改指令**：
5. en-US 2-3 P01："Birds flew above." → 補 V 意象（方向示例："Birds flew above in a V!"）。
6. en-US 2-3 P09：P01 補好 setup 後，本頁指涉自然成立；僅需順讀微調（如 "Birds made a V up high!"），由撰寫 agent 定。

### 朗讀自然度 — 需修改（語言工藝，對應 piyo-text-qa R3 真問題）

**問題與指令**（逐項定向修，不動結構）：
7. 5-6 P04／3-5 P03：旁白 "Her webbed feet kept her steady…" 後緊接逐字自語 "My feet kept me steady!" 冗餘（H3-03）——二留一：保留台詞、旁白改敘動作（或反之）。
8. 5-6 P06／3-5 P05："Lift, wings, lift!" 身體部位 vocative 生硬（H3-04）——改自然自我喊話（避免與 2-3 P06 "Up, up, up—" 撞句）。
9. 5-6 P08／3-5 P07："Water pressed/pushed under her feet, and wind filled her wings." 搭配不自然（H3-05）——改 GA 自然搭配（方向示例："The water pushed at her feet. The wind tugged at her wings."）。
10. 5-6 P07／3-5 P06（polish，H3-06）："spun until her open wings helped her straighten out" 機械——例如 "spun in a little circle—until her wings steadied her."
11. 5-6 P09（polish，H3-07）："opened her wings" → "spread her wings"。

### 兩語一致性 — 輕量補拍（建議隨輪執行）

12. 5-6 P11：母本「看看腳掌，看看翅膀，再看看身邊的朋友」的能力辨認拍在 en-US 被刪——補回三看節奏（方向示例："An-An looked at her feet. She looked at her wings. Then she looked at her friends."），讓辨認→選擇的鋪墊完整。

## 逐頁修改標注

| 語言 | 檔位 | 頁碼 | 問題維度 | 修改指令 |
|---|---|---|---|---|
| en-US | 5-6 | P10 | 圖文配合／兩語一致／朗讀 | 刪 "A V!"；V 改未成形大水紋；全頁收兩口氣 |
| en-US | 3-5 | P09 | 圖文配合／兩語一致 | "forming a V" → 未成形長水紋 |
| en-US | 5-6 | P13 | 圖文配合（負載遺漏） | 補主題錨句（sky-fast/water-slow 對應句） |
| en-US | 2-3 | P01 | 幼兒可理解性 | 補 V 隊形 setup（"…in a V!"） |
| en-US | 2-3 | P09 | 幼兒可理解性 | setup 補好後微調指涉句 |
| en-US | 5-6/3-5 | P04/P03 | 朗讀自然度 | 冗餘 kept-steady 二留一 |
| en-US | 5-6/3-5 | P06/P05 | 朗讀自然度 | "Lift, wings, lift!" 改自然喊話 |
| en-US | 5-6/3-5 | P08/P07 | 朗讀自然度 | 水／風搭配詞改 GA 自然搭配 |
| en-US | 5-6/3-5 | P07/P06 | 朗讀自然度(polish) | 轉圈句去機械感 |
| en-US | 5-6 | P09 | 朗讀自然度(polish) | opened → spread |
| en-US | 5-6 | P11 | 兩語一致性(輕) | 補「三看」辨認拍 |

## 待 Stacy 裁決項（不在修改 agent 權限內，與上表並行）

| 決定點 | 來源 | 建議 |
|---|---|---|
| Display title 改 *The Little Swan Grows in Her Own Time* | gate4 上呈④ | 支持；slug／目錄不動，book.yaml `title.en-US` 連動 en-GB |
| 2-3 `swish` motif 低齡豁免 | gate4 上呈③ | 建議豁免（與 gate3 接受 zh 省略沙啦的先例一致），並補註 per-tier 範圍 |
| 2-3 因果鏈是否跨語補回 | gate4 上呈② | 建議維持凍結不補（解凍級變更） |
| 收束式並列形 "One V flew. One V swam."＋5-6 P14 旁白改台詞 | 本審 F4 | 建議接受並記錄為刻意取捨 |
| R3 未收斂整包接受範圍 | gate4 上呈① | 本報告第 7-11 條即為「修語言不動結構」的定向清單，可直接作為接受範圍的執行稿 |

## 修改後的品牌紅線提醒

修改時不可違反：
1. 旁白從不對聽眾出題
2. 旁白從不總結道理
3. 收尾永遠回到「大家在一起」
4. 角色名和擬聲詞必須和 registry 一致，不得自行更改——並於本輪回填 registry en-US 欄：`character_names.md` swan_anan → An-An；`onomatopoeia_map.md` 翅膀試飛 → `flap, flap, flap!`、安全落水 → `PLOP!`、游出水紋 → `swish, swish, swish!`
5. 疊句與變奏（"Faster, faster—…"／"Steady, steady—…"）已定稿，逐字不動；擬聲寫法維持現行三種形，零新變體

## 修改完成後

修改後的 en-US 三檔（落回 `text/en-US/*.draft.json`）連同重跑的 locale_lint 結果重新提交 S4 審查（piyo-copywriting-review），進入 R3 審查；若 Stacy 同時完成 gate4 裁決，R3 可與關卡④收斂合併驗收。
