# S4 Greenlight：《小天鵝慢慢長大》

## 審稿識別
- 繪本編號：PYO-008
- 繪本 Slug：the-little-swan-grows-in-time
- 書名（zh-TW）：《小天鵝慢慢長大》
- 審稿輪次：R3（R1＝材料不齊判退；R2＝12 條修改指令；本輪驗收修訂版）
- 審稿日期：2026-07-20
- 審稿依據：piyo-copywriting-review v0.9（docs/skill/skill-s4-copywriting-review.md）
- 審稿對象檔案：
  - zh-TW 三檔：`text/zh-TW/{2-3,3-5,5-6}.json`（gate3 凍結版，全程未動）
  - en-US 三檔：取自 Stacy 提供的更新版證據包 `gate4_en-US_review-PYO-008.md`（2026-07-20 23:12:09 生成；與根目錄 `gate4_en-US_review.md` 逐位元相同）逐頁表重建
- 本報告檔名：the-little-swan-grows-in-time_s4_review_R3_greenlight.md
- 判定：**GREENLIGHT — S4 文字審查放行**
- **範圍聲明：本 Greenlight 是 AI 文字審查放行，不是也不能取代關卡④ Stacy Green Light。TTS 生成開跑仍以 Stacy 完成 gate4 裁決為前提。**

## 來源文件核對
- S2 storyboard：`PYO-008_storyboard.md`
- Storyboard greenlit：是
- 核心訊息（提案卡）：一隻長得不一樣的小鳥慢慢長大，發現每個生命都有自己的時間表。

## R2 修改指令落實驗證（12/12，機械逐條核對）

| # | 指令 | 修訂後證據 | 驗證 |
|---|---|---|---|
| 1 | 5-6 P10 刪 "A V!"、V 改未成形 | "Her wide wake streamed behind them."，全頁縮回換氣帶內 | ✅ |
| 2 | 3-5 P09 未成形長水紋 | "three long wakes trailing behind them" | ✅ |
| 3 | P12 成形時刻不動 | 5-6 "opening into a V"／3-5 "making a V" 均保留 | ✅ |
| 4 | 5-6 P13 補主題錨句 | "The sky could hurry. The water could take its time."（優於審稿示例） | ✅ |
| 5 | 2-3 P01 補 V setup | "Birds flew above in a V!" | ✅ |
| 6 | 2-3 P09 指涉修 | "A V crossed the lake. Birds made one above!" 指涉鏈成立 | ✅ |
| 7 | kept-steady 冗餘二留一 | 旁白改敘動作（"kept paddling as she bobbed back"），台詞保留 | ✅ |
| 8 | "Lift, wings, lift!" 改喊話 | "Come on—higher!"，未與 2-3 "Up, up, up—" 撞句 | ✅ |
| 9 | 水／風搭配詞 | "Water pressed/pushed against her feet… wind tugged at her wings." | ✅ |
| 10 | 轉圈句去機械感 | "spun in a little circle—until her (open) wings steadied her." | ✅ |
| 11 | opened → spread | "spread her wings"，全文無 "opened her wings" | ✅ |
| 12 | 5-6 P11 三看辨認拍 | feet → wings → friends 三看齊備 | ✅ |

## 五維度判定

| 維度 | 判定 |
|---|---|
| 朗讀自然度 | 通過（zh-TW＋en-US；R3 可見工藝問題全數修畢，換氣偏長頁清零於 5-6） |
| 幼兒可理解性 | 通過（2-3 V 指涉鏈修復；無抽象詞宣告；三檔質化分檔成立） |
| 圖文配合度 | 通過（早交 V 解除、P10 辨認→P11 選擇→P12 成形四拍恢復；P13 負載補齊） |
| 品牌與 Registry 合規 | 通過（三條線＋結尾四件套零違規；lint 三檔 0 違規；registry en-US 欄依審包已回填為「提案」） |
| 三檔 × 兩語一致性 | 通過（映射全對；母本欄與凍結 zh-TW 逐字一致；疊句 9＋變奏 3、擬聲三形零漂移；兩語 beat／情緒弧線對齊） |

機檢紀錄：本 session 從審包重建三檔獨立重跑 `locale_lint.py --locale en-US`——0 違規（警告 4／5／5 均為 repeat_discount 折計，屬設計內）；折計後 84.5／234／329 全帶內。

## 審包流程紀律核驗（附帶確認）
- 歷史 `verdict: escalated` 三輪原樣保留、未開 Round 4、修訂以 `qa/en-US/revision_R2.md` 獨立記錄、狀態標 `awaiting next QA by Stacy` —— 符合「AI verdict 與人工授權分離」。
- P10／P09 舊中度偏移標記保留為「修訂前歷史、待下一輪 E 重判」，未由修訂方自行改判 —— 正確。

## 備註（不影響放行）

1. **待 Stacy 裁決 5 點**（審包也明列「仍未代裁」，本審不代裁）：① display title 改 *The Little Swan Grows in Her Own Time*（建議採納；slug 不動）；② 2-3 `swish` 低齡豁免（建議豁免，同 gate3 先例）；③ 2-3 因果鏈是否跨語補回（建議維持凍結）；④ 收束式並列形取捨（建議接受為刻意取捨）；⑤ Gate 4 Green Light 本身。①–④ 除非裁反向，均不需再動頁面文字。
2. **殘餘不可見項**：R3 歷史 10 項真問題中，ESL 獵手可見 6 項已全修；其餘 4 項在 round 檔內（不在本快照），本審以五維度重讀最終文本未見阻斷級問題，仍建議 Stacy 下一輪 QA／E 重判時覆核。
3. **快照限制**：`text/en-US/*.draft.json`、`qa/en-US/`、registry 回填後版本均只存在於 S4A 側 repo；本審以審包逐頁表為據。正式落地時 draft 原檔為準，需經 `piyo_deliver_gate.py` 交付，屆時建議抽驗 draft 與審包一致。
4. **TTS 前瞻**（非本關卡事項）：5-6 P12 "One down here!"／"One up there!" 說話者仍未歸屬，S5/S6 分角前需指定；5-6 P10 第三行為長複合行，karaoke 斷行建議按句切分。
