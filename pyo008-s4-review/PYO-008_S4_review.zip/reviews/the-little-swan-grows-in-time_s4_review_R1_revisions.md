# S4 修改指令：《小天鵝慢慢長大》

## 審稿識別
- 繪本編號：PYO-008
- 繪本 Slug：the-little-swan-grows-in-time
- 書名（zh-TW）：《小天鵝慢慢長大》
- 審稿輪次：R1（首輪）
- 審稿日期：2026-07-20
- 審稿依據：piyo-copywriting-review v0.9（docs/skill/skill-s4-copywriting-review.md）
- 審稿對象檔案：
  - `content/PYO-008_the-little-swan-grows-in-time/text/zh-TW/2-3.json` ✅
  - `content/PYO-008_the-little-swan-grows-in-time/text/zh-TW/3-5.json` ✅
  - `content/PYO-008_the-little-swan-grows-in-time/text/zh-TW/5-6.json` ✅
  - `text/en-US/2-3.json` ❌ **不存在**
  - `text/en-US/3-5.json` ❌ **不存在**
  - `text/en-US/5-6.json` ❌ **不存在**
- 本報告檔名：the-little-swan-grows-in-time_s4_review_R1_revisions.md
- 判定：**不通過 — 材料不齊（en-US 三檔缺失），補齊後重審**

## 來源文件核對
- S2 storyboard：`PYO-008_storyboard.md`（schema piyo_storyboard/v0.10；gate2 審包已出、站別已推進至 S3 之後 → 視為 greenlit）
- 核心訊息（提案卡，book_slate.md PYO-008）：一隻長得不一樣的小鳥慢慢長大，發現每個生命都有自己的時間表。（自我認知／自我接納；公版 Andersen 低壓改寫，避免外貌羞辱與「變美才被接納」）
- 前置狀態：`PYO-008_book.yaml` status = `zh-TW_text_frozen`（gate3 Green Light 2026-07-19）——**zh-TW 三檔已凍結**，本輪 zh-TW 側發現均為備註級，不要求解凍。

## 五維度判定總覽

| 維度 | 判定 |
|---|---|
| 朗讀自然度 | zh-TW 通過／en-US **無法審（檔案缺失）** |
| 幼兒可理解性 | zh-TW 通過 |
| 圖文配合度 | 通過（zh-TW × storyboard） |
| 品牌與 Registry 合規 | 通過（含 1 筆已登記 waiver，見備註 W1） |
| 三檔 × 兩語一致性 | 三檔一致性通過／兩語一致性 **無法審（en-US 缺失）** |

## 必須修改的項目

### 材料缺失 — 需補齊（阻斷本輪 Greenlight 的唯一原因）

**問題**：skill 要求六份文字檔缺一不可；PYO-008 目前只有 zh-TW 三檔，en-US 三檔從未產出（全 repo 搜尋確認不存在，其他同批書 PYO-009／012／013 均已有 `text/en-US/*.draft.json`）。PYO-008 尚停在 zh-TW 凍結、S4A 未啟動的狀態。

**修改指令**：
1. 依 v5 主線執行 S4A：以 `.claude/skills/piyo-text-writer/`（模式 B 盲稿改編制）產出 en-US 三檔至 `content/PYO-008_the-little-swan-grows-in-time/text/en-US/`。
2. en-US 完成後走 `.claude/skills/piyo-text-qa/` gate4 流程產出 `qa/review/gate4_en-US_review.md`。
3. 將六檔齊備的版本重新提交本 skill 進入 R2 完整審（屆時補審：en-US 朗讀自然度、翻譯腔、兩語 beat／情緒一致性、en-US 擬聲詞是否遵循 onomatopoeia map）。

## 逐頁修改標注

本輪無新增的必改項。zh-TW 側可審部分全數通過；下表為已登記事項與備註級觀察（不阻斷、不要求解凍）。

| 語言 | 檔位 | 頁碼 | 問題維度 | 說明（備註級） |
|---|---|---|---|---|
| zh-TW | 2-3 | P10（母版 P14） | 品牌合規（量化門檻） | **W1（已登記 waiver）**：收束式單句 25 字＞2-3 句長上限 15 字。locale_lint 實跑確認為三檔唯一違規；copy 總表已標 escalation「結構性衝突——收束式為 design.md 凍結宣告，不可拆不可縮」，gate3 帶此項 Green Light。維持現狀，無需動作。 |
| zh-TW | 三檔 | 多頁 | 朗讀自然度 | 「朋友／朋友們」單複數在頁間混用（如 2-3 P01「朋友」vs P07「朋友們」）。台灣口語兩者皆自然，唸讀無礙；若未來有解凍機會可順手統一，非必改。 |
| zh-TW | 5-6/3-5 | P05/P11/P12 | Registry 合規 | 游出水紋 motif 同用 registry 選字「沙啦」，但寫法有「沙啦沙啦——」（P05 長水紋）與「沙啦——」（P11/P12）兩種延展形；選字一致、僅疊用不同，lint 未判違規。2-3 檔依 copy 總表決策整檔省略「沙啦」（圖承載游水），亦屬記錄在案的檔位取捨。 |
| zh-TW | 各檔 | P04（母版） | 圖文配合度 | storyboard P04 負載含「游出水紋 motif」，copy 總表決策將「沙啦」移至 P05（每頁擬聲配額），已附理由、gate3 接受。屬記錄在案偏差，非新發現。 |

### 各維度審查摘要（zh-TW 可審範圍）

- **朗讀自然度**：三檔唸讀順口，台灣語感到位（「游呀游」「停了一下下」「咦？」「呢／呀」）；無簡體語感滲漏（無「進行」「開展」「小朋友們」）。句長短-長-短有節奏，擬聲詞（撲撲／噗通／沙啦）都落在動作爆點。翻頁 hook 落點正確：P09「安安跳到了最高最高的地方——」（動作中斷）、P05「是不是就能飛起來……」（懸念上揚）。2-3 每頁一口氣可唸完。
- **幼兒可理解性**：每頁一件事；無抽象詞宣告（「勇氣／自信」不出現；「自己的時間表」概念全程以「天空有天空的快，水面有水面的慢」等具象語呈現且僅入 5-6 檔）。情緒靠動作展現（「安安笑了」「停了一下下」），無旁白宣告心情。三檔是質化分檔而非刪字：2-3 電報式＝疊句＋擬聲主導、3-5 短中句混合、5-6 因果複句＋內心辨認，與 copy 總表取捨說明一致。
- **圖文配合度**：逐頁對 storyboard「文說什麼」負載核對，旁白／台詞／內心／擬聲／時間各項均由文字承擔，無一頁重述圖面已明示的視覺事實（低檔位刪內心、刪時間標記處均有「圖已表達」的記錄在案理由）。情緒語氣與分鏡情緒欄逐頁相符（P10 失落轉安靜＝「停了一下下。可是……」）。
- **品牌與 Registry 合規**：旁白零出題、零總結道理（P05 疑問句為安安內心自語，非對聽眾）；結尾四件套齊：收束式＋游回湖灣「大家在一起」＋無開放懸疑＋情緒安定。角色名「安安」與 `character_names.md`（swan_anan）一致，三檔一致；擬聲詞與 `onomatopoeia_map.md` 逐項吻合（撲撲 ×3、噗通 ×3、沙啦）。量化門檻 locale_lint 實跑：3-5／5-6 零違規，2-3 僅 W1。
- **三檔一致性**：頁面選用嚴格繼承 storyboard 三檔選用表（3-5 砍 P02/P13；2-3 砍 P02/P05/P08/P13），主線 beat 序列一致；疊句三現＋P11 變奏三檔齊備；收束式三檔逐字相同；角色名無暱稱漂移。
- **兩語一致性**：無法執行（en-US 缺失），列入 R2 補審清單。

## 修改後的品牌紅線提醒

（供 S4A en-US 撰寫 agent 一併遵守）
1. 旁白從不對聽眾出題
2. 旁白從不總結道理
3. 收尾永遠回到「大家在一起」
4. 角色名和擬聲詞必須和 registry 一致，不得自行更改（swan_anan 的 en-US 名依 design.md 提案為 An-An，落定時需回填 `character_names.md`；en-US 擬聲需依 onomatopoeia map 建立對應欄）
5. 重複句不逐字互譯：en-US 需自建韻律，維持「催促起飛 → 接納當下游法」的功能轉折（design.md 第 7 節）

## 修改完成後

補齊 en-US 三檔（S4A ＋ gate4 QA）後，將六份文字檔重新提交 S4 審查（piyo-copywriting-review），進入 R2 審查。

---

## 附：指定 QA 對象「gate4_en-US_review.md」核查結果

任務要求 QA `content/PYO-008_the-little-swan-grows-in-time/qa/review/gate4_en-US_review.md`。核查結論：

- **該檔案不存在**（PYO-008 的 `qa/review/` 只有 gate1／gate2／gate3_review.md；全 repo 搜尋亦無 PYO-008 的任何 gate4 檔）。
- 這與書目狀態自洽：`PYO-008_book.yaml` status = `zh-TW_text_frozen`（gate3 GL 2026-07-19），S4A 英文文案尚未啟動，自然沒有 gate4 審包。
- 對照同批派工的 PYO-009／PYO-012／PYO-013：三本皆已有 `text/en-US/*.draft.json` 與 `qa/review/gate4_en-US_review.md`，唯 PYO-008 未到站。判斷派工模板套用到了尚未進入 S4A 的書。
- 無檔可審＝本項 QA 無法執行；待 S4A＋gate4 產出後於 R2 一併補審。
