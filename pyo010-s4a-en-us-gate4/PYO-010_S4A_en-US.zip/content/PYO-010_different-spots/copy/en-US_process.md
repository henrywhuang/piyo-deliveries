# PYO-010 en-US S4A Process Record

## B0 Frozen String Table (Proposals)

| # | Type | Frozen String | Pages | Notes |
|---|---|---|---|---|
| F01 | refrain core | `Spots, spots, go away!` | P02, P05, P08 | Echoes "Rain, rain, go away" nursery rhyme — deeply familiar to American toddlers; 4 words, chantable |
| F02 | refrain variation | `Spots, spots — here to stay!` | P10 | Rhyming reversal of F01; preserves "wanting to hide → choosing to be seen" functional arc |
| F03 | ending prefix | `And from that day on` | P15 | Brand frozen unit (en-US spec brand_frozen_units, exempt max_sentence_len) |
| F04 | onomatopoeia | `SWISH!` | P03, P12 | Wind on petals/leaves (唰啦); O1 independent effect, all caps |
| F05 | onomatopoeia | `drip, drop, drip!` | P06 | Dew rolling (滴答); O3 rhythm pattern, lowercase |
| F06 | onomatopoeia | `crinkle, crinkle, crinkle!` | P08 (5-6 only) | Leaf bundle rustling (沙沙沙); O3 rhythm, lowercase; 3-5 shortened to `crinkle, crinkle!` |
| F07 | onomatopoeia | `SNAP!` | P11 | Rope breaking (啪); O1 independent effect, all caps |
| F08 | character name | `Dotty` | all | design.md §7 proposal; rhymes with "spotty," instant association |
| F09 | character name | `Roundy` | all | design.md §7 proposal; echoes "round" shape of neat black spots |

### Character Speech Patterns

- **Dotty**: Curious, determined little kid. Short declarative sentences. Contractions natural ("can't," "couldn't"). Refrain delivery shifts: whispered (P02) → said (P05, P08) → "clear and sure" (P10) — tracking growing confidence.
- **Roundy**: Brief reactions only. One exclamation at P13 ("I see you!") — warm, genuine. No coaching, no commentary on spots.

## B1 Fold Budget Table

### 5-6 (15 pages, max_total_len = 505 words)

| Element | Words | Occurrences | Repeat Discount | Folded Cost |
|---|---|---|---|---|
| Refrain F01 | 4 | 3 (P02, P05, P08) | 1st full, 2nd-3rd ×0.25 | 4 + 1 + 1 = 6 |
| Variation F02 | 5 | 1 (P10) | — | 5 |
| SWISH! F04 | 1 | 2 (P03, P12) | 1st full, 2nd ×0.25 | 1.25 |
| drip, drop, drip! F05 | 3 | 1 (P06) | — | 3 |
| crinkle ×3 F06 | 3 | 1 (P08) | — | 3 |
| SNAP! F07 | 1 | 1 (P11) | — | 1 |
| **Fixed total** | | | | **19.25** |
| **Remaining** | | | | **485.75 (ample)** |

### 3-5 (13 pages, max_total_len = 389 words)

| Element | Folded Cost |
|---|---|
| Refrain F01 ×3 | 6 |
| Variation F02 ×1 | 5 |
| SWISH! ×2 | 1.25 |
| drip, drop, drip! ×1 | 3 |
| crinkle ×2 (shortened) | 2 |
| SNAP! ×1 | 1 |
| **Fixed total** | **18.25** |
| **Remaining** | **370.75 (ample)** |

### 2-3 (10 pages, max_total_len = 88 words)

| Element | Folded Cost |
|---|---|
| Refrain F01 ×2 (P03, P08; P02, P05 skipped) | 4 + 1 = 5 |
| Variation F02 ×1 (P10) | 5 |
| SWISH! ×2 (P03, P12) | 1.25 |
| drip, drop, drip! ×1 (P06) | 3 |
| **Fixed total** | **14.25** |
| **Remaining** | **73.75 (tight; P15 ending = 14w at max_page_len)** |

2-3 note: crinkle (P08) and SNAP (P11) not used — P08 keeps refrain only, P11 skipped. Refrain embedded in P03 (same page as SWISH) following zh-TW 2-3 strategy — gives toddlers 2 refrain exposures. Multiple pages below target band lower (10) due to tight budget; justified by telegraph style + image authority. Raw total after B2 = 85 words (under 88 ✓).

## Blind Draft Discipline Declaration

B1 blind draft: **no zh-TW text files were opened** (`text/zh-TW/`, `copy/zh-TW.md`). Draft written solely from:
- `PYO-010_design.md` (concept contract, refrain, onomatopoeia, character definitions)
- `PYO-010_storyboard.md` ("文說什麼" column per page)
- `knowledge_base/locale_specs/en-US.md` (language rules, counting unit = word)
- `knowledge_base/story_creation/` (craft techniques, style guide, age calibration)
- B0 frozen string table above

## B2 Source Alignment Changes

B2 opened zh-TW frozen text (`text/zh-TW/{5-6,3-5,2-3}.json`) for cross-reference. Changes:

| Page | Tier | Change | Rationale |
|---|---|---|---|
| P06 | 5-6 | Removed "but two silly streaks stayed under her chin, like a little mustache!" | zh-TW P06 doesn't describe mustache (image carries humor); two-layer rule ②: text shouldn't restate visual facts zh-TW omitted. Internal feeling "much better" retained (= zh-TW "比較舒服") |
| P06 | 3-5 | Removed "two silly streaks stayed, like a mustache!" | Same as 5-6 |
| P06 | 2-3 | "Funny mustache!" → "Much better!" | Same principle; "Much better!" = internal feeling matching zh-TW "比較舒服" |
| P01 | 2-3 | "Dotty had shiny spots.\nRoundy's were dark.\nDotty wanted to hide." (11w) → "Dotty's spots were different.\nRoundy was right there." (8w) | Budget freed for P03 refrain embedding |
| P03 | 2-3 | "SWISH!\nThe petals blew into a silly hat!\nSpots came back out." → "Spots, spots, go away!\nSWISH!\nThe petals blew into a silly hat!" | zh-TW 2-3 P02 embeds refrain in same page as SWISH/hat result; adopting same strategy gives 2-3 readers 2 refrain exposures (P03 + P08) instead of 1 |

Word count impact: 5-6 = 435→423, 3-5 = 258→251, 2-3 = 88→85. All within limits.
