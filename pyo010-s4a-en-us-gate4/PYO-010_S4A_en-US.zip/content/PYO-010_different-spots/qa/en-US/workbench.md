# 關卡WB整合審閱：不一樣的斑點（E 對位底稿／en-US）

- 生成時間：2026-07-22 19:57:59 +0800
- 書目錄：`content/PYO-010_different-spots`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate WB`（決定性腳本，純解析＋排版）
- locale：en-US
- 用途：E 主審與裁決 agent 的單檔輸入 bundle——文字＝QA 對象本體逐字轉錄；可疑頁保留開原檔抽驗權

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-010_storyboard.md` | 2026-07-21 17:08:45 |
| copy | `copy/en-US.md` | 2026-07-22 19:46:12 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-21 17:08:45 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-22 19:44:58 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-21 17:08:45 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-22 19:44:54 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-21 17:08:45 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-22 19:44:50 |
| qa/en-US/backtranslation.md | `qa/en-US/backtranslation.md` | 2026-07-22 19:49:36 |

## 檔頭 commitments 逐字轉錄（兌現比對用）

```yaml
schema: piyo_copy/v0.9
slug: different-spots
locale: en-US
mode: B
storyboard: content/PYO-010_different-spots/PYO-010_storyboard.md
design: content/PYO-010_different-spots/PYO-010_design.md
image_pool: 15
selection:
  "3-5": [P01, P02, P03, P05, P06, P08, P09, P10, P11, P12, P13, P14, P15]
  "2-3": [P01, P03, P06, P08, P09, P10, P12, P13, P14, P15]
commitments:
  refrain: "Spots, spots, go away!"
  ending: "And from that day on"
  onomatopoeia: [SWISH!, "drip, drop, drip!", "crinkle, crinkle, crinkle!", SNAP!]
characters: [Dotty, Roundy]
```

## 檔位 5-6（15 頁）

### 5-6｜P01（母版 P01）

- 圖說什麼：遠景採前景角色大、背景縱深展開的深空間構圖：點點與圓圓以略偏側的並排角度佔畫面下方約三分之一，兩者背部與表情同時清楚，合成唯一主焦點群；點點低頭抬起一隻前腳指向自己固定的七顆珍珠銀斑，眉眼在意，晚霞已有太陽光形成七處柔和反射，不另加自發光暈；約 0.9x 的圓圓帶六顆黑斑與綠領巾，安靜友善地看著點點；中後景拉開雛菊光地全貌，低彩度簡單小徑輪廓 ×1 通往遠方，晚霞光帶 ×1 鋪過低矮雛菊 ×3 與軟草叢 ×2，背景不放第三主體；構圖裝置：對照雙圓
- 文說什麼：內心：注意差異後的在意與藏起願望<br>旁白：朋友未作評價的關係前提
- 鉤子：—
- 選圖與提純說明：R1 past tense narrator; 3-5 condensed setup; 2-3 telegraph setup【B2: condensed P01 to free budget for P03 refrain embedding, zh-TW 2-3 同策略】
- 匹配欄：✓

【zh-TW】
「我的斑點，好像不太一樣呢。」
點點好想把那些不一樣藏起來。
圓圓什麼都沒說，走在她旁邊。

【en-US】
Dotty looked down at her seven pearly spots. They caught the evening sun and shimmered — not like Roundy's six neat black ones at all.
Nobody said a word.
But Dotty wanted to hide them.

【回譯】
點點低頭看著她的七個珍珠色斑點。它們在傍晚的陽光下閃閃發光——一點也不像圓圓那六個整齊的黑色斑點。沒有人說一句話。但點點想把它們藏起來。
【偏移標記】輕微：en 以第三人稱感官描寫取代 zh 首人稱台詞「我的斑點，好像不太一樣呢。」，對比更顯式（珍珠銀/黑），核心語義同（想藏）

### 5-6｜P02（母版 P02）

- 圖說什麼：點點居畫面中央，三片大花瓣從左右搭成弧形披肩，完整遮住原本七顆斑點；她露出期待微笑，一隻前腳朝頁緣跨出，雛菊光地只留模糊雛菊 ×3 與軟草 ×1；構圖裝置：中央遮蓋弧
- 文說什麼：台詞：招牌疊句第一輪<br>旁白：第一次藏法的啟動
- 鉤子：—
- 選圖與提純說明：2-3 skips; P03 image carries petal-hat result
- 匹配欄：✓

【zh-TW】
「藏一藏，斑點看不見！」
點點用花瓣搭了一件小披肩，開心地往前走。

【en-US】
She draped three big petals over her back like a shawl.
"Spots, spots, go away!" she whispered.
Then she took one step forward.

【回譯】
她把三片大花瓣像披肩一樣披在背上。「斑點斑點，快走開！」她低聲說。然後她向前踏出一步。
【偏移標記】無

### 5-6｜P03（母版 P03）

- 圖說什麼：點點與圓圓在雛菊光地前景並肩踏出同一步，角色群仍佔畫面約四成；三片大花瓣已疊成點點頭頂的大花帽，固定的七顆珍珠銀斑重新露出並反射已有晚霞，點點笑彎眼，圓圓帶六顆黑斑與綠領巾回身貼近她微笑；彎曲風線 ×1 提供花瓣受風的動作源；背景細節層：畫角小蝸牛用一片迷你落瓣當傘，尺寸小且低彩度，不形成第三焦點；構圖裝置：斜向風弧
- 文說什麼：擬聲：花瓣受風的唰啦 motif<br>旁白：第一次藏法的滑稽結果與朋友關係不變
- 鉤子：—
- 選圖與提純說明：2-3 跳接 P01→P03: refrain bridges hiding intent; SWISH + hat = result; self-sufficient ✓【B2: zh-TW 2-3 同頁嵌疊句，照搬曝光策略；替換 "Spots came back out" 交圖】【R1 QA: F07 3-5 "Her spots"限定詞; F11 三檔 "walked back"→"walked right"; F12 2-3 引號一致】
- 匹配欄：✓

【zh-TW】
唰啦！晚風把花瓣吹到了點點頭上，變成一頂大花帽。
圓圓笑了笑，還是走在她旁邊。

【en-US】
SWISH!
The breeze flipped the petals into a big, silly flower hat!
Seven spots popped right back out.
Roundy walked right to Dotty's side, smiling.

【回譯】
咻！微風把花瓣翻成一頂大大的、傻傻的花帽子！七個斑點立刻又冒了出來。圓圓微笑著走到點點身邊。
【偏移標記】無

### 5-6｜P04（母版 P04）

- 圖說什麼：紅莓小溪的圓葉邊緣框住點點，她睜大眼好奇前傾，一隻前腳停在一滴紅莓果汁上方；紅莓果串 ×2、承汁圓葉 ×1、小溪亮帶 ×1，點點原本七顆銀斑在背上保持固定位置；構圖裝置：框中框
- 文說什麼：內心：第二種藏法點子萌生<br>旁白：新材料嘗試的起點
- 鉤子：—
- 選圖與提純說明：3-5/2-3 skip; P05 (3-5) bridges "found berry juice"
- 匹配欄：✓

【zh-TW】
點點看到紅莓汁，眼睛亮了起來。
「把汁塗上去，就看不出來了吧？」

【en-US】
Down by the berry brook, Dotty spotted a drop of red juice on a round leaf.
She reached out one little leg…

【回譯】
在莓果小溪旁，點點發現一片圓葉上有一滴紅色果汁。她伸出一條小小的腿……
【偏移標記】輕微：en 改用場景描寫＋動作懸念取代 zh 內心對白「把汁塗上去，就看不出來了吧？」，核心語義同

### 5-6｜P05（母版 P05）

- 圖說什麼：點點居畫面中央，七處紅莓汁塗層依原斑點位置形成遮蓋弧，一隻前腳黏在最後一處塗層上；她肩背緊縮、嘴角繃住，表情由專心轉不舒服；紅莓果串 ×2、圓葉 ×2、小溪亮帶 ×1；構圖裝置：中央遮蓋弧
- 文說什麼：台詞：招牌疊句第二輪<br>內心：背部黏緊感由專注轉不舒服
- 鉤子：—
- 選圖與提純說明：3-5 跳接 P03→P05: "This time" bridges from petal fail; "found berry juice" bridges skipped P04; self-sufficient ✓; 2-3 skips
- 匹配欄：✓

【zh-TW】
「藏一藏，斑點看不見！」
可是塗上以後，背又黏又緊，好不舒服。

【en-US】
Dotty dabbed berry juice over every spot.
"Spots, spots, go away!" she said.
The juice dried. Her back got tighter… and tighter… and stickier.

【回譯】
點點把莓果汁塗在每一個斑點上。「斑點斑點，快走開！」她說。果汁乾了。她的背越來越緊……越來越緊……越來越黏。
【偏移標記】無

### 5-6｜P06（母版 P06）

- 圖說什麼：點點在紅莓小溪旁以三分之二側身伸直全身，胸口抬起、六隻腳舒展，眼睛笑彎；下巴掛著兩道滑稽紅汁鬍子，背上固定七顆珍珠銀斑已全露出並只反射已有晚霞，臉側殘留露水珠 ×3；背景細節層：畫角同一隻小蝸牛把迷你落瓣放到下巴前模仿鬍子，尺寸小且低彩度，不干擾點點單一主體；構圖裝置：身體伸展弧
- 文說什麼：擬聲：露水洗色的滴答 motif<br>旁白：露水洗掉假色的直接結果<br>內心：原本背部較舒服的初次辨認
- 鉤子：—
- 選圖與提純說明：2-3 跳接 P03→P06: dew washes away; image authority; self-sufficient ✓; 2-3 below band: telegraph reveal, image carries humor【B2: zh-TW 不描寫鬍子→對位原則→三檔刪 mustache，改 internal "much better"（同 zh-TW "比較舒服"）】【R1 QA: F01 2-3 "Red"→"All"（2-3 莓汁頁被跳過, "Red" 無前因; zh-TW 策略「洗乾淨了」）】
- 匹配欄：✓

【zh-TW】
滴答、滴答，露水沖掉了紅莓汁。
點點伸直身體，深深地吸了一口氣。
嗯，原本的背比較舒服嘛。

【en-US】
drip, drop, drip!
Dew washed the red right off.
Dotty wiped her back and stretched. Her own spots actually felt… much better.

【回譯】
滴、答、滴！露水把紅色洗掉了。點點擦了擦背，伸展了一下。她自己的斑點其實感覺……好多了。
【偏移標記】無

### 5-6｜P07（母版 P07）

- 圖說什麼：天色轉暗的乾葉藏處全貌中，寬大乾葉 ×1 已把點點全身包成封閉葉子團，背部、固定七顆斑點與六隻腳全部藏在葉內，只從一道窄葉縫露出專注的雙眼；點點從葉內完成最後一拉，環繞葉團的柔草繩 ×1 已繃緊，外側草繩結 ×1 牢牢收住葉緣，短繩尾仍帶一條剛收緊的動作弧線；三岔路輪廓在遠處保持簡單；構圖裝置：包覆剪影
- 文說什麼：時間：天色轉暗後的第三次嘗試<br>內心：最後一次藏好斑點的決心
- 鉤子：—
- 選圖與提純說明：3-5/2-3 skip; P08 bridges "hid inside a big dry leaf tied with grass rope" (3-5) / "hid inside a leaf" (2-3)
- 匹配欄：✓

【zh-TW】
天色暗了。
這次，點點用草繩把自己綁進一片大乾葉裡。
「一定要藏好！」

【en-US】
The sky grew dim. Dotty found a big dry leaf and a soft grass rope.
She tied the leaf tight around herself — back, spots, and all six legs.

【回譯】
天色暗了下來。點點找到一片大的乾葉子和一條柔軟的草繩。她把葉子緊緊綁在自己身上——背、斑點和全部六條腿。
【偏移標記】輕微：en 缺 zh 決心台詞「一定要藏好！」，改以動作細節替代

### 5-6｜P08（母版 P08）

- 圖說什麼：寬大乾葉包成的葉子團佔畫面約六成，停在乾葉藏處的簡單草徑中央；點點的雙眼從單一葉縫向下尋找被完全遮住的腳，眉眼由得意轉空落，固定七顆斑點也全不可見；葉子團外只有一圈沙沙轉動的殘留弧線與草繩結 ×1，無其他角色；構圖裝置：中央遮蓋弧
- 文說什麼：台詞：招牌疊句第三輪<br>擬聲：葉子團轉動的沙沙聲源<br>內心：全藏成功後看不見自己的空落
- 鉤子：—
- 選圖與提純說明：3-5 跳接 P06→P08: "hid inside a big dry leaf tied with grass rope" self-bridges P07; self-sufficient ✓; 3-5 above band (27/25): P07 bridge + refrain + ono + consequence all needed; 2-3 跳接 P06→P08: "hid inside a leaf" + refrain + "No feet!"; self-sufficient ✓
- 匹配欄：✓

【zh-TW】
「藏一藏，斑點看不見！」
沙沙沙，那團葉子在地上轉呀轉。
可是，連自己的腳也看不到了。

【en-US】
crinkle, crinkle, crinkle!
The leaf bundle spun in a circle.
"Spots, spots, go away!" she said.
It worked — her spots were completely hidden.
But Dotty looked down… and she couldn't even see her own feet.

【回譯】
窸窣、窸窣、窸窣！葉子包裹轉了一圈。「斑點斑點，快走開！」她說。成功了——她的斑點完全藏起來了。但點點低頭一看……她連自己的腳都看不到了。
【偏移標記】無

### 5-6｜P09（母版 P09）

- 圖說什麼：薄霧岔路以三條平緩草徑形成清楚放射線，霧只薄覆地面；前景大比例的圓圓帶六顆黑斑與綠領巾，一隻前腳懸在錯路上方，眼神猶豫，領巾安靜垂下；側後方的點點仍是乾葉團，只露出一雙擔心的眼睛看向圓圓；兩個角色各為一個大焦點群，三條路以外不放細節；構圖裝置：三岔放射線
- 文說什麼：內心：圓圓的方向不確定與點點的擔心<br>旁白：走錯危機的未決狀態
- 鉤子：懸念型：圓圓前腳懸在錯路上方，落腳結果留到下一頁
- 選圖與提純說明：2-3 below band: crisis page, minimal text + image authority for mist/paths/wrong turn【R1 QA: F02 3-5 "find"→"tell"（搭配修正, 與 5-6 統一）】
- 匹配欄：✓

【zh-TW】
薄霧蓋住三條路。
圓圓停下來。
看看左邊。看看右邊。
點點好擔心。
圓圓的腳，往那條路伸過去——

【en-US】
Thin mist drifted across three paths.
Roundy's green scarf hung still. She couldn't tell which way led home.
One little leg hovered over the wrong turn.
Inside the leaf bundle, Dotty saw it all.

【回譯】
薄霧飄過三條小路。圓圓的綠色圍巾靜靜垂著。她分不清哪條路通往家。一條小小的腿懸在錯誤的岔路上方。在葉子包裹裡面，點點全都看到了。
【偏移標記】輕微：en 加領巾視覺描述（E 對位不通過）＋改 zh 頓拍式「看看左邊。看看右邊。」為描述式；zh「點點好擔心」內心句改 en「Dotty saw it all」

### 5-6｜P10（母版 P10）

- 圖說什麼：點點主動把葉子團轉向圓圓並移到草徑中央可見處，頭部與一隻前腳探到弧形葉緣外，前腳穩穩按在唯一草繩結上；固定七顆斑點仍全被乾葉遮住，她眉眼踏實直視圓圓；約 0.9x 的圓圓帶六顆黑斑與綠領巾，在同一視線端停步看她；寬大乾葉 ×1、草繩結 ×1；構圖裝置：中央遮蓋弧
- 文說什麼：台詞：招牌疊句反轉輪與主動被看見選擇<br>內心：由空落轉為踏實的決定
- 鉤子：—
- 選圖與提純說明：Refrain reversal F02; 2-3 below band: reversal + declaration only, tight budget【R1 QA: F08 5-6 "placed"→"held"（搭配修正）; F10 2-3 "Dotty grabbed the rope."→"No more hiding!"（繩未在 2-3 出現, 跟隨 zh-TW 宣告策略）】
- 匹配欄：✓

【zh-TW】
點點看著圓圓，心裡忽然踏實了。
她不想再把自己藏起來了。
「不藏了，讓你看見我！」

【en-US】
Dotty pushed the leaf bundle forward and held one leg steady on the rope knot.
"Spots, spots — here to stay!" she said, clear and sure.

【回譯】
點點把葉子包裹往前推，一隻腳穩穩踩在繩結上。「斑點、斑點——留下來！」她說，清楚又堅定。
【偏移標記】輕微：en 以外在動作＋疊句反轉替代 zh 內心轉折「心裡忽然踏實了。她不想再把自己藏起來了。」，主題意圖同

### 5-6｜P11（母版 P11）

- 圖說什麼：乾葉藏處的草地近處，點點用兩隻前腳把柔草繩 ×1 拉到最緊，身體向後用力、眼睛專注；草繩結 ×1 已鬆開，寬大乾葉 ×1 只彈開一角，露出珊瑚紅翅鞘邊緣但尚未露出任何斑點；構圖裝置：斜拉張力線
- 文說什麼：旁白：拉繩動作的最高點與結果延後<br>擬聲：草繩繃開的短促聲源
- 鉤子：動作中斷型：草繩拉到最緊，乾葉一角剛彈開
- 選圖與提純說明：2-3 skips; P10→P12 causal chain intact (P10 refrain reversal → P12 spots emerge)
- 匹配欄：✓

【zh-TW】
啪！
點點用力拉住草繩，身體往後一仰。
乾葉的一角，剛剛彈開——

【en-US】
Dotty pulled hard with both front legs.
SNAP!
The grass rope gave way. One corner of the dry leaf popped open.

【回譯】
點點用兩條前腿用力拉。啪！草繩斷了。乾葉子的一個角彈開了。
【偏移標記】無

### 5-6｜P12（母版 P12）

- 圖說什麼：晚風正把鬆開的寬大乾葉 ×1 帶到畫面右上緣，點點在乾葉藏處中央站穩伸展，固定七顆珍珠銀斑全部露出，表情輕鬆；乾葉與草繩結維持連在一起，不纏角色；一片帶露水的高葉尖只從翻頁側入框，點點的視線與身體朝向它，斑點沒有獨立光暈；構圖裝置：對角飛散線
- 文說什麼：擬聲：乾葉受風的唰啦 motif<br>旁白：遮蓋解除後被看見的事件結果
- 鉤子：視覺引導型：飛葉弧線與點點視線指向頁緣濕葉
- 選圖與提純說明：2-3 跳接 P10→P12: P10 established rope action; result (leaf away + spots) clear; self-sufficient ✓; 2-3 below band: extreme telegraph reveal, image carries
- 匹配欄：✓

【zh-TW】
唰啦——晚風把乾葉帶走了。
斑點一顆一顆露了出來。

【en-US】
SWISH!
The evening breeze lifted the leaf and carried it away.
All seven pearly spots shone in the open air.

【回譯】
咻！傍晚的微風掀起葉子，把它吹走了。全部七個珍珠色斑點在空氣中閃耀。
【偏移標記】無

### 5-6｜P13（母版 P13）

- 圖說什麼：第一片濕高葉佔畫面中央約一半，點點的完整全身與圓圓的前半身在近距離內同時清楚；點點停在葉面中央，身體保持單一站立姿勢，神情專注又有希望；露水珠 ×3 沾在固定七顆珍珠銀斑表面，已有月光形成七處近距離反射而無自發光暈；圓圓帶六顆黑斑與綠領巾，抬起一隻前腳、睜大眼看見第一站亮點，尚未前進；兩隻角色各為一個大而清楚的焦點，濕高葉 ×1，背景只留低密度薄霧；構圖裝置：視線接力線
- 文說什麼：旁白：近葉反射機制的第一站結果<br>台詞：圓圓辨認近處指引的短反應
- 鉤子：動作中斷型：圓圓抬起前腳朝第一站亮點，尚未落步
- 選圖與提純說明：2-3 below band: moonlight reflection + Roundy's dialogue; image carries mechanism
- 匹配欄：✓

【zh-TW】
點點飛到濕葉上，露水沾上了斑點。
月光一照，斑點閃了一下。
圓圓看見了——

【en-US】
Dotty landed on a wet leaf nearby. Dew touched her spots, and the moonlight bounced off — a soft, close glow.
Roundy's eyes went wide. "I see you!"

【回譯】
點點降落在附近一片濕葉子上。露水碰到她的斑點，月光反射出來——柔和的、近近的光芒。圓圓的眼睛瞪大了。「我看到你了！」
【偏移標記】輕微：en 提前圓圓辨認台詞至 P13（zh 在 P14「那邊有亮亮的！」）

### 5-6｜P14（母版 P14）

- 圖說什麼：月光下的第二片濕高葉緊鄰三葉草家門，高潮到達瞬間鋪滿全頁；點點停在家門旁高葉上，固定七顆珍珠銀斑只反射已有月光，神情踏實；約 0.9x 的圓圓帶六顆黑斑與綠領巾，一隻前腳剛落上家門苔地，回頭與點點相視安心；點點、圓圓與三葉草家門三點構成畫面下半部的緊密三角群聚，角色群保持大而清楚；濕高葉 ×1、三葉草拱門 ×1、薄霧帶 ×1，無連續路程或多時刻分格；本頁為全書明暗對比最高點：冷藍月光底上，濕葉斑點的既有月光反射與家門柔暖光同時達到全書最亮，但只提高明暗差，不使用高飽和色塊，整體維持低飽和水彩基調；構圖裝置：家門下半部三角群聚
- 文說什麼：旁白：跟隨近處指引後的到家結果<br>台詞：到達時的安心短反應
- 鉤子：—
- 選圖與提純說明：2-3 below band: "followed the glow" + "Home!" = telegraph climax
- 匹配欄：✓

【zh-TW】
「那邊有亮亮的！」
點點飛到下一片濕葉。
斑點又閃了一下。
圓圓跟著亮點走。
一步、一步，踩到家門口了。

【en-US】
Dotty hopped to the next leaf, even closer to home. Her spots caught the moonlight once more.
Roundy followed the glow — one step, then another — all the way to the clover door.
They were home.

【回譯】
點點跳到下一片葉子上，離家更近了。她的斑點再次映照月光。圓圓跟著那道光芒——一步，又一步——一路走到苜蓿門前。她們到家了。
【偏移標記】輕微：en 缺圓圓台詞「那邊有亮亮的！」（B-4 對話比議題）

### 5-6｜P15（母版 P15）

- 圖說什麼：三葉草家門前的柔軟苔地只放一個安靜舞姿瞬間：點點與圓圓緊靠成一個中央焦點群，各自抬起同側一隻前腳，笑著在晚風裡擺動；點點固定七顆原本珍珠銀斑完整露出並只承接已有月光，圓圓保持六顆黑斑、綠領巾與 0.9x 比例；沒有迷路、帶路或指引動作；柔光窗 ×1、三葉草拱門 ×1 與苔地反照共同形成家門柔暖光，主導並覆蓋中央舞姿群，月光藍退為低飽和背景層；背景細節層：同一隻小蝸牛在畫角舉著迷你落瓣輕擺，完成自己的小舞，尺寸小且低彩度；大量留白包住中央舞姿，全頁使用低飽和、低對比的暖色收束，維持安心入睡基調；構圖裝置：中央環舞。
- 文說什麼：時間：後來的固定收束式功能<br>旁白：無帶路任務仍露出原本斑點的收暖結果
- 鉤子：—
- 選圖與提純說明：Brand frozen unit "And from that day on" exempt max_sentence_len; 5-6 adds rhyme pair ("No one to guide. Nothing to hide."); 2-3 distills to core
- 匹配欄：✓

【zh-TW】
後來呀，點點帶著不一樣的斑點，在晚風裡開開心心地跳舞。
圓圓也在旁邊，跳著跳著就笑了。

【en-US】
And from that day on, Dotty danced in the evening breeze with all seven spots shining.
No one to guide. Nothing to hide.
Roundy danced right beside her.

【回譯】
後來呀，點點在傍晚的微風中跳舞，七個斑點全都閃閃發亮。不用引路。不用躲藏。圓圓就在她身旁跳舞。
【偏移標記】輕微：en 新增原創韻句「No one to guide. Nothing to hide.」（zh 無）；zh「笑了」en 無

## 檔位 3-5（13 頁）

### 3-5｜P01（母版 P01）

- 圖說什麼：遠景採前景角色大、背景縱深展開的深空間構圖：點點與圓圓以略偏側的並排角度佔畫面下方約三分之一，兩者背部與表情同時清楚，合成唯一主焦點群；點點低頭抬起一隻前腳指向自己固定的七顆珍珠銀斑，眉眼在意，晚霞已有太陽光形成七處柔和反射，不另加自發光暈；約 0.9x 的圓圓帶六顆黑斑與綠領巾，安靜友善地看著點點；中後景拉開雛菊光地全貌，低彩度簡單小徑輪廓 ×1 通往遠方，晚霞光帶 ×1 鋪過低矮雛菊 ×3 與軟草叢 ×2，背景不放第三主體；構圖裝置：對照雙圓
- 文說什麼：內心：注意差異後的在意與藏起願望<br>旁白：朋友未作評價的關係前提
- 鉤子：—
- 選圖與提純說明：R1 past tense narrator; 3-5 condensed setup; 2-3 telegraph setup【B2: condensed P01 to free budget for P03 refrain embedding, zh-TW 2-3 同策略】
- 匹配欄：✓

【zh-TW】
「我的斑點，不太一樣。」
點點好想藏起來。
圓圓走在她旁邊。

【en-US】
Dotty looked down at her seven pearly spots — they shimmered in the sun.
Roundy's black spots didn't shine at all.
Dotty wanted to hide hers.

【回譯】
點點低頭看著她的七個珍珠色斑點——它們在陽光下閃閃發光。圓圓的黑色斑點一點也不會發光。點點想把自己的藏起來。
【偏移標記】輕微：同 5-6 P01，第三人稱描寫取代 zh 首人稱台詞

### 3-5｜P02（母版 P02）

- 圖說什麼：點點居畫面中央，三片大花瓣從左右搭成弧形披肩，完整遮住原本七顆斑點；她露出期待微笑，一隻前腳朝頁緣跨出，雛菊光地只留模糊雛菊 ×3 與軟草 ×1；構圖裝置：中央遮蓋弧
- 文說什麼：台詞：招牌疊句第一輪<br>旁白：第一次藏法的啟動
- 鉤子：—
- 選圖與提純說明：2-3 skips; P03 image carries petal-hat result
- 匹配欄：✓

【zh-TW】
「藏一藏，斑點看不見！」
點點用花瓣搭了一件小披肩。

【en-US】
She tucked three big petals over her back like a cape.
"Spots, spots, go away!"

【回譯】
她把三片大花瓣像斗篷一樣蓋在背上。「斑點斑點，快走開！」
【偏移標記】無

### 3-5｜P03（母版 P03）

- 圖說什麼：點點與圓圓在雛菊光地前景並肩踏出同一步，角色群仍佔畫面約四成；三片大花瓣已疊成點點頭頂的大花帽，固定的七顆珍珠銀斑重新露出並反射已有晚霞，點點笑彎眼，圓圓帶六顆黑斑與綠領巾回身貼近她微笑；彎曲風線 ×1 提供花瓣受風的動作源；背景細節層：畫角小蝸牛用一片迷你落瓣當傘，尺寸小且低彩度，不形成第三焦點；構圖裝置：斜向風弧
- 文說什麼：擬聲：花瓣受風的唰啦 motif<br>旁白：第一次藏法的滑稽結果與朋友關係不變
- 鉤子：—
- 選圖與提純說明：2-3 跳接 P01→P03: refrain bridges hiding intent; SWISH + hat = result; self-sufficient ✓【B2: zh-TW 2-3 同頁嵌疊句，照搬曝光策略；替換 "Spots came back out" 交圖】【R1 QA: F07 3-5 "Her spots"限定詞; F11 三檔 "walked back"→"walked right"; F12 2-3 引號一致】
- 匹配欄：✓

【zh-TW】
唰啦！花瓣變成大花帽了。
圓圓笑了笑，還是走在旁邊。

【en-US】
SWISH!
The breeze flipped the petals into a flower hat!
Her spots popped right back out.
Roundy walked right to Dotty's side.

【回譯】
咻！微風把花瓣翻成一頂花帽子！她的斑點立刻又冒了出來。圓圓走到點點身邊。
【偏移標記】無

### 3-5｜P04（母版 P05）

- 圖說什麼：點點居畫面中央，七處紅莓汁塗層依原斑點位置形成遮蓋弧，一隻前腳黏在最後一處塗層上；她肩背緊縮、嘴角繃住，表情由專心轉不舒服；紅莓果串 ×2、圓葉 ×2、小溪亮帶 ×1；構圖裝置：中央遮蓋弧
- 文說什麼：台詞：招牌疊句第二輪<br>內心：背部黏緊感由專注轉不舒服
- 鉤子：—
- 選圖與提純說明：3-5 跳接 P03→P05: "This time" bridges from petal fail; "found berry juice" bridges skipped P04; self-sufficient ✓; 2-3 skips
- 匹配欄：✓

【zh-TW】
這次用紅莓汁試試！
「藏一藏，斑點看不見！」
可是背好黏，好不舒服。

【en-US】
This time, Dotty found berry juice and dabbed it over every spot.
"Spots, spots, go away!"
Her back got tighter and stickier.

【回譯】
這一次，點點找到莓果汁，把它塗在每一個斑點上。「斑點斑點，快走開！」她的背越來越緊、越來越黏。
【偏移標記】無

### 3-5｜P05（母版 P06）

- 圖說什麼：點點在紅莓小溪旁以三分之二側身伸直全身，胸口抬起、六隻腳舒展，眼睛笑彎；下巴掛著兩道滑稽紅汁鬍子，背上固定七顆珍珠銀斑已全露出並只反射已有晚霞，臉側殘留露水珠 ×3；背景細節層：畫角同一隻小蝸牛把迷你落瓣放到下巴前模仿鬍子，尺寸小且低彩度，不干擾點點單一主體；構圖裝置：身體伸展弧
- 文說什麼：擬聲：露水洗色的滴答 motif<br>旁白：露水洗掉假色的直接結果<br>內心：原本背部較舒服的初次辨認
- 鉤子：—
- 選圖與提純說明：2-3 跳接 P03→P06: dew washes away; image authority; self-sufficient ✓; 2-3 below band: telegraph reveal, image carries humor【B2: zh-TW 不描寫鬍子→對位原則→三檔刪 mustache，改 internal "much better"（同 zh-TW "比較舒服"）】【R1 QA: F01 2-3 "Red"→"All"（2-3 莓汁頁被跳過, "Red" 無前因; zh-TW 策略「洗乾淨了」）】
- 匹配欄：✓

【zh-TW】
滴答、滴答，露水沖掉了紅莓汁。
嗯，原本的背比較舒服。

【en-US】
drip, drop, drip!
Dew washed the red off.
Dotty stretched. Her own back felt much better.

【回譯】
滴、答、滴！露水把紅色洗掉了。點點伸展了一下。她自己的背感覺好多了。
【偏移標記】無

### 3-5｜P06（母版 P08）

- 圖說什麼：寬大乾葉包成的葉子團佔畫面約六成，停在乾葉藏處的簡單草徑中央；點點的雙眼從單一葉縫向下尋找被完全遮住的腳，眉眼由得意轉空落，固定七顆斑點也全不可見；葉子團外只有一圈沙沙轉動的殘留弧線與草繩結 ×1，無其他角色；構圖裝置：中央遮蓋弧
- 文說什麼：台詞：招牌疊句第三輪<br>擬聲：葉子團轉動的沙沙聲源<br>內心：全藏成功後看不見自己的空落
- 鉤子：—
- 選圖與提純說明：3-5 跳接 P06→P08: "hid inside a big dry leaf tied with grass rope" self-bridges P07; self-sufficient ✓; 3-5 above band (27/25): P07 bridge + refrain + ono + consequence all needed; 2-3 跳接 P06→P08: "hid inside a leaf" + refrain + "No feet!"; self-sufficient ✓
- 匹配欄：✓

【zh-TW】
綁好葉子，再藏一次！
「藏一藏，斑點看不見！」
沙沙，轉呀轉。
可是，腳不見了。

【en-US】
Dotty hid inside a big dry leaf tied with grass rope.
"Spots, spots, go away!"
crinkle, crinkle! The leaf bundle spun.
She couldn't see her own feet.

【回譯】
點點躲進一片用草繩綁住的大乾葉子裡。「斑點斑點，快走開！」窸窣、窸窣！葉子包裹轉了起來。她看不到自己的腳了。
【偏移標記】無

### 3-5｜P07（母版 P09）

- 圖說什麼：薄霧岔路以三條平緩草徑形成清楚放射線，霧只薄覆地面；前景大比例的圓圓帶六顆黑斑與綠領巾，一隻前腳懸在錯路上方，眼神猶豫，領巾安靜垂下；側後方的點點仍是乾葉團，只露出一雙擔心的眼睛看向圓圓；兩個角色各為一個大焦點群，三條路以外不放細節；構圖裝置：三岔放射線
- 文說什麼：內心：圓圓的方向不確定與點點的擔心<br>旁白：走錯危機的未決狀態
- 鉤子：懸念型：圓圓前腳懸在錯路上方，落腳結果留到下一頁
- 選圖與提純說明：2-3 below band: crisis page, minimal text + image authority for mist/paths/wrong turn【R1 QA: F02 3-5 "find"→"tell"（搭配修正, 與 5-6 統一）】
- 匹配欄：✓

【zh-TW】
薄霧來了。
圓圓看看左邊。看看右邊。
腳，往那條路伸過去——

【en-US】
Mist covered three paths.
Roundy couldn't tell which way was home.
Inside the leaf bundle, Dotty saw her.

【回譯】
霧氣覆蓋了三條路。圓圓分不清哪條路是回家的。在葉子包裹裡面，點點看見了她。
【偏移標記】輕微：en 簡化為描述句取代 zh 頓拍式「看看左邊。看看右邊。」

### 3-5｜P08（母版 P10）

- 圖說什麼：點點主動把葉子團轉向圓圓並移到草徑中央可見處，頭部與一隻前腳探到弧形葉緣外，前腳穩穩按在唯一草繩結上；固定七顆斑點仍全被乾葉遮住，她眉眼踏實直視圓圓；約 0.9x 的圓圓帶六顆黑斑與綠領巾，在同一視線端停步看她；寬大乾葉 ×1、草繩結 ×1；構圖裝置：中央遮蓋弧
- 文說什麼：台詞：招牌疊句反轉輪與主動被看見選擇<br>內心：由空落轉為踏實的決定
- 鉤子：—
- 選圖與提純說明：Refrain reversal F02; 2-3 below band: reversal + declaration only, tight budget【R1 QA: F08 5-6 "placed"→"held"（搭配修正）; F10 2-3 "Dotty grabbed the rope."→"No more hiding!"（繩未在 2-3 出現, 跟隨 zh-TW 宣告策略）】
- 匹配欄：✓

【zh-TW】
點點看著圓圓。
她不想再藏了。
「不藏了，讓你看見我！」

【en-US】
Dotty pushed the leaf bundle forward and placed one leg on the rope knot.
"Spots, spots — here to stay!"

【回譯】
點點把葉子包裹往前推，把一條腿踩在繩結上。「斑點斑點——留下來！」
【偏移標記】輕微：同 5-6 P10，外在動作取代 zh 內心轉折

### 3-5｜P09（母版 P11）

- 圖說什麼：乾葉藏處的草地近處，點點用兩隻前腳把柔草繩 ×1 拉到最緊，身體向後用力、眼睛專注；草繩結 ×1 已鬆開，寬大乾葉 ×1 只彈開一角，露出珊瑚紅翅鞘邊緣但尚未露出任何斑點；構圖裝置：斜拉張力線
- 文說什麼：旁白：拉繩動作的最高點與結果延後<br>擬聲：草繩繃開的短促聲源
- 鉤子：動作中斷型：草繩拉到最緊，乾葉一角剛彈開
- 選圖與提純說明：2-3 skips; P10→P12 causal chain intact (P10 refrain reversal → P12 spots emerge)
- 匹配欄：✓

【zh-TW】
啪！點點拉住草繩，用力一扯。
乾葉的一角，彈開了——

【en-US】
SNAP!
Dotty pulled the grass rope hard. The dry leaf popped open — just one corner.

【回譯】
啪！點點用力拉草繩。乾葉子彈開了——只有一個角。
【偏移標記】無

### 3-5｜P10（母版 P12）

- 圖說什麼：晚風正把鬆開的寬大乾葉 ×1 帶到畫面右上緣，點點在乾葉藏處中央站穩伸展，固定七顆珍珠銀斑全部露出，表情輕鬆；乾葉與草繩結維持連在一起，不纏角色；一片帶露水的高葉尖只從翻頁側入框，點點的視線與身體朝向它，斑點沒有獨立光暈；構圖裝置：對角飛散線
- 文說什麼：擬聲：乾葉受風的唰啦 motif<br>旁白：遮蓋解除後被看見的事件結果
- 鉤子：視覺引導型：飛葉弧線與點點視線指向頁緣濕葉
- 選圖與提純說明：2-3 跳接 P10→P12: P10 established rope action; result (leaf away + spots) clear; self-sufficient ✓; 2-3 below band: extreme telegraph reveal, image carries
- 匹配欄：✓

【zh-TW】
唰啦——風把乾葉帶走了。
斑點一顆一顆露了出來。

【en-US】
SWISH!
The breeze lifted the leaf and carried it away.
All seven spots shone bright.

【回譯】
咻！微風掀起葉子，把它吹走了。全部七個斑點閃閃發亮。
【偏移標記】無

### 3-5｜P11（母版 P13）

- 圖說什麼：第一片濕高葉佔畫面中央約一半，點點的完整全身與圓圓的前半身在近距離內同時清楚；點點停在葉面中央，身體保持單一站立姿勢，神情專注又有希望；露水珠 ×3 沾在固定七顆珍珠銀斑表面，已有月光形成七處近距離反射而無自發光暈；圓圓帶六顆黑斑與綠領巾，抬起一隻前腳、睜大眼看見第一站亮點，尚未前進；兩隻角色各為一個大而清楚的焦點，濕高葉 ×1，背景只留低密度薄霧；構圖裝置：視線接力線
- 文說什麼：旁白：近葉反射機制的第一站結果<br>台詞：圓圓辨認近處指引的短反應
- 鉤子：動作中斷型：圓圓抬起前腳朝第一站亮點，尚未落步
- 選圖與提純說明：2-3 below band: moonlight reflection + Roundy's dialogue; image carries mechanism
- 匹配欄：✓

【zh-TW】
點點飛到濕葉上。
月光一照，斑點閃了一下——

【en-US】
Dotty landed on a wet leaf. Dew touched her spots — moonlight bounced off.
"I see you!" said Roundy.

【回譯】
點點降落在一片濕葉子上。露水碰到她的斑點——月光反射出來。「我看到你了！」圓圓說。
【偏移標記】輕微：en 新增「我看到你了」台詞（zh 3-5 P11 為敘述「月光一照，斑點閃了一下——」）

### 3-5｜P12（母版 P14）

- 圖說什麼：月光下的第二片濕高葉緊鄰三葉草家門，高潮到達瞬間鋪滿全頁；點點停在家門旁高葉上，固定七顆珍珠銀斑只反射已有月光，神情踏實；約 0.9x 的圓圓帶六顆黑斑與綠領巾，一隻前腳剛落上家門苔地，回頭與點點相視安心；點點、圓圓與三葉草家門三點構成畫面下半部的緊密三角群聚，角色群保持大而清楚；濕高葉 ×1、三葉草拱門 ×1、薄霧帶 ×1，無連續路程或多時刻分格；本頁為全書明暗對比最高點：冷藍月光底上，濕葉斑點的既有月光反射與家門柔暖光同時達到全書最亮，但只提高明暗差，不使用高飽和色塊，整體維持低飽和水彩基調；構圖裝置：家門下半部三角群聚
- 文說什麼：旁白：跟隨近處指引後的到家結果<br>台詞：到達時的安心短反應
- 鉤子：—
- 選圖與提純說明：2-3 below band: "followed the glow" + "Home!" = telegraph climax
- 匹配欄：✓

【zh-TW】
「那邊！」
點點飛到下一片葉子。
圓圓跟著亮點，一步一步走到家了。

【en-US】
Dotty hopped to the next leaf. Her spots caught the moonlight again.
Roundy followed the glow all the way to the clover door.

【回譯】
點點跳到下一片葉子上。她的斑點再次映照月光。圓圓跟著那道光芒一路走到苜蓿門前。
【偏移標記】輕微：en 缺圓圓台詞「那邊！」

### 3-5｜P13（母版 P15）

- 圖說什麼：三葉草家門前的柔軟苔地只放一個安靜舞姿瞬間：點點與圓圓緊靠成一個中央焦點群，各自抬起同側一隻前腳，笑著在晚風裡擺動；點點固定七顆原本珍珠銀斑完整露出並只承接已有月光，圓圓保持六顆黑斑、綠領巾與 0.9x 比例；沒有迷路、帶路或指引動作；柔光窗 ×1、三葉草拱門 ×1 與苔地反照共同形成家門柔暖光，主導並覆蓋中央舞姿群，月光藍退為低飽和背景層；背景細節層：同一隻小蝸牛在畫角舉著迷你落瓣輕擺，完成自己的小舞，尺寸小且低彩度；大量留白包住中央舞姿，全頁使用低飽和、低對比的暖色收束，維持安心入睡基調；構圖裝置：中央環舞。
- 文說什麼：時間：後來的固定收束式功能<br>旁白：無帶路任務仍露出原本斑點的收暖結果
- 鉤子：—
- 選圖與提純說明：Brand frozen unit "And from that day on" exempt max_sentence_len; 5-6 adds rhyme pair ("No one to guide. Nothing to hide."); 2-3 distills to core
- 匹配欄：✓

【zh-TW】
後來呀，點點帶著不一樣的斑點，開開心心地跳舞。
圓圓也在旁邊笑。

【en-US】
And from that day on, Dotty danced with all seven spots shining.
Roundy danced right beside her.

【回譯】
後來呀，點點跳著舞，七個斑點全都閃閃發亮。圓圓就在她身旁跳舞。
【偏移標記】無

## 檔位 2-3（10 頁）

### 2-3｜P01（母版 P01）

- 圖說什麼：遠景採前景角色大、背景縱深展開的深空間構圖：點點與圓圓以略偏側的並排角度佔畫面下方約三分之一，兩者背部與表情同時清楚，合成唯一主焦點群；點點低頭抬起一隻前腳指向自己固定的七顆珍珠銀斑，眉眼在意，晚霞已有太陽光形成七處柔和反射，不另加自發光暈；約 0.9x 的圓圓帶六顆黑斑與綠領巾，安靜友善地看著點點；中後景拉開雛菊光地全貌，低彩度簡單小徑輪廓 ×1 通往遠方，晚霞光帶 ×1 鋪過低矮雛菊 ×3 與軟草叢 ×2，背景不放第三主體；構圖裝置：對照雙圓
- 文說什麼：內心：注意差異後的在意與藏起願望<br>旁白：朋友未作評價的關係前提
- 鉤子：—
- 選圖與提純說明：R1 past tense narrator; 3-5 condensed setup; 2-3 telegraph setup【B2: condensed P01 to free budget for P03 refrain embedding, zh-TW 2-3 同策略】
- 匹配欄：✓

【zh-TW】
點點的斑點，不太一樣。
圓圓在旁邊。

【en-US】
Dotty's spots were different.
Roundy was right there.

【回譯】
點點的斑點不一樣。圓圓就在旁邊。
【偏移標記】無

### 2-3｜P02（母版 P03）

- 圖說什麼：點點與圓圓在雛菊光地前景並肩踏出同一步，角色群仍佔畫面約四成；三片大花瓣已疊成點點頭頂的大花帽，固定的七顆珍珠銀斑重新露出並反射已有晚霞，點點笑彎眼，圓圓帶六顆黑斑與綠領巾回身貼近她微笑；彎曲風線 ×1 提供花瓣受風的動作源；背景細節層：畫角小蝸牛用一片迷你落瓣當傘，尺寸小且低彩度，不形成第三焦點；構圖裝置：斜向風弧
- 文說什麼：擬聲：花瓣受風的唰啦 motif<br>旁白：第一次藏法的滑稽結果與朋友關係不變
- 鉤子：—
- 選圖與提純說明：2-3 跳接 P01→P03: refrain bridges hiding intent; SWISH + hat = result; self-sufficient ✓【B2: zh-TW 2-3 同頁嵌疊句，照搬曝光策略；替換 "Spots came back out" 交圖】【R1 QA: F07 3-5 "Her spots"限定詞; F11 三檔 "walked back"→"walked right"; F12 2-3 引號一致】
- 匹配欄：✓

【zh-TW】
「藏一藏，斑點看不見！」
唰啦！花瓣變成大花帽！
圓圓在旁邊笑。

【en-US】
"Spots, spots, go away!"
SWISH!
The petals blew into a silly hat!

【回譯】
斑點斑點，快走開！咻！花瓣吹成一頂傻傻的帽子！
【偏移標記】輕微：en 缺「圓圓在旁邊笑」

### 2-3｜P03（母版 P06）

- 圖說什麼：點點在紅莓小溪旁以三分之二側身伸直全身，胸口抬起、六隻腳舒展，眼睛笑彎；下巴掛著兩道滑稽紅汁鬍子，背上固定七顆珍珠銀斑已全露出並只反射已有晚霞，臉側殘留露水珠 ×3；背景細節層：畫角同一隻小蝸牛把迷你落瓣放到下巴前模仿鬍子，尺寸小且低彩度，不干擾點點單一主體；構圖裝置：身體伸展弧
- 文說什麼：擬聲：露水洗色的滴答 motif<br>旁白：露水洗掉假色的直接結果<br>內心：原本背部較舒服的初次辨認
- 鉤子：—
- 選圖與提純說明：2-3 跳接 P03→P06: dew washes away; image authority; self-sufficient ✓; 2-3 below band: telegraph reveal, image carries humor【B2: zh-TW 不描寫鬍子→對位原則→三檔刪 mustache，改 internal "much better"（同 zh-TW "比較舒服"）】【R1 QA: F01 2-3 "Red"→"All"（2-3 莓汁頁被跳過, "Red" 無前因; zh-TW 策略「洗乾淨了」）】
- 匹配欄：✓

【zh-TW】
身上黏黏的。
滴答、滴答，洗乾淨了。
嗯，這樣比較舒服！

【en-US】
drip, drop, drip!
All washed off!
Much better!

【回譯】
滴、答、滴！全部洗掉了！好多了！
【偏移標記】輕微：en 缺 zh「身上黏黏的」前因，直接從 drip 聲開始；修正後 "All" 不再指名紅色，與 zh「洗乾淨了」策略趨近

### 2-3｜P04（母版 P08）

- 圖說什麼：寬大乾葉包成的葉子團佔畫面約六成，停在乾葉藏處的簡單草徑中央；點點的雙眼從單一葉縫向下尋找被完全遮住的腳，眉眼由得意轉空落，固定七顆斑點也全不可見；葉子團外只有一圈沙沙轉動的殘留弧線與草繩結 ×1，無其他角色；構圖裝置：中央遮蓋弧
- 文說什麼：台詞：招牌疊句第三輪<br>擬聲：葉子團轉動的沙沙聲源<br>內心：全藏成功後看不見自己的空落
- 鉤子：—
- 選圖與提純說明：3-5 跳接 P06→P08: "hid inside a big dry leaf tied with grass rope" self-bridges P07; self-sufficient ✓; 3-5 above band (27/25): P07 bridge + refrain + ono + consequence all needed; 2-3 跳接 P06→P08: "hid inside a leaf" + refrain + "No feet!"; self-sufficient ✓
- 匹配欄：✓

【zh-TW】
藏在葉子裡！
「藏一藏，斑點看不見！」
可是，腳也不見了。

【en-US】
Dotty hid inside a leaf.
"Spots, spots, go away!"
No feet!

【回譯】
點點躲進一片葉子裡。「斑點斑點，快走開！」看不到腳了！
【偏移標記】無

### 2-3｜P05（母版 P09）

- 圖說什麼：薄霧岔路以三條平緩草徑形成清楚放射線，霧只薄覆地面；前景大比例的圓圓帶六顆黑斑與綠領巾，一隻前腳懸在錯路上方，眼神猶豫，領巾安靜垂下；側後方的點點仍是乾葉團，只露出一雙擔心的眼睛看向圓圓；兩個角色各為一個大焦點群，三條路以外不放細節；構圖裝置：三岔放射線
- 文說什麼：內心：圓圓的方向不確定與點點的擔心<br>旁白：走錯危機的未決狀態
- 鉤子：懸念型：圓圓前腳懸在錯路上方，落腳結果留到下一頁
- 選圖與提純說明：2-3 below band: crisis page, minimal text + image authority for mist/paths/wrong turn【R1 QA: F02 3-5 "find"→"tell"（搭配修正, 與 5-6 統一）】
- 匹配欄：✓

【zh-TW】
霧來了。
圓圓看看左邊，看看右邊——

【en-US】
Mist came.
Roundy couldn't find home.

【回譯】
霧來了。圓圓找不到家。
【偏移標記】輕微：zh「看看左邊，看看右邊」en 改「找不到家」

### 2-3｜P06（母版 P10）

- 圖說什麼：點點主動把葉子團轉向圓圓並移到草徑中央可見處，頭部與一隻前腳探到弧形葉緣外，前腳穩穩按在唯一草繩結上；固定七顆斑點仍全被乾葉遮住，她眉眼踏實直視圓圓；約 0.9x 的圓圓帶六顆黑斑與綠領巾，在同一視線端停步看她；寬大乾葉 ×1、草繩結 ×1；構圖裝置：中央遮蓋弧
- 文說什麼：台詞：招牌疊句反轉輪與主動被看見選擇<br>內心：由空落轉為踏實的決定
- 鉤子：—
- 選圖與提純說明：Refrain reversal F02; 2-3 below band: reversal + declaration only, tight budget【R1 QA: F08 5-6 "placed"→"held"（搭配修正）; F10 2-3 "Dotty grabbed the rope."→"No more hiding!"（繩未在 2-3 出現, 跟隨 zh-TW 宣告策略）】
- 匹配欄：✓

【zh-TW】
點點不藏了。
「不藏了，讓你看見我！」

【en-US】
No more hiding!
"Spots, spots — here to stay!"

【回譯】
不再躲藏了！「斑點、斑點——留下來！」
【偏移標記】無（修正後 en「不再躲藏了」≈ zh「不藏了」，策略趨同）

### 2-3｜P07（母版 P12）

- 圖說什麼：晚風正把鬆開的寬大乾葉 ×1 帶到畫面右上緣，點點在乾葉藏處中央站穩伸展，固定七顆珍珠銀斑全部露出，表情輕鬆；乾葉與草繩結維持連在一起，不纏角色；一片帶露水的高葉尖只從翻頁側入框，點點的視線與身體朝向它，斑點沒有獨立光暈；構圖裝置：對角飛散線
- 文說什麼：擬聲：乾葉受風的唰啦 motif<br>旁白：遮蓋解除後被看見的事件結果
- 鉤子：視覺引導型：飛葉弧線與點點視線指向頁緣濕葉
- 選圖與提純說明：2-3 跳接 P10→P12: P10 established rope action; result (leaf away + spots) clear; self-sufficient ✓; 2-3 below band: extreme telegraph reveal, image carries
- 匹配欄：✓

【zh-TW】
唰啦——葉子飛走了。
斑點全都露出來了！

【en-US】
SWISH!
Spots came out!

【回譯】
咻！斑點出來了！
【偏移標記】無

### 2-3｜P08（母版 P13）

- 圖說什麼：第一片濕高葉佔畫面中央約一半，點點的完整全身與圓圓的前半身在近距離內同時清楚；點點停在葉面中央，身體保持單一站立姿勢，神情專注又有希望；露水珠 ×3 沾在固定七顆珍珠銀斑表面，已有月光形成七處近距離反射而無自發光暈；圓圓帶六顆黑斑與綠領巾，抬起一隻前腳、睜大眼看見第一站亮點，尚未前進；兩隻角色各為一個大而清楚的焦點，濕高葉 ×1，背景只留低密度薄霧；構圖裝置：視線接力線
- 文說什麼：旁白：近葉反射機制的第一站結果<br>台詞：圓圓辨認近處指引的短反應
- 鉤子：動作中斷型：圓圓抬起前腳朝第一站亮點，尚未落步
- 選圖與提純說明：2-3 below band: moonlight reflection + Roundy's dialogue; image carries mechanism
- 匹配欄：✓

【zh-TW】
月光照到斑點——亮了！
圓圓看見了——

【en-US】
Spots caught moonlight.
"I see you!" said Roundy.

【回譯】
斑點映照月光。「我看到你了！」圓圓說。
【偏移標記】無

### 2-3｜P09（母版 P14）

- 圖說什麼：月光下的第二片濕高葉緊鄰三葉草家門，高潮到達瞬間鋪滿全頁；點點停在家門旁高葉上，固定七顆珍珠銀斑只反射已有月光，神情踏實；約 0.9x 的圓圓帶六顆黑斑與綠領巾，一隻前腳剛落上家門苔地，回頭與點點相視安心；點點、圓圓與三葉草家門三點構成畫面下半部的緊密三角群聚，角色群保持大而清楚；濕高葉 ×1、三葉草拱門 ×1、薄霧帶 ×1，無連續路程或多時刻分格；本頁為全書明暗對比最高點：冷藍月光底上，濕葉斑點的既有月光反射與家門柔暖光同時達到全書最亮，但只提高明暗差，不使用高飽和色塊，整體維持低飽和水彩基調；構圖裝置：家門下半部三角群聚
- 文說什麼：旁白：跟隨近處指引後的到家結果<br>台詞：到達時的安心短反應
- 鉤子：—
- 選圖與提純說明：2-3 below band: "followed the glow" + "Home!" = telegraph climax
- 匹配欄：✓

【zh-TW】
「那邊！」圓圓跟著亮點走。
一步，一步。
到家了！

【en-US】
Roundy followed the glow.
Home!

【回譯】
圓圓跟著光芒走。到家了！
【偏移標記】輕微：en 缺圓圓台詞「那邊！」＋頓拍「一步，一步」

### 2-3｜P10（母版 P15）

- 圖說什麼：三葉草家門前的柔軟苔地只放一個安靜舞姿瞬間：點點與圓圓緊靠成一個中央焦點群，各自抬起同側一隻前腳，笑著在晚風裡擺動；點點固定七顆原本珍珠銀斑完整露出並只承接已有月光，圓圓保持六顆黑斑、綠領巾與 0.9x 比例；沒有迷路、帶路或指引動作；柔光窗 ×1、三葉草拱門 ×1 與苔地反照共同形成家門柔暖光，主導並覆蓋中央舞姿群，月光藍退為低飽和背景層；背景細節層：同一隻小蝸牛在畫角舉著迷你落瓣輕擺，完成自己的小舞，尺寸小且低彩度；大量留白包住中央舞姿，全頁使用低飽和、低對比的暖色收束，維持安心入睡基調；構圖裝置：中央環舞。
- 文說什麼：時間：後來的固定收束式功能<br>旁白：無帶路任務仍露出原本斑點的收暖結果
- 鉤子：—
- 選圖與提純說明：Brand frozen unit "And from that day on" exempt max_sentence_len; 5-6 adds rhyme pair ("No one to guide. Nothing to hide."); 2-3 distills to core
- 匹配欄：✓

【zh-TW】
後來呀，點點帶著不一樣的斑點。
開開心心跳舞。圓圓也笑了。

【en-US】
And from that day on, Dotty danced with her spots.
Roundy danced beside her.

【回譯】
後來呀，點點帶著她的斑點跳舞。圓圓在她身旁跳舞。
【偏移標記】無

