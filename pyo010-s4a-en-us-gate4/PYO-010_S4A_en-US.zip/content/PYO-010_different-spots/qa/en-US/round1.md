# QA 報告：different-spots / en-US / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: different-spots
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-22"
step1_lint: {exit_code: 0, warnings: 8}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 5, 朗讀口感: 7, 孩子抓得住度: 6}
  - id: en-US-parent
    scores: {睡前適讀性: 8, 零說教: 8}
  - id: en-US-editor
    scores: {母語自然度: 7, 文字工藝: 7}
step4_triage: {real: 7, rejected: 3, escalated: 4}
verdict: fix_required
```

## STEP 1 機檢

### copy_check.py

```
⚠ [band] 低於帶下緣：2-3 第 1 頁 8（帶底 10）— telegraph setup
⚠ [band] 低於帶下緣：2-3 第 3 頁 8（帶底 10）— telegraph reveal
⚠ [band] 超帶上緣：3-5 第 6 頁 27（帶頂 25）— P07 bridge + refrain + ono + consequence all needed
⚠ [band] 低於帶下緣：2-3 第 5 頁 6（帶底 10）— crisis page, minimal text + image authority
⚠ [band] 低於帶下緣：2-3 第 6 頁 8（帶底 10）— reversal + declaration only
⚠ [band] 低於帶下緣：2-3 第 7 頁 4（帶底 10）— telegraph reveal, image carries
⚠ [band] 低於帶下緣：2-3 第 8 頁 8（帶底 10）— moonlight + dialogue
⚠ [band] 低於帶下緣：2-3 第 9 頁 5（帶底 10）— telegraph climax
✅ copy 機檢通過（警告 8 筆）
```

判讀：2-3 多頁低於帶下緣為電報式語體（R7）合法，總量 84 字在帶內；3-5 P06 超帶上緣 27/25 因 P07 橋接＋疊句＋擬聲＋結果四元素需保留，非塞字。

### locale_lint.py ×3

```
5-6: ✅ 無違規（警告 3 筆：repeat_discount SWISH! P03/P12, refrain P05/P08, raw 423→folded 397.75）
3-5: ✅ 無違規（警告 3 筆：repeat_discount refrain P02/P04/P06, SWISH! P03/P10, raw 252→folded 245.25）
2-3: ✅ 無違規（警告 4 筆：frozen sentence P10 And from that day on…, repeat_discount refrain P02/P04, SWISH! P02/P07, raw 84→folded 80.25）
```

## STEP 2 checklist 自檢

**主題錨復述**：本書教孩子「不一樣不是缺陷，自我接納後反而能幫助別人」——點點的珍珠色斑點與眾不同，三次遮掩失敗後在圓圓迷路時主動露出斑點引路回家，賣點是三嘗試結構＋疊句反轉（go away → here to stay）的體感記憶。

### A-E 逐項判定

| 項 | 判定 | 證據 |
|---|---|---|
| A-1 主角目標 | PASS | 三檔：點點的隱性目標＝隱藏斑點（5-6 P01 "wanted to hide them"） |
| A-2 外在障礙 | PASS | 三次遮掩手段各自失敗：花瓣被風吹成帽子、莓果汁黏住背、葉子包裹困住腳 |
| A-3 內在衝突 | PASS | 想藏 vs 需要露（5-6 P09 看到圓圓迷路→P10 反轉疊句） |
| A-4 結尾共鳴 | PASS | 「danced with all seven spots shining」＝行為證明接納（非教訓宣言） |
| B-1 翻頁鉤子 | PASS | P01→P02 hide intent; P07 rope bundle build; P09 mist+wrong turn→P10 reversal |
| B-2 疊句三變奏 | PASS | 遮掩×3（P02/P05/P08）＋反轉（P10）結構完整 |
| B-3 擬聲詞配額 | PASS | SWISH! ×2, drip drop drip ×1, crinkle ×1, SNAP! ×1＝5 組 ≤ design 配額 |
| B-4 對話比例 | DEFER→TRIAGE | 三檔對話偏低（轉 F06） |
| C-1 句長配情緒 | PASS | 遮掩段短促爆發（SWISH!/SNAP!）、反轉段漸長（P10 兩句） |
| C-2 加速減速 | PASS | P01-P03 加速→P04-P06 中速→P07-P08 減速→P09 緊張→P10 爆發→P13-P15 回慢 |
| D-1 (stage-N/A) | — | |
| D-2 (stage-N/A) | — | |
| D-3 (stage-N/A) | — | |
| E-1 角色一致 | PASS | 點點從想藏→嘗試→失敗→為友露出＝弧線一致 |
| E-2 世界觀規則 | PASS | 斑點隱喻規則一致（珍珠色＝反光/引路＝天賦外化） |
| E-3 最後一頁 | PASS | P15 "danced…with all seven spots shining" 行為展示、非說教 |
| E-4 品牌語感 | PASS | "And from that day on…" golden ending |
| E-5 趣味兌現 | PASS | design 宣告逐項兌現：疊句反轉、三嘗試、擬聲 motif、花帽笑點、月光引路 |

快速掃描 9 項：#1-6 PASS, #7 stage-N/A, #8-9 PASS

### 對位逐頁比對

三檔逐頁掃描：文字專屬負載均為聲音（擬聲詞）、台詞（疊句）、內心（想藏/不藏）、時間（And from that day on）。5-6 P09 "Roundy's green scarf hung still" 為 E 轉 TRIAGE 項（F05：圍巾屬視覺描述，但 storyboard 有此元素，疑撞設計凍結——轉分診）。其餘頁無視覺事實重述。

### concept fidelity

三檔均通過。5-6 完整展開三次遮掩＋友情驅動反轉、3-5 壓縮但弧線自足、2-3 電報式但核心「藏→不藏→被看見」完整。

### 回譯偏移標記

S4A 逐頁全量回譯完成（38/38 頁覆蓋）。偏移標記摘要：
- 無偏移：24 頁
- 輕微偏移：13 頁（主要為 en 以第三人稱描寫取代 zh 首人稱台詞、外在動作取代內心獨白、頓拍式改描述式——改編手法差異，非語義漂移）
- 中度偏移：1 頁（2-3 P03 "Red washed off" 直接指名未引入物質→F01）

### ESL 獵手

**獵物①翻譯腔**：

| 檔位 | 頁 | 原句 | 問題 | 建議 |
|---|---|---|---|---|
| 3-5 | P07 | "find which way" | 不自然搭配，母語說 "tell which way" | "tell which way"→F02 |
| 5-6 | P10 | "placed one leg steady" | "placed…steady" 非標準搭配，"steady" 應為副詞或改動詞 | "held one leg steady"→F08 |
| 三檔 | P03 | "walked back to" | 圓圓未曾離開，"walked back" 暗示先前離開 | "walked right to"→F11 |

**獵物② AI 機械句**：未發現。三檔語感原生，無電報式裸動詞堆疊（2-3 為合法 R7 語體）。

訊源計量：獵手獨有 real 1（F08）｜回譯獨有 real 0｜人設獨有 real 3（F07, F10, F12）｜多路收斂 real 3（F01, F02, F11）

## STEP 3 人設 blind QA

### en-US-teacher (Ms. Rivera)

**分檔評分**：

| 維度 | 5-6 | 3-5 | 2-3 | min |
|---|---|---|---|---|
| 年齡適配度 | 8 | 7 | 5 | 5 |
| 朗讀口感 | 8 | 8 | 7 | 7 |
| 孩子抓得住度 | 8 | 7 | 6 | 6 |

2-3 年齡適配度 5 理由：page count 10 頁但多頁極短（P07 "SWISH! Spots came out!" 4 字），circle time 時 2 歲需要更穩定的節奏密度；P05 "Mist came. Roundy couldn't find home." 的「找不到家」需較大孩子才理解危機感。

**發現**：

| 檔位 | 頁 | 原句 | 問題 | 嚴重度 | 建議 |
|---|---|---|---|---|---|
| 3-5 | P03 | "Spots popped right back out." | 裸名詞 "Spots" 首次出現需限定詞，circle time 孩子會問 whose spots | 中 | "Her spots popped…" |
| 2-3 | P06 | "Dotty grabbed the rope." | 2-3 P04 沒提繩子，"the rope" 對 toddler 無指涉 | 高 | 跟隨 zh-TW 內心宣告策略 |
| 2-3 | P02 | refrain 無引號 | P04/P06 有引號，P02 無引號＝不一致，影響跟讀視覺提示 | 低 | 加引號 |

### en-US-parent (Jessica)

**分檔評分**：

| 維度 | 5-6 | 3-5 | 2-3 | min |
|---|---|---|---|---|
| 睡前適讀性 | 8 | 9 | 9 | 8 |
| 零說教 | 8 | 9 | 9 | 8 |

5-6 睡前適讀性 8：P09 mist + wrong turn 有微緊張但 P13-P15 wind-down 充足。零說教 8：結尾無教訓宣言，P15 couplet "No one to guide. Nothing to hide." 稍顯公式但可接受。

**發現**：

| 檔位 | 頁 | 原句 | 問題 | 嚴重度 | 建議 |
|---|---|---|---|---|---|
| 5-6 | P15 | "No one to guide. Nothing to hide." | 韻句脫離故事（點點從未 "guide" 別人，全書都是 "find the way home"） | 低 | — |

### en-US-editor (Margaret)

**分檔評分**：

| 維度 | 5-6 | 3-5 | 2-3 | min |
|---|---|---|---|---|
| 母語自然度 | 8 | 7 | 8 | 7 |
| 文字工藝 | 8 | 7 | 7 | 7 |

3-5 母語自然度 7：P07 "find which way" 非標準搭配（應 "tell which way"）、P03 "walked back" 暗示先前離開。文字工藝 7：整體 solid 但 page turn hooks 偏弱（3-5 P06→P07 缺 hook）。

**發現**：

| 檔位 | 頁 | 原句 | 問題 | 嚴重度 | 建議 |
|---|---|---|---|---|---|
| 5-6/3-5 | P03 | "walked back to Dotty's side" | 圓圓未離開，"walked back" 暗示返回 | 中 | "walked right to" |
| 3-5 | P07 | "find which way" | 非母語搭配 | 中 | "tell which way" |
| 2-3 | P03 | "Red washed off!" | 2-3 跳過莓果頁，"Red" 對 toddler 無上下文 | 高 | 跟隨 zh-TW 策略不指名 |

## STEP 4 三分法分診

**主題錨復述**：本書教「不一樣不是缺陷，自我接納後反而能幫助別人」——主角點點三次遮掩失敗後為迷路的朋友主動露出斑點引路回家；反轉從 go away 到 here to stay。

| # | 頁 | 來源 | 問題摘要 | 裁決 | 收斂 | 修改級別 | 依據 |
|---|---|---|---|---|---|---|---|
| F01 | 2-3 P03 | editor＋teacher＋回譯中度 | "Red washed off!" — 2-3 跳過莓果頁(P04/P05)，"Red" 直接指名未引入物質 | ✅ | 3路 | 字串級 | zh-TW 2-3 策略「洗乾淨了」不指名→ "All washed off!" |
| F02 | 3-5 P07 | editor＋teacher＋獵手 | "find which way" 非母語搭配 | ✅ | 3路 | 字串級 | 5-6 P09 已用 "tell which way"；統一搭配 |
| F03 | 5-6 P08-P12 | teacher | 葉子包裹藏住期間斑點不可見——圖文同步問題 | ⏸️ | 1路 | — | storyboard 設計層問題，非文字可修；上呈 |
| F04 | 5-6 P15 | parent | "No one to guide" — 全書未出現 guide 概念，韻句脫離故事 | ⏸️ | 1路 | — | 創作性產品決策（韻句服務 golden ending 還是嚴格服務劇情），上呈 |
| F05 | 5-6 P09 | E 對位 | "Roundy's green scarf hung still" — 圍巾為視覺描述 | ⏸️ | 1路 | — | storyboard 有圍巾元素、design 角色設計有 scarf；疑撞凍結，上呈 |
| F06 | 三檔 | E B-4 | 對話比例偏低 | ⏸️ | 1路 | — | 本書結構＝疊句＋敘事為主、對話少是盲稿產物非翻譯遺留；lock-in 衝突，上呈 |
| F07 | 3-5 P03 | teacher | "Spots popped right back out" 裸名詞需限定詞 | ✅ | 1路 | 字串級 | "Spots"→"Her spots"；5-6 有 "Seven spots" 限定；2-3 R7 電報式豁免 |
| F08 | 5-6 P10 | 獵手 | "placed one leg steady" 非標準搭配 | ✅ | 1路 | 字串級 | "placed…steady"→"held…steady"（固定搭配） |
| F09 | 5-6 P01 | teacher | 5-6 P01 開頭偏靜態 | ❌ | 1路 | — | design 指定 quiet opening（觀察→行動弧），合設計意圖 |
| F10 | 2-3 P06 | teacher | "Dotty grabbed the rope." — 2-3 P04 未提繩子 | ✅ | 1路 | 句級 | zh-TW 2-3 P06「不藏了」＝內心宣告→ "No more hiding!" |
| F11 | 三檔 P03 | editor＋teacher＋獵手 | "walked back to Dotty's side" — 圓圓未離開 | ✅ | 3路 | 字串級 | "walked back to"→"walked right to" |
| F12 | 2-3 P02 | teacher | refrain 無引號，P04/P06 有引號不一致 | ✅ | 1路 | 字串級 | 加引號 `"Spots, spots, go away!"` |
| F13 | 2-3 P07 | editor | "SWISH! Spots came out!" 過短 | ❌ | 1路 | — | R7 電報式合法；4 字＝reveal page，圖權威 |
| F14 | 三檔 | editor | page turn hooks 偏弱 | ❌ | 1路 | — | design hook 頁位全兌現（B-1 PASS）；hook 強度非可量化缺陷 |

✅ 修改清單（7 筆）：

| # | 檔位 | 頁 | 修改級別 | 原文 | 修正 |
|---|---|---|---|---|---|
| F01 | 2-3 | P03 | 字串級 | "Red washed off!" | "All washed off!" |
| F02 | 3-5 | P07 | 字串級 | "find which way" | "tell which way" |
| F07 | 3-5 | P03 | 字串級 | "Spots popped" | "Her spots popped" |
| F08 | 5-6 | P10 | 字串級 | "placed one leg steady" | "held one leg steady" |
| F10 | 2-3 | P06 | 句級 | "Dotty grabbed the rope." | "No more hiding!" |
| F11 | 三檔 | P03 | 字串級 | "walked back to" | "walked right to" |
| F12 | 2-3 | P02 | 字串級 | Spots, spots, go away! | "Spots, spots, go away!" |

訊源計量：獵手獨有 real 1（F08）｜回譯獨有 real 0｜人設獨有 real 3（F07, F10, F12）｜多路收斂 real 3（F01, F02, F11）

⏸️ 上呈批次（4 筆，隨 gate4 證據包交 Stacy）：

1. **F03 葉子包裹可見性**：5-6 P08-P12 斑點被葉子包裹蓋住期間，圖與文的同步需求——storyboard 設計層問題。裁決傾向：保持現狀（圖負責表現包裹狀態）。
2. **F04 "No one to guide"**：5-6 P15 韻句 "No one to guide. Nothing to hide." 中 "guide" 概念全書未建立。裁決傾向：保留——韻句服務 golden ending 的情感收束，"guide" 在此為 metaphorical（月光引路即 guide），但語義嚴格度上呈 Stacy。
3. **F05 圍巾視覺描述**：5-6 P09 "Roundy's green scarf hung still"——storyboard 與 design 角色設計均含圍巾，屬凍結設計元素引用而非新增視覺描述。裁決傾向：保留。
4. **F06 B-4 對話比例**：三檔對話比例偏低，但本書為疊句＋敘事結構（非對話驅動型），且為盲稿原生產物非翻譯腔遺留——改為增對話可能動搖 beat 結構。裁決傾向：保留。
