# QA 報告：different-spots / en-US / round 2（復核輪）

```yaml
schema: piyo_text_qa_report/v0.9
slug: different-spots
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-22"
step1_lint: {exit_code: 0, warnings: 8}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 5, 朗讀口感: 7, 孩子抓得住度: 6}
  - id: en-US-parent
    scores: {睡前適讀性: 8, 零說教: 8}
  - id: en-US-editor
    scores: {母語自然度: 7, 文字工藝: 7}
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

**復核輪聲明**：本輪為復核輪——R1 的 7 項真問題修改中 6 筆字串級＋1 筆句級（F10 2-3 P06 整句替換、未動 beat）。機檢全量重跑、修改逐筆落地驗證、copy↔draft 同源檢、E-lite 受修頁複審、回譯同步已完成。人設分數沿用 R1（復核輪不重跑人設）。

## STEP 1 機檢

### copy_check.py

```
⚠ [band] 低於帶下緣：2-3 第 1 頁 8（帶底 10）— telegraph setup
⚠ [band] 低於帶下緣：2-3 第 3 頁 8（帶底 10）— telegraph reveal
⚠ [band] 超帶上緣：3-5 第 6 頁 27（帶頂 25）— P07 bridge + refrain + ono + consequence all needed
⚠ [band] 低於帶下緣：2-3 第 5 頁 6（帶底 10）— crisis page, minimal text + image authority
⚠ [band] 低於帶下緣：2-3 第 6 頁 8（帶底 10）— reversal + declaration only
⚠ [band] 低於帶下緣：2-3 第 7 頁 4（帶底 10）— telegraph reveal, image carries
⚠ [band] 低於帶下緣：2-3 第 8 頁 8（帶底 10）— moonlight + dialogue
⚠ [band] 低於帶下緣：2-3 第 9 頁 5（帶底 10）— telegraph climax
✅ copy 機檢通過（警告 8 筆）
```

R1 對比：警告數不變（8→8），修改均為字串／句級，不影響字數帶判定。

### locale_lint.py ×3

```
5-6: ✅ 無違規（警告 3 筆：repeat_discount SWISH! P03/P12, refrain P05/P08, raw 423→folded 397.75）
3-5: ✅ 無違規（警告 3 筆：repeat_discount refrain P02/P04/P06, SWISH! P03/P10, raw 252→folded 245.25）
2-3: ✅ 無違規（警告 4 筆：frozen sentence P10, repeat_discount refrain P02/P04, SWISH! P02/P07, raw 84→folded 80.25）
```

## STEP 2 checklist 自檢

**主題錨復述**：本書教「不一樣不是缺陷，自我接納後反而能幫助別人」——點點三次遮掩→圓圓迷路→疊句反轉→月光引路。

復核輪：E-lite 只複審受修頁與相鄰頁。

| 受修頁 | 相鄰頁 | 判定 | 說明 |
|---|---|---|---|
| 5-6 P03 | P02, P04 | PASS | "walked right to" 自然搭配，上下文銜接正常 |
| 5-6 P10 | P09, P11 | PASS | "held one leg steady" 固定搭配，P09→P10 反轉銜接完整 |
| 3-5 P03 | P02, P04 | PASS | "Her spots" 限定詞到位，"walked right to" 一致 |
| 3-5 P07 | P06, P08 | PASS | "tell which way" 與 5-6 P09 搭配統一 |
| 2-3 P02 | P01, P03 | PASS | 引號一致性修復，與 P04/P06 格式對齊 |
| 2-3 P03 | P02, P04 | PASS | "All washed off!" 不再指名未引入物質，語義自足 |
| 2-3 P06 | P05, P07 | PASS | "No more hiding!" 內心宣告＋疊句反轉，P05 crisis→P06 reversal 弧線完整 |

28 pass / 0 fail 維持。

## STEP 3 人設 blind QA

復核輪：人設分數沿用 R1（復核輪不重跑人設）。

## STEP 4 三分法分診

復核輪 triage：R1 7 項 ✅ 修改全部落地驗證通過，無新發現。✅=0，收斂。

## R1 修改逐筆落地驗證

| # | 檔位 | 頁 | R1 修改 | draft 落地 | copy 同源 | 回譯同步 |
|---|---|---|---|---|---|---|
| F01 | 2-3 | P03 | "Red washed off!" → "All washed off!" | ✓ | ✓ | ✓ |
| F02 | 3-5 | P07 | "find which way" → "tell which way" | ✓ | ✓ | ✓ |
| F07 | 3-5 | P03 | "Spots popped" → "Her spots popped" | ✓ | ✓ | ✓ |
| F08 | 5-6 | P10 | "placed one leg steady" → "held one leg steady" | ✓ | ✓ | ✓ |
| F10 | 2-3 | P06 | "Dotty grabbed the rope." → "No more hiding!" | ✓ | ✓ | ✓ |
| F11a | 5-6 | P03 | "walked back to" → "walked right to" | ✓ | ✓ | ✓ |
| F11b | 3-5 | P03 | "walked back to" → "walked right to" | ✓ | ✓ | ✓ |
| F12 | 2-3 | P02 | 加引號 "Spots, spots, go away!" | ✓ | ✓ | — (P02 非回譯覆蓋頁) |

8 筆落地全部驗證通過（F11 拆兩檔各驗）。

## 回譯同步確認

6 修改頁重譯完成、偏移標記已重填。回譯覆蓋率：38/38（S4A 逐頁全量），無殘留「回修待重譯」。

修改頁偏移標記變化：
- 2-3 P03：中度→輕微（"All" 不再指名紅色，與 zh 策略趨近）
- 2-3 P06：輕微→無（"No more hiding" ≈ zh "不藏了"，策略趨同）
- 其餘 4 頁：偏移標記不變

## 字數影響彙總

| 檔位 | R1 raw | R2 raw | 變化 | R2 folded | max_total | 通過 |
|---|---|---|---|---|---|---|
| 5-6 | 423 | 423 | 0 | 397.75 | 505 | ✓ |
| 3-5 | 251 | 252 | +1 (P03 +1 "Her") | 245.25 | 389 | ✓ |
| 2-3 | 85 | 84 | -1 (P06 -1) | 80.25 | 114 | ✓ |
