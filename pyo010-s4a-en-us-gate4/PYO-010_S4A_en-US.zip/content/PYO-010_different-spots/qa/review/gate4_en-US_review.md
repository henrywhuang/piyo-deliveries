# 關卡4整合審閱：不一樣的斑點（S4 證據包／en-US）

- 生成時間：2026-07-22 19:58:03 +0800
- 書目錄：`content/PYO-010_different-spots`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：en-US
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-010_storyboard.md` | 2026-07-21 17:08:45 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-21 17:08:45 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-22 19:44:58 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-21 17:08:45 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-22 19:44:54 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-21 17:08:45 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-22 19:44:50 |
| qa/en-US/backtranslation.md | `qa/en-US/backtranslation.md` | 2026-07-22 19:49:36 |
| qa/en-US round | `qa/en-US/round1.md` | 2026-07-22 19:56:42 |
| qa/en-US round | `qa/en-US/round2.md` | 2026-07-22 19:57:48 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | en-US 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 15 | 15 頁有文 | 15 頁有文 | 15/15 | 8 |
| 3-5 | 13 | 13 頁有文 | 13 頁有文 | 13/13 | 5 |
| 2-3 | 10 | 10 頁有文 | 10 頁有文 | 10/10 | 5 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 「我的斑點，好像不太一樣呢。」／點點好想把那些不一樣藏起來。／圓圓什麼都沒說，走在她旁邊。 | Dotty looked down at her seven pearly spots. They caught the evening sun and shimmered — not like Roundy's six neat black ones at all.／Nobody said a word.／But Dotty wanted to hide them. | 點點低頭看著她的七個珍珠色斑點。它們在傍晚的陽光下閃閃發光——一點也不像圓圓那六個整齊的黑色斑點。沒有人說一句話。但點點想把它們藏起來。 | 輕微：en 以第三人稱感官描寫取代 zh 首人稱台詞「我的斑點，好像不太一樣呢。」，對比更顯式（珍珠銀/黑），核心語義同（想藏） |
| P02 | P02 | 「藏一藏，斑點看不見！」／點點用花瓣搭了一件小披肩，開心地往前走。 | She draped three big petals over her back like a shawl.／"Spots, spots, go away!" she whispered.／Then she took one step forward. | 她把三片大花瓣像披肩一樣披在背上。「斑點斑點，快走開！」她低聲說。然後她向前踏出一步。 | 無 |
| P03 | P03 | 唰啦！晚風把花瓣吹到了點點頭上，變成一頂大花帽。／圓圓笑了笑，還是走在她旁邊。 | SWISH!／The breeze flipped the petals into a big, silly flower hat!／Seven spots popped right back out.／Roundy walked right to Dotty's side, smiling. | 咻！微風把花瓣翻成一頂大大的、傻傻的花帽子！七個斑點立刻又冒了出來。圓圓微笑著走到點點身邊。 | 無 |
| P04 | P04 | 點點看到紅莓汁，眼睛亮了起來。／「把汁塗上去，就看不出來了吧？」 | Down by the berry brook, Dotty spotted a drop of red juice on a round leaf.／She reached out one little leg… | 在莓果小溪旁，點點發現一片圓葉上有一滴紅色果汁。她伸出一條小小的腿…… | 輕微：en 改用場景描寫＋動作懸念取代 zh 內心對白「把汁塗上去，就看不出來了吧？」，核心語義同 |
| P05 | P05 | 「藏一藏，斑點看不見！」／可是塗上以後，背又黏又緊，好不舒服。 | Dotty dabbed berry juice over every spot.／"Spots, spots, go away!" she said.／The juice dried. Her back got tighter… and tighter… and stickier. | 點點把莓果汁塗在每一個斑點上。「斑點斑點，快走開！」她說。果汁乾了。她的背越來越緊……越來越緊……越來越黏。 | 無 |
| P06 | P06 | 滴答、滴答，露水沖掉了紅莓汁。／點點伸直身體，深深地吸了一口氣。／嗯，原本的背比較舒服嘛。 | drip, drop, drip!／Dew washed the red right off.／Dotty wiped her back and stretched. Her own spots actually felt… much better. | 滴、答、滴！露水把紅色洗掉了。點點擦了擦背，伸展了一下。她自己的斑點其實感覺……好多了。 | 無 |
| P07 | P07 | 天色暗了。／這次，點點用草繩把自己綁進一片大乾葉裡。／「一定要藏好！」 | The sky grew dim. Dotty found a big dry leaf and a soft grass rope.／She tied the leaf tight around herself — back, spots, and all six legs. | 天色暗了下來。點點找到一片大的乾葉子和一條柔軟的草繩。她把葉子緊緊綁在自己身上——背、斑點和全部六條腿。 | 輕微：en 缺 zh 決心台詞「一定要藏好！」，改以動作細節替代 |
| P08 | P08 | 「藏一藏，斑點看不見！」／沙沙沙，那團葉子在地上轉呀轉。／可是，連自己的腳也看不到了。 | crinkle, crinkle, crinkle!／The leaf bundle spun in a circle.／"Spots, spots, go away!" she said.／It worked — her spots were completely hidden.／But Dotty looked down… and she couldn't even see her own feet. | 窸窣、窸窣、窸窣！葉子包裹轉了一圈。「斑點斑點，快走開！」她說。成功了——她的斑點完全藏起來了。但點點低頭一看……她連自己的腳都看不到了。 | 無 |
| P09 | P09 | 薄霧蓋住三條路。／圓圓停下來。／看看左邊。看看右邊。／點點好擔心。／圓圓的腳，往那條路伸過去—— | Thin mist drifted across three paths.／Roundy's green scarf hung still. She couldn't tell which way led home.／One little leg hovered over the wrong turn.／Inside the leaf bundle, Dotty saw it all. | 薄霧飄過三條小路。圓圓的綠色圍巾靜靜垂著。她分不清哪條路通往家。一條小小的腿懸在錯誤的岔路上方。在葉子包裹裡面，點點全都看到了。 | 輕微：en 加領巾視覺描述（E 對位不通過）＋改 zh 頓拍式「看看左邊。看看右邊。」為描述式；zh「點點好擔心」內心句改 en「Dotty saw it all」 |
| P10 | P10 | 點點看著圓圓，心裡忽然踏實了。／她不想再把自己藏起來了。／「不藏了，讓你看見我！」 | Dotty pushed the leaf bundle forward and held one leg steady on the rope knot.／"Spots, spots — here to stay!" she said, clear and sure. | 點點把葉子包裹往前推，一隻腳穩穩踩在繩結上。「斑點、斑點——留下來！」她說，清楚又堅定。 | 輕微：en 以外在動作＋疊句反轉替代 zh 內心轉折「心裡忽然踏實了。她不想再把自己藏起來了。」，主題意圖同 |
| P11 | P11 | 啪！／點點用力拉住草繩，身體往後一仰。／乾葉的一角，剛剛彈開—— | Dotty pulled hard with both front legs.／SNAP!／The grass rope gave way. One corner of the dry leaf popped open. | 點點用兩條前腿用力拉。啪！草繩斷了。乾葉子的一個角彈開了。 | 無 |
| P12 | P12 | 唰啦——晚風把乾葉帶走了。／斑點一顆一顆露了出來。 | SWISH!／The evening breeze lifted the leaf and carried it away.／All seven pearly spots shone in the open air. | 咻！傍晚的微風掀起葉子，把它吹走了。全部七個珍珠色斑點在空氣中閃耀。 | 無 |
| P13 | P13 | 點點飛到濕葉上，露水沾上了斑點。／月光一照，斑點閃了一下。／圓圓看見了—— | Dotty landed on a wet leaf nearby. Dew touched her spots, and the moonlight bounced off — a soft, close glow.／Roundy's eyes went wide. "I see you!" | 點點降落在附近一片濕葉子上。露水碰到她的斑點，月光反射出來——柔和的、近近的光芒。圓圓的眼睛瞪大了。「我看到你了！」 | 輕微：en 提前圓圓辨認台詞至 P13（zh 在 P14「那邊有亮亮的！」） |
| P14 | P14 | 「那邊有亮亮的！」／點點飛到下一片濕葉。／斑點又閃了一下。／圓圓跟著亮點走。／一步、一步，踩到家門口了。 | Dotty hopped to the next leaf, even closer to home. Her spots caught the moonlight once more.／Roundy followed the glow — one step, then another — all the way to the clover door.／They were home. | 點點跳到下一片葉子上，離家更近了。她的斑點再次映照月光。圓圓跟著那道光芒——一步，又一步——一路走到苜蓿門前。她們到家了。 | 輕微：en 缺圓圓台詞「那邊有亮亮的！」（B-4 對話比議題） |
| P15 | P15 | 後來呀，點點帶著不一樣的斑點，在晚風裡開開心心地跳舞。／圓圓也在旁邊，跳著跳著就笑了。 | And from that day on, Dotty danced in the evening breeze with all seven spots shining.／No one to guide. Nothing to hide.／Roundy danced right beside her. | 後來呀，點點在傍晚的微風中跳舞，七個斑點全都閃閃發亮。不用引路。不用躲藏。圓圓就在她身旁跳舞。 | 輕微：en 新增原創韻句「No one to guide. Nothing to hide.」（zh 無）；zh「笑了」en 無 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 「我的斑點，不太一樣。」／點點好想藏起來。／圓圓走在她旁邊。 | Dotty looked down at her seven pearly spots — they shimmered in the sun.／Roundy's black spots didn't shine at all.／Dotty wanted to hide hers. | 點點低頭看著她的七個珍珠色斑點——它們在陽光下閃閃發光。圓圓的黑色斑點一點也不會發光。點點想把自己的藏起來。 | 輕微：同 5-6 P01，第三人稱描寫取代 zh 首人稱台詞 |
| P02 | P02 | 「藏一藏，斑點看不見！」／點點用花瓣搭了一件小披肩。 | She tucked three big petals over her back like a cape.／"Spots, spots, go away!" | 她把三片大花瓣像斗篷一樣蓋在背上。「斑點斑點，快走開！」 | 無 |
| P03 | P03 | 唰啦！花瓣變成大花帽了。／圓圓笑了笑，還是走在旁邊。 | SWISH!／The breeze flipped the petals into a flower hat!／Her spots popped right back out.／Roundy walked right to Dotty's side. | 咻！微風把花瓣翻成一頂花帽子！她的斑點立刻又冒了出來。圓圓走到點點身邊。 | 無 |
| P04 | P05 | 這次用紅莓汁試試！／「藏一藏，斑點看不見！」／可是背好黏，好不舒服。 | This time, Dotty found berry juice and dabbed it over every spot.／"Spots, spots, go away!"／Her back got tighter and stickier. | 這一次，點點找到莓果汁，把它塗在每一個斑點上。「斑點斑點，快走開！」她的背越來越緊、越來越黏。 | 無 |
| P05 | P06 | 滴答、滴答，露水沖掉了紅莓汁。／嗯，原本的背比較舒服。 | drip, drop, drip!／Dew washed the red off.／Dotty stretched. Her own back felt much better. | 滴、答、滴！露水把紅色洗掉了。點點伸展了一下。她自己的背感覺好多了。 | 無 |
| P06 | P08 | 綁好葉子，再藏一次！／「藏一藏，斑點看不見！」／沙沙，轉呀轉。／可是，腳不見了。 | Dotty hid inside a big dry leaf tied with grass rope.／"Spots, spots, go away!"／crinkle, crinkle! The leaf bundle spun.／She couldn't see her own feet. | 點點躲進一片用草繩綁住的大乾葉子裡。「斑點斑點，快走開！」窸窣、窸窣！葉子包裹轉了起來。她看不到自己的腳了。 | 無 |
| P07 | P09 | 薄霧來了。／圓圓看看左邊。看看右邊。／腳，往那條路伸過去—— | Mist covered three paths.／Roundy couldn't tell which way was home.／Inside the leaf bundle, Dotty saw her. | 霧氣覆蓋了三條路。圓圓分不清哪條路是回家的。在葉子包裹裡面，點點看見了她。 | 輕微：en 簡化為描述句取代 zh 頓拍式「看看左邊。看看右邊。」 |
| P08 | P10 | 點點看著圓圓。／她不想再藏了。／「不藏了，讓你看見我！」 | Dotty pushed the leaf bundle forward and placed one leg on the rope knot.／"Spots, spots — here to stay!" | 點點把葉子包裹往前推，把一條腿踩在繩結上。「斑點斑點——留下來！」 | 輕微：同 5-6 P10，外在動作取代 zh 內心轉折 |
| P09 | P11 | 啪！點點拉住草繩，用力一扯。／乾葉的一角，彈開了—— | SNAP!／Dotty pulled the grass rope hard. The dry leaf popped open — just one corner. | 啪！點點用力拉草繩。乾葉子彈開了——只有一個角。 | 無 |
| P10 | P12 | 唰啦——風把乾葉帶走了。／斑點一顆一顆露了出來。 | SWISH!／The breeze lifted the leaf and carried it away.／All seven spots shone bright. | 咻！微風掀起葉子，把它吹走了。全部七個斑點閃閃發亮。 | 無 |
| P11 | P13 | 點點飛到濕葉上。／月光一照，斑點閃了一下—— | Dotty landed on a wet leaf. Dew touched her spots — moonlight bounced off.／"I see you!" said Roundy. | 點點降落在一片濕葉子上。露水碰到她的斑點——月光反射出來。「我看到你了！」圓圓說。 | 輕微：en 新增「我看到你了」台詞（zh 3-5 P11 為敘述「月光一照，斑點閃了一下——」） |
| P12 | P14 | 「那邊！」／點點飛到下一片葉子。／圓圓跟著亮點，一步一步走到家了。 | Dotty hopped to the next leaf. Her spots caught the moonlight again.／Roundy followed the glow all the way to the clover door. | 點點跳到下一片葉子上。她的斑點再次映照月光。圓圓跟著那道光芒一路走到苜蓿門前。 | 輕微：en 缺圓圓台詞「那邊！」 |
| P13 | P15 | 後來呀，點點帶著不一樣的斑點，開開心心地跳舞。／圓圓也在旁邊笑。 | And from that day on, Dotty danced with all seven spots shining.／Roundy danced right beside her. | 後來呀，點點跳著舞，七個斑點全都閃閃發亮。圓圓就在她身旁跳舞。 | 無 |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 點點的斑點，不太一樣。／圓圓在旁邊。 | Dotty's spots were different.／Roundy was right there. | 點點的斑點不一樣。圓圓就在旁邊。 | 無 |
| P02 | P03 | 「藏一藏，斑點看不見！」／唰啦！花瓣變成大花帽！／圓圓在旁邊笑。 | "Spots, spots, go away!"／SWISH!／The petals blew into a silly hat! | 斑點斑點，快走開！咻！花瓣吹成一頂傻傻的帽子！ | 輕微：en 缺「圓圓在旁邊笑」 |
| P03 | P06 | 身上黏黏的。／滴答、滴答，洗乾淨了。／嗯，這樣比較舒服！ | drip, drop, drip!／All washed off!／Much better! | 滴、答、滴！全部洗掉了！好多了！ | 輕微：en 缺 zh「身上黏黏的」前因，直接從 drip 聲開始；修正後 "All" 不再指名紅色，與 zh「洗乾淨了」策略趨近 |
| P04 | P08 | 藏在葉子裡！／「藏一藏，斑點看不見！」／可是，腳也不見了。 | Dotty hid inside a leaf.／"Spots, spots, go away!"／No feet! | 點點躲進一片葉子裡。「斑點斑點，快走開！」看不到腳了！ | 無 |
| P05 | P09 | 霧來了。／圓圓看看左邊，看看右邊—— | Mist came.／Roundy couldn't find home. | 霧來了。圓圓找不到家。 | 輕微：zh「看看左邊，看看右邊」en 改「找不到家」 |
| P06 | P10 | 點點不藏了。／「不藏了，讓你看見我！」 | No more hiding!／"Spots, spots — here to stay!" | 不再躲藏了！「斑點、斑點——留下來！」 | 無（修正後 en「不再躲藏了」≈ zh「不藏了」，策略趨同） |
| P07 | P12 | 唰啦——葉子飛走了。／斑點全都露出來了！ | SWISH!／Spots came out! | 咻！斑點出來了！ | 無 |
| P08 | P13 | 月光照到斑點——亮了！／圓圓看見了—— | Spots caught moonlight.／"I see you!" said Roundy. | 斑點映照月光。「我看到你了！」圓圓說。 | 無 |
| P09 | P14 | 「那邊！」圓圓跟著亮點走。／一步，一步。／到家了！ | Roundy followed the glow.／Home! | 圓圓跟著光芒走。到家了！ | 輕微：en 缺圓圓台詞「那邊！」＋頓拍「一步，一步」 |
| P10 | P15 | 後來呀，點點帶著不一樣的斑點。／開開心心跳舞。圓圓也笑了。 | And from that day on, Dotty danced with her spots.／Roundy danced beside her. | 後來呀，點點帶著她的斑點跳舞。圓圓在她身旁跳舞。 | 無 |

## 三、QA 摘要（qa/en-US）

- `qa/en-US/round1.md`：round 1／verdict fix_required
- `qa/en-US/round2.md`：round 2／verdict pass

最新 round：`qa/en-US/round2.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: different-spots
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-22"
step1_lint: {exit_code: 0, warnings: 8}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 5, 朗讀口感: 7, 孩子抓得住度: 6}
  - id: en-US-parent
    scores: {睡前適讀性: 8, 零說教: 8}
  - id: en-US-editor
    scores: {母語自然度: 7, 文字工藝: 7}
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

### ESL 獵手發現（原文引用）

（缺）最新 round 無「ESL」標題節——確認漏斗是否執行 ESL 獵手維度。

## 四、⏸️ 上呈批次

- （`qa/en-US/round1.md`）| F03 | 5-6 P08-P12 | teacher | 葉子包裹藏住期間斑點不可見——圖文同步問題 | ⏸️ | 1路 | — | storyboard 設計層問題，非文字可修；上呈 |
- （`qa/en-US/round1.md`）| F04 | 5-6 P15 | parent | "No one to guide" — 全書未出現 guide 概念，韻句脫離故事 | ⏸️ | 1路 | — | 創作性產品決策（韻句服務 golden ending 還是嚴格服務劇情），上呈 |
- （`qa/en-US/round1.md`）| F05 | 5-6 P09 | E 對位 | "Roundy's green scarf hung still" — 圍巾為視覺描述 | ⏸️ | 1路 | — | storyboard 有圍巾元素、design 角色設計有 scarf；疑撞凍結，上呈 |
- （`qa/en-US/round1.md`）| F06 | 三檔 | E B-4 | 對話比例偏低 | ⏸️ | 1路 | — | 本書結構＝疊句＋敘事為主、對話少是盲稿產物非翻譯遺留；lock-in 衝突，上呈 |
- （`qa/en-US/round1.md`）⏸️ 上呈批次（4 筆，隨 gate4 證據包交 Stacy）：

