# QA 報告：my-spots-are-different / en-US / round 3（Stacy R1 修改落地）

```yaml
schema: piyo_text_qa_report/v0.9
slug: my-spots-are-different
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 3
date: "2026-07-30"
step1_lint: {exit_code: 0, warnings: 7}
step2_checklist: {pass: 26, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 5, 朗讀口感: 6, 孩子抓得住度: 5}
  - id: en-US-parent
    scores: {睡前適讀性: 6, 零說教: 6}
  - id: en-US-editor
    scores: {母語自然度: 8, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

## 輪次性質

Stacy R1 修改指令（piyo-enUS-copywriting-review v1.0，2026-07-29）。5 項文字修改＋registry 補登。3-5 無修改。

## STEP 1 機檢

| 檔位 | exit | 結果 |
|---|---|---|
| 5-6 | 0 | ✅ 無違規（警告 2：疊句折計） |
| 3-5 | 0 | ✅ 無違規（警告 2：疊句折計） |
| 2-3 | 1 | ⚠ 3 項違規——全部來自 Stacy R1 指定增字 |

**2-3 lint 違規明細**（Stacy 指定修改造成，原樣保留不改）：

| 項目 | 說明 |
|---|---|
| P12 max_page_len | 16 > 14（R1 加「came close」+2 字） |
| P13 max_page_len | 15 > 14（R1 加「said Patch」+2 字） |
| max_total_len | 94 > 88（R1 五項合計 +7 字） |

## 修改驗證

| # | 檔位 | 頁 | Stacy 指定修改 | diff 驗證 |
|---|---|---|---|---|
| 1 | 5-6 | P02 | "That one looks funny" → "That spot looks funny" | ✅ 精確匹配 |
| 2 | 2-3 | P05 | "the mud broke!" → "off came the mud!" | ✅ 精確匹配 |
| 3 | 2-3 | P11 | "Guess who?" → "\"Guess who I am!\"" | ✅ 精確匹配 |
| 4 | 2-3 | P12 | "Mama, nose to nose." → "Mama came close, nose to nose." | ✅ 精確匹配 |
| 5 | 2-3 | P13 | "\"No more round spots!\"" → "\"No more round spots!\" said Patch." | ✅ 精確匹配 |

copy↔draft 同步：5 頁已驗證一致，字數已更新。

## STEP 2 checklist 自檢

- 主題錨：三檔疊句「Patch's spots are NOT the same!」完整、收束式「And from that day on…」完整。未受修改影響。
- 修改頁＋相鄰頁抽查：5-6 P01-P03、2-3 P04-P05、P11-P13——無新 issue。
- concept fidelity：結尾四件套三檔完整。

## STEP 3 人設 blind QA

不重跑。分數沿用 round 2。

## STEP 4 三分法分診

修改後 ✅＝0，QA 收斂。

## registry 補登

角色名 character_names.md：新增 `## 我的斑點不一樣` 區塊（ban_ban/Patch、yuan_yuan/Dot、mama_leopard/Mama）。
擬聲詞 onomatopoeia_map.md：新增 5 場景（拍泥巴/泥巴裂開/捏莓果/大雨/噴嚏）含 zh-TW 定案＋en-US 提案。

## 回譯同步

5 個修改頁 blind 重譯完成、E 偏移重標。覆蓋：5-6×1 + 2-3×4 = 5 頁。全量 33/33 頁覆蓋。

## gate4 證據包

`qa/review/gate4_en-US_review.md` 已用 R2 後文本重生成（2026-07-30）。
