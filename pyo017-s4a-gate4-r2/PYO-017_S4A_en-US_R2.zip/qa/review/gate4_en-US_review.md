# 關卡4整合審閱：我的斑點不一樣（S4 證據包／en-US）

- 生成時間：2026-07-30 10:27:27 +0800
- 書目錄：`content/PYO-017_my-spots-are-different`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：en-US
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-017_storyboard.md` | 2026-07-29 10:58:34 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-29 17:37:05 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-30 10:22:25 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-29 17:37:05 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-29 19:56:47 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-29 17:37:05 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-30 10:22:25 |
| qa/en-US/backtranslation.md | `qa/en-US/backtranslation.md` | 2026-07-30 10:27:20 |
| qa/en-US round | `qa/en-US/round1.md` | 2026-07-29 19:56:47 |
| qa/en-US round | `qa/en-US/round2.md` | 2026-07-29 19:56:47 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | en-US 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 13 | 13 頁有文 | 13 頁有文 | 13/13 | 8 |
| 3-5 | 12 | 12 頁有文 | 12 頁有文 | 12/12 | 4 |
| 2-3 | 8 | 8 頁有文 | 8 頁有文 | 8/8 | 7 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 小花豹們追著蝴蝶跑呀跑。／斑斑跑在最前面，跑得好快好快！ | The little leopard cubs chased butterflies across the grassland.／Patch ran ahead of everyone — so fast, so fast! | 小花豹們在草原上追著蝴蝶跑。小斑跑在最前面——好快、好快！ | 輕微：en-US 增添「草原」場景詞（across the grassland），zh-TW 無此地點 |
| P02 | P02 | 「你這顆好奇怪，像一顆星星耶！」圓圓說。／「對呀，我的都是圓圓的。」另一隻說。／斑斑低頭看看自己，又看看大家。 | "That spot looks funny — like a star!" said Dot.／"Yeah, mine are all round," said another cub.／Patch looked down at himself, then at everyone else. | 「那個斑點好好笑——像一顆星星！」點點說。「對啊，我的都是圓的。」另一隻小豹說。補丁低頭看看自己，又看看大家。 | 輕微：「好奇怪」→「好好笑」(funny) 語氣稍異但觸發功能一致；R2「That spot」比 R1「That one」更具體，回譯「那個斑點」更接近 zh-TW「你這顆」 |
| P03 | P03 | 斑斑看了一眼自己的斑點。／不行！我要把斑點變圓！／他往水塘跑去。 | Patch touched the star-shaped spot on his side.／No way! I have to make my spots round!／Off he ran! | 小斑摸了摸身上星星形狀的斑點。不行！我一定要把斑點變圓！他跑走了！ | 輕微：「看了一眼」→「摸了摸」(touched) 動作從視覺改觸覺；「往水塘跑去」→「跑走了」刪去方向（P04 泥塘場景自會出現） |
| P04 | P04 | 啪嗒啪嗒！啪嗒啪嗒！／斑斑把泥巴拍在身上，／再用手指頭戳出一個個圓圓的假斑點。 | Splat, splat, splat! Splat, splat, splat!／Patch smeared mud all over himself,／then poked little round dots into the mud with one finger. | 啪、啪、啪！啪、啪、啪！小斑把泥巴抹得全身都是，再用一根手指在泥巴上戳出一個一個小圓點。 | 無 |
| P05 | P05 | 嘎吱嘎吱…… 泥巴裂開了！／星星斑點第一個露出來。／斑斑的斑點，不～一～樣！ | Crack… crack… the mud split apart!／The star spot peeked out first.／Patch's spots are NOT the same! | 喀……喀……泥巴裂開了！星星斑點最先探出頭來。小斑的斑點就是不一樣！ | 無 |
| P06 | P06 | 噗滋！斑斑把莓果捏碎了。／他用果汁在身上畫出一個個圓圓的點，／這次比上次還像！ | SQUISH! Patch squeezed the berries until they burst.／He painted round dots all over himself with the juice —／even better than last time! | 噗嘰！小斑把莓果捏到爆開。他用果汁在全身塗上圓圓的點——比上次還好看！ | 輕微：「比上次還像」→「比上次還好看」(even better) 表述稍異但語義相近 |
| P07 | P07 | 嘩啦嘩啦！大雨沖下來了！／果汁都被沖掉了——斑點比原來還亂！／斑斑的斑點，不～一～樣！ | SPLISH SPLASH! Down came the rain!／The juice washed away in purple streaks — spots messier than before!／Patch's spots are NOT the same! | 嘩啦嘩啦！雨落了下來！果汁被沖走，留下紫色的痕跡——斑點比之前更亂了！小補丁的斑點才不一樣！ | 輕微：en-US 增添「purple streaks」視覺細節，zh-TW 僅寫「被沖掉了」 |
| P08 | P08 | 雨停了。／斑斑一個人坐在大樹下，／低頭看著水窪裡的自己。／什麼斑點都分不清了…… | The rain stopped.／Patch sat alone under the big tree,／looking down at the puddle.／He couldn't tell his spots apart anymore… | 雨停了。小斑一個人坐在大樹下，低頭看著水窪。他已經分不清自己的斑點了…… | 輕微：「水窪裡的自己」→「水窪」(puddle) 省略倒影細節 |
| P09 | P09 | 斑斑站了起來。／他用長長的藤把大圓葉子一片片綁在身上——／這次，全身都是圓斑點了！ | Patch stood up.／He tied big round leaves all over himself with long vines —／this time, round spots everywhere! | 小斑站了起來。他用長長的藤蔓把大大的圓葉子綁在全身——這次，到處都是圓斑點！ | 無 |
| P10 | P10 | 一片葉子搔了鼻子——／哈——啾！／超大噴嚏把葉子炸得漫天飛！／斑斑的斑點，不～一～樣！ | A leaf tickled his nose —／ACHOOOO!／Leaves exploded everywhere!／Patch's spots are NOT the same! | 一片葉子搔到他的鼻子——哈——啾！葉子炸得到處都是！小斑的斑點就是不一樣！ | 無 |
| P11 | P11 | 大家撿起葉子遮住臉——猜猜我是誰！／圓斑點都一樣，猜來猜去猜不中。／斑斑走了進去。／「是斑斑！」一猜就中。 | Everyone grabbed leaves and covered their faces.／Guess who I am!／Round spots all looked the same — guess after guess, all wrong.／Patch held up a leaf and walked right in.／"It's Patch!" said Dot. One guess — that's all it took. | 大家抓起葉子遮住臉。猜猜我是誰！圓斑點看起來都一樣——猜來猜去，全猜錯。小斑舉起一片葉子走了進去。「是小斑！」小點說。一猜就中。 | 輕微：en-US 增添動作細節「held up a leaf」、具名 Dot 喊出（zh-TW 未標說話者）、增添「One guess — that's all it took」為 en-US 原創節奏句 |
| P12 | P12 | 「那是我的斑斑！」／媽媽跑過來，鼻尖碰鼻尖。／「你的星星斑點，是媽媽最喜歡的記號喔。」／斑斑的斑點，不～一～樣。 | "That's MY Patch!"／Mama came close, nose to nose.／"Your star-shaped spots are my favorite thing about you."／Patch's spots are not the same. | 「那是我的小斑！」媽媽靠過來，鼻子碰鼻子。「你的星星形狀的斑點，是我最喜歡你的地方。」小斑的斑點不一樣。 | 輕微：「跑過來」→「靠過來」(came close) 配合特寫構圖；「媽媽最喜歡的記號」→「我最喜歡你的地方」(my favorite thing about you) 從辨識標記轉為情感表達，核心均承載「被愛」 |
| P13 | P13 | 「我這顆有點橢圓耶！」／原來大家的斑點，都有一點點不一樣。／「我再也不想把斑點變圓了！」斑斑說。／後來呀…… | "This one's a little oval!" said Dot.／Everyone's spots were a little bit different, after all.／"I don't ever want to make my spots round again!" said Patch.／And from that day on… | 「這個有點橢圓！」小點說。每個人的斑點，其實都有一點點不一樣。「我再也不要把斑點變圓了！」小斑說。從那天起…… | 無 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 小花豹們追著蝴蝶跑呀跑。／斑斑跑在最前面！ | The little leopard cubs chased butterflies.／Patch ran ahead of everyone! | 小花豹們追著蝴蝶跑。小斑跑在最前面！ | 無 |
| P02 | P02 | 「你這顆好奇怪，像星星耶！」圓圓說。／斑斑低頭看看自己，看看大家。 | "That spot looks funny — like a star!" said Dot.／Patch looked down at himself, then at everyone else. | 「那個斑點好好笑——像星星！」小點說。小斑低頭看看自己，又看看大家。 | 輕微：同 5-6 P02，「好奇怪」→「好好笑」(funny) |
| P03 | P03 | 斑斑看了看自己的斑點——／不行！我要把斑點變圓！／他往水塘跑去。 | Patch touched his star spot —／No way! I have to make them round!／Off he ran! | 小斑摸了摸他的星星斑點——不行！我要把它們變圓！他跑走了！ | 輕微：同 5-6 P03，「看了看」→「摸了摸」(touched) |
| P04 | P04 | 啪嗒啪嗒！啪嗒啪嗒！／斑斑把泥巴拍在身上，／戳出圓圓的假斑點。 | Splat, splat, splat! Splat, splat, splat!／Patch smeared mud all over,／then poked little round dots. | 啪、啪、啪！啪、啪、啪！小補丁把泥巴抹得到處都是，然後戳出一個個小圓點。 | 無 |
| P05 | P05 | 嘎吱嘎吱…… 泥巴裂開了！／星星斑點露出來了。／斑斑的斑點，不～一～樣！ | Crack… crack… the mud split!／The star spot peeked right out.／Patch's spots are NOT the same! | 喀……喀……泥巴裂開了！星星斑點馬上探出頭來。小斑的斑點就是不一樣！ | 無 |
| P06 | P06 | 噗滋！斑斑把莓果捏碎了。／他用果汁在身上畫出圓圓的點。 | SQUISH! Patch squeezed the berries.／He painted round dots all over with the juice. | 噗嘰！小斑把莓果擠爆。他用果汁在全身塗上圓圓的點。 | 無 |
| P07 | P07 | 嘩啦嘩啦！大雨來了！／果汁都被沖掉了！／斑斑的斑點，不～一～樣！ | SPLISH SPLASH! Down came the rain!／The juice all washed away!／Patch's spots are NOT the same! | 嘩啦嘩啦！下雨了！果汁全被沖掉了！小斑的斑點就是不一樣！ | 無 |
| P08 | P09 | 斑斑站起來。／他把大葉子一片片綁在身上——／全身都是圓斑點了！ | Patch stood up.／He tied big leaves all over himself —／round spots everywhere! | （缺） | — |
| P09 | P10 | 一片葉子搔了鼻子——／哈——啾！／葉子炸得漫天飛！／斑斑的斑點，不～一～樣！ | A leaf tickled his nose —／ACHOOOO!／Leaves went flying!／Patch's spots are NOT the same! | 小斑站了起來。他把大葉子綁在全身——到處都是圓斑點！ | 無 |
| P10 | P11 | 大家遮住臉——猜猜我是誰！／猜不中，猜不中。／斑斑走進去。「是斑斑！」 | Everyone covered their faces — Guess who I am!／Wrong, wrong — they all looked the same.／Patch walked right in. "It's Patch!" | 一片葉子搔到他的鼻子——哈——啾！葉子飛得到處都是！小斑的斑點就是不一樣！ | 無 |
| P11 | P12 | 「那是我的斑斑！」媽媽碰碰鼻尖。／「你的斑點，是媽媽的記號喔。」／斑斑的斑點，不～一～樣。 | "That's MY Patch!" Mama came close, nose to nose.／"Your spots are my favorite."／Patch's spots are not the same. | 大家遮住臉——猜猜我是誰！猜錯、猜錯——大家看起來都一樣。小斑走了進去。「是小斑！」 | 輕微：en-US 增添「they all looked the same」旁白解釋，zh-TW 僅寫「猜不中」 |
| P12 | P13 | 「這顆長長的耶！」／大家的斑點，都不一樣。／「不想變圓了！」／後來呀…… | "This one's a long one!" said Dot.／Everyone's spots were all different.／"No more round spots!"／And from that day on… | 「那是我的小斑！」媽媽靠過來，鼻子碰鼻子。「你的斑點是我最喜歡的。」小斑的斑點不一樣。 | 輕微：同 5-6 P12，「媽媽的記號」→「我最喜歡的」 |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 小花豹們追蝴蝶。／斑斑跑在最前面！ | Little leopard cubs chased butterflies!／Patch ran so, so fast! | 小花豹們追蝴蝶！小斑跑得好快、好快！ | 輕微：zh-TW「跑在最前面」→ en-US「跑得好快好快」(so, so fast) 不同描述角度但語義等價 |
| P02 | P02 | 「你的斑點好奇怪！像星星！」／斑斑低頭看了看自己。 | "Your spots look funny! Like stars!"／Patch looked down at his spots. | 「你的斑點好好笑！像星星！」小斑低頭看看自己的斑點。 | 輕微：同 5-6 P02，「好奇怪」→「好好笑」(funny) |
| P03 | P03 | 不行不行！／斑斑要把斑點變圓！ | No no no!／Patch wanted round spots! | 不要不要不要！小斑想要圓圓的斑點！ | 輕微：「不行不行」(2x)→「不要不要不要」(No no no, 3x) 節奏不同但情緒等價 |
| P04 | P04 | 啪嗒啪嗒！／斑斑用泥巴蓋住斑點。 | Splat, splat, splat!／Patch put mud on his spots. | 啪、啪、啪！小斑把泥巴抹在斑點上。 | 無 |
| P05 | P05 | 嘎吱嘎吱——泥巴裂開了！／斑斑的斑點，不～一～樣！ | Crack… crack… off came the mud!／Patch's spots are NOT the same! | 喀啦……喀啦……泥巴掉下來了！補丁的斑點真的不一樣！ | 輕微：zh-TW「泥巴裂開了」vs en-US "off came the mud"（脫落），Stacy R1 刻意修改——語義從「裂開」轉為「脫落」 |
| P06 | P11 | 大家玩遊戲！猜猜我是誰？／斑斑走進去——「是斑斑！」 | Everyone played a game! "Guess who I am!"／Patch walked in — "It's Patch!" | （缺） | — |
| P07 | P12 | 媽媽碰碰鼻尖。／「媽媽最愛的點點喔。」／斑斑的斑點，不～一～樣。 | Mama came close, nose to nose.／"My favorite little spots!"／Patch's spots are not the same. | （缺） | — |
| P08 | P13 | 大家的斑點，都不一樣！／「不要變圓了！」斑斑說。／後來呀…… | Everyone's spots were different!／"No more round spots!" said Patch.／And from that day on… | （缺） | — |

## 三、QA 摘要（qa/en-US）

- `qa/en-US/round1.md`：round 1／verdict fix_required
- `qa/en-US/round2.md`：round 2／verdict pass

最新 round：`qa/en-US/round2.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: my-spots-are-different
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-29"
step1_lint: {exit_code: 0, warnings: 0}
step2_checklist: {pass: 26, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 5, 朗讀口感: 6, 孩子抓得住度: 5}
  - id: en-US-parent
    scores: {睡前適讀性: 6, 零說教: 6}
  - id: en-US-editor
    scores: {母語自然度: 8, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

### ESL 獵手發現（原文引用）

（缺）最新 round 無「ESL」標題節——確認漏斗是否執行 ESL 獵手維度。

## 四、⏸️ 上呈批次

- （`qa/en-US/round1.md`）### ⏸️ 上呈批次

