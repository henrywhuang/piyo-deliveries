# 關卡4整合審閱：輪到你，輪到我（S4 證據包／en-US）

- 生成時間：2026-07-23 12:03:44 +0800
- 書目錄：`content/PYO-011_your-turn-my-turn`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate 4`（決定性腳本，純解析＋排版）
- locale：en-US
- 審讀說明：全中文證據審——逐頁看「回譯」欄與母本語義是否一致；目標語文字僅供對照，不要求逐字審

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-011_storyboard.md` | 2026-07-21 17:08:45 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-23 11:45:13 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-23 11:45:13 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-23 11:45:13 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-23 11:45:13 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-23 11:45:13 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-23 11:52:08 |
| qa/en-US/backtranslation.md | `qa/en-US/backtranslation.md` | 2026-07-23 12:01:30 |
| qa/en-US round | `qa/en-US/round1.md` | 2026-07-22 20:17:25 |
| qa/en-US round | `qa/en-US/round2.md` | 2026-07-22 22:12:52 |
| qa/en-US round | `qa/en-US/round3.md` | 2026-07-23 12:03:29 |

## 一、總覽儀表板

選用來源：storyboard 三檔選用表

| 檔位 | 選用頁數 | zh-TW 母本 | en-US 改編 | 回譯覆蓋 | 偏移標記數 |
|---|---|---|---|---|---|
| 5-6 | 12 | 12 頁有文 | 12 頁有文 | 12/12 | 6 |
| 3-5 | 10 | 10 頁有文 | 10 頁有文 | 10/10 | 8 |
| 2-3 | 9 | 9 頁有文 | 9 頁有文 | 9/9 | 4 |

## 二、逐頁三欄對照（母本 × 改編 × 回譯；審讀主戰場＝「回譯」欄 vs 母本）

### 5-6

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 丟過去，接住！／兔兔和企企玩著球，你一次，我一次，笑聲跟著球一起飛。 | Dash threw the ball. Waddle caught it and threw it back.／Back and forth, back and forth — they never, ever missed. | Dash 把球丟出去。Waddle 接住了，又丟回來。來來回回，來來回回——他們從來、從來沒有漏接過。 | 輕微：zh-TW「笑聲跟著球一起飛」傳達歡樂氛圍，en-US 改為「從來沒漏接」強調默契；核心輪替節奏保留 |
| P02 | P02 | 兔兔和企企同時看到——一座空鞦韆！／「我先！」兔兔喊。／「我也想先！」企企說。 | Then they spotted something — an empty swing!／They both ran for it at once.／"Me first!" shouted Dash.／"No, me first!" shouted Waddle. | 然後他們發現了一個東西——一個空的鞦韆！他們倆同時衝了過去。「我先！」Dash 大喊。「不，我先！」Waddle 大喊。 | 無 |
| P03 | P03 | 咻——／兔兔搶先跳上鞦韆。／嘎吱嘎吱，越盪越高。／回頭一看，企企還在等。兔兔覺得不好意思…… 可是也捨不得下來。 | ZIP! Dash got there first.／He hopped onto the seat and pushed off — creak, creak — higher and higher!／But then he looked down. Waddle was still standing there.／Dash's tummy felt funny. | 咻！(ZIP!) Dash 先到了。他跳上座椅，用力一蹬——嘎吱，嘎吱 (creak, creak)——越盪越高！但接著他往下看。Waddle 還站在那裡。Dash 的肚子感覺怪怪的。 | 輕微：zh-TW 明確寫「不好意思＋捨不得下來」雙重情緒，en-US 以「肚子怪怪的」概括，失去「捨不得下來」的抗拒層 |
| P04 | P04 | 「一起坐吧！」兔兔把手伸向企企。／兩個人擠上去。／嘎吱嘎吱！鞦韆動也不動，他們差點滑下來。 | "Hop on!" said Dash. "We can share!"／They squeezed together on the tiny seat. Waddle held on tight. Dash held on tighter.／The swing didn't budge. Not one bit.／CREEAK! The seat tilted sideways, and they almost slid right off! | 「跳上來！」Dash 說。「我們可以一起用！」他們擠在小小的座椅上。Waddle 緊緊抓著。Dash 抓得更緊。鞦韆一動也不動。一點都不動。嘎——吱！(CREEAK!) 座椅歪向一邊，他們差點滑下去！ | 無 |
| P05 | P05 | 「猜拳，贏的先玩！」企企說。／兔兔猜輸了。企企搖呀搖走去盪鞦韆。／兔兔在旁邊踢泥巴——怎麼還沒輪到我？ | "I know!" said Waddle. "Rock, paper, scissors — winner goes first!"／They played. Waddle won.／Waddle waddled right to the swing. Dash sat down to wait.／He kicked the dirt. And kicked. And kicked some more. | 「我知道了！」Waddle 說。「剪刀、石頭、布——贏的人先玩！」他們玩了。Waddle 贏了。Waddle 搖搖擺擺地走向鞦韆。Dash 坐下來等。他踢著泥土。又踢。又踢了更多。 | 無 |
| P06 | P06 | 「太久了啦！」兔兔大喊。／「可是我贏的呀！」企企也喊。／兩個人越說越大聲，誰都沒在聽。最後，誰都不想玩了。 | "You've been on there forever!" Dash shouted.／"I won fair and square!" Waddle said. "Rules are rules!"／They argued and argued until neither one wanted to play anymore.／The swing sat empty. | 「你已經玩了好久了！」Dash 大喊。「我贏得公平又正當！」Waddle 說。「規則就是規則！」他們吵了又吵，直到兩個人都不想玩了。鞦韆空空地坐在那裡。 | 無 |
| P07 | P07 | 好久好久，都沒有人說話。／兔兔和企企背對背坐著，誰也不看誰。／嘎吱嘎吱…… 風推著空鞦韆，晃呀晃。 | Neither of them said a word.／They sat on the grass, back to back. The empty swing creaked in the wind.／Creak… creak… | 他們倆都沒有說一句話。他們坐在草地上，背對背。空的鞦韆在風中嘎吱作響。嘎吱……嘎吱…… (Creak... creak...) | 無 |
| P08 | P08 | 兔兔坐了一下子，走到沙坑邊。／他把沙漏倒過來。沙沙沙…… 流完了，再倒一次，又開始流。／兔兔的眼睛亮了—— | Dash turned his head. Over by the sandbox, something caught the sunlight — a little hourglass!／He picked it up and flipped it over. Shh, shh, shh — the sand trickled down.／It ran out! He flipped it again. Shh, shh, shh — it started all over.／Dash's eyes went wide— | Dash 轉過頭。沙坑旁邊，有什麼東西在陽光下閃閃發亮——一個小沙漏！他撿起來翻過去。沙沙沙 (Shh, shh, shh)——沙子慢慢流下來。流完了！他又翻過來。沙沙沙 (Shh, shh, shh)——又重新開始了。Dash 的眼睛睜得好大—— | 輕微：en-US 增添發現過程（picked up/陽光下閃光）為 5-6 增色；核心拍「翻轉→流完→再翻→又流」已對齊 zh-TW（R2 修正） |
| P09 | P09 | 「對不起，我忘了你也在等。」兔兔說，「沙漏漏完就換你，好不好？」／企企先盪。／沙沙沙。／「輪到你，輪到我。」 | "Waddle, I'm sorry — I forgot you were waiting, too," said Dash. "Look what I found!"／He held up the hourglass. "When the sand runs out, we switch!"／"Your turn, my turn!"／Waddle grabbed the rope and pushed off — creak, creak!／Shh, shh, shh. | 「Waddle，對不起——我忘了你也在等，」Dash 說。「你看我找到什麼！」他舉起沙漏。「沙子流完，我們就換！」「你一次，我一次！」Waddle 抓住繩子，用力一蹬——嘎吱嘎吱 (creak, creak)！沙沙沙 (Shh, shh, shh)。 | 輕微：en-US 增添展示手勢「Look!」「held up」＋擺盪動作；道歉核心「我忘了你也在等」已完全對齊 zh-TW（R2 修正） |
| P10 | P10 | 兔兔盪完，企企幫他數：「一、二、三！」／輪到兔兔數。看企企踢呀踢，兔兔笑得肚子痛。／兩個人唱著：「輪到你，輪到我。」／兔兔抬起手—— | Before, Waddle counted for Dash — "One, two, three!"／Now it was Dash's turn to count.／Waddle kicked the sky with his little feet — and Dash laughed so hard his tummy hurt!／"Your turn, my turn!" they sang.／Dash raised his hand— | 之前，Waddle 幫 Dash 數——「一、二、三！」現在輪到 Dash 數了。Waddle 用小腳丫踢向天空——Dash 笑到肚子都痛了！「你一次，我一次！」他們一起唱。Dash 舉起手—— | 輕微：時間框架「Before/之前」vs zh-TW 順序「盪完」；感官「小腳丫/kicked the sky」增添；「數/count」＋「舉起手」已對齊 zh-TW（R2 修正） |
| P11 | P11 | 沙沙沙停了。輪到兔兔了。／兔兔卻說：「再給你盪一次吧！」／「下次換你先喔！」企企說。／兔兔笑了：「輪到你，輪到我——我想看你盪！」 | The sand ran out. It was Dash's turn.／But Dash didn't hop on.／"One more for you!" he said.／Waddle blinked. "Really?"／"Your turn, my turn." Dash smiled. "I want to watch you swing!"／"Next time," said Waddle, "you go first." | 沙子流完了。輪到 Dash 了。可是 Dash 沒有跳上去。「再給你盪一次！」他說。Waddle 眨眨眼。「真的嗎？」「你一次，我一次。」Dash 笑了。「我想看你盪鞦韆！」「下一次，」Waddle 說，「換你先。」 | 輕微：en-US 增添「沒有跳上去」動作呈現＋Waddle 驚喜反應「Really?」；核心「我想看你盪」已完全對齊 zh-TW——E-2 中度偏移已修正（R2） |
| P12 | P12 | 他們把沙漏留在鞦韆旁，跑去溜滑梯了。／後來呀，兔兔和企企不管玩什麼，都會唱那首輪流歌：／「輪到你，輪到我！」 | As the sun set, Dash and Waddle walked toward the slide.／They left the hourglass by the swing, for the next friend.／And from that day on, wherever they played, Dash and Waddle always sang their song:／"Your turn, my turn!" | 夕陽西下時，Dash 和 Waddle 走向溜滑梯。他們把沙漏留在鞦韆旁，給下一個朋友。從那天起，不管在哪裡玩，Dash 和 Waddle 總是唱著他們的歌：「你的回合，我的回合！」 | 無 |

### 3-5

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 丟過去，接住！／兔兔和企企玩著球，你一次，我一次。 | Dash threw the ball. Waddle caught it and threw it back.／Back and forth, back and forth. | Dash 把球丟出去。Waddle 接住了，又丟回來。來來回回，來來回回。 | 無 |
| P02 | P02 | 兔兔和企企看到了——空鞦韆！／「我先！」兔兔喊。／「我也想先！」企企說。 | Then they spotted it — an empty swing!／"Me first!" shouted Dash.／"No, me first!" shouted Waddle. | 然後他們發現了——一個空的鞦韆！「我先！」Dash 大喊。「不，我先！」Waddle 大喊。 | 無 |
| P03 | P03 | 咻—— 兔兔搶先跳上鞦韆。／嘎吱嘎吱，越盪越高。／企企還在等。 | ZIP! Dash got there first.／Creak, creak — he swung higher and higher.／Waddle was still standing there. Dash's tummy felt funny. | 咻！(ZIP!) Dash 先到了。嘎吱，嘎吱 (Creak, creak)——他越盪越高。Waddle 還站在那裡。Dash 的肚子感覺怪怪的。 | 輕微：en-US 加入「肚子怪怪的」內心感受，zh-TW 3-5 僅陳述事實「企企還在等」不含內心描寫 |
| P04 | P04 | 「一起坐吧！」／兩個人擠上去。／嘎吱嘎吱！鞦韆動也不動。／兩人悶悶的。 | "Hop on!" said Dash. "We can share!"／They squeezed onto the seat together. The swing didn't budge.／CREEAK! They almost slid off!／They just sat there. | 「跳上來！」Dash 說。「我們可以一起！」他們一起擠上座位。鞦韆動也不動。嘎吱——！(CREEAK!) 他們差點滑下來！他們就坐在那裡。 | 輕微：邀請拆分為兩句並改寫（"Hop on! We can share!" vs「一起坐吧」）；擬聲詞移至動作後；喜劇節拍增添「almost slid off」；QA F2 修正將內心情緒「悶悶的」轉為可見行為「They just sat there」（showing > telling） |
| P05 | P07 | 風推著空鞦韆，晃呀晃。／兩個人坐在旁邊，不知道怎麼辦。／嘎吱嘎吱…… | They sat on the grass, not looking at each other.／The empty swing creaked in the wind.／Creak… creak… | 他們坐在草地上，不看對方。空的鞦韆在風中嘎吱作響。嘎吱……嘎吱…… (Creak... creak...) | 輕微：zh-TW「鞦韆還是不動＋不知道怎辦」vs en-US「不看對方」，低谷功能等價但描寫焦點不同 |
| P06 | P08 | 兔兔走到沙坑，把沙漏倒過來。／沙沙沙…… 流完了，再倒一次。／兔兔的眼睛亮了—— | Dash turned his head. By the sandbox — a little hourglass!／He flipped it over. Shh, shh, shh. It ran out! He flipped it again.／Dash's eyes went wide— | Dash 轉過頭。沙坑旁邊——一個小沙漏！他把它翻過來。沙沙沙 (Shh, shh, shh)。流完了！他又翻過去。Dash 的眼睛睜得好大—— | 無（「翻轉→流完→再翻」核心拍已完全對齊 zh-TW——R2 修正） |
| P07 | P09 | 「對不起。沙漏漏完就換你！」兔兔說。／企企先盪。／「輪到你，輪到我。」 | "Waddle, I'm sorry I grabbed the swing. Look!"／Dash held up the hourglass. "When the sand runs out, we switch!"／"Your turn, my turn!"／Creak, creak! | 「Waddle，對不起我搶了鞦韆。你看！」Dash 舉起沙漏。「沙子流完，我們就換！」「你的回合，我的回合！」嘎吱，嘎吱！(Creak, creak!) | 輕微：道歉擴展明指過失（"I grabbed the swing" vs 泛化「對不起」）；呼格「Waddle」+「Look!」增添；展示手勢「held up the hourglass」插入；「企企先盪」以擬聲效果呈現取代（"Creak, creak!"）；與 F6 消歧修正一致 |
| P08 | P10 | 兔兔盪，企企數：「一、二、三！」／換！兔兔笑著看。／兩個人唱：「輪到你，輪到我。」／兔兔抬手—— | Waddle counted for Dash — "One, two, three!"／Now Dash waited. Waddle kicked the sky!／Dash laughed until his tummy hurt.／"Your turn, my turn!"／Dash raised his hand— | Waddle 幫 Dash 數——「一、二、三！」現在換 Dash 等了。Waddle 踢向天空！Dash 笑到肚子好痛。「你一次，我一次！」Dash 舉起手—— | 輕微：視角互換——zh-TW「兔兔盪，企企數」en-US「Waddle counted for Dash」；en-US 加入感官「tummy hurt」；「舉起手」已對齊 zh-TW（R2 修正） |
| P09 | P11 | 輪到兔兔了。／「你再盪一次吧！」／「下次換你先喔！」／兔兔笑了：「輪到你，輪到我——我想看你盪！」 | The sand ran out. Dash's turn!／But Dash didn't hop on. "One more for you!"／"Your turn, my turn." Dash smiled. "I want to watch you swing!"／"Next time," said Waddle, "you go first." | 沙子流完了。輪到 Dash 了！可是 Dash 沒有跳上去。「再給你盪一次！」「你一次，我一次。」Dash 笑了。「我想看你盪鞦韆！」「下一次，」Waddle 說，「換你先。」 | 輕微：en-US 增添「沙子流完了」起始＋「沒跳上去」動作呈現；核心「我想看你盪」＋互惠承諾均完全對齊——E-2 中度偏移已修正（R2） |
| P10 | P12 | 後來呀，兔兔和企企不管玩什麼，都會唱那首輪流歌：／「輪到你，輪到我！」 | As the sun set, Dash and Waddle walked toward the slide.／They left the hourglass for the next friend.／And from that day on, they always sang their song:／"Your turn, my turn!" | 夕陽西下時，Dash 和 Waddle 走向溜滑梯。他們把沙漏留給下一個朋友。從那天起，他們總是唱著他們的歌：「你的回合，我的回合！」 | 輕微：en-US 保留夕陽轉場＋溜滑梯＋留沙漏細節，zh-TW 3-5 精簡為純收束式 |

### 2-3

| 頁 | 母版頁 | zh-TW 母本 | en-US 改編 | 回譯（zh-TW） | 偏移標記 |
|---|---|---|---|---|---|
| P01 | P01 | 丟過去，接住！／兔兔一次，企企一次。 | Dash threw the ball.／Waddle threw it back.／Back and forth! | Dash 把球丟出去。Waddle 把球丟回來。來來回回！ | 無 |
| P02 | P02 | 空鞦韆！／兔兔喊：「我先！」／企企喊：「我也要！」 | An empty swing!／"Me first!" said Dash.／"Me first!" said Waddle. | 一個空的鞦韆！「我先！」Dash 說。「我先！」Waddle 說。 | 無 |
| P03 | P03 | 咻——／兔兔先跳上去。／嘎吱嘎吱！／企企還在等。 | ZIP! Dash sat on the swing.／Creak, creak!／Waddle waited. | 咻！(ZIP!) Dash 坐上鞦韆。嘎吱嘎吱！(Creak, creak!) Waddle 等著。 | 無 |
| P04 | P04 | 「一起坐！」／兩個人擠上去。／嘎吱嘎吱！／鞦韆不動了。 | "Hop on!" said Dash.／They squeezed together. CREEAK! Stuck! | 「跳上來！」Dash 說。他們擠在一起。嘎——吱！(CREEAK!) 卡住了！ | 無 |
| P05 | P08 | 兔兔走到沙坑。／他把沙漏倒過來。／沙沙沙……／兔兔的眼睛亮了—— | Dash walked to the sandbox.／An hourglass!／Shh, shh, shh— | Dash 走到沙坑旁。一個沙漏！沙沙沙 (Shh, shh, shh)—— | 輕微：zh-TW「眼睛亮了——」為視覺驚喜懸念，en-US 2-3 以聽覺懸念「Shh, shh, shh—」替代；zh-TW 寫「倒過來」翻轉動作，en-US 省略 |
| P06 | P09 | 「對不起。沙漏漏完就換！」／企企先盪。／「輪到你，輪到我。」 | "Sorry! Sand out — switch!"／"Your turn, my turn!"／Creak, creak! | 「對不起！沙子流完了——換人！」「你一次，我一次！」嘎吱嘎吱！(Creak, creak!) | 無（R2 修正：「Sand out — switch!」直接對齊 zh-TW「沙漏漏完就換」規則說明） |
| P07 | P10 | 兔兔盪，企企數。／「一、二、三！」／換！／一起唱：「輪到你，輪到我。」／兔兔抬手—— | Waddle kicked the sky!／"Your turn, my turn!"／The sand ran out— | Waddle 踢向天空！「你的回合，我的回合！」沙子漏完了—— | 輕微：zh-TW 保留「兔兔盪→企企數 1-2-3→換」完整回合節奏，en-US 精簡為企企踢天空＋疊句＋沙漏鉤子 |
| P08 | P11 | 輪到兔兔了。／「你再盪吧！」／「下次你先喔！」／兔兔笑了：「輪到你，輪到我。我想看你盪！」 | "One more for you!"／"Your turn, my turn!"／"I want to watch you swing!" | 「再給你盪一次！」「你一次，我一次！」「我想看你盪鞦韆！」 | 輕微：zh-TW 保留互惠承諾「下次你先喔」＋「兔兔笑了」情態，en-US 2-3 因 14w hard limit 壓縮為三句純對話——核心利他快樂高潮線「我想看你盪」已到位（R2 E-2 修正） |
| P09 | P12 | 後來呀，兔兔和企企不管玩什麼，都會唱那首輪流歌：／「輪到你，輪到我！」 | And from that day on, they sang:／"Your turn, my turn!" | 從那天起，他們唱著：「你的回合，我的回合！」 | 無 |

## 三、QA 摘要（qa/en-US）

- `qa/en-US/round1.md`：round 1／verdict fix_required
- `qa/en-US/round2.md`：round 2／verdict escalated
- `qa/en-US/round3.md`：round 3／verdict pass

最新 round：`qa/en-US/round3.md`

```yaml
schema: piyo_text_qa_report/v0.9
slug: your-turn-my-turn
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 3
date: "2026-07-23"
step1_lint: {exit_code: 0, warnings: 16}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: en-US-teacher
    scores: {年齡適配度: 6, 朗讀口感: 7, 孩子抓得住度: 7}
  - id: en-US-parent
    scores: {睡前適讀性: 6, 零說教: 9}
  - id: en-US-editor
    scores: {母語自然度: 9, 文字工藝: 8}
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

### ESL 獵手發現（原文引用）

（缺）最新 round 無「ESL」標題節——確認漏斗是否執行 ESL 獵手維度。

## 四、⏸️ 上呈批次

- （`qa/en-US/round1.md`）| E-2 | 回譯中度偏移 | 全檔 | P11/P09/P08 | 高潮 vicarious joy→patience 偏移 | 3頁中度 | **⏸️** | 創作級 | zh-TW 高潮線「我想看你盪」（觀看＝利他快樂）→ en-US "There's always next time"（耐心/充裕心態）。語義核心從利他轉耐心＝concept fidelity 層級，上呈 Stacy |
- （`qa/en-US/round1.md`）### ⏸️ 上呈批次
- （`qa/en-US/round2.md`）**⏸️ 沿用**：E-2（高潮 vicarious joy→patience 偏移）從 round 1 帶入，維持 ⏸️ 上呈。
- （`qa/en-US/round2.md`）### ⏸️ 上呈批次
- （`qa/en-US/round3.md`）Round 2 唯一 ⏸️（E-2 vicarious joy→patience 偏移）已由 Stacy 裁定 **Option A 落地**：三檔高潮統一為 "I want to watch you swing!"。回譯確認三檔均對齊 zh-TW「我想看你盪」。
- （`qa/en-US/round3.md`）本輪無新裁決對象。✅=0, ❌=0, ⏸️=0。

