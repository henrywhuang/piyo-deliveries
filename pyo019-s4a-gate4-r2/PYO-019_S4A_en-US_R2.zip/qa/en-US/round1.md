# QA 報告：the-city-mouse-and-the-country-mouse / en-US / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: the-city-mouse-and-the-country-mouse
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-29"
step1_lint: {exit_code: 0, warnings: 9}
step2_checklist: {pass: 24, fail: 0}
step3_mode: consolidated
step3_personas: []
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

## STEP 1 機檢

```
locale_lint 5-6: exit 0 (warnings 3: repeat_discount crunch×2, refrain×3, 310→300.25w)
locale_lint 3-5: exit 0 (warnings 3: repeat_discount crunch×2, refrain×3, 180→170.25w)
locale_lint 2-3: exit 0 (warnings 3: repeat_discount crunch×2, refrain×3, 95→85.25w)
```

保留警告判讀：9 筆警告全為 repeat_discount 折計資訊，非違規。

text-writer 交接保留警告：
- 3-5 P08 14w < band 下緣 15：climax 頁刻意靜默，合理
- 2-3 P11 8w < band 下緣 10：電報式合法語體

## STEP 2 checklist 自檢

### 合併審查（S4A v0.15）

**主題錨復述句**：本書要教的是「最適合自己的地方就是最好的地方」——鄉下老鼠去城市嘗美食，三次驚嚇後覺察「吃不安心」的內在感受，主動選擇回家。賣點是感官落差＋驚嚇喜劇＋暖收。

### Checklist（A-E 19 項＋快速掃描 9 項，stage-N/A 3 項）

| 項 | 判定 | 證據摘要 |
|---|---|---|
| A-1 完整弧線 | ✅ 三檔 | 觸發P01→上升P05-07→高潮P08→收束P11-12 |
| A-2 衝突有份量 | ✅ 三檔 | 三次嘗試跨P05-08(≥2跨頁)；主角自主選擇 |
| A-3 情緒有起伏 | ✅ 三檔 | 好奇→震撼→驚嚇升級→堅定→滿足 |
| A-4 結尾有回響 | ✅ 三檔 | 圓滿式P11 crunch呼應P01＋開放收束語 |
| A-5 開場有鉤子 | ✅ 三檔 | P01衝突型：Glitz闖入日常 |
| B-1 每頁字數 | N/A(量化) | STEP 1 已判 |
| B-2 句長配情緒 | ✅ 三檔 | 短句≤8w(P05-07)；長句≥15w(P10 27w) |
| B-3 聲音裝置 | ✅ 三檔 | 5組擬聲詞各≤3次 |
| B-4 對話比例 | ✅ 5-6/3-5；tier-N/A 2-3 | 疊句型豁免適用；2-3旁白為主屬R7規格 |
| B-5 無百科腔 | ✅ 三檔 | — |
| C-1 主角辨識度 | ✅ 三檔 | Nibble安靜觀察者透過行為呈現 |
| C-2 成長弧線 | ✅ 三檔 | 困境→觸發→P08主動選擇 |
| C-3 障礙有阻力 | ✅ 三檔 | 三次環境危險逐次阻擋 |
| C-4 配角有功能 | ✅ 三檔 | Glitz＝觸發者＋鏡像者 |
| D-1~D-3 | stage-N/A | 待媒體線補檢 |
| D-4 翻頁hook | ✅ 三檔 | P07動作中斷em dash＋P08懸念 |
| E-1 主題由行動 | ✅ 三檔 | P08自我覺察＋P11意願句，無旁白說教 |
| E-2 情感共鳴 | ✅ 三檔 | P08心跳聲＋whispered＝場景呈現 |
| E-3 末頁無教訓 | ✅ 三檔 | 開放式收束語 |
| E-4 抽象度匹配 | ✅ 三檔 | 2-3無抽象詞；5-6有場景支撐 |

快速掃描 #1-10（#4 N/A量化、#7 stage-N/A）：全過。

### 對位逐頁比對

12 頁×三檔全檢：零違反。文字負載限定於台詞/擬聲/內心/事件敘述/收束語，未重述圖已明示的視覺屬性。

### ESL 獵手

逐頁掃描 en-US spec R1-R7 雷區＋style_guide §3.4 四型 AI 機械句：

- R2 縮寫：全文正確使用（wasn't/I'll/couldn't/don't），無翻譯腔
- R3 tag：said 為主力，whispered/laughed 限情緒峰值
- R5 sight words：骨架全高頻，內容詞具體可畫
- R6 重複句：三組逐字一致
- R7 幼幼版：2-3 fragment 合法(Cheese!/Mmmm!)

ESL calque/搭配/語序異常：0 筆。
AI 機械句四型：0 筆。

### 原生語感三視角

- **Teacher**：疊句節奏清晰可預期接話；5 組擬聲詞適合互動朗讀；P08 語彙自然
- **Parent**：城鄉中立（P09 Glitz 正向自定）；驚嚇去牙化；2-3 P12 詩意收束適合睡前
- **Editor**：P03/P10 結構對稱（escalation/diminution）；P07 em dash hook 技術成熟；2-3 P11 純感官替代意願句符合 §5

三視角零發現。

### Concept fidelity

- 5-6：P08「I don't feel safe」＝覺察非恐懼→P11「I like eating at home best」＝主動偏好。✅
- 3-5：同核心弧線壓縮 10 頁，變奏＋意願句完整。✅
- 2-3：P08 覺察拍點保留＋P11 感官呈現替代語言表達（2-3 合法）。✅

### Inline 分診

| 筆數 | 計數 |
|---|---|
| ✅ real | 0 |
| ❌ rejected | 0 |
| ⏸️ escalated | 0 |

一輪 ✅=0，QA 收斂。

## STEP 3 人設 blind QA

S4A v0.15：見 STEP 2 合併審查。

## STEP 4 三分法分診

S4A v0.15：見 STEP 2 合併審查。
