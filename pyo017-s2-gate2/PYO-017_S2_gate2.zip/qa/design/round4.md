# 設計 QA 報告：my-spots-are-different / design / round 4（S2 分鏡）

```yaml
schema: piyo_design_qa_report/v0.9
slug: my-spots-are-different
stage: S2
round: 4
date: "2026-07-28"
step3_check: {exit_code: 0, warnings: 0}
concept_fidelity: pass
theme_engine: pass
reviewer: {pass: 8, fail: 0}
triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

## 主題錨復述

本書講的是小花豹斑斑因斑點形狀（星星、雲朵）與同伴不同，三次偽裝全狼狽失敗後，在「猜猜我是誰」遊戲中主動選擇讓斑點被看見——同伴一猜就中、媽媽一眼認出——「不一樣」從來不是需要修好的問題，而是你之所以是你的標記。

## 八維判定表

| # | 維度 | 判定 | 證據摘要 |
|---|---|---|---|
| ① | 主題錨與敘事兌現 | pass | 疊句四頁位、hook P10/P11、三次嘗試成對、雙層翻轉 P11/P12、B11 抽驗 2 項全兌現 |
| ② | 鏡頭節奏動機與多樣性 | pass | 三主類 4-5-4（30.8/38.5/30.8%）、五級距寫法、俯仰精確落低谷進出口、中景家族 61.5%、無紅線無警告 |
| ③ | 對位分工乾淨 | pass | 逐頁圖文無重疊、無前綴分類、每頁負載有畫面底座 |
| ④ | 翻頁拉力與五源覆蓋 | pass | 12 頁鉤子全填（末頁除外）、design 宣告 P10 動作中斷/P11 懸念一致、五源每源≥1 |
| ⑤ | 構圖複雜度 | pass | 全數≤80 字、無禁止項、一頁一圖、每頁視覺層≤2 |
| ⑥ | 2-3 選用頁可讀性 | pass | 8 頁逐頁三判準通過（P01/P13 為開場/收束慣例，有視覺優先處理） |
| ⑦ | 跨頁一致性 | pass | 角色 lock 特徵逐頁呼應、光線時序連續、狀態線 9 區間與圖說全對齊 |
| ⑧ | 角色佔比節奏與品牌整體感 | pass | 小/中/大 均衡（4/5/4）、高潮放大低谷縮小、iyashikei 低飽和未破、末兩頁安定開闊 |

## 分診

無 fail 維度，無需分診。

## 收斂結論

一輪 ✅=0、⏸️=0，正常收斂。verdict: pass。進入 awaiting_green_light。
