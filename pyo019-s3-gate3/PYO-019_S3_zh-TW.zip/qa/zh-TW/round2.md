# QA 報告：the-city-mouse-and-the-country-mouse / zh-TW / round 2（復核輪）

```yaml
schema: piyo_text_qa_report/v0.9
slug: the-city-mouse-and-the-country-mouse
locale: zh-TW
tiers: ["2-3", "3-5", "5-6"]
round: 2
date: "2026-07-29"
step1_lint: {exit_code: 0, warnings: 4}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: zh-TW-teacher
    scores: {年齡適配度: 7, 朗讀口感: 8, 孩子抓得住度: 8}
  - id: zh-TW-parent
    scores: {睡前適讀性: 9, 零說教: 10}
  - id: zh-TW-editor
    scores: {母語自然度: 10, 文字工藝: 7}
step4_triage: {real: 0, rejected: 0, escalated: 2}
verdict: escalated
```

**本輪性質：復核輪**（round 1 ✅ 全數 ∈ {字串級}，符合復核輪資格——SKILL.md v0.14）。E-lite 只複審受修頁與相鄰頁；人設不重跑，分數沿用 round 1。

## STEP 1 機檢

四道機檢全數 exit 0：

| 機檢 | 結果 |
|---|---|
| `copy_check.py copy/zh-TW.md` | exit 0（4⚠：5-6 P06=41、P08=41 核心載荷；3-5 P04=26 回修+1；2-3 P07=21 回修+1） |
| `locale_lint.py --pages-file text/zh-TW/5-6.draft.json --locale zh-TW --band 5-6` | exit 0 |
| `locale_lint.py --pages-file text/zh-TW/3-5.draft.json --locale zh-TW --band 3-5` | exit 0 |
| `locale_lint.py --pages-file text/zh-TW/2-3.draft.json --locale zh-TW --band 2-3` | exit 0 |

回修新增警告理由：3-5 P04 由 23→26（「大宅」2 字→「好大的房子」5 字，超帶上緣 25 僅 1 字）；2-3 P07 由 18→21（補「跑呀跑——」4 字，超帶上緣 20 僅 1 字）。兩處均為 QA 裁決指定的字串級回修，無法再縮。

## STEP 2 checklist 自檢（E-lite 複審）

**主題錨復述**：禾禾到城市吃大餐，每次剛要開吃就被嚇跑，最終不是因為害怕而逃，而是覺察「吃不安心」這個感受，主動選擇回家——核心是自我認知。

### 修改落地驗證

| 回修 | 裁決指定 | 實際 diff | 精確吻合 | 受修頁新問題 | 相鄰頁波及 | 目標修復 | 結論 |
|---|---|---|---|---|---|---|---|
| A（2-3 P07） | 「翻了！噴了！」後補「跑呀跑——」 | 「噴了！\n」→「噴了！跑呀跑——\n」 | ✓ | 無 | P06/P08 銜接自然 | D-4 已修復：動作中斷型 hook 新增 | 通過 |
| B（3-5 P04） | 「大宅」→ 口語化 | 「大宅」→「好大的房子」 | ✓ | 無 | P02/P05 無衝突 | 語域口語化達成 | 通過 |

E-lite 判定：全 28 項通過（round 1 的 D-4 與 #8 已修復；對位、concept fidelity 無新問題）。

## STEP 3 人設 blind QA

**復核輪不重跑人設**，分數沿用 round 1（全人設均有 finding，不適用 zero-finding 免重跑條件）。

| 人設 | 摘要分（最弱檔位） |
|---|---|
| zh-TW-teacher | 年齡適配度 7、朗讀口感 8、孩子抓得住度 8 |
| zh-TW-parent | 睡前適讀性 9、零說教 10 |
| zh-TW-editor | 母語自然度 10、文字工藝 7 |

## STEP 4 三分法分診

**主題錨復述**：同上。

本輪 ✅=0。Round 1 的 2 筆 ✅（#1/#2 合併＋#6）已回修落地驗證通過。⏸️ 2 筆照常上呈，不在復核輪重新裁決。

**QA 收斂**：✅=0 → zh-TW 文本 QA 收斂。⏸️ 2 筆隨 gate3 審包上呈 Stacy。

### ⏸️ 上呈批次（承繼 round 1，zh-TW，PYO-019，共 2 筆）

| # | 涉及頁 | 為什麼裁決不了 | 裁決傾向 |
|---|---|---|---|
| 5 | 2-3 P08 | concept_contract 核心詞（安心）vs 2-3 年齡適切性 | 若改，需找到既保留「不只是害怕」語義又具象化的替代（如「吃不開心」） |
| 7 | 5-6/3-5 P06 | 食物矛盾源自凍結上游（storyboard＋design） | 最小侵入方案：「奶油」→「起司」，需確認文本與圖說偏差 |
