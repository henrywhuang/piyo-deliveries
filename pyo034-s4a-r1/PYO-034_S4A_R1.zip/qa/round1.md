# QA 報告：monkeys-fishing-for-the-moon / en-US / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: monkeys-fishing-for-the-moon
locale: en-US
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-31"
step1_lint: {exit_code: 0, warnings: 10}
step2_checklist: {pass: 28, fail: 0}
step3_mode: consolidated
step3_personas: []
step4_triage: {real: 0, rejected: 0, escalated: 0}
verdict: pass
```

## STEP 1 機檢

### locale_lint

```
5-6: ✅ 無違規（警告 2 筆——repeat_discount x3, adjusted 342→331.5）
3-5: ✅ 無違規（警告 2 筆——repeat_discount x3, adjusted 247→236.5）
2-3: ✅ 無違規（警告 3 筆——frozen unit 句長豁免 P08 closing formula 9>8, repeat_discount x2, adjusted 91→85.75）
```

保留警告判讀：
- repeat_discount：疊句「Scoop, scoop, scoop the moon—SPLASH! It broke!」在 5-6 出現 3 次、3-5 出現 3 次、2-3 出現 2 次，折計合理。
- frozen unit 豁免：2-3 P08 收束式「And from that day on, they watched the moon.」9 詞超 max_sentence_len 8，品牌凍結單元豁免，合規。

### copy_check

```
✅ copy 機檢通過（警告 5 筆）
```

保留警告判讀：
- 3-5 P04 31⚠（帶頂 25）：橋接 P04 跳接，合併「月亮回來了＋新策略＋疊句＋反應」。
- 3-5 P05 34⚠（帶頂 25）：橋接 P06 跳接，合併「rallying 句＋長鏈場面＋Teeny 位置」。
- 5-6 P09 17（帶底 20）：情緒低谷刻意短（craft C1），非漏拍。
- 5-6 P12 46⚠（帶頂 40）：結尾四件套全件（同框＋感謝＋前瞻＋收束），結構需求。
- 3-5 P10 38⚠（帶頂 25）：結尾四件套（同框＋感謝＋前瞻＋收束），結構需求。

### localize_readiness

```
✅ en-US 契約綠（檔頭↔registry↔storyboard 同 audit 尺）
```

## STEP 2 checklist 自檢

**主題錨復述**：一群猴子看到月亮倒映在池塘裡，以為月亮掉水裡了，反覆嘗試去撈——每次碰到水面月亮就碎成碎片。全隊最安靜的小不點抬頭一看，月亮好好的掛在天上。核心教訓＝觀察——停下來、換個角度看（`target_ability: 觀察——停下來、換個角度看`）。

### Checklist A-E（19 項通過 / 0 項失敗；text stage N/A = D-1, D-2, D-3）

| 節 | 項目 | 判定 | 證據 |
|---|---|---|---|
| A-1 | 完整弧線 | ✓ | 觸發 P01 → 三次升級 P03/P05/P08 → 高潮 P08 → 低谷 P09 → 啟示 P10 → 收束 P12 |
| A-2 | 衝突有份量 | ✓ | 解決跨 P03-P10（8 頁），主角付出三次具體行動 |
| A-3 | 情緒有起伏 | ✓ | 好奇→興奮→挫敗→沮喪(P09)→驚喜(P10)→溫暖(P12) |
| A-4 | 結尾有回響 | ✓ | 圓滿式——P12 呼應 P01 池塘月光；無旁白說教 |
| A-5 | 開場有鉤子 | ✓ | P01 "Whoa! The moon is in the water!" = 反常事件 |
| B-1 | 每頁字數達標 | ✓ | locale_lint exit 0 |
| B-2 | 句長配情緒 | ✓ | P09 短句（17 詞/2 句）；P08 長句高潮；P12 流暢結尾 |
| B-3 | 聲音裝置 | ✓ | 5 種：SPLASH/SPLOOSH/chitter-chatter/swing and sway/Hee-hee；各 ≤3 次 |
| B-4 | 對話比例 | ✓ | B-4 疊句架構豁免：疊句即角色動作呼喊，疊句頁計入 |
| B-5 | 無百科腔 | ✓ | 零教科書句式 |
| C-1 | 主角有辨識度 | ✓ | Pip 行為呈現（scratched his head / jumped up / shouted）；Teeny 行為呈現（stayed up high / looking here, looking there / looked up） |
| C-2 | 成長弧線完整 | ✓ | Pip 缺陷＝只看水面→觸發＝Teeny 發現月亮在天上→轉變「Next time, I'll look up first」 |
| C-3 | 障礙有阻力 | ✓ | 月影障礙阻擋 3 次，逐次升級 |
| C-4 | 配角有功能 | ✓ | Teeny＝觸發者（P10 啊哈時刻）＋鏡像者（觀察 vs 行動） |
| D-4 | 翻頁有牽引 | ✓ | P03 懸念型、P07 動作中斷型、P08 動作中斷型、P09 懸念型（4 處 ≥2） |
| E-1 | 主題由行動呈現 | ✓ | Teeny 抬頭行動＋Pip「I'll look up first」自覺——無旁白說教 |
| E-2 | 情感共鳴可達 | ✓ | P09 "Pip hung his head. He didn't say a word." = 場景呈現沮喪 |
| E-3 | 末頁無教訓宣言 | ✓ | P12 = 角色對話＋收束敘事，無「從此以後 X 學會了」 |
| E-4 | 抽象度匹配年齡 | ✓ | 三檔零抽象概念詞 |

### 快速掃描（9 項通過 / 0 項失敗；#7 text stage N/A）

1-6, 8-10 全 ✓。#7（圖文關係類型）text stage N/A。

### 對位逐頁比對

| 頁 | 判定 | 備註 |
|---|---|---|
| 5-6 P01-P12 | 全 ✓ | P11 "big and bright, hanging in the sky" 觀察——啟示時刻情緒放大，非冗餘重述視覺屬性（「刪掉這句，閉眼聽者會漏掉情節嗎？」→會，少了月亮完好無缺的認知衝擊） |
| 3-5 P01-P10 | 全 ✓ | — |
| 2-3 P01-P08 | 全 ✓ | — |

零違反。

### ESL 獵手

逐頁全量掃描（en-US spec 雷區 + style_guide §3.4 四型）：

| 頁 | ESL calque | AI 機械句 | 判定 |
|---|---|---|---|
| 5-6 全 12 頁 | 無 | 無 | ✓ |
| 3-5 全 10 頁 | 無 | 無 | ✓ |
| 2-3 全 8 頁 | 無 | 2-3 電報式在合法邊界內（R2-7） | ✓ |

零 ESL 痕跡：無中文語序直譯、無 measure word 滲漏、無 of-pile-up、無 Chinese-pattern conjunctions。§3.4 四型零命中。

### 原生語感三視角

- **Teacher**：詞彙分級合適（5-6 shimmery/tumbled 可由圖輔助理解；2-3 基礎詞）；疊句 "Scoop, scoop, scoop the moon—SPLASH!" 高度 participatory，三歲能接下半句。
- **Parent**：朗讀順暢，情緒轉折清晰（P09 自然放慢、P10 自然加速）；結尾溫暖不說教。
- **Editor**：角色聲音 distinct（Pip 祈使句 "Quick!" / "Get over here!" vs Teeny 觀察句 "Look! The moon!"）；零翻譯感——reads like Kevin Henkes / Caps for Sale 風格原生英文繪本。

零發現。

### Concept fidelity

| 檔位 | 判定 | 依據 |
|---|---|---|
| 5-6 | ✓ | 三次嘗試失敗＋Teeny 抬頭啟示＝「停下來、換個角度看」。forbidden_substitutes（合作/不放棄）未滲入——合作只讓失敗規模更大（P08）；堅持同方向只碎得更厲害。 |
| 3-5 | ✓ | 同核心，簡化表達不偏離 |
| 2-3 | ✓ | 壓縮為兩次嘗試，啊哈時刻 P06-P07 保留——核心教訓完整 |

### Inline 分診

零發現。✅=0 ❌=0 ⏸️=0。

## STEP 3 人設 blind QA

S4A v0.15：見 STEP 2 合併審查。

## STEP 4 三分法分診

S4A v0.15：見 STEP 2 合併審查。✅=0 ❌=0 ⏸️=0。一輪收斂。
