# 關卡WB整合審閱：猴子撈月（E 對位底稿／en-US）

- 生成時間：2026-07-31 14:01:53 +0800
- 書目錄：`content/PYO-034_monkeys-fishing-for-the-moon`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate WB`（決定性腳本，純解析＋排版）
- locale：en-US
- 用途：E 主審與裁決 agent 的單檔輸入 bundle——文字＝QA 對象本體逐字轉錄；可疑頁保留開原檔抽驗權

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-034_storyboard.md` | 2026-07-30 14:01:12 |
| copy | `copy/en-US.md` | 2026-07-31 13:58:30 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-31 12:02:23 |
| text/en-US/5-6 | `text/en-US/5-6.draft.json` | 2026-07-31 13:58:30 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-31 12:02:23 |
| text/en-US/3-5 | `text/en-US/3-5.draft.json` | 2026-07-31 13:58:30 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-31 12:02:23 |
| text/en-US/2-3 | `text/en-US/2-3.draft.json` | 2026-07-31 13:58:30 |
| qa/en-US/backtranslation.md | （缺） | — |

## 檔頭 commitments 逐字轉錄（兌現比對用）

```yaml
schema: piyo_copy/v0.9
slug: monkeys-fishing-for-the-moon
locale: en-US
mode: B
storyboard: content/PYO-034_monkeys-fishing-for-the-moon/PYO-034_storyboard.md
design: content/PYO-034_monkeys-fishing-for-the-moon/PYO-034_design.md
image_pool: 12
selection:
  "3-5": [P01, P02, P03, P05, P07, P08, P09, P10, P11, P12]
  "2-3": [P01, P02, P03, P07, P08, P10, P11, P12]
commitments:
  refrain: "Scoop, scoop, scoop the moon—SPLASH! It broke!"
  ending:
    "5-6": "And from that day on, every full-moon night, the monkeys watched the moon together. And the best moon-watcher of all? That was Teeny."
    "3-5": "And from that day on, the monkeys watched the moon together. The best moon-watcher of all? That was Teeny."
    "2-3": "And from that day on, they watched the moon."
  onomatopoeia: [SPLASH!, SPLOOSH!, chitter-chatter, "swing and sway", "Hee-hee!"]
characters: [Pip, Teeny, the monkeys]
voice_cards:
  Pip: "Action-first leader. Short exclamations. 'Come on!' / 'I know!' / 'Not enough!' He = impulsive, always has a plan."
  Teeny: "Quiet observer. Short sentences with wonder. She = looks up, notices what others miss."
```

## 檔位 5-6（12 頁）

### 5-6｜P01（母版 P01）

- 圖說什麼：月圓夜晚，森林空地的池塘靜靜映著一輪又大又圓的月亮。皮皮從大樹上跑下來趴在池邊，瞪大圓眼盯著水裡亮晃晃的月亮，嘴巴張成O形
- 文說什麼：介紹月圓夜場景，皮皮發現池塘裡映著月亮，驚訝大叫
- 鉤子：視覺引導型：皮皮趴在池邊，目光直直盯著水面的亮光
- 選圖與提純說明：母版；3-5 砍 forest 場景鋪陳；2-3 電報式重述
- 匹配欄：✓

【zh-TW】
月圓的晚上，森林裡好安靜好安靜。
皮皮跑到池塘邊喝水，低頭一看——
「哇！月亮掉到水裡了！」

【en-US】
One full-moon night, the forest was so quiet, so still.
Pip ran to the pond for a drink. He looked down and—
"Whoa! The moon is in the water!"

### 5-6｜P02（母版 P02）

- 圖說什麼：皮皮站在池邊拍胸脯，一手指著水面，嘴巴大張正在喊。三四隻猴子從大樹跳下來圍過來看。大樹高枝上，小不點抬頭望著星星
- 文說什麼：皮皮宣布月亮掉進水裡了，號召大家一起撈月亮還給天空
- 鉤子：視覺引導型：皮皮指著池塘，猴群的目光全跟過去
- 選圖與提純說明：母版；3-5 砍 the water、rally 對話簡化、But not 句式；2-3 砍 chitter-chatter 與 Teeny 伏筆
- 匹配欄：✓

【zh-TW】
皮皮喊：
「月亮掉到水裡了！快來，一起撈月亮！」
猴子們嘰嘰喳喳跑過來。
小不點沒下來，抬頭看星星呢。

【en-US】
"The moon fell in the water!" Pip shouted. "Quick, everybody, come help me scoop it out!"
The monkeys came running, chitter-chatter, chitter-chatter.
But not Teeny. She stayed way up high, looking at the stars.

### 5-6｜P03（母版 P03）

- 圖說什麼：皮皮棕色的大手剛碰到水面，月亮的倒影裂成搖晃的碎片，漣漪一圈圈往外擴。皮皮的臉倒映在碎裂的月光裡，眼珠子瞪得圓滾滾
- 文說什麼：疊句帶擬聲詞節奏，碰水的聲音和月亮碎裂，皮皮的驚叫
- 鉤子：懸念型：月亮碎成搖晃碎片，會不會拼回來？
- 選圖與提純說明：疊句第一次，三檔共核心句；3-5 砍 leaned over；2-3 砍驚叫
- 匹配欄：✓

【zh-TW】
皮皮伸手往水裡一撈——
撈呀撈，撈月亮——嘩啦！碎了！
「啊！月亮碎掉了！」

【en-US】
Pip leaned over and reached into the water—
Scoop, scoop, scoop the moon—SPLASH! It broke!
"Oh no! I broke the moon!"

### 5-6｜P04（母版 P04）

- 圖說什麼：水面慢慢恢復平靜，月亮的倒影又圓回來。皮皮蹲在池邊搔搔頭，一手伸出三根手指比劃，表情認真地看著身旁的猴群
- 文說什麼：月亮回來了，皮皮分析失敗原因，提出新策略——多人輕碰
- 鉤子：視覺引導型：皮皮比出三根手指，目光掃向猴群
- 選圖與提純說明：反思過渡頁；3-5/2-3 跳——策略升級由 P05 橋接
- 匹配欄：✓

【zh-TW】
水面慢慢平靜下來…… 月亮又回來了。
皮皮想了想：「太粗魯了！要輕一點。」
「大家一起來，很多隻手，輕輕撈！」

【en-US】
The water got still again… and the moon came back!
Pip scratched his head. "Too rough! We need more hands—everybody, gently!"

### 5-6｜P05（母版 P05）

- 圖說什麼：三隻猴子排成短鏈掛在池邊樹枝上，最下面那隻小心翼翼伸手碰水面。月亮的倒影又裂開了，碎片在三張倒映的猴臉之間搖晃
- 文說什麼：疊句第二次，動作更輕但結果一樣，碰碎的擬聲詞和猴子們的反應
- 鉤子：懸念型：換了方法月亮照樣碎了，還能怎麼辦？
- 選圖與提純說明：疊句第二次；3-5 橋接 P04（月亮回來了＋新策略句）故字數偏高；2-3 跳——壓縮為兩次嘗試
- 匹配欄：✓

【zh-TW】
這次，三隻猴子一起，輕輕碰了碰水面——
撈呀撈，撈月亮——嘩啦！碎了！
「又碎了！怎麼辦！」

【en-US】
This time, three monkeys leaned in, ever so gently—
Scoop, scoop, scoop the moon—SPLASH! It broke!
"It broke again! What do we do?"

### 5-6｜P06（母版 P06）

- 圖說什麼：皮皮跳起來，紅頭帶飛揚，雙手高舉往大樹方向揮。嘴巴張到最大在喊，表情又急又不服輸。旁邊猴群全仰著頭看他
- 文說什麼：皮皮分析「不夠長」，號召全體猴子排成最長的鏈子
- 鉤子：視覺引導型：皮皮雙手高舉揮向大樹，猴子們目光跟著往上
- 選圖與提純說明：號召全員頁；3-5/2-3 跳——全員長鏈由 P07 鏈條畫面與對話承接
- 匹配欄：✓

【zh-TW】
皮皮跳起來喊：
「不夠長！所有猴子都來！」
「排成一條好長好長的鏈子，一定撈得到！」

【en-US】
Pip jumped up and shouted,
"Not long enough! Every monkey, get over here!"
"We'll make a chain—the longest chain—all the way down to the moon!"

### 5-6｜P07（母版 P07）

- 圖說什麼：從大樹頂往下看——猴子們一隻接一隻掛成長長的鏈子，從粗樹枝一路晃到池塘水面上方。鏈子中間胖猴子卡住在扭、瘦猴子搖搖晃晃。最上面坐著金黃色的小不點
- 文說什麼：全員排長鏈的壯觀場面和搖晃緊張感，小不點被安排在最上面
- 鉤子：動作中斷型：長鏈晃呀晃，最底下的手指快碰到水面了
- 選圖與提純說明：長鏈＋搖擺＋小不點位置；3-5 橋接 P06（rallying 句）故字數偏高；2-3 砍 Teeny 位置
- 匹配欄：✓

【zh-TW】
猴子們一隻接一隻掛下去，排成好長好長的鏈子。
晃呀晃，晃呀晃……
小不點在最上面——「你最輕，別動喔！」

【en-US】
One by one, the monkeys hung from the big branch, all the way down to the water.
Swing and sway, swing and sway…
Teeny sat at the very top. "You're the lightest—don't move!"

### 5-6｜P08（母版 P08）

- 圖說什麼：長鏈最下面的猴子伸手碰到水面——巨大的水花炸開！月亮碎成滿池閃爍的碎銀光。水花濺得到處都是，鏈子裡的猴子被水打得東搖西歪，有的已經鬆手
- 文說什麼：疊句第三次變奏——規模最大的碰碎，擬聲詞升級，猴子們掉水裡的動靜
- 鉤子：動作中斷型：巨大水花沖天碎銀飛舞，猴子們正往下掉
- 選圖與提純說明：疊句第三次變奏＋高潮；3-5 砍碎片修飾詞；2-3 砍動作起始與碎片句
- 匹配欄：✓

【zh-TW】
最下面的猴子伸出手——
撈呀撈，撈月亮——嘩啦！碎了！
碎成好多好多碎片！
撲通！撲通！猴子們全掉進水裡了！

【en-US】
The monkey at the very bottom reached down—
Scoop, scoop, scoop the moon—SPLASH! It broke!
It broke into a thousand tiny, shimmery pieces!
SPLOOSH! SPLOOSH! The monkeys all tumbled into the water!

### 5-6｜P09（母版 P09）

- 圖說什麼：猴子們濕答答地蹲在池塘邊，毛皮貼著身體滴水。皮皮坐在地上低著頭，紅頭帶歪了也沒理。池塘裡只剩搖搖晃晃的碎銀光
- 文說什麼：失敗後的安靜和沮喪，皮皮不說話的低落情緒
- 鉤子：懸念型：皮皮低著頭一句話不說，月亮怎麼辦？
- 選圖與提純說明：情緒低谷刻意短（craft C1）；2-3 跳——由 P08 失敗直接接 P10 啊哈時刻
- 匹配欄：✓

【zh-TW】
猴子們濕答答地坐在池塘邊。
皮皮低著頭，一句話都不說。

【en-US】
The monkeys sat by the pond, dripping wet.
Pip hung his head. He didn't say a word.

### 5-6｜P10（母版 P10）

- 圖說什麼：小不點坐在大樹枝上，圓圓大眼睛猛然睜到最大，整個身體轉向天空。一隻小手指著頭頂——天上掛著一輪又大又亮的圓月，月光灑在小不點金黃色的毛上
- 文說什麼：小不點抬頭發現月亮在天上，興奮的叫喊——啊哈時刻的聲音爆發
- 鉤子：視覺引導型：小不點的手指指著天空，眼神引導往上看
- 選圖與提純說明：啊哈時刻；3-5 砍 big、Whoa；2-3 電報式保留核心發現
- 匹配欄：✓

【zh-TW】
小不點一直坐在大樹上，東看看，西看看。
一抬頭——
「哇！你們看！月亮在天上！」

【en-US】
Teeny was still up in the big tree, looking here, looking there.
She looked up and—
"Whoa! Look! The moon is in the sky!"

### 5-6｜P11（母版 P11）

- 圖說什麼：所有猴子都仰著頭，月光灑在他們濕漉漉的臉上。天上月亮又圓又亮。池塘水面慢慢平靜下來，也映出一輪完整的月亮
- 文說什麼：猴子們抬頭確認月亮在天上，再看池塘月亮也回來了，恍然大悟
- 鉤子：視覺引導型：池塘水面也映出完整月亮，引向溫暖結尾
- 選圖與提純說明：雙重揭示；3-5 砍修飾語與池塘細節；2-3 砍池塘回來
- 匹配欄：✓

【zh-TW】
猴子們抬頭看——月亮好好地掛在天上呢。
「原來月亮一直都在呀！」
再看看池塘…… 水靜了，月亮也回來了。

【en-US】
All the monkeys looked up—the moon was right there, big and bright, hanging in the sky.
"It was up there the whole time!"
They looked at the pond… the water was still, and the moon was back.

### 5-6｜P12（母版 P12）

- 圖說什麼：猴子們擠在大樹的粗枝上，肩靠肩一起看月亮。皮皮搔著頭笑，小不點坐在皮皮肩上。月光灑下來，池塘裡也映著圓月
- 文說什麼：結尾四件套——全員同框賞月、皮皮感謝小不點、前瞻意願句、固定收束語
- 鉤子：—
- 選圖與提純說明：結尾四件套；5-6 全件（同框＋感謝＋前瞻意願＋收束）；3-5 砍 on the big branch、every full-moon night；2-3 保留同框＋Hee-hee＋收束式（golden 先例：幼幼版感謝可省）
- 匹配欄：✓

【zh-TW】
猴子們一起看月亮。
皮皮笑了：「多虧小不點！下次我也要先抬頭看一看。」
「嘻嘻！」
後來呀，每到月圓的晚上，猴子們都會一起坐在大樹上看月亮。那個最會看的，就是小不點。

【en-US】
The monkeys sat together on the big branch, watching the moon.
Pip laughed. "Teeny, thank you! Next time, I'll look up first."
"Hee-hee!"
And from that day on, every full-moon night, the monkeys watched the moon together. And the best moon-watcher of all? That was Teeny.

## 檔位 3-5（10 頁）

### 3-5｜P01（母版 P01）

- 圖說什麼：月圓夜晚，森林空地的池塘靜靜映著一輪又大又圓的月亮。皮皮從大樹上跑下來趴在池邊，瞪大圓眼盯著水裡亮晃晃的月亮，嘴巴張成O形
- 文說什麼：介紹月圓夜場景，皮皮發現池塘裡映著月亮，驚訝大叫
- 鉤子：視覺引導型：皮皮趴在池邊，目光直直盯著水面的亮光
- 選圖與提純說明：母版；3-5 砍 forest 場景鋪陳；2-3 電報式重述
- 匹配欄：✓

【zh-TW】
月圓的晚上，好安靜好安靜。
皮皮低頭一看——
「哇！月亮掉到水裡了！」

【en-US】
One full-moon night, Pip ran to the pond. He looked down—
"Whoa! The moon is in the water!"

### 3-5｜P02（母版 P02）

- 圖說什麼：皮皮站在池邊拍胸脯，一手指著水面，嘴巴大張正在喊。三四隻猴子從大樹跳下來圍過來看。大樹高枝上，小不點抬頭望著星星
- 文說什麼：皮皮宣布月亮掉進水裡了，號召大家一起撈月亮還給天空
- 鉤子：視覺引導型：皮皮指著池塘，猴群的目光全跟過去
- 選圖與提純說明：母版；3-5 砍 the water、rally 對話簡化、But not 句式；2-3 砍 chitter-chatter 與 Teeny 伏筆
- 匹配欄：✓

【zh-TW】
「快來撈月亮！」
猴子們嘰嘰喳喳跑過來。
小不點沒下來呢。

【en-US】
"The moon fell in!" Pip shouted. "Let's scoop it out!"
The monkeys came running, chitter-chatter, chitter-chatter.
Teeny stayed up high, looking at the stars.

### 3-5｜P03（母版 P03）

- 圖說什麼：皮皮棕色的大手剛碰到水面，月亮的倒影裂成搖晃的碎片，漣漪一圈圈往外擴。皮皮的臉倒映在碎裂的月光裡，眼珠子瞪得圓滾滾
- 文說什麼：疊句帶擬聲詞節奏，碰水的聲音和月亮碎裂，皮皮的驚叫
- 鉤子：懸念型：月亮碎成搖晃碎片，會不會拼回來？
- 選圖與提純說明：疊句第一次，三檔共核心句；3-5 砍 leaned over；2-3 砍驚叫
- 匹配欄：✓

【zh-TW】
皮皮伸手往水裡一撈——
撈呀撈，撈月亮——嘩啦！碎了！
「啊！碎掉了！」

【en-US】
Pip reached into the water—
Scoop, scoop, scoop the moon—SPLASH! It broke!
"Oh no! I broke the moon!"

### 3-5｜P04（母版 P05）

- 圖說什麼：三隻猴子排成短鏈掛在池邊樹枝上，最下面那隻小心翼翼伸手碰水面。月亮的倒影又裂開了，碎片在三張倒映的猴臉之間搖晃
- 文說什麼：疊句第二次，動作更輕但結果一樣，碰碎的擬聲詞和猴子們的反應
- 鉤子：懸念型：換了方法月亮照樣碎了，還能怎麼辦？
- 選圖與提純說明：疊句第二次；3-5 橋接 P04（月亮回來了＋新策略句）故字數偏高；2-3 跳——壓縮為兩次嘗試
- 匹配欄：✓

【zh-TW】
月亮回來了。「大家一起，輕輕撈！」
撈呀撈，撈月亮——嘩啦！碎了！

【en-US】
The moon came back… but Pip had a new idea.
Three monkeys leaned in, ever so gently—
Scoop, scoop, scoop the moon—SPLASH! It broke!
"It broke again! What do we do?"

### 3-5｜P05（母版 P07）

- 圖說什麼：從大樹頂往下看——猴子們一隻接一隻掛成長長的鏈子，從粗樹枝一路晃到池塘水面上方。鏈子中間胖猴子卡住在扭、瘦猴子搖搖晃晃。最上面坐著金黃色的小不點
- 文說什麼：全員排長鏈的壯觀場面和搖晃緊張感，小不點被安排在最上面
- 鉤子：動作中斷型：長鏈晃呀晃，最底下的手指快碰到水面了
- 選圖與提純說明：長鏈＋搖擺＋小不點位置；3-5 橋接 P06（rallying 句）故字數偏高；2-3 砍 Teeny 位置
- 匹配欄：✓

【zh-TW】
猴子們排成好長好長的鏈子。
晃呀晃，晃呀晃……
小不點在最上面。

【en-US】
"Everybody, come! We'll make the longest chain!" said Pip.
One by one, the monkeys hung from the big branch.
Swing and sway, swing and sway…
Teeny sat at the top. "You're the lightest—don't move!"

### 3-5｜P06（母版 P08）

- 圖說什麼：長鏈最下面的猴子伸手碰到水面——巨大的水花炸開！月亮碎成滿池閃爍的碎銀光。水花濺得到處都是，鏈子裡的猴子被水打得東搖西歪，有的已經鬆手
- 文說什麼：疊句第三次變奏——規模最大的碰碎，擬聲詞升級，猴子們掉水裡的動靜
- 鉤子：動作中斷型：巨大水花沖天碎銀飛舞，猴子們正往下掉
- 選圖與提純說明：疊句第三次變奏＋高潮；3-5 砍碎片修飾詞；2-3 砍動作起始與碎片句
- 匹配欄：✓

【zh-TW】
撈呀撈，撈月亮——嘩啦！碎了！
撲通！撲通！猴子們全掉進水裡了！

【en-US】
The bottom monkey reached down—
Scoop, scoop, scoop the moon—SPLASH! It broke!
It broke into a thousand pieces!
SPLOOSH! SPLOOSH! Everyone fell in!

### 3-5｜P07（母版 P09）

- 圖說什麼：猴子們濕答答地蹲在池塘邊，毛皮貼著身體滴水。皮皮坐在地上低著頭，紅頭帶歪了也沒理。池塘裡只剩搖搖晃晃的碎銀光
- 文說什麼：失敗後的安靜和沮喪，皮皮不說話的低落情緒
- 鉤子：懸念型：皮皮低著頭一句話不說，月亮怎麼辦？
- 選圖與提純說明：情緒低谷刻意短（craft C1）；2-3 跳——由 P08 失敗直接接 P10 啊哈時刻
- 匹配欄：✓

【zh-TW】
猴子們濕答答地坐在池塘邊。
皮皮低著頭，一句話都不說。

【en-US】
The monkeys sat by the pond, dripping wet.
Pip hung his head. He didn't say a word.

### 3-5｜P08（母版 P10）

- 圖說什麼：小不點坐在大樹枝上，圓圓大眼睛猛然睜到最大，整個身體轉向天空。一隻小手指著頭頂——天上掛著一輪又大又亮的圓月，月光灑在小不點金黃色的毛上
- 文說什麼：小不點抬頭發現月亮在天上，興奮的叫喊——啊哈時刻的聲音爆發
- 鉤子：視覺引導型：小不點的手指指著天空，眼神引導往上看
- 選圖與提純說明：啊哈時刻；3-5 砍 big、Whoa；2-3 電報式保留核心發現
- 匹配欄：✓

【zh-TW】
小不點坐在大樹上，東看看，西看看。
一抬頭——
「哇！月亮在天上！」

【en-US】
Teeny was still up in the tree, looking here, looking there.
She looked up—
"Look! The moon is in the sky!"

### 3-5｜P09（母版 P11）

- 圖說什麼：所有猴子都仰著頭，月光灑在他們濕漉漉的臉上。天上月亮又圓又亮。池塘水面慢慢平靜下來，也映出一輪完整的月亮
- 文說什麼：猴子們抬頭確認月亮在天上，再看池塘月亮也回來了，恍然大悟
- 鉤子：視覺引導型：池塘水面也映出完整月亮，引向溫暖結尾
- 選圖與提純說明：雙重揭示；3-5 砍修飾語與池塘細節；2-3 砍池塘回來
- 匹配欄：✓

【zh-TW】
猴子們抬頭看——月亮好好地掛在天上呢。
「原來月亮一直都在呀！」

【en-US】
The monkeys looked up—the moon was in the sky!
"Up there the whole time!"
They looked at the pond… the moon was back.

### 3-5｜P10（母版 P12）

- 圖說什麼：猴子們擠在大樹的粗枝上，肩靠肩一起看月亮。皮皮搔著頭笑，小不點坐在皮皮肩上。月光灑下來，池塘裡也映著圓月
- 文說什麼：結尾四件套——全員同框賞月、皮皮感謝小不點、前瞻意願句、固定收束語
- 鉤子：—
- 選圖與提純說明：結尾四件套；5-6 全件（同框＋感謝＋前瞻意願＋收束）；3-5 砍 on the big branch、every full-moon night；2-3 保留同框＋Hee-hee＋收束式（golden 先例：幼幼版感謝可省）
- 匹配欄：✓

【zh-TW】
猴子們一起看月亮。
「多虧小不點！」「嘻嘻！」
「下次我也要先抬頭看一看。」
後來呀，猴子們都會坐在大樹上看月亮。最會看的，就是小不點。

【en-US】
The monkeys sat together, watching the moon.
Pip laughed. "Teeny, thank you! Next time, I'll look up first."
"Hee-hee!"
And from that day on, the monkeys watched the moon together. The best moon-watcher of all? That was Teeny.

## 檔位 2-3（8 頁）

### 2-3｜P01（母版 P01）

- 圖說什麼：月圓夜晚，森林空地的池塘靜靜映著一輪又大又圓的月亮。皮皮從大樹上跑下來趴在池邊，瞪大圓眼盯著水裡亮晃晃的月亮，嘴巴張成O形
- 文說什麼：介紹月圓夜場景，皮皮發現池塘裡映著月亮，驚訝大叫
- 鉤子：視覺引導型：皮皮趴在池邊，目光直直盯著水面的亮光
- 選圖與提純說明：母版；3-5 砍 forest 場景鋪陳；2-3 電報式重述
- 匹配欄：✓

【zh-TW】
月亮好圓好圓。
「月亮掉到水裡了！」皮皮喊。

【en-US】
Full-moon night!
Pip looked in the pond—
"Whoa! The moon!"

### 2-3｜P02（母版 P02）

- 圖說什麼：皮皮站在池邊拍胸脯，一手指著水面，嘴巴大張正在喊。三四隻猴子從大樹跳下來圍過來看。大樹高枝上，小不點抬頭望著星星
- 文說什麼：皮皮宣布月亮掉進水裡了，號召大家一起撈月亮還給天空
- 鉤子：視覺引導型：皮皮指著池塘，猴群的目光全跟過去
- 選圖與提純說明：母版；3-5 砍 the water、rally 對話簡化、But not 句式；2-3 砍 chitter-chatter 與 Teeny 伏筆
- 匹配欄：✓

【zh-TW】
「快來撈月亮！」
猴子們跑過來。嘰嘰喳喳！

【en-US】
"Moon fell in! Let's scoop it out!"
The monkeys came running.

### 2-3｜P03（母版 P03）

- 圖說什麼：皮皮棕色的大手剛碰到水面，月亮的倒影裂成搖晃的碎片，漣漪一圈圈往外擴。皮皮的臉倒映在碎裂的月光裡，眼珠子瞪得圓滾滾
- 文說什麼：疊句帶擬聲詞節奏，碰水的聲音和月亮碎裂，皮皮的驚叫
- 鉤子：懸念型：月亮碎成搖晃碎片，會不會拼回來？
- 選圖與提純說明：疊句第一次，三檔共核心句；3-5 砍 leaned over；2-3 砍驚叫
- 匹配欄：✓

【zh-TW】
皮皮伸手一撈——
撈呀撈，撈月亮——嘩啦！碎了！

【en-US】
Pip reached in—
Scoop, scoop, scoop the moon—SPLASH! It broke!

### 2-3｜P04（母版 P07）

- 圖說什麼：從大樹頂往下看——猴子們一隻接一隻掛成長長的鏈子，從粗樹枝一路晃到池塘水面上方。鏈子中間胖猴子卡住在扭、瘦猴子搖搖晃晃。最上面坐著金黃色的小不點
- 文說什麼：全員排長鏈的壯觀場面和搖晃緊張感，小不點被安排在最上面
- 鉤子：動作中斷型：長鏈晃呀晃，最底下的手指快碰到水面了
- 選圖與提純說明：長鏈＋搖擺＋小不點位置；3-5 橋接 P06（rallying 句）故字數偏高；2-3 砍 Teeny 位置
- 匹配欄：✓

【zh-TW】
猴子們排成好長好長的鏈子。
晃呀晃，晃呀晃……

【en-US】
All the monkeys made a long, long chain!
Swing and sway, swing and sway…

### 2-3｜P05（母版 P08）

- 圖說什麼：長鏈最下面的猴子伸手碰到水面——巨大的水花炸開！月亮碎成滿池閃爍的碎銀光。水花濺得到處都是，鏈子裡的猴子被水打得東搖西歪，有的已經鬆手
- 文說什麼：疊句第三次變奏——規模最大的碰碎，擬聲詞升級，猴子們掉水裡的動靜
- 鉤子：動作中斷型：巨大水花沖天碎銀飛舞，猴子們正往下掉
- 選圖與提純說明：疊句第三次變奏＋高潮；3-5 砍碎片修飾詞；2-3 砍動作起始與碎片句
- 匹配欄：✓

【zh-TW】
撈呀撈，撈月亮——嘩啦！碎了！
撲通！撲通！掉進水裡了！

【en-US】
Scoop, scoop, scoop the moon—SPLASH! It broke!
SPLOOSH! Everyone fell in!

### 2-3｜P06（母版 P10）

- 圖說什麼：小不點坐在大樹枝上，圓圓大眼睛猛然睜到最大，整個身體轉向天空。一隻小手指著頭頂——天上掛著一輪又大又亮的圓月，月光灑在小不點金黃色的毛上
- 文說什麼：小不點抬頭發現月亮在天上，興奮的叫喊——啊哈時刻的聲音爆發
- 鉤子：視覺引導型：小不點的手指指著天空，眼神引導往上看
- 選圖與提純說明：啊哈時刻；3-5 砍 big、Whoa；2-3 電報式保留核心發現
- 匹配欄：✓

【zh-TW】
小不點抬頭一看——
「月亮在天上！」

【en-US】
Teeny looked up.
"Look! The moon! Up in the sky!"

### 2-3｜P07（母版 P11）

- 圖說什麼：所有猴子都仰著頭，月光灑在他們濕漉漉的臉上。天上月亮又圓又亮。池塘水面慢慢平靜下來，也映出一輪完整的月亮
- 文說什麼：猴子們抬頭確認月亮在天上，再看池塘月亮也回來了，恍然大悟
- 鉤子：視覺引導型：池塘水面也映出完整月亮，引向溫暖結尾
- 選圖與提純說明：雙重揭示；3-5 砍修飾語與池塘細節；2-3 砍池塘回來
- 匹配欄：✓

【zh-TW】
猴子們抬頭看——
月亮在天上呢！
「原來月亮在天上呀！」

【en-US】
Everybody looked up.
"The moon! It was there the whole time!"

### 2-3｜P08（母版 P12）

- 圖說什麼：猴子們擠在大樹的粗枝上，肩靠肩一起看月亮。皮皮搔著頭笑，小不點坐在皮皮肩上。月光灑下來，池塘裡也映著圓月
- 文說什麼：結尾四件套——全員同框賞月、皮皮感謝小不點、前瞻意願句、固定收束語
- 鉤子：—
- 選圖與提純說明：結尾四件套；5-6 全件（同框＋感謝＋前瞻意願＋收束）；3-5 砍 on the big branch、every full-moon night；2-3 保留同框＋Hee-hee＋收束式（golden 先例：幼幼版感謝可省）
- 匹配欄：✓

【zh-TW】
嘻嘻！
後來呀，猴子們都坐在大樹上看月亮。

【en-US】
The monkeys sat together. "Hee-hee!"
And from that day on, they watched the moon.

