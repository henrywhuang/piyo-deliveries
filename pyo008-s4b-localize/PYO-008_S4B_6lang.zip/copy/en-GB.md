# 圖文總表：The Little Swan Grows in Time（the-little-swan-grows-in-time / en-GB）

> Mode B / derivative variant. Base = en-US frozen text (Gate 4 Green Light 2026-07-20).
> BrE divergence calibration applied: `leaped` → `leapt` (5-6 P09, 3-5 P08); all other text identical to en-US.
> Character name `An-An`, refrain, SFX, and ending unchanged from en-US.
> Derivative base declaration: en-US frozen three-tier text is the sole derivation source; no blind draft (B0/B1/B2 not applicable).

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: the-little-swan-grows-in-time
locale: en-GB
mode: B
storyboard: content/PYO-008_the-little-swan-grows-in-time/PYO-008_storyboard.md
design: content/PYO-008_the-little-swan-grows-in-time/PYO-008_design.md
image_pool: 14
selection:
  "3-5": [P01, P03, P04, P05, P06, P07, P08, P09, P10, P11, P12, P14]
  "2-3": [P01, P03, P04, P06, P07, P09, P10, P11, P12, P14]
commitments:
  refrain: "Faster, faster—I'll fly right now!"
  ending: "And from then on…"
  onomatopoeia: [flap, flap, flap!, PLOP!, swish, swish, swish!]
characters: [An-An]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | An-An was swimming with her two friends when a flock swept overhead.<br>"Look at them!"<br>"I want to fly with them right now!" | 23✓ | 1 | An-An was swimming with two friends when a flock swept overhead.<br>"Look at those birds!"<br>"I want to fly with them!" | 21✓ | 1 | An-An swam with her friends.<br>Birds flew above in a V! | 11✓ | ✓ | 【BrE】No divergence; text is BrE-neutral. |
| P02 | 2 | An-An spotted a space between two birds. "There's room for me!"<br>She left her friends and climbed onto the low rock. "I can't wait another second!" | 26✓ | — | — | — | — | — | — | ✓ | 【BrE】No divergence; text is BrE-neutral. |
| P03 | 3 | "Faster, faster—I'll fly right now!"<br>flap, flap, flap!<br>An-An sprang up and hovered for one tiny, breathless moment. "Am I flying?" | 21✓ | 2 | "Faster, faster—I'll fly right now!"<br>flap, flap, flap!<br>An-An sprang up from the low rock. "Up I go!" | 18✓ | 2 | "Faster, faster—I'll fly right now!"<br>flap, flap, flap! | 8✓ | ✓ | 【BrE】No divergence; text is BrE-neutral. |
| P04 | 4 | PLOP!<br>Her webbed feet kept paddling as she bobbed back between her friends.<br>"My feet kept me steady!"<br>"I'm back!" | 20✓ | 3 | PLOP!<br>Her webbed feet kept paddling as she bobbed back between her friends.<br>"My feet kept me steady!"<br>"I'm back!" | 20✓ | 3 | PLOP!<br>Her feet kept her steady.<br>She paddled back to her friends. | 12✓ | ✓ | 【BrE】No divergence; text is BrE-neutral. |
| P05 | 5 | Together they swam on, three wakes streaming far behind.<br>swish, swish, swish!<br>"Look how far they go!"<br>"Could the water be my runway?" | 23✓ | 4 | Together they swam on, their wakes stretching far behind.<br>swish, swish, swish!<br>"Look at those wakes!"<br>"Could the water help me fly?" | 22✓ | — | — | — | ✓ | 【BrE】No divergence; "runway" is universally understood in both varieties. |
| P06 | 6 | "Faster, faster—I'll fly right now!"<br>flap, flap, flap!<br>An-An paddled harder and harder, lifting her chest from the water.<br>"Come on—higher!" | 21✓ | 5 | "Faster, faster—I'll fly right now!"<br>An-An paddled harder and harder across the water—<br>flap, flap, flap!<br>"Come on—higher!" | 18✓ | 4 | "Faster, faster—I'll fly right now!"<br>flap, flap, flap! | 8✓ | ✓ | 【BrE】No divergence; text is BrE-neutral. |
| P07 | 7 | PLOP!<br>An-An spun in a little circle—until her open wings steadied her.<br>"Whoa!"<br>"My wings can steer!" She swam around the reeds with her friends. | 25✓ | 6 | PLOP!<br>An-An spun in a little circle—until her wings steadied her.<br>"Whoa!"<br>"My wings can steer!" She swam around the reeds with her friends. | 24✓ | 5 | PLOP!<br>An-An spun around.<br>Her wings could steer! | 8✓ | ✓ | 【BrE】No divergence; text is BrE-neutral. |
| P08 | 8 | A breeze ruffled An-An's feathers; her friends stayed close.<br>Water pressed against her feet, and wind tugged at her wings.<br>"What if I use both?"<br>"One more try!" | 28✓ | 7 | A breeze lifted An-An's feathers; her friends stayed close.<br>Water pushed against her feet. Wind tugged at her wings.<br>"Both at once?"<br>"One more try!" | 25✓ | — | — | — | ✓ | 【BrE】No divergence; text is BrE-neutral. |
| P09 | 9 | "Faster, faster—I'll fly right now!"<br>flap, flap, flap!<br>An-An paddled hard, spread her wings, and leapt—higher and higher.<br>"Up I go!" | 21✓ | 8 | "Faster, faster—I'll fly right now!"<br>flap, flap, flap!<br>An-An leapt into the wind. "Up I go!"<br>Higher than ever— | 19✓ | 6 | "Faster, faster—I'll fly right now!"<br>flap, flap, flap!<br>Up, up, up— | 11✓ | ✓ | 【BrE】`leaped` → `leapt` (BrE irregular past tense preference; both forms are valid in BrE but `leapt` is the natural choice in UK children's literature). Word count unchanged (1 word either way). |
| P10 | 10 | PLOP!<br>An-An's heart sank. "Not yet."<br>Then her feet kept paddling, her wings kept guiding her, and her friends stayed beside her. "I'm not flying—but I'm not stuck." Her wide wake streamed behind them. | 34✓ | 9 | PLOP!<br>An-An's heart sank. "Not yet."<br>Her feet kept paddling. "I'm still moving!"<br>Her friends stayed beside her, three long wakes trailing behind them. | 24✓ | 7 | PLOP!<br>An-An paused.<br>Her friends were still beside her. | 9✓ | ✓ | 【BrE】No divergence; text is BrE-neutral. |
| P11 | 11 | An-An looked at her feet. She looked at her wings. Then she looked at her friends, still swimming on both sides.<br>She smiled. "Right here beside me."<br>"Steady, steady—I'll swim for now!"<br>swish, swish, swish! | 35✓ | 10 | An-An looked both ways and saw her friends still beside her.<br>She smiled. "Still here."<br>"Steady, steady—I'll swim for now!"<br>swish, swish, swish! | 23✓ | 8 | An-An smiled.<br>"Steady, steady—I'll swim for now!" | 7✓ | ✓ | 【BrE】No divergence; text is BrE-neutral. |
| P12 | 12 | swish, swish, swish!<br>An-An stayed between her friends as they slipped into place on either side, their three wakes opening into a V.<br>"One down here!"<br>"One up there!" | 29✓ | 11 | swish, swish, swish!<br>An-An swam between her friends as they settled on both sides, their three wakes making a V.<br>"One on the lake!"<br>"One in the sky!" | 28⚠ | 9 | An-An swam between her friends.<br>A V crossed the lake.<br>Birds made one above! | 14✓ | ✓ | 【BrE】No divergence; text is BrE-neutral. 3-5 word count 28 carried over from en-US (target-band warning, no hard-limit violation). |
| P13 | 13 | An-An was still the same young swan, swimming between the same two friends.<br>The sky could hurry. The water could take its time. | 23✓ | — | — | — | — | — | — | ✓ | 【BrE】No divergence; text is BrE-neutral. |
| P14 | 14 | By evening, An-An said, "Time to go home."<br>And from then on…<br>One V flew.<br>One V swam. | 18✓ | 12 | And from then on…<br>One V flew.<br>One V swam. | 10✓ | 10 | And from then on…<br>One V flew.<br>One V swam. | 10✓ | ✓ | 【BrE】No divergence; text is BrE-neutral. |

## 2. 作家流程與自檢說明（非機檢契約）

### Derivative variant record

- **Derivation base**: en-US frozen three-tier text (Gate 4 Green Light 2026-07-20). No B0/B1/B2 applied (derivative variant procedure per SKILL.md).
- **BrE divergence calibration**: Systematic scan of all en-US pages across three tiers for AmE-specific spelling (-ize/-ise, -or/-our, -er/-re, single/double L), vocabulary (banned_terms and warn_terms per en-GB spec Machine Checks YAML), grammar (gotten, collective nouns, prepositions), and expressions (come/go + bare infinitive, US praisewords).
- **Changes made**: `leaped` → `leapt` in 5-6 P09 and 3-5 P08. This is the sole divergence. The en-US source text contains no AmE-specific spelling, no banned or warned vocabulary, and no AmE-specific grammar or expression patterns.
- **Unchanged elements**: Character name An-An, refrain ("Faster, faster--I'll fly right now!" / "Steady, steady--I'll swim for now!"), all three SFX families (flap/PLOP/swish), ending formula ("And from then on..."), story structure, page counts, plot events.
- **3-5 P12 word count warning (28 words)**: Carried over from en-US; same text, same warning disposition. No hard-limit violation.

### W0-W9 evidence (derivative variant abbreviated)

- W0 PASS: Three tiers carry the same concept as en-US (rushing to fly --> safe landings --> seeing present ability and belonging --> choosing to swim for now). No meaning drift from BrE calibration.
- W1 PASS: No selection, shot, or plot changes from en-US.
- W2 PASS: No new visual restatements introduced (sole change is verb form `leapt`).
- W3 PASS: No entity changes.
- W4 PASS: `leapt` reads naturally aloud in BrE; refrain and SFX unchanged.
- W5 PASS: Refrain, character name, and SFX all identical across three tiers and to en-US.
- W6 PASS: All design commitments carried over unchanged.
- W7 PASS: 2-3 telegraph style and ending formula unchanged.
- W8 N/A for derivative variant (no blind draft); BrE naturalness confirmed -- `leapt` is the natural BrE past tense.
- W9 PASS: All jump-gap self-sufficiency identical to en-US (no text removed or restructured).
