# vi-VN Mode B Process: PYO-008 The Little Swan Grows in Time

## B0 Frozen Strings Table

| # | Type | Frozen String (vi-VN) | Source / Rationale |
|---|---|---|---|
| F1 | Character name | `An-An` | canonical key swan_anan; no vi-VN registry entry yet -- propose 2-syllable Vietnamese-friendly form matching canonical key; hyphenated for clarity in space-delimited script |
| F2 | Refrain (urgent) | `Nhanh lên, nhanh lên, mình bay lên nào!` | B0 self-built; "nhanh lên" = natural Vietnamese child urgency (hurry up); "bay lên nào" = imperative to fly with nào softener; 8 tiếng, rhythmic AB-AB-ABCD |
| F3 | Refrain (variation P11) | `Chậm thôi, chậm thôi, mình bơi trước đã!` | B0 self-built; "chậm thôi" mirrors "nhanh lên" rhythm; "bơi trước đã" = swim first (đã = acceptance particle); 8 tiếng, same prosodic frame |
| F4 | Ending / closure | `Từ đó về sau… cứ mỗi lần trời vẽ một chữ V, mặt hồ cũng vẽ theo một chữ V.` | B0 self-built; "Từ đó về sau" = Vietnamese "from that day on" (brand closure equivalent); "vẽ" = draw/trace (water traces V); 22 tiếng |
| F5 | SFX: wing flap | `phập phập!` | B0 proposal; phập = northern Vietnamese bird-wing flap onomatopoeia (từ láy hoàn toàn); soft labial plosive matches small cygnet |
| F6 | SFX: water landing | `TÕM!` | B0 proposal; tõm = classic Vietnamese splash/plop (ngã tone adds drama); all-caps for independent high-intensity effect line |
| F7 | SFX: water wake | `loạt soạt——` | B0 proposal; loạt soạt = Vietnamese từ láy for continuous gentle water swishing; em dash for sustained sound |
| F8 | First appearance | `Thiên nga nhỏ An-An` | Full character introduction form; subsequent uses = An-An |
| F9 | V-formation term | `chữ V` | Vietnamese standard for V-shape formation (used for both sky and water) |

## B0 Character Speech Quirk Card

- **An-An**: Eager, impulsive child voice. Uses "mình" (informal first person, northern child register). Exclamations with "nào!" (let's-go urging). In P11 variation, shifts to calm self-talk with "đã" (acceptance/patience particle). No adult vocabulary. No southern particles (hổng, nè, hen).

## B1 Budget Table (Pre-draft)

| Tier | max_total_len | Refrain x N (tiếng) | Repeat discount (0.25) savings | SFX fixed repeat | Available net | Target midpoint |
|---|---|---|---|---|---|---|
| 5-6 (14 pages) | 658 | F2 x3 + F3 x1 = 32 full; repeats = 24 @ 0.25 = 6 | ~26 saved | phập phập x3, TÕMM x3, loạt soạt x3 = ~18 | ~640 effective | ~450 |
| 3-5 (12 pages) | 506 | F2 x3 + F3 x1 = 32 full; repeats = 24 @ 0.25 = 6 | ~26 saved | ~12 | ~492 effective | ~350 |
| 2-3 (10 pages) | 114 | F2 x3 + F3 x1 = 32 full; repeats = 24 @ 0.25 = 6 | ~26 saved | ~6 | ~108 effective | ~80 |

Budget assessment: All tiers have comfortable margin. 2-3 is tight but manageable with telegraph style. Closure F4 at 22 tiếng is the single largest fixed commitment in 2-3 (escalation note: may exceed max_page_len 18 for that page -- structural conflict same as zh-TW).

## B1 Read-Order Declaration

B1 blind draft composed without opening any zh-TW or en-US text files. Only design.md + storyboard "what text says" columns + B0 card + vi-VN locale spec were consulted.

## B2 Calibration Notes

After B1, opened zh-TW frozen texts for calibration. Key adjustments:
- P04: Added explicit "wide feet caught her" beat to match zh-TW's body-awareness thread
- P05: Strengthened water-wake hook to match storyboard visual-guide function
- P08: Added "friends still beside" beat (pre-belonging evidence per design)
- P10: Ensured "friends right beside" presence after third fall
- P11: Confirmed observation triad (feet, wings, friends) before variation
- P14: Closure sentence structure calibrated to match brand formula
- All bridging decisions for skipped pages independently verified against storyboard
