# 圖文總表：Thiên Nga Nhỏ Lớn Theo Nhịp Riêng（the-little-swan-grows-in-time / vi-VN）

> Mode B = vi-VN locale adaptation (S4B). Adaptation, not translation — story retold natively in Vietnamese after reading design + storyboard only; zh-TW frozen text used as calibration reference only (B2).
> Page selection fully inherits storyboard tier selection tables; one page one image; image sequence strictly ascending.
> Text payload = sound, dialogue, inner thought, time; no restating visually obvious facts.

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: the-little-swan-grows-in-time
locale: vi-VN
mode: B
storyboard: content/PYO-008_the-little-swan-grows-in-time/PYO-008_storyboard.md
design: content/PYO-008_the-little-swan-grows-in-time/PYO-008_design.md
image_pool: 14
selection:
  "3-5": [P01, P03, P04, P05, P06, P07, P08, P09, P10, P11, P12, P14]
  "2-3": [P01, P03, P04, P06, P07, P09, P10, P11, P12, P14]
commitments:
  refrain: "Nhanh lên, nhanh lên, mình bay lên nào!"
  ending: "Từ đó về sau… cứ mỗi lần trời vẽ một chữ V, mặt hồ cũng vẽ theo một chữ V."
  onomatopoeia: [phập phập, TÕM, loạt soạt]
characters: [An-An]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Thiên nga nhỏ An-An bơi cùng bạn trên mặt hồ.<br>Bỗng trên trời, một đàn chim xếp thành chữ V bay qua!<br>An-An ngẩng đầu, lòng thầm ước. | 28✓ | 1 | Thiên nga nhỏ An-An bơi cùng bạn.<br>Trên trời, đàn chim xếp chữ V bay qua!<br>An-An muốn bay theo quá. | 21✓ | 1 | An-An bơi cùng bạn.<br>Chữ V bay qua trời! | 9✓ | ✓ | 3-5 compact narration; 2-3 telegraph: action + sky event only (below band lower: telegraph page, 2 beats sufficient for toddler) |
| P02 | 2 | An-An thấy đàn chim như có chỗ trống.<br>An-An rời bạn, leo lên hòn đá bên bờ——<br>"Mình sắp bay lên rồi!" | 22✓ | — | — | — | — | — | — | ✓ | 3-5/2-3 skip P02: P01->P03 direct to attempt; refrain provides motivation (self-sufficient) |
| P03 | 3 | "Nhanh lên, nhanh lên, mình bay lên nào!"<br>An-An đạp thật mạnh—— phập phập!<br>An-An lơ lửng trên không một chút xíu. | 22✓ | 2 | "Nhanh lên, nhanh lên, mình bay lên nào!"<br>An-An nhảy thật mạnh—— phập phập! | 14✓ | 2 | "Nhanh lên, nhanh lên, mình bay lên nào!"<br>phập phập! | 10✓ | ✓ | 3-5 cut result sentence (page turn delivers it); 2-3 telegraph: refrain + SFX only |
| P04 | 4 | TÕM!<br>Bàn chân rộng đỡ An-An thật vững.<br>Bàn chân biết đạp nước rồi kìa!<br>An-An bơi về bên bạn, cùng nhau đi tiếp. | 24✓ | 3 | TÕM!<br>Bàn chân rộng đỡ An-An thật vững.<br>An-An bơi về bên bạn. | 13✓ | 3 | TÕM!<br>Bàn chân đỡ rồi. An-An bơi về bên bạn. | 10✓ | ✓ | 5-6 full body-awareness beat; 3-5 keep feet + return (below band lower: landing pages are naturally short -- SFX + result); 2-3 telegraph: result + return |
| P05 | 5 | Bàn chân rộng của An-An đã theo kịp bạn rồi!<br>loạt soạt—— vệt nước kéo dài mãi.<br>Nếu cứ bơi mãi, biết đâu sẽ bay được… | 26✓ | 4 | An-An bơi cùng bạn vào khúc sông dài.<br>loạt soạt—— vệt nước dài lắm… | 14✓ | — | — | — | ✓ | 3-5 cut reasoning, keep hook atmosphere (below band lower: hook page focused on sound + visual); 2-3 skip P05: P04->P06 try-fail pattern self-evident for toddlers |
| P06 | 6 | "Nhanh lên, nhanh lên, mình bay lên nào!"<br>An-An đạp nước thật nhanh, muốn bay lên từ mặt nước——<br>phập phập! | 21✓ | 5 | "Nhanh lên, nhanh lên, mình bay lên nào!"<br>An-An đạp nhanh hơn—— phập phập! | 14✓ | 4 | "Nhanh lên, nhanh lên, mình bay lên nào!"<br>phập phập! | 10✓ | ✓ | 3-5 cut intent clause (below band lower: refrain + action pages are structurally compact); 2-3 telegraph same as P03 (visual difference carried by illustration) |
| P07 | 7 | TÕM!<br>An-An xoay tròn một vòng trên mặt nước.<br>Ơ? Cánh ngắn giờ biết rẽ hướng rồi kìa!<br>An-An rẽ lại thật vững, bơi về bên bạn. | 27✓ | 6 | TÕM!<br>An-An xoay một vòng.<br>Ơ? Cánh biết rẽ rồi! An-An bơi về bên bạn. | 15✓ | 5 | TÕM!<br>An-An xoay một vòng. Cánh biết rẽ rồi! | 9✓ | ✓ | 3-5 compact but keep recognition + return; 2-3 telegraph: funny result + short recognition, cut return (below band lower: telegraph landing page) |
| P08 | 8 | Bạn vẫn ở bên, cùng bơi qua chỗ gió lớn.<br>Bàn chân đạp nước, cánh ngắn rẽ hướng…<br>An-An nghĩ: thêm gió nữa, lần này nhất định được! | 28✓ | 7 | Bạn vẫn ở bên.<br>Bàn chân đạp nước, cánh rẽ hướng…<br>Thêm gió, lần này nhất định được! | 18✓ | — | — | — | ✓ | 3-5 cut scene description, keep buildup; 2-3 skip P08: P07->P09 three-attempt pattern self-evident, no strategy assembly needed |
| P09 | 9 | "Nhanh lên, nhanh lên, mình bay lên nào!"<br>Bàn chân đạp! Cánh xòe! Gió tới——<br>phập phập!<br>An-An nhảy lên cao nhất, cao nhất—— | 24✓ | 8 | "Nhanh lên, nhanh lên, mình bay lên nào!"<br>phập phập!<br>An-An nhảy lên cao nhất, cao nhất—— | 17✓ | 6 | "Nhanh lên, nhanh lên, mình bay lên nào!"<br>phập phập!<br>Cao quá, cao quá—— | 14✓ | ✓ | 5-6 three elements listed for maximum scale; 3-5 cut element list, keep height + hook; 2-3 telegraph: exclamatory height for hook |
| P10 | 10 | TÕM!<br>An-An dừng lại một chút.<br>Nhưng mà… bàn chân vẫn đạp, cánh vẫn giữ thăng bằng.<br>Vệt nước sau lưng lớn lắm. Bạn vẫn ở ngay bên. | 28✓ | 9 | TÕM!<br>An-An dừng lại một chút.<br>Nhưng mà… bàn chân vẫn đạp, vệt nước lớn lắm. Bạn ở ngay bên. | 20✓ | 7 | TÕM!<br>An-An dừng lại. Bạn vẫn ở bên. | 8✓ | ✓ | 3-5 merge recognition + belonging; 2-3 telegraph: fall + friends remain (core belonging; below band lower: emotional pause page, minimal words by design) |
| P11 | 11 | An-An nhìn bàn chân, nhìn đôi cánh, rồi nhìn bạn bên cạnh.<br>An-An cười rồi.<br>"Chậm thôi, chậm thôi, mình bơi trước đã!"<br>loạt soạt—— | 25✓ | 10 | An-An cười rồi.<br>"Chậm thôi, chậm thôi, mình bơi trước đã!"<br>loạt soạt—— | 13✓ | 8 | An-An cười rồi.<br>"Chậm thôi, chậm thôi, mình bơi trước đã!" | 11✓ | ✓ | 3-5 cut observation triad, straight to smile + variation (below band lower: variation page, refrain is the beat); 2-3 telegraph: cut loạt soạt (swim conveyed by image), keep emotional turn + refrain variation |
| P12 | 12 | An-An dùng bàn chân vẽ ra vệt nước, cánh chỉnh hướng.<br>loạt soạt—— bạn bè dọc theo vệt nước dàn ra!<br>Trời một chữ V, hồ cũng một chữ V. | 30✓ | 11 | loạt soạt—— bạn bè dàn theo vệt nước rồi!<br>Trời một chữ V, hồ cũng một chữ V. | 18✓ | 9 | Bạn bè dàn ra rồi!<br>Trời một chữ V, hồ cũng một chữ V! | 14✓ | ✓ | 3-5 cut action description, straight to climax result; 2-3 telegraph: cut loạt soạt, compress to result + double-V declaration |
| P13 | 13 | An-An vẫn là An-An nhỏ xíu ấy thôi.<br>Bạn bè vẫn cười, vẫn sát bên An-An.<br>Trời có nhịp của trời, nước có nhịp của nước. | 26✓ | — | — | — | — | — | — | ✓ | 3-5/2-3 skip P13: P12->P14 climax to closure direct (self-sufficient: P12 delivers full emotional climax, P14 closes directly) |
| P14 | 14 | Chiều tà, An-An cùng bạn bè bơi về vịnh hồ.<br>Từ đó về sau… cứ mỗi lần trời vẽ một chữ V, mặt hồ cũng vẽ theo một chữ V. | 30✓ | 12 | Từ đó về sau… cứ mỗi lần trời vẽ một chữ V, mặt hồ cũng vẽ theo một chữ V. | 20✓ | 10 | Từ đó về sau… trời vẽ chữ V. Hồ cũng vẽ chữ V. | 13✓ | ✓ | 3-5 cut dusk scene sentence, keep closure only (time conveyed by image palette); 2-3 closure split into two short sentences to fit 2-3 band (max_sentence_len 10, max_page_len 18) while preserving double-V echo |
