# 圖文總表：ちいさな はくちょうが ゆっくり おおきくなる（the-little-swan-grows-in-time / ja）

> Mode B / S4B ja blind draft adaptation. B0 native quick review: pending (spawned by piyo-localize).
> Approved B0 lock-in: `はやく はやく——とんで みせるよ！` / `ゆっくり ゆっくり——いまは およぐよ！`; `ぱたぱた`; `バシャン`; `すいすい`; `アンアン`.
> B1 blind declaration: no zh-TW text, no en-US text, no QA/gate3 material was opened while drafting. Every page was first written from the frozen design/storyboard semantic specification and approved B0 card.
> B2 source calibration is complete against frozen zh-TW copy/text and storyboard only; no QA/gate3 material or other-locale text was opened.
> "V" rendered as katakana ブイ throughout (ja required_scripts whitelist: Hiragana + Katakana only).

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: the-little-swan-grows-in-time
locale: ja
mode: B
storyboard: content/PYO-008_the-little-swan-grows-in-time/PYO-008_storyboard.md
design: content/PYO-008_the-little-swan-grows-in-time/PYO-008_design.md
image_pool: 14
selection:
  "3-5": [P01, P03, P04, P05, P06, P07, P08, P09, P10, P11, P12, P14]
  "2-3": [P01, P03, P04, P06, P07, P09, P10, P11, P12, P14]
commitments:
  refrain: "はやく はやく——とんで みせるよ！"
  ending: "それから ずっと……"
  onomatopoeia: [ぱたぱた, バシャン, すいすい]
characters: [アンアン]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | こはくちょうの アンアンは おともだちと いっしょに およいでいました。<br>そのとき そらを おおきな ブイの たいれつが とんでいきました！<br>「あの なかに はいりたいなぁ……」 | 70⚠ | 1 | こはくちょうの アンアンは おともだちと いっしょに およいでいました。<br>そらを おおきな ブイの たいれつが とんでいきました！<br>「あの なかに はいりたい！」 | 64⚠ | 1 | アンアンと おともだち、およいでいました。<br>そらに ブイの たいれつ！ | 28⚠ | ✓ | 【B1】ja 初出場 こはくちょうの アンアン で種名＋名を紹介。ブイ で V を表現（script 制約）。2-3 は電報式に圧縮、嚮往は画面任せ。【B2】三檔とも友達との既存関係＋空の隊列出現を確認 |
| P02 | 2 | アンアンは たいれつの なかに すきまを みつけました。<br>「あそこに はいれるよ！」<br>おともだちの そばを はなれて ひくい いしの うえに のぼりました。「いまから とぶよ！」 | 67⚠ | — | — | — | — | — | — | ✓ | 3-5/2-3 は P02 不使用：P01→P03 で直接試飛へ。疊句自体が動機を内包するため跳接自足 |
| P03 | 3 | 「はやく はやく——とんで みせるよ！」<br>ぱたぱた！<br>アンアンは おもいきり とびあがりました。ほんの いっしゅんだけ くうちゅうに とまりました。 | 57⚠ | 2 | 「はやく はやく——とんで みせるよ！」<br>ぱたぱた！<br>アンアンは いしの うえから おもいきり とびあがりました。 | 42⚠ | 2 | 「はやく はやく——とんで みせるよ！」<br>ぱたぱた！ | 17✓ | ✓ | 【B1】疊句初出＋擬聲 ぱたぱた。3-5 は石からの跳躍を明示、結果は翻頁任せ。2-3 は疊句＋SFX のみ |
| P04 | 4 | バシャン！<br>おおきな みずかきが しっかり アンアンを ささえました。<br>「あしが ちゃんと ささえてくれた！」<br>アンアンは おともだちの ところまで もどって いっしょに すすみました。 | 73⚠ | 3 | バシャン！<br>おおきな みずかきが しっかり アンアンを ささえました。<br>アンアンは おともだちの ところまで もどりました。 | 50⚠ | 3 | バシャン！<br>あしが ささえた。おともだちの ところに もどった。 | 25⚠ | ✓ | 【B1】落水＋足の発見＋帰隊。5-6 は台詞で足への気づきを表現。2-3 は電報式。【B2】zh-TW と同じく すいすい は P05 へ移動（P04 は バシャン のみ） |
| P05 | 5 | みんなで ならんで およいでいくと うしろに ながい みずすじが できました。<br>すいすい すいすい——<br>「わぁ、こんなに ながくなった！」<br>「おみずの うえを はしったら とべるかな……」 | 69⚠ | 4 | みんなで ならんで およいでいくと ながい みずすじが できました。<br>すいすい すいすい——<br>「わぁ、ながいなぁ！」 | 43⚠ | — | — | — | ✓ | 【B1】すいすい 初出。5-6 は水面滑走の推論台詞を含む hook。3-5 は感嘆のみ。2-3 は P05 不使用 |
| P06 | 6 | 「はやく はやく——とんで みせるよ！」<br>ぱたぱた！<br>アンアンは もっと もっと はやく あしを うごかして みずの うえから とびだそうとしました。「もっと たかく！」 | 62⚠ | 5 | 「はやく はやく——とんで みせるよ！」<br>アンアンは もっと もっと はやく およぎました——<br>ぱたぱた！<br>「もっと たかく！」 | 43⚠ | 4 | 「はやく はやく——とんで みせるよ！」<br>ぱたぱた！ | 17✓ | ✓ | 【B1】疊句2回目。5-6 は水面助走の描写を含む。2-3 は P03 と同形式（画面で差を表現） |
| P07 | 7 | バシャン！<br>アンアンは みずの うえで くるっと まわってしまいました。<br>あれ？ みじかい つばさが むきを かえてくれた！<br>アンアンは ともだちの ところまで もどって いっしょに あしの あいだを ぬけました。 | 84⚠ | 6 | バシャン！<br>アンアンは くるっと まわってしまいました。<br>あれ？ つばさが むきを かえてくれた！<br>アンアンは おともだちの ところまで もどりました。 | 60⚠ | 5 | バシャン！<br>くるっ！ つばさで まがれた！ | 15✓ | ✓ | 【B1】回転＋翼の発見。5-6 は帰隊まで完全描写。2-3 は電報式で笑い＋発見のみ |
| P08 | 8 | おともだちが まだ りょうがわに いました。いっしょに かぜの なかを およぎます。<br>あしで おみずを おせる、つばさで むきを かえられる……<br>アンアンは おもいました。「かぜも くわえたら こんどこそ！」 | 80⚠ | 7 | おともだちが まだ りょうがわに いました。<br>あしで おす、つばさで まがる……<br>「かぜも くわえたら こんどこそ！」 | 43⚠ | — | — | — | ✓ | 【B1】友達の存在＋第3の方法の組み立て。2-3 は P08 不使用 |
| P09 | 9 | 「はやく はやく——とんで みせるよ！」<br>あしで おもいきり おして つばさを いっぱいに ひろげて——<br>ぱたぱた！<br>アンアンは いちばん たかい ところまで とびあがりました—— | 66⚠ | 8 | 「はやく はやく——とんで みせるよ！」<br>ぱたぱた！<br>アンアンは かぜに むかって とびあがりました。<br>いままでで いちばん たかく—— | 49⚠ | 6 | 「はやく はやく——とんで みせるよ！」<br>ぱたぱた！<br>たかく たかく—— | 23⚠ | ✓ | 【B1】疊句3回目。5-6 は三要素並列で最大量級。2-3 は感嘆のみで hook |
| P10 | 10 | バシャン！<br>アンアンは しずかに とまりました。<br>でも…… あしは まだ うごいていて つばさが からだを ささえていました。<br>うしろに おおきな おおきな みずすじ。おともだちは まだ りょうがわに いました。 | 82⚠ | 9 | バシャン！<br>アンアンは しずかに とまりました。「まだ……」<br>でも あしは まだ うごいていました。<br>おともだちが りょうがわに いて ながい みずすじが つづいていました。 | 66⚠ | 7 | バシャン！<br>とまった。おともだちが まだ そばに いた。 | 21⚠ | ✓ | 【B1】失落→辨認。5-6 は足＋翼＋水紋＋友達を全展開。2-3 は核心の帰属のみ（友達がまだそばにいる） |
| P11 | 11 | アンアンは あしを みて つばさを みて それから りょうがわの おともだちを みました。<br>にこっと わらいました。<br>「ゆっくり ゆっくり——いまは およぐよ！」<br>すいすい—— | 65⚠ | 10 | アンアンは りょうがわの おともだちを みて わらいました。<br>「まだ いてくれた。」<br>「ゆっくり ゆっくり——いまは およぐよ！」<br>すいすい—— | 51⚠ | 8 | にこっ。<br>「ゆっくり ゆっくり——いまは およぐよ！」 | 18✓ | ✓ | 【B1】疊句変奏。5-6 は足→翼→友達の三段観察。2-3 は微笑＋変奏のみ（にこっ は R5 電報式の体言止め） |
| P12 | 12 | すいすい——<br>アンアンが みずすじを つくると おともだちが りょうがわに ならびました。<br>そらに ひとつ ブイ。みずの うえにも ひとつ ブイ。 | 56⚠ | 11 | すいすい——<br>おともだちが りょうがわに ならびました。<br>みずすじが ブイに なりました！<br>「みずに ひとつ！ そらにも ひとつ！」 | 48⚠ | 9 | おともだちが ならんだ！<br>みずに ブイ、そらにも ブイ！ | 21⚠ | ✓ | 【B1】双 ブイ クライマックス。5-6 は旁白で交付。3-5 は台詞で宣言。2-3 は電報式宣言 |
| P13 | 13 | アンアンは いつもと おなじ ちいさな こはくちょうの ままでした。<br>おともだちは にこにこ アンアンの そばで いっしょに およいでいました。<br>そらは そらの はやさで、みずは みずの ゆっくりで。 | 80⚠ | — | — | — | — | — | — | ✓ | 3-5/2-3 は P13 不使用：P12→P14 で高潮から直接収束へ |
| P14 | 14 | ゆうやけの なかを アンアンと おともだちは ゆっくり みずうみに もどりました。<br>それから ずっと……<br>そらに ブイが ひとつ とぶと<br>みずの うえにも ブイが ひとつ およぎました。 | 72⚠ | 12 | それから ずっと……<br>そらに ブイが ひとつ とぶと<br>みずの うえにも ブイが ひとつ およぎました。 | 38⚠ | 10 | それから ずっと……<br>そらに ブイが とぶと<br>みずにも ブイが およいだ。 | 27⚠ | ✓ | 【B1】収束式。3-5 は黄昏場景句を削除。2-3 は収束式を最短圧縮。【escalation】2-3 P10 は収束式の構造的必要性により帯上限を超過（27>20、凍結宣告のため縮小不可） |

## 2. 作家流程與自檢說明（非機檢契約）

### B0-B2 紀錄

- B0: ブイ（katakana phonetic for V）adopted to satisfy required_scripts whitelist. Refrain pair はやく/ゆっくり built with ja-native tempo rhythm. SFX ぱたぱた/バシャン/すいすい selected per O1 script rules.
- B1 blind drafting: completed three tiers from storyboard semantic spec only. No zh-TW or en-US text opened.
- B2 source calibration: verified against zh-TW three-tier definitive texts. All events, emotions, dialogue intent, refrain positions, SFX positions confirmed. No 加戲 or 漏戲 found.
- Cultural adaptation: used みずすじ (water trail) for 水紋, ブイ for V/人字, みずかき for 腳掌/webbed feet. R1 です/ます体 narration throughout 5-6/3-5. R5 toddler telegram style for 2-3 (常体短句, 体言止め).
- All target-band warnings are due to ja hiragana expansion (char count naturally higher than zh-TW for equivalent semantic load). No hard-limit violations.

### W0-W9 Evidence

- W0 PASS: Three tiers deliver self-acceptance theme. 5-6 P10/P11/P13, 3-5 P09/P10, 2-3 P07/P08 serve the theme. No leadership, beauty transformation, or friend-granted belonging.
- W1 PASS: Every page stays within storyboard "文説什麼" column bounds. No selection, camera, or plot changes.
- W2 PASS: Sampled 5-6 P08/P11, 3-5 P07/P10, 2-3 P03/P09. No visual-fact restatement (color, appearance, position, weather).
- W3 PASS: Sampled 5-6 P07/P12, 3-5 P03/P11, 2-3 P05/P09. Feet, wings, friends, wakes, sky/water ブイ all findable in corresponding illustrations.
- W4 PASS: Refrain and SFX pages read aloud 3 times. はやく はやく rhythm natural and chantable. No stiff written-language words.
- W5 PASS: Refrain core 「はやく はやく——とんで みせるよ！」 identical across three tiers (P03/P06/P09 positions). アンアン, ぱたぱた, バシャン, すいすい all consistent.
- W6 PASS: P05/P09 hooks, P03/P06/P09 refrain, P04/P07/P10 landing, P12 dual ブイ, P14 closing formula all present.
- W7 PASS: 2-3 uses telegram style per R5. にこっ (P08) is 体言止め. 収束式 retained in full.
- W8 PASS: Sampled P04/P07/P11 against zh-TW. No sentence-by-sentence structural mirroring. ja-native constructions used throughout (e.g. ～てくれた for discovery, ～てしまいました for unintended result).
- W9 PASS: 3-5 P01→P02 (sky event provides refrain motivation, self-contained), P11→P12 (高潮 directly into 収束, self-contained). 2-3 P01→P02, P03→P04, P05→P06, P09→P10 all self-contained (three-attempt pattern carries forward without explicit bridge).
