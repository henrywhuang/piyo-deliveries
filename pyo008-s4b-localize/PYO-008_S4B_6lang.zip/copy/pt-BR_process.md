# pt-BR Mode B Process — PYO-008 小天鵝慢慢長大

## B0 Frozen Strings Table

| # | Type | Frozen String | Notes |
|---|---|---|---|
| F1 | character_name | `Ani` | Diminutivo-friendly, 2-syllable, maps canonical `swan_anan` An- root; full intro: "a pequena cisne Ani" |
| F2 | refrain_core | `Mais rápido, mais rápido, eu vou voar!` | Self-urging function; rhythmic triple-stress; 3-5 year old can echo second half |
| F3 | refrain_variation | `Devagar, devagar, eu vou nadar!` | P11 pivot: from urging flight to accepting swim; same syllable cadence as F2 |
| F4 | ending_formula | `E desde aquele dia…` | Brand closing formula; pt-BR equivalent of "And from that day on…" |
| F5 | ending_final | `Um V voou.` / `Um V nadou.` | Fixed double-V closing couplet |
| F6 | sfx_wing_flap | `plap, plap, plap!` | Wing-flap motif; Brazilian native labial plosive for small-wing beating (P03, P06, P09) |
| F7 | sfx_water_landing | `TCHIBUM!` | Safe-splash motif; classic BR children's media splash (P04, P07, P10) |
| F8 | sfx_water_wake | `xá, xá, xá!` | Water-wake motif; BR native swishing water sound (P04, P05, P11, P12) |

## B0 Speech Quirk Card

Ani talks to herself in self-urging mode: short exclamations, lots of "eu vou!" (I will!), breathless rhythm. When accepting, her speech slows: "devagar" replaces "mais rápido." Friends have no dialogue.

## B1 Budget Table (pre-draft)

### 5-6 (14 pages)
- max_total_len: 761 words
- Refrain "Mais rápido, mais rápido, eu vou voar!" = ~8 words x3 occurrences (first=full, 2nd/3rd @0.25 discount) = 8 + 2 + 2 = 12 effective
- Variation "Devagar, devagar, eu vou nadar!" = ~7 words x1 = 7 effective
- SFX fixed repeats: "plap, plap, plap!" x3 = 3 + 0.75 + 0.75 = 4.5; "TCHIBUM!" x3 = 1 + 0.25 + 0.25 = 1.5; "xá, xá, xá!" x~4 = 3 + 0.75*3 = 5.25
- Repeat discount savings: ~17 words
- Available for prose: ~744 words; target mid-band ~500 words. Ample headroom.

### 3-5 (12 pages)
- max_total_len: 585 words
- Same refrain discount structure (fewer pages = fewer prose words needed)
- Available for prose: ~568 words; target mid-band ~380 words. Comfortable.

### 2-3 (10 pages)
- max_total_len: 101 words
- Refrain x3 + variation x1 = 8+2+2+7 = 19 effective words
- SFX: minimal prose around them, SFX themselves ~6 effective words
- Available for prose: ~76 words across 10 pages. Tight but feasible with telegraphic style.
- Average ~7-8 words/page (max 16/page). Each page = 1-2 short sentences.

## B2 Source Calibration Notes

Opened zh-TW finalized text (5-6.json, 3-5.json, 2-3.json) for source calibration after completing B1 blind draft.

**Semantic payload verification (per design.md concept_contract):**
- All three theme-cycle beats present in all tiers: feet recognition (P04), wings recognition (P07), full acceptance (P10-P11)
- Refrain variation pivot (P11) intact: "Mais rápido" -> "Devagar" maps zh-TW "快一點" -> "慢一點"
- Double-V climax (P12) delivered in all tiers
- Ending formula "E desde aquele dia..." + closing couplet "Um V voou. / Um V nadou." in all tiers

**No zh-TW structural leakage detected:**
- pt-BR uses natural BR diminutivos (asinhas, folhinha, coroinha, pedrinha, juntinhos) -- not calques
- Sentence structures diverge from zh-TW (e.g., "Era uma vez" opening, em dash dialogue markers, gerund constructions)
- SFX are native BR choices (TCHIBUM, plap, xa) not transliterations

**2-3 tier required full rewrite after B3 lint fail** (P01=19>16 word limit, total 124.5>101). Rewrote to pure telegraphic: refrain+SFX only on attempt pages, minimal narration on transition pages. New total: 90 raw, 72 after discount. All pages within 16-word page limit.

**Cultural adaptation decisions:**
1. Character name "Ani" (not "An-An" like en-US/es-MX): BR diminutivo-friendly, 2-syllable, maintains An- root
2. SFX "TCHIBUM" (splash): classic BR children's media term, widely recognized
3. SFX "plap, plap, plap!" (wing-flap): native labial plosive for small-wing beating
4. SFX "xa, xa, xa!" (water-wake): BR native swishing water sound
5. Refrain uses "eu vou voar/nadar" (first person) matching self-urging register
6. Internal monologue uses travessao (em dash) for dialogue per pt-BR spec R2-5
