# PYO-008 es-MX Mode B Process Log

## B0 Language Foundation (es-MX)

### Frozen Strings Table

| # | Type | Frozen String | Notes |
|---|---|---|---|
| F1 | refrain-main | `¡Rápido, rápido, ya voy a volar!` | Self-urging to fly; MX child rhythm, 7 words |
| F2 | refrain-variation | `Despacito, despacito, primero voy a nadar.` | Acceptance shift to swimming; despacito = MX warmth diminutive; 6 words |
| F3 | ending-bridge | `Después de aquello…` | Fixed closure equivalent of "後來呀……" |
| F4 | ending-dual-V | `Un V voló. Un V nadó.` | Dual V closure; parallel minimal sentences |
| F5 | sfx-wing-flap | `¡Plaf, plaf, plap!` | Wing-beat onomatopoeia x3 (P03, P06, P09); comma-separated per R4.2 |
| F6 | sfx-water-landing | `¡CHAF!` | Body landing in water x3 (P04, P07, P10); all-caps for dramatic force per R4.3 |
| F7 | sfx-water-wake | `chas, chas, chas` | Feet pushing water / wake x few; lowercase in-sentence form |
| F8 | character-name | `An-An` | Retain reduplication; first appearance "el cisne An-An" |

### Character Speech Quirks (es-MX)
- An-An speaks in short, eager phrases with exclamation
- Uses tú form exclusively (R2.1)
- Narrator voice: warm, simple narrative past tense (llegó, nadó), occasional diminutives (despacito, chiquita, cerquita)
- No俚語, no vosotros, no Peninsular markers

### B0 Machine Check Probe
- All frozen strings to be tested via locale_lint before proceeding to B1

### Budget Table (B1 pre-draft)

| Tier | Pages | max_total_len | Refrain repeats (F1) | Refrain discount (0.25) | SFX fixed repeats | Net budget estimate |
|---|---|---|---|---|---|---|
| 5-6 | 14 | 761 | 3× F1 (7w ea) + 1× F2 (6w) = 27w; discount = 3×7×0.25 + 0 = 5.25 → saves ~16w | 3× wing + 3× splash + few wake ≈ 30w | ~715w usable |
| 3-5 | 12 | 585 | same refrain pattern | same SFX pattern | ~540w usable |
| 2-3 | 10 | 101 | 3× F1 + 1× F2; discount saves ~16w | fewer SFX | ~85w usable (tight) |

### Read Sequence Declaration
B1 blind draft: NO zh-TW or en-US text files opened. Only design.md, storyboard.md "文說什麼" column, es-MX locale spec, B0 card, and registries consulted.
