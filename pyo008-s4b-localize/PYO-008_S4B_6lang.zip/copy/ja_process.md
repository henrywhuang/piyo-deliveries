# PYO-008 ja Mode B Process Notes

## B0 Frozen Strings Card

### Refrain (ja native build)

| # | Frozen string | Function |
|---|---|---|
| R1 | `はやく はやく——とんで みせるよ！` | Self-urging to fly (P03, P06, P09) |
| R2 | `ゆっくり ゆっくり——いまは およぐよ！` | Accepting to swim (P11 variation) |

Design rationale: はやく/ゆっくり pair preserves the tempo-word pivot (fast/slow); とんで みせるよ／いまは およぐよ preserves the fly/swim object shift. 4-mora rhythm (はやく) doubles naturally for toddler chanting. Not a word-for-word translation of zh-TW or en-US.

### SFX (ja native proposals)

| # | Frozen string | Action | Script rationale |
|---|---|---|---|
| S1 | `ぱたぱた` | Wing flap (x3: P03, P06, P09) | Hiragana, soft repeated motion (O1); bird-wing standard giongo |
| S2 | `バシャン` | Water landing (x3: P04, P07, P10) | Katakana, single impact (O1); water-splash standard giongo |
| S3 | `すいすい` | Water wake / gliding (P05, P11, P12) | Hiragana, smooth gliding state (O1 gitaigo) |

### Character name

| # | Frozen string | Rationale |
|---|---|---|
| N1 | `アンアン` | Katakana per P8 animal character name convention; maps directly to canonical key swan_anan |

### Ending / closing formula

| # | Frozen string |
|---|---|
| E1 | `それから ずっと……` |
| E2 | `そらに ブイが ひとつ とぶと みずの うえにも ブイが ひとつ およぎました。` (5-6/3-5) |
| E3 | `そらに ブイが とぶと みずにも ブイが およいだ。` (2-3 compressed) |

Note: "V" rendered as katakana ブイ to satisfy ja required_scripts whitelist (Hiragana + Katakana only; Latin banned).

### Speech quirks

- An-An uses 常体 (casual form) per R3; self-talk endings: よ、なぁ
- Narration uses です/ます体 per R1 (ました past tense dominant)
- 2-3 tier uses 常体短句 (telegram style) per R5

## B1 Blind Draft Pre-Budget

| Tier | max_total_len | Refrain discount (13 char x2 @0.25) | SFX discount | Estimated net budget |
|---|---|---|---|---|
| 5-6 | 1089 | -19.5 | ぱたぱた -6, バシャン -6, すいすい -3 = -15 | ~1054 |
| 3-5 | 838 | -19.5 | same -15 | ~803 |
| 2-3 | 190 | -19.5 | same -12 | ~158 |

Actual post-B3 values: 5-6 = 948.5, 3-5 = 546, 2-3 = 180.5. All within budget.

## B1 Blind Declaration

B1 blind drafting period: no zh-TW text files (text/zh-TW/*.json, copy/zh-TW.md), no en-US text files (text/en-US/*.json, copy/en-US.md), and no QA/gate3 material was opened while drafting. Every page was first written from the frozen design/storyboard semantic specification ("文説什麼" column) and the approved B0 card.

## B2 Source Calibration

B2 calibration completed against zh-TW copy/zh-TW.md and text/zh-TW/{5-6,3-5,2-3}.json.

Key adjustments:
- P01: Confirmed "friends already together + sky V appears" beat complete
- P04: Confirmed foot-discovery + return-to-friends sequence
- P05: Confirmed wake-as-runway inference retained
- P07: Confirmed circle-spin + wing-discovery + return beat
- P10: Confirmed landing + pause + friends-still-here + large wake
- P11: Confirmed three-look recognition (feet/wings/friends) + variation refrain
- P12: Confirmed dual-V climax (sky + water)
- P14: Confirmed closing formula with dual-V echo

No 加戲 (added content) or 漏戲 (missing content) found after calibration.
"V" rendered as ブイ (katakana phonetic) throughout all tiers to comply with ja script whitelist.
