# 圖文總表：El Cisne que Creció a su Tiempo（the-little-swan-grows-in-time / es-MX）

> 模式 B＝locale 改編（S4B，**改編不是翻譯**——讀設計文件後用該語言重新講一次故事；
> zh-TW 定稿是參考素材、不是對位基準）。
> 頁面選用**完全繼承** storyboard 三檔選用表；一頁一圖：每檔每頁恰用一張圖、用圖序號嚴格遞增。
> 文字的專屬負載＝聲音、台詞、內心、時間；不重述圖已明示的視覺事實。

## 0. 檔頭（機檢契約）

```yaml
schema: piyo_copy/v0.9
slug: the-little-swan-grows-in-time
locale: es-MX
mode: B
storyboard: content/PYO-008_the-little-swan-grows-in-time/PYO-008_storyboard.md
design: content/PYO-008_the-little-swan-grows-in-time/PYO-008_design.md
image_pool: 14
selection:
  "3-5": [P01, P03, P04, P05, P06, P07, P08, P09, P10, P11, P12, P14]
  "2-3": [P01, P03, P04, P06, P07, P09, P10, P11, P12, P14]
commitments:
  refrain: "¡Rápido, rápido, ya voy a volar!"
  ending:
    "5-6": "Un V voló. Un V nadó."
    "3-5": "Un V voló. Un V nadó."
    "2-3": "Un V voló. Un V nadó."
  onomatopoeia: ["¡Plaf, plaf, plap!", "¡CHAF!", "chas, chas, chas"]
characters: [An-An]
```

## 1. 圖文總表

| 圖 | 5-6 頁 | 5-6 文案 | 5-6 字數 | 3-5 頁 | 3-5 文案 | 3-5 字數 | 2-3 頁 | 2-3 文案 | 2-3 字數 | 匹配 | 選圖與提純說明 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P01 | 1 | Un gran V cruzó el cielo sobre el lago.<br>Abajo, An-An nadaba entre sus amigos. Detrás de ella, el agua dibujaba un pequeño V.<br>Pero An-An solo miraba hacia arriba.<br>—Yo quiero estar allá —susurró. | 35✓ | 1 | Un gran V cruzó el cielo.<br>An-An nadaba con sus amigos. Detrás de ella, el agua dibujaba un pequeño V.<br>Pero solo miraba arriba. | 24✓ | 1 | Un V cruzó el cielo.<br>An-An nadaba con sus amigos.<br>Pero solo miraba arriba. | 14✓ | ✓ | B2: zh-TW 人字隊 → es-MX V directly (natural in Spanish). 5-6 whispered dialogue for longing. 2-3 telegraph: events only. |
| P02 | 2 | An-An vio un espacio entre las aves del cielo.<br>Dejó a sus amigos y trepó a una piedra de la orilla.<br>Abrió sus alas cortas lo más que pudo.<br>—¡Ya voy! —dijo, lista para saltar. | 35✓ | — | — | — | — | — | — | ✓ | 3-5/2-3 omit P02: refrain at next page provides motivation (self-sufficient) |
| P03 | 3 | —¡Rápido, rápido, ya voy a volar! —gritó An-An.<br>Empujó con sus patas y saltó.<br>¡Plaf, plaf, plap!<br>Se quedó en el aire… solo un momentito. | 25✓ | 2 | —¡Rápido, rápido, ya voy a volar! —gritó An-An.<br>Saltó desde una piedra.<br>¡Plaf, plaf, plap!<br>Se quedó en el aire solo un momentito. | 23✓ | 2 | —¡Rápido, rápido, ya voy a volar!<br>¡Plaf, plaf, plap! | 9✓ | ✓ | Refrain #1. 2-3 telegraph: refrain + SFX only. |
| P04 | 4 | ¡CHAF!<br>Una hoja se le posó en la cabeza.<br>Sus patas anchas la sostuvieron enseguida.<br>—¡Mis patas ya saben nadar!<br>chas, chas, chas<br>An-An nadó con sus amigos y siguieron adelante. | 31✓ | 3 | ¡CHAF!<br>Una hoja se le posó en la cabeza.<br>Sus patas la sostuvieron.<br>chas, chas, chas<br>Nadó con sus amigos y siguieron adelante. | 23✓ | 3 | ¡CHAF!<br>Sus patas la sostuvieron.<br>An-An nadó con sus amigos. | 10✓ | ✓ | B2: leaf-on-head humor + paw recognition + return to friends. 5-6 adds dialogue. |
| P05 | 5 | An-An y sus amigos nadaron por un largo canal.<br>Sus patas la empujaban al mismo paso.<br>chas, chas, chas<br>Las líneas de agua se estiraron y estiraron.<br>—¿Y si salgo volando desde el agua? | 33✓ | 4 | An-An y sus amigos nadaron por un largo canal.<br>chas, chas, chas<br>Las líneas de agua se estiraron y estiraron… | 20✓ | — | — | — | ✓ | 2-3 omits P05: trial pattern self-explanatory. 5-6 adds hook question. |
| P06 | 6 | —¡Rápido, rápido, ya voy a volar! —gritó An-An.<br>Sus patas remaron fuerte. El agua se abrió a los lados.<br>¡Plaf, plaf, plap!<br>Pero sus alas cortas solo aleteaban para no caerse. | 31✓ | 5 | —¡Rápido, rápido, ya voy a volar! —gritó An-An.<br>Sus patas remaron fuerte.<br>¡Plaf, plaf, plap!<br>Pero sus alas solo aleteaban para no caerse. | 23✓ | 4 | —¡Rápido, rápido, ya voy a volar!<br>¡Plaf, plaf, plap! | 9✓ | ✓ | Refrain #2. Same telegraph pattern for 2-3. |
| P07 | 7 | ¡CHAF!<br>An-An giró en un pequeño círculo sobre el agua.<br>—Mis alitas todavía no vuelan —dijo quedito—, pero sí me ayudan a girar.<br>Se enderezó y nadó de vuelta junto a sus amigos. | 33✓ | 6 | ¡CHAF!<br>An-An giró en un círculo.<br>—Mis alitas todavía no vuelan —dijo quedito—, pero sí me ayudan a girar.<br>Nadó de vuelta junto a sus amigos. | 26⚠ | 5 | ¡CHAF!<br>An-An giró en un círculo.<br>¡Sus alitas sabían girar! | 10✓ | ✓ | Circle-spinning humor + wing recognition. quedito = MX diminutive adverb. 3-5 slightly over band upper: wing recognition dialogue needed for thematic integrity. |
| P08 | 8 | Un viento grande sopló. Los carrizos se doblaron.<br>Sus amigos seguían junto a ella, uno de cada lado.<br>An-An sintió sus patas en el agua y el viento en sus alas.<br>—Patas y alas —pensó—. ¡Las dos juntas! | 38✓ | 7 | Un viento grande sopló.<br>Sus amigos seguían junto a ella.<br>An-An sintió sus patas y el viento en sus alas.<br>—Las dos juntas —pensó. | 24✓ | — | — | — | ✓ | 2-3 omits P08: three-attempt pattern self-explanatory. |
| P09 | 9 | —¡Rápido, rápido, ya voy a volar! —gritó An-An con todas sus fuerzas.<br>Patas derechitas, alas abiertas contra el viento.<br>¡Plaf, plaf, plap!<br>An-An saltó más alto que nunca— | 28✓ | 8 | —¡Rápido, rápido, ya voy a volar! —gritó An-An.<br>Patas derechitas, alas abiertas, saltó más alto que nunca.<br>¡Plaf, plaf, plap! | 20✓ | 6 | —¡Rápido, rápido, ya voy a volar!<br>¡Plaf, plaf, plap!<br>Muy alto, muy alto— | 13✓ | ✓ | Refrain #3, peak intensity. 5-6 suspense dash. 2-3 adds height exclamation as hook. |
| P10 | 10 | ¡CHAF!<br>La salpicadura más grande le cayó como una corona de agua.<br>An-An se quedó quieta.<br>Pero sus amigos seguían ahí, uno a cada lado.<br>Sus patas remaban. Sus alas guiaban.<br>Detrás se abría el V de agua más grande del día. | 42⚠ | 9 | ¡CHAF!<br>La salpicadura más grande le cayó como una corona.<br>An-An se quedó quieta.<br>Sus amigos seguían ahí. Sus patas remaban. Y detrás, el V más grande del día. | 29⚠ | 7 | ¡CHAF!<br>An-An se quedó quieta.<br>Sus amigos seguían a su lado. | 11✓ | ✓ | B2: water crown + pause + friends present + biggest V wake. P10 over band: emotional turning point requires pause + body recognition + friends + biggest V (4 semantic loads per storyboard). |
| P11 | 11 | An-An miró sus patas. Miró sus alas. Miró a sus amigos.<br>Sonrió.<br>Despacito, despacito, primero voy a nadar.<br>chas, chas, chas | 21✓ | 10 | An-An sonrió.<br>Despacito, despacito, primero voy a nadar.<br>chas, chas, chas | 11✓ | 8 | An-An sonrió.<br>Despacito, despacito, primero voy a nadar. | 8✓ | ✓ | Refrain variation. 5-6 three-part observation (patas/alas/amigos). despacito = MX warmth diminutive. |
| P12 | 12 | Las patas de An-An dejaban una marca de agua firme. Sus alas ajustaban el rumbo.<br>chas, chas, chas<br>Sus amigos se acomodaron a los lados.<br>Arriba, el gran V del cielo cruzó.<br>Abajo, tres cisnes nadaban en su propio V. | 38✓ | 11 | chas, chas, chas<br>Sus amigos se acomodaron a los lados.<br>Arriba, un V del cielo pasó.<br>Abajo, tres cisnes nadaban en su V. | 23✓ | 9 | ¡Sus amigos se acomodaron!<br>Arriba, un V voló.<br>Abajo, un V nadó. | 12✓ | ✓ | Dual V climax. 2-3 compresses to exclamation + parallel minimal V statements. |
| P13 | 13 | An-An seguía siendo la misma cisne pequeña.<br>Sus amigos nadaban cerquita, como al principio.<br>El cielo tenía su paso rápido. El agua tenía su paso tranquilo. | 26✓ | — | — | — | — | — | — | ✓ | 3-5/2-3 omit P13. B2 add: pace parallel (zh-TW 天空有天空的快，水面有水面的慢). cerquita = MX diminutive. |
| P14 | 14 | Al atardecer, An-An y sus amigos llevaron su V de regreso a la bahía.<br>Después de aquello…<br>Cada vez que un V cruzaba el cielo, otro V nadaba en el lago.<br>Un V voló. Un V nadó. | 37✓ | 12 | Después de aquello…<br>Cada vez que un V cruzaba el cielo, otro V nadaba en el lago.<br>Un V voló. Un V nadó. | 23✓ | 10 | Después de aquello…<br>Un V voló. Un V nadó. | 9✓ | ✓ | Fixed closure. 3-5 drops dusk scene. 2-3 minimal: bridge + dual V. |
