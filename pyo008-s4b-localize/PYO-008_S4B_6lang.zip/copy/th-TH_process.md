# Mode B Process: th-TH — PYO-008 The Little Swan Grows in Time

## B0 Language Foundation

### Frozen String Table

| # | Category | Frozen th-TH String | Rationale |
|---|---|---|---|
| F1 | Character name: swan_anan | `น้องอัน` | น้อง = warm child prefix (th-TH registry convention: น้องทอง, น้องกอด); อัน = canonical "An" root preserved; 2 syllables, toddler-friendly |
| F2 | Refrain (urging): P03, P06, P09 | `เร็ว ๆ เร็ว ๆ หนูจะบินให้ได้!` | เร็ว ๆ = reduplication "fast fast" (spec O1); หนู = child self-reference (warm, gender-neutral); จะบินให้ได้ = "will manage to fly"; rhythmic 4-beat pattern; ! = half-width (spec P3) |
| F3 | Refrain variation: P11 | `ช้า ๆ ช้า ๆ หนูจะว่ายก่อนนะ!` | ช้า ๆ = "slow slow" mirror structure; จะว่ายก่อน = "will swim first"; นะ = soft particle adding acceptance tone; functional shift: self-urging flight -> accepting current swimming ability |
| F4 | SFX wing-flap (翅膀試飛): P03, P06, P09 | `พับ ๆ ๆ` | พับ = fold/flap action sound; ๆ ๆ = three-beat repetition (spec O1 triple); labial onset mimics wing movement; sentence-internal form (no !) |
| F5 | SFX water-landing (安全落水): P04, P07, P10 | `จ๋อม!` | จ๋อม = body splash into water; rising tone ๋ adds playful lightness; independent SFX line with ! (spec O2); safe landing not heavy crash |
| F6 | SFX water-wake (游出水紋): P04, P05, P11, P12 | `ซ่า ๆ` | ซ่า = water swishing softly; ๆ = continuation; gentle wake/trail sound; sentence-internal form |
| F7 | Ending formula (收束式) | `ต่อจากนั้นนะคะ… ทุกครั้งที่ท้องฟ้ามีตัว V ผิวน้ำก็จะมีตัว V ตามไปด้วยค่ะ` | ต่อจากนั้นนะคะ… = "from then on" (Thai equivalent of 後來呀…); นะคะ = warm narrator closing; ค่ะ = polite feminine sentence end; V retained as visual shape symbol |

### Character Speech Quirks

- น้องอัน (An): uses หนู for self-reference (child's warm self-address); eager tone with จะ (future tense marker) when excited; acceptance pages shift to softer particles (นะ, ค่ะ)
- Narrator: uses ค่ะ / นะคะ sentence-final particles for warm kindergarten teacher register (spec R2); past/completed aspect marked with แล้ว / ไป / มา

### Budget Pre-calculation

| Tier | max_total_len | Refrain x N (core sentence L* chars) | repeat_discount savings | SFX fixed repeat savings | Estimated usable budget |
|---|---|---|---|---|---|
| 5-6 | 1768 | F2 x3 + F3 x1 = ~27 L* x3 + ~28 x1 = 109; discount = 27*0.25*2 = ~14 saved | SFX repeats across pages: marginal | ~1768 (comfortable margin) |
| 3-5 | 1360 | F2 x3 + F3 x1; discount similar | | ~1360 (comfortable) |
| 2-3 | 310 | F2 x2 + F3 x1 = ~27*2 + 28 = 82; discount = 27*0.25*1 = ~7 | | 310 - need tight writing |

## B1 Blind Draft Declaration

B1 blind draft written from design.md + storyboard.md "文說什麼" column + B0 frozen strings + th-TH locale spec ONLY. No zh-TW or en-US text files were opened during B1 drafting.

## B2 Source Calibration Notes

(To be filled after B2 calibration against zh-TW sources)
