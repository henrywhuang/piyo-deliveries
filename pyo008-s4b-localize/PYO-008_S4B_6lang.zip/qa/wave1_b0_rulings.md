# Wave 1 B0 Rulings — PYO-008 The Little Swan Grows in Time

```yaml
schema: piyo_b0_rulings/v1
book_id: PYO-008
wave: 1
lanes: [ja, en-GB, es-MX, pt-BR]
date: 2026-07-21
```

## 凍結字串表

| # | 泳道 | 類型 | 凍結字串 | 用法 |
|---|---|---|---|---|
| F1 | ja | refrain-main | `はやく はやく——とんで みせるよ！` | P03, P06, P09 |
| F2 | ja | refrain-variation | `ゆっくり ゆっくり——いまは およぐよ！` | P11 |
| F3 | ja | sfx-wing-flap | `ぱたぱた` | P03, P06, P09 |
| F4 | ja | sfx-water-landing | `バシャン` | P04, P07, P10 |
| F5 | ja | sfx-water-wake | `すいすい` | P05, P11, P12 |
| F6 | ja | character-name | `アンアン` | 全書 |
| F7 | ja | ending-formula | `それから ずっと……` | P14(5-6/3-5), P10(2-3) |
| F8 | en-GB | refrain-main | `Faster, faster—I'll fly right now!` | P03, P06, P09（同 en-US） |
| F9 | en-GB | refrain-variation | `Steady, steady—I'll swim for now!` | P11（同 en-US） |
| F10 | en-GB | sfx-wing-flap | `flap, flap, flap!` | 同 en-US |
| F11 | en-GB | sfx-water-landing | `PLOP!` | 同 en-US |
| F12 | en-GB | sfx-water-wake | `swish, swish, swish!` | 同 en-US |
| F13 | en-GB | character-name | `An-An` | 同 en-US |
| F14 | en-GB | ending-formula | `And from then on…` | 同 en-US |
| F15 | es-MX | refrain-main | `¡Rápido, rápido, ya voy a volar!` | P03, P06, P09 |
| F16 | es-MX | refrain-variation | `Despacito, despacito, primero voy a nadar.` | P11 |
| F17 | es-MX | sfx-wing-flap | `¡Plaf, plaf, plap!` | P03, P06, P09 |
| F18 | es-MX | sfx-water-landing | `¡CHAF!` | P04, P07, P10 |
| F19 | es-MX | sfx-water-wake | `chas, chas, chas` | P05, P11, P12 |
| F20 | es-MX | character-name | `An-An` | 全書 |
| F21 | es-MX | ending-formula | `Después de aquello…` | P14 |
| F22 | pt-BR | refrain-main | `Mais rápido, mais rápido — eu vou voar!` | P03, P06, P09 |
| F23 | pt-BR | refrain-variation | `Devagar, devagar — eu vou nadar!` | P11 |
| F24 | pt-BR | sfx-wing-flap | `plap, plap, plap!` | P03, P06, P09 |
| F25 | pt-BR | sfx-water-landing | `TCHIBUM!` | P04, P07, P10 |
| F26 | pt-BR | sfx-water-wake | `xá, xá, xá!` | P04, P05, P11, P12 |
| F27 | pt-BR | character-name | `Ani` | 全書 |
| F28 | pt-BR | ending-formula | `E desde aquele dia…` | P14 |

## B0 快審結果

- ja：PASS — 語感自然、ひらがな為主符合 2-3 歲可跟唸需求
- en-GB：PASS — 派生變體，僅 leaped→leapt（2 處）
- es-MX：PASS — MX 地域風 diminutivo 語感到位
- pt-BR：PASS — BR diminutivo 語感到位；角色名 Ani（非 An-An）經 B0 提案

## golden 句式衝突

無。四泳道 B0 提案均與 design 指定句式相容。

## ⏸️ 上呈事項

- ja 2-3 檔位字數緊繃（180.5/190 上限），結構承諾不可刪（收束式＋雙 V），QA 可能需逐句精練
- pt-BR 角色名 Ani（非 An-An）：候選，QA 若無異議則維持
