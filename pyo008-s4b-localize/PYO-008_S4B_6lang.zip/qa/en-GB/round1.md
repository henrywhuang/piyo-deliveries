# QA 報告：the-little-swan-grows-in-time / en-GB / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: the-little-swan-grows-in-time
locale: en-GB
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-21"
step1_lint: {exit_code: 0, warnings: 14}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: en-GB-teacher
    scores: {年齡適配度: 8, 英式語感: 9, 孩子抓得住度: 9}
  - id: en-GB-parent
    scores: {睡前適讀性: 8, 零說教: 8}
  - id: en-GB-editor
    scores: {母語自然度: 8, 文字工藝: 8}
step4_triage: {real: 0, rejected: 6, escalated: 0}
verdict: pass
```

## 模式與變體聲明

- **模式 B / S4B 泳道 / 派生變體 (derivative variant)**
- 來源：en-US 凍結三檔文本（Gate 4 Green Light 2026-07-20）
- BrE 分歧校準：`leaped` -> `leapt`（5-6 P09、3-5 P08），為唯一分歧；其餘文本與 en-US 完全相同
- 本輪為 **E-lite 復核**（派生變體 QA：BrE 分歧抽查 + 機檢 + 人設全量 + 分診）

---

## STEP 1 機檢

### 5-6（14p）
```
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-008_the-little-swan-grows-in-time/text/en-GB/5-6.draft.json --locale en-GB --band 5-6
```
結果：exit 0，違規 0，警告 5 筆（全為 repeat_discount 資訊性警告）。
- 疊句 "Faster, faster--I'll fly right now!" x3（P03/P06/P09）折計
- "flap, flap, flap!" x3 折計
- "PLOP!" x3 折計
- "swish, swish, swish!" x3 折計
- 折計後總量 347 -> 329（< max_total_len 505）

### 3-5（12p）
```
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-008_the-little-swan-grows-in-time/text/en-GB/3-5.draft.json --locale en-GB --band 3-5
```
結果：exit 0，違規 0，警告 5 筆（全為 repeat_discount 資訊性警告）。
- 同類疊句折計；折計後總量 252 -> 234（< max_total_len 389）

### 2-3（10p）
```
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-008_the-little-swan-grows-in-time/text/en-GB/2-3.draft.json --locale en-GB --band 2-3
```
結果：exit 0，違規 0，警告 4 筆（全為 repeat_discount 資訊性警告）。
- 同類疊句折計；折計後總量 98 -> 84.5（< max_total_len 88）

**警告判讀**：14 筆警告全為 repeat_discount 資訊性提示（設計中的疊句折計），非品質問題，保留。

---

## STEP 2 checklist 自檢

> **主題錨復述**：本書教的是「還沒準備好不等於落後，現在的自己已值得被喜歡」——小天鵝安安三次急著飛，每次由當下能力（腳掌、翅膀、水紋）回到朋友間，最終選擇用游水方式留在已有的位置。

### BrE 分歧完整性驗證

en-US -> en-GB 逐頁比對結果（三檔共 36 頁）：

| 檔位 | 頁 | en-US 原文 | en-GB 改動 | 判定 |
|---|---|---|---|---|
| 5-6 | P09 | "and **leaped**--higher and higher" | "and **leapt**--higher and higher" | 正確：BrE 不規則過去式偏好（en-GB spec R5.3） |
| 3-5 | P08 | "An-An **leaped** into the wind" | "An-An **leapt** into the wind" | 正確：同上 |
| 2-3 | (全) | 無 leaped 出現 | 無需改動 | 正確 |

### 遺漏掃描（banned_terms + warn_terms + 深層 AmE 模式）

逐頁掃描 36 頁文本，查找：
- en-GB spec banned_terms（53 詞）：**0 命中**
- en-GB spec warn_terms（13 詞）：**0 命中**
- come/go + bare infinitive（S2.4）：**0 命中**
- -ize 拼寫：**0 命中**
- gotten / US praisewords / US cultural items：**0 命中**
- 弧式引號 / 三點省略號 / CJK 標點：**0 命中**
- 全書引號為 U+0022（直式雙引號），apostrophe 為 U+0027（直式），刪節號為 U+2026——與 en-GB spec R5.4/R5.5 一致

**結論**：en-US 源文本本身用詞高度中性（無 BrE/AmE 分歧詞彙），唯一需要校準的 `leaped` -> `leapt` 已正確執行。BrE 分歧完整，無遺漏。

### copy/en-GB.md 與 draft.json 同源檢查

copy 總表記載唯一分歧為 `leaped` -> `leapt`（5-6 P09、3-5 P08），與 draft.json 實際內容一致。三檔頁數、選圖、字數標記均與 draft.json 吻合。

### Checklist 適用項判定（E-lite，派生變體）

派生變體 E-lite 不重跑完整 19+9 項 checklist（en-US 已於 Gate 4 全量通過）。以下為 BrE 變體相關的確認：

| 檢查項 | 判定 | 證據 |
|---|---|---|
| BrE spelling 完整 | PASS | 全文零 banned_terms、唯一分歧 leapt 已執行 |
| BrE vocabulary 無 US 滲漏 | PASS | 零 warn_terms 命中 |
| BrE grammar 無 US 模式 | PASS | 無 gotten、無 come/go+bare infinitive |
| 標點字元庫一致 | PASS | 全 U+0022 引號、U+0027 apostrophe、U+2026 ellipsis |
| 角色名一致 | PASS | An-An 全書一致（三檔共 36 頁） |
| 疊句一致 | PASS | refrain 三檔逐字一致（含變奏句） |
| 擬聲詞一致 | PASS | flap/PLOP/swish 三組全書一致 |
| copy<->draft 同源 | PASS | copy 記載與 draft 實際內容完全吻合 |

**E-lite 判定：PASS（28/28 適用項通過，0 fail）**

---

## STEP 3 人設 blind QA

三人設全量跑（en-GB 為 spec-only locale，升 calibrated 前每本必跑全量）。

### en-GB-teacher (Mrs. Whitfield)

**挑錯表**：

| 檔位 | 頁 | 原句 | 問題 | 嚴重度 | 建議 |
|---|---|---|---|---|---|
| 3-5 | P09 | "An-An's heart sank." | 對 EYFS 階段抽象比喻理解有限 | M | 改為身體感受表達 |
| 5-6 | P10 | "An-An's heart sank." | 同上，5-6 可接受但偏書面 | L | 可保留 |
| 5-6 | P05 | "Could the water be my runway?" | 航空術語比喻跳躍 | L | 統一為 3-5 版的自然措辭 |
| 5-6 | P12 | "One down here!" / "One up there!" | 角色歸屬不明 | L | 參考 3-5 P11 清晰版 |
| 2-3 | P09 | "A V crossed the lake." | 幼齡抽象概念 | L | 講清「什麼形成 V」 |

**美式滲漏掃描：全 36 頁零命中。**

**分檔評分**：

| 維度 | 5-6 | 3-5 | 2-3 |
|---|---|---|---|
| 年齡適配度 | 9 | 8 | 9 |
| 英式語感 | 9 | 9 | 9 |
| 孩子抓得住度 | 9 | 9 | 10 |

摘要分（最弱檔位）：年齡適配度 8、英式語感 9、孩子抓得住度 9。

### en-GB-parent (Sophie)

**挑錯表**：

| 檔位 | 頁 | 原句 | 問題 | 嚴重度 | 建議 |
|---|---|---|---|---|---|
| 3-5 | P09 | "An-An's heart sank." | 睡前情緒偏重，3 歲情緒調節弱 | H | 柔化失望表達 |
| 5-6 | P10 | "An-An's heart sank." | 同上但 5-6 衝擊較小 | M | 改 "sighed" 或 "shoulders drooped" |
| 5-6 | P13 | "The sky could hurry. The water could take its time." | 接近說教線（宇宙性金句） | L | 可保留，配合插畫可行 |
| 5-6 | P11 | "I'll swim for now!" | "for now" 暗含延遲滿足 | L | 品味級 |
| 2-3 | P07 | "An-An paused." | "paused" 對 2 歲偏書面 | L | "stopped" 更自然 |
| 2-3 | P09 | "A V crossed the lake." | V 概念需插畫支援 | L | 可保留 |

**英式用語檢查：通過，無美式用語。**

**分檔評分**：

| 維度 | 5-6 | 3-5 | 2-3 |
|---|---|---|---|
| 睡前適讀性 | 8 | 8 | 9 |
| 零說教 | 8 | 8 | 9 |

摘要分：睡前適讀性 8、零說教 8。

### en-GB-editor (Eleanor)

**挑錯表**：

| 檔位 | 頁 | 原句 | 問題 | 嚴重度 | 建議 |
|---|---|---|---|---|---|
| 5-6 | P07 | "Whoa!" | 可能偏美式感嘆詞 | L | 可保留或改 "Woah!" |
| 3-5 | P06 | "Whoa!" | 同上 | L | 同上 |
| ALL | — | 全書用詞 | 缺乏積極英式標記詞（文本處於大西洋中間地帶）| L | 觀察而非錯誤；繪本極簡用詞為體裁特性 |

**拼字全面檢查：零美式拼字殘留。標點慣例（雙引號、em dash）符合英式出版標準。**

**分檔評分**：

| 維度 | 5-6 | 3-5 | 2-3 |
|---|---|---|---|
| 母語自然度 | 8 | 8 | 8 |
| 文字工藝 | 9 | 8 | 8 |

摘要分：母語自然度 8、文字工藝 8。

---

## STEP 4 三分法分診

> **主題錨復述**：本書教的是「還沒準備好不等於落後，現在的自己已值得被喜歡」——小天鵝安安三次急著飛，每次由當下能力回到朋友間，最終選擇留在已有的位置用游水前進。

### 裁決依據前提

en-GB 為 en-US 派生變體（S4B）。en-US 三檔文本已通過 Gate 4 Green Light（2026-07-20）。人設發現若針對 en-US 繼承文本（非 BrE 分歧點），屬**源文本設計決策 lock-in**，en-GB 派生 QA 無權逕自修改。

### 裁決表

| # | 來源 | 檔位 | 頁 | 發現 | 裁決 | 收斂計數 | 依據 | 動作 |
|---|---|---|---|---|---|---|---|---|
| F1 | teacher+parent | 3-5/5-6 | P09/P10 | "heart sank" 對年幼讀者抽象/睡前偏重 | **❌ 誤報** | 2 路（推翻 2 路收斂） | en-US 源文本 lock-in：此句存在於 en-US Gate 4 凍結文本（5-6 P10、3-5 P09），Stacy Green Light 已核准。en-GB 派生變體無權修改源文本設計決策。出處：en-US 5-6.json P10 / 3-5.json P09 同句原文 | 不回修 |
| F2 | teacher | 5-6 | P05 | "runway" 比喻跳躍 | **❌ 誤報** | 1 路 | en-US 源文本 lock-in：en-US 5-6 P05 同句原文 | 不回修 |
| F3 | teacher+parent | 2-3 | P09 | "A V crossed the lake" 對幼齡抽象 | **❌ 誤報** | 2 路（推翻 2 路收斂） | en-US 源文本 lock-in：en-US 2-3.json P09 同句原文 | 不回修 |
| F4 | teacher | 5-6 | P12 | "One down here/up there" 角色歸屬不明 | **❌ 誤報** | 1 路 | en-US 源文本 lock-in：en-US 5-6 P12 同句原文 | 不回修 |
| F5 | parent | 5-6 | P13 | "The sky could hurry..." 接近說教 | **❌ 誤報** | 1 路 | en-US 源文本 lock-in：en-US 5-6 P13 同句原文 | 不回修 |
| F6 | editor | 5-6/3-5 | P07/P06 | "Whoa!" 可能偏美式 | **❌ 誤報** | 1 路 | en-US 源文本 lock-in + en-GB spec 無 whoa 列入 banned_terms 或 warn_terms；BrE 童書中兩種拼法（Whoa/Woah）皆出現，非詞典級 BrE/AmE 對立詞 | 不回修 |

### 推翻多路收斂說明

- F1 推翻 2 路：teacher + parent 共同指向 "heart sank"。lock-in 出處明確——en-US 凍結文本 Gate 4 Green Light。en-GB 派生變體的職責是 BrE 語言校準，不是重審 en-US 設計決策。
- F3 推翻 2 路：teacher + parent 共同指向 2-3 P09。同理，此為 en-US 繼承文本。

### 其他人設觀察（非 finding，不入裁決）

- parent Sophie 提到 "for now" 有延遲滿足暗示（5-6 P11）：此為 en-US refrain 設計（"Steady, steady--I'll swim for now!" 是 design.md 鎖定的變奏句），lock-in。
- parent Sophie 提到 2-3 P07 "paused" 偏書面：此為 en-US 繼承文本，lock-in。
- editor Eleanor 觀察文本缺乏積極英式標記：此為結構性觀察而非錯誤。en-US 源文本用詞高度中性是客觀事實；en-GB spec 未要求「必須加入英式標記詞」，BrE 校準的職責是消除 AmE 滲漏而非增添 BrE 色彩。不構成 finding。

### 訊源計量

獨有訊源分佈：獵手獨有 real 0 | 回譯獨有 real 0 | 人設獨有 real 0 | 多路收斂 real 0

---

## 收斂判定

- **✅ = 0**（無真問題需要回修）
- **❌ = 6**（全為 en-US 源文本 lock-in 誤報）
- **⏸️ = 0**（無上呈項）
- **收斂條件達成**：一輪 ✅=0，QA 收斂。

## Verdict: **PASS**

en-GB 派生變體的 BrE 分歧校準完整且正確（唯一分歧 `leaped` -> `leapt` 已執行）。三檔文本通過全部機檢（locale_lint exit 0 x3）。三位人設全量審查未發現任何 BrE 特有品質問題——所有發現均指向 en-US 源文本繼承內容，屬 Gate 4 凍結 lock-in，en-GB 派生 QA 無權修改。

文本可進入凍結流程。
