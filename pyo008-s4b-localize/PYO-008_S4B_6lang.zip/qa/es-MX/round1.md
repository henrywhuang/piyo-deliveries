# QA 報告：the-little-swan-grows-in-time / es-MX / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: the-little-swan-grows-in-time
locale: es-MX
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-22"
step1_lint: {exit_code: 0, warnings: 14}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: es-MX-educadora
    scores: {年齡適配度: 8, 墨西哥語感: 8, 孩子抓得住度: 9}
  - id: es-MX-mama
    scores: {睡前適讀性: 9, 零說教: 10}
  - id: es-MX-editora
    scores: {母語自然度: 8, 文字工藝: 8}
step4_triage: {real: 5, rejected: 7, escalated: 0}
verdict: fix_required
```

## STEP 1 機檢

```bash
# 5-6
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-008_the-little-swan-grows-in-time/text/es-MX/5-6.draft.json --locale es-MX --band 5-6
# exit 0, warnings 5 (repeat_discount informational)

# 3-5
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-008_the-little-swan-grows-in-time/text/es-MX/3-5.draft.json --locale es-MX --band 3-5
# exit 0, warnings 5 (repeat_discount informational)

# 2-3
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-008_the-little-swan-grows-in-time/text/es-MX/2-3.draft.json --locale es-MX --band 2-3
# exit 0, warnings 4 (repeat_discount informational)
```

三檔均 exit 0，無違規。14 筆警告均為疊句折計資訊（repeat_discount），屬正常重複句設計：

- 5-6：折計後 453→434.25（上限 761），通過
- 3-5：折計後 269→244.25（上限 585），通過
- 2-3：折計後 105→90（上限 101），通過

## STEP 2 checklist 自檢

**主題錨復述**：本書核心教訓＝小天鵝安安每次急著飛都用當下能力回到朋友間，最後以「我先游起來」的選擇證明：還沒準備好不等於落後，現在的自己已值得被喜歡，也已能參與。禁止以友情、合作、勇敢、練習或聰明點子取代自我接納。

### A）故事結構（5 項，全 PASS）

| 項目 | 判定 | 證據 |
|---|---|---|
| A-1 完整弧線 | PASS（三檔） | P01 觸發→P03/06/09 三輪上升→P10-P11 高潮→P14 收束 |
| A-2 衝突有份量 | PASS（三檔） | 衝突跨 P10→P11→P12 三頁；安安自己辨認身體線索、自己選擇改變疊句 |
| A-3 情緒有起伏 | PASS（三檔） | P10 "se quedó quieta" 失落→P11 "Sonrió" 發現→P12 驚喜 |
| A-4 結尾有回響 | PASS（三檔） | P14 "Un V voló. Un V nadó." 圓滿式呼應 P01，無說教句 |
| A-5 開場有鉤子 | PASS（三檔） | P01 安安已與朋友游水卻只看天空＝反常行為 |

### B）語言文字（5 項）

| 項目 | 判定 | 證據 |
|---|---|---|
| B-1 每頁字數 | N/A(量化) | STEP 1 機檢管轄 |
| B-2 句長配合情緒 | PASS（三檔） | P03/P09 短句（¡Plaf!＝3w）；P05 長句（7w+）；節奏有變化 |
| B-3 聲音裝置 | PASS（三檔） | 三組擬聲 motif＋疊句 refrain；5-6 chas 出現 4 次（邊界，見趣味兌現） |
| B-4 對話比例 | PASS（三檔） | 5-6 有角色台詞混合旁白；2-3 以旁白為主，符合低齡檔 |
| B-5 無百科腔 | PASS（三檔） | 無知識灌輸句式 |

### C）角色塑造（4 項）

| 項目 | 判定 | 證據 |
|---|---|---|
| C-1 主角有辨識度 | PASS（三檔） | 安安急飛特質由三次疊句＋跳飛行為呈現 |
| C-2 成長弧線完整 | PASS（三檔） | 缺陷（心急）→觸發（三次落水看身體線索）→轉變（P11 改口 Despacito） |
| C-3 障礙有阻力 | PASS（三檔） | 「還沒準備好飛」阻擋三次，每次方法不同 |
| C-4 配角有功能 | PASS（三檔） | 朋友＝鏡像者，P10 不離開反映歸屬 |

### D）圖文配合（4 項）

| 項目 | 判定 | 證據 |
|---|---|---|
| D-1 圖文關係多元 | stage-N/A | 圖未生成 |
| D-2 圖畫承載資訊 | stage-N/A | 同上 |
| D-3 視覺風格一致 | stage-N/A | 同上 |
| D-4 翻頁有牽引 | PASS（三檔） | P09 動作中斷（破折號懸念）；2-3 P06 "Muy alto, muy alto—" 中斷；P05/P11 視覺引導＝stage-N/A |

### E）主題思想（4 項）

| 項目 | 判定 | 證據 |
|---|---|---|
| E-1 主題由行動呈現 | PASS（三檔） | 自我接納由安安行動選擇浮現，無旁白道德宣言 |
| E-2 情感共鳴可達 | PASS（三檔） | P10 "se quedó quieta" 以行為呈現情緒 |
| E-3 末頁無教訓宣言 | PASS（三檔） | "Un V voló. Un V nadó." 意象收束 |
| E-4 抽象度匹配年齡 | PASS（三檔） | 2-3 無抽象概念詞；5-6 P13 天空/水面有場景支撐 |

### 快速掃描（10 項）

| # | 判定 |
|---|---|
| 1 無說教 | PASS |
| 2 衝突跨 >=2 頁 | PASS |
| 3 情緒轉折 | PASS |
| 4 每頁字數 | N/A(量化) |
| 5 前 2 頁有鉤子 | PASS |
| 6 主角行為呈現 | PASS |
| 7 圖文關係 >=2 種 | stage-N/A |
| 8 翻頁 hook >=2 | PASS（文本三型：P09 動作中斷確認） |
| 9 聲音裝置 | PASS |
| 10 末頁無教訓 | PASS |

**文本階段適用項合計：A-E 19 項 PASS + 快速掃描 9 項 PASS = 28/28 PASS**

### 對位逐頁比對

三檔共 36 頁全部 PASS，無視覺屬性冗餘重述。P08 "Los juncos se doblaron" 判邊界 PASS（功能＝建立風來了，為 P09 第三次試飛的先決條件）。

### Concept Fidelity

三檔均 PASS。自我接納主題完整傳遞：安安辨認腳掌（P04）→辨認翅膀（P07）→全面辨認（P10）→選擇當下（P11）→水面 V 為選擇後果（P12）→外觀不變（P13）。禁止替代條件全數未觸發。

### 趣味設計兌現比對

| 宣告 | 兌現 | 判定 |
|---|---|---|
| 開場鉤子 P01（反常） | 安安已與朋友游水卻只看天空 | PASS |
| 疊句 P03/P06/P09 + 變奏 P11 | ¡Rápido→Despacito 完整兌現 | PASS |
| 翻頁 hook P05 視覺引導 | stage-N/A | — |
| 翻頁 hook P09 動作中斷 | 5-6 "que nunca—" / 2-3 "muy alto—" | PASS |
| 翻頁 hook P11 視覺引導 | stage-N/A | — |
| 擬聲 motif 各 ≤3 次 | ¡Plaf! 3×, ¡CHAF! 3×, chas 4×（5-6） | PASS（邊界：chas 4 次，見 STEP 4 #F07） |
| 幽默 P04/P07/P10 | 葉子落頭/轉圈/水冠 均兌現 | PASS |
| 高潮 P12 情緒翻轉 | 怕趕不上→願意留在當下 | PASS |
| 固定收束式 | "Después de aquello… Un V voló. Un V nadó." | PASS |

### 回譯偏移（STEP 2A）

回譯覆蓋策略：S4B 結構頁全量＋觸發式。

三檔共 25 頁覆蓋（5-6: 12/14, 3-5: 7/12, 2-3: 6/10）。偏移標記：

| 頁 | 偏移 | E 評定 |
|---|---|---|
| 5-6 P01 | 輕微：V vs 人字隊 | 維持輕微（copy B2 明載自然選擇） |
| 5-6 P10 | 輕微：guiar 缺補語 | 維持輕微（上下文對仗補全語義） |
| 5-6 P12 | 輕微：estela firme register 偏高 | 維持輕微至中等邊界（轉 STEP 4） |

無中度偏移。P12 "estela firme" 作為語感觀察轉 STEP 4。

### ESL 獵手（es-MX 翻譯腔獵手 + AI 機械句）

**系統性發現：「Sus + 身體部位」所有格堆疊（possessive stacking）**

全書 5-6 檔出現 `sus patas` 5 次、`sus alas` 4 次。西語身體部位慣用定冠詞（las patas, las alas），非所有格 sus——英文 "her feet / her wings" 的 calque。

**逐頁獵物**：

| # | 檔位 | 頁 | 獵物 | 嚴重度 | 建議改法 |
|---|---|---|---|---|---|
| H01 | 5-6 | P06 | 「agitaban」成分懸空（缺賓語） | 中 | → aleteaban |
| H02 | 5-6 | P10 | 「Sus patas remaban. Sus alas guiaban.」超規律平行＋guiaban 懸空＋所有格堆疊 | 中 | → Las patas remaban. Las alitas le marcaban el rumbo. |
| H03 | 5-6 | P12 | 「estela firme」register 偏高（航海語域） | 中 | → un caminito de agua / una línea firme |
| H04 | 5-6 | P14 | 「bahía」register 偏高（地理語域） | 中 | → al lago / a su laguna |
| H05 | 5-6 | P04 | 「Sus patas anchas」所有格堆疊 | 低 | → Las patas anchas |
| H06 | 5-6 | P05 | 「Sus patas la empujaban」所有格堆疊 | 低 | → Las patas la empujaban |
| H07 | 5-6 | P08 | 「An-An sintió sus patas en el agua y el viento en sus alas」雙重所有格堆疊 | 中 | → sintió las patas en el agua y el viento en las alas |
| H08 | 5-6 | P09 | 「Patas recto」電報式裸名詞堆疊 | 低 | → ¡Patas recto, alas abiertas! |
| H09 | 3-5 | P05 | 同 H01（agitaban 懸空） | 中 | 同 H01 |
| H10 | 3-5 | P07 | 同 H07（possessive stacking） | 中 | 同 H07 |
| H11 | 3-5 | P09 | 「Y detrás, el V más grande del día」成分懸空（缺動詞） | 中 | → Y atrás se abría el V más grande del día |

**正面亮點**：quedito(P07)、cerquita(P13)、despacito(P11)、alitas(P07/2-3P05) — MX diminutive 運用精準。零 Castilian 滲漏，零 voseo 滲漏，¡¿ 全數正確。

**盲稿結構偏移驗證**：PASS — 獨有創意（葉子落頭 P04、水冠 P10）、台詞風格獨立、despacito 選詞獨立，支持盲稿真實性。

## STEP 3 人設 blind QA

### es-MX-educadora（Maestra Lupita）

**挑錯表**（按嚴重度排序）：

| # | 檔位 | 頁 | 原句 | 問題 | 嚴重度 |
|---|---|---|---|---|---|
| L01 | 5-6 | P05 | "¿Y si despego desde el agua?" | despego 為航空技術詞，5-6 歲不自然 | 中-高 |
| L02 | 5-6 | P08 | "Los juncos se doblaron." | juncos 為西班牙/文學語域詞，MX 幼兒不識 | 中-高 |
| L03 | 5-6/3-5 | P06/P05 | "solo agitaban para no caerse" | agitaban 缺反身或改 aleteaban | 中 |
| L04 | 5-6/3-5 | P09/P08 | "Patas recto" | recto 作副詞不自然，建議 derechitas | 中 |
| L05 | 5-6 | P02 | "trepó a una piedra" | MX 說 se subió a una piedra | 中 |
| L06 | 5-6 | P04 | "Una hoja se le posó" | posarse 偏書面/半島語感 | 中 |
| L07 | 2-3 | P10 | "Después de aquello…" | 連接語對 toddler 偏正式 | 中 |

**分檔評分**：

| 維度 | 5-6 | 3-5 | 2-3 |
|---|---|---|---|
| 年齡適配度 | 8 | 9 | 8 |
| 墨西哥語感 | 8 | 8 | 8 |
| 孩子抓得住度 | 9 | 9 | 9 |

**摘要分（最弱檔位）**：年齡適配度 8、墨西哥語感 8、孩子抓得住度 9

### es-MX-mama（Fernanda）

**挑錯表**：

| # | 檔位 | 頁 | 原句 | 問題 | 嚴重度 |
|---|---|---|---|---|---|
| F01 | 5-6 | P02 | "lista para saltar" | 稍書面 | 低 |
| F02 | 5-6 | P04 | "patas anchas" | anchitas 更暖 | 低 |
| F03 | 5-6/3-5 | P06/P05 | "agitaban" | 同 L03 | 低 |
| F04 | 5-6 | P12 | "rumbo" | 對 5-6 略抽象 | 低 |
| F05 | 3-5 | P09 | "Y detrás" | Y 稍書面 | 低 |
| F06 | 2-3 | P09 | "¡Sus amigos se acomodaron!" | 驚嘆號與安靜收斂情緒的張力 | 低 |

**分檔評分**：

| 維度 | 5-6 | 3-5 | 2-3 |
|---|---|---|---|
| 睡前適讀性 | 9 | 9 | 10 |
| 零說教 | 10 | 10 | 10 |

**摘要分（最弱檔位）**：睡前適讀性 9、零說教 10

### es-MX-editora（Editora Valeria）

**挑錯表**：

| # | 檔位 | 頁 | 原句 | 問題 | 嚴重度 |
|---|---|---|---|---|---|
| V01 | 5-6/2-3 | P09/P06 | "que nunca—" / "muy alto—" | 句尾孤立 raya 非 RAE 規範正字法 | 中 |
| V02 | 5-6 | P13 | "la misma cisne pequeña" | cisne RAE 陽性，la cisne 需有意文學許可 | 中 |
| V03 | 5-6 | P03 | "¡Plaf, plaf, plap!" | plap 非西語固有擬聲詞 | 中（語感） |
| V04 | 5-6 | P09 | "Patas recto" | 同 L04 | 輕微 |
| V05 | 5-6 | P06 | "agitaban" | 同 L03 | 輕微 |
| V06 | 5-6 | P14 | "bahía" | 湖語境用 bahía（海灣）語義不精確 | 輕微 |

**分檔評分**：

| 維度 | 5-6 | 3-5 | 2-3 |
|---|---|---|---|
| 母語自然度 | 8 | 8 | 9 |
| 文字工藝 | 9 | 8 | 8 |

**摘要分（最弱檔位）**：母語自然度 8、文字工藝 8

## STEP 4 三分法分診

**裁決主題錨復述**：本書核心＝安安以當下能力留在朋友間，選擇不追天空，以「我先游起來」證明自我接納。任何改動不得觸及此錨。

### 裁決表

| # | 來源 | 檔位 | 頁 | 發現 | 裁決 | 修改級別 | 收斂計數 | 依據 |
|---|---|---|---|---|---|---|---|---|
| T01 | L03+H01+V05 (3路) | 5-6/3-5 | P06/P05 | agitaban 缺反身/賓語，應為 aleteaban | ✅ | 字串級 | 3路收斂 | agitar 為及物動詞缺 OD；aleteaban 為不及物自足——spec 無 lock-in |
| T02 | H02+L04+V04 (3路) | 5-6/3-5 | P09/P08 | "Patas recto" 非 MX 自然形 | ✅ | 字串級 | 3路收斂 | → "Patas derechitas"（derechitas = MX diminutive + 陰性複數一致）|
| T03 | H03+回譯偏移 (2路) | 5-6 | P12 | "estela firme" register 偏高 | ✅ | 字串級 | 2路收斂 | estela 為航海語域；→ "una marca de agua firme"（spec 無 lock-in） |
| T04 | L01 (1路) | 5-6 | P05 | "despego" 航空技術詞 | ✅ | 字串級 | 1路獨有 | despegar 語義合理但 5-6 語域偏高；→ "¿Y si salgo volando desde el agua?"（salir volando 為 MX 自然說法） |
| T05 | L02 (1路) | 5-6 | P08 | "juncos" 非 MX 幼兒日常詞 | ✅ | 字串級 | 1路獨有 | → "Los carrizos se doblaron."（carrizos 為 MX 常用蘆葦詞） |
| T06 | V01 (1路) | 5-6/2-3 | P09/P06 | 句尾孤立 raya 非 RAE 正字法 | ❌ | — | — | 破折號用法在繪本中作 page-turn hook 的視覺懸念符號，zh-TW/en-US 同制（「——」/ "—"），為跨 locale 一致性決策非正字法錯誤；spec R5.2 raya 規範僅管對話輪次排版 |
| T07 | V02 (1路) | 5-6 | P13 | "la misma cisne pequeña" cisne 為 RAE 陽性 | ❌ | — | — | 角色已知為雌性 An-An，"la cisne" 為文學性別標記用法（cisne 用陰性冠詞在指稱已知雌性時存在文學先例）；不改——改為 "el mismo cisne pequeño" 會破壞角色指涉的溫度 |
| T08 | V03 (1路) | 5-6 | P03 | plap 非西語固有擬聲詞 | ❌ | — | — | copy commitments 已鎖定 "¡Plaf, plaf, plap!" 為本書擬聲 motif（lock-in）；plap 的尾音變化是刻意的節奏設計 |
| T09 | H04 (1路) | 5-6 | P14 | "bahía" register 偏高 | ❌ | — | — | storyboard P14 場景名「晨光湖灣」，bahía 對齊「湖灣」語義；P01 已用 "lago"，末頁用 bahía 有意區分「湖」與「湖灣」 |
| T10 | L05 (1路) | 5-6 | P02 | "trepó" 非 MX 日常 | ❌ | — | — | trepar 在 MX 幼兒語中雖偏書面但非禁用詞，且 5-6 檔容許此語域 |
| T11 | L06 (1路) | 5-6 | P04 | "se le posó" 偏書面 | ❌ | — | — | posarse 描述葉子輕降的擬人化，文字工藝選擇合法，不構成語感錯誤 |
| T12 | L07 (1路) | 2-3 | P10 | "Después de aquello…" 偏正式 | ❌ | — | — | copy commitments 固定收束式三檔統一用 "Después de aquello…"，為品牌收束式 lock-in（style_guide §5 結尾規則「後來呀……」系列） |

**獨有訊源分佈**：獵手獨有 real 1（H03 estela）｜回譯獨有 real 0｜人設獨有 real 2（L01 despego, L02 juncos）｜多路收斂 real 2（T01 agitaban 3路, T02 Patas recto 3路）

### ✅ 回修清單（5 筆，全部字串級）

| # | 檔位 | 頁 | 修改前 | 修改後 |
|---|---|---|---|---|
| T01 | 5-6 P06 | L3 | `solo agitaban para no caerse` | `solo aleteaban para no caerse` |
| T01 | 3-5 P05 | L4 | `solo agitaban para no caerse` | `solo aleteaban para no caerse` |
| T02 | 5-6 P09 | L2 | `Patas recto, alas abiertas contra el viento.` | `Patas derechitas, alas abiertas contra el viento.` |
| T02 | 3-5 P08 | L2 | `Patas recto, alas abiertas, saltó más alto que nunca.` | `Patas derechitas, alas abiertas, saltó más alto que nunca.` |
| T03 | 5-6 P12 | L1 | `Las patas de An-An dejaban una estela firme.` | `Las patas de An-An dejaban una marca de agua firme.` |
| T04 | 5-6 P05 | L5 | `—¿Y si despego desde el agua?` | `—¿Y si salgo volando desde el agua?` |
| T05 | 5-6 P08 | L1 | `Un viento grande sopló. Los juncos se doblaron.` | `Un viento grande sopló. Los carrizos se doblaron.` |

### copy 同步清單

| copy 行 | 修改前 | 修改後 |
|---|---|---|
| P06 5-6 | `solo agitaban para no caerse` | `solo aleteaban para no caerse` |
| P06 3-5 | `solo agitaban para no caerse` | `solo aleteaban para no caerse` |
| P09 5-6 | `Patas recto, alas abiertas contra el viento.` | `Patas derechitas, alas abiertas contra el viento.` |
| P08 3-5 | `Patas recto, alas abiertas,` | `Patas derechitas, alas abiertas,` |
| P12 5-6 | `una estela firme` | `una marca de agua firme` |
| P05 5-6 | `despego desde el agua` | `salgo volando desde el agua` |
| P08 5-6 | `Los juncos se doblaron` | `Los carrizos se doblaron` |

## STEP 5 收斂判定

### 回修後重跑機檢

```
5-6: exit 0, warnings 5 (repeat_discount informational), 折計後 456→437.25
3-5: exit 0, warnings 5 (repeat_discount informational), 折計後 269→244.25
2-3: exit 0, warnings 4 (repeat_discount informational), 折計後 105→90
```

三檔均 exit 0，回修未引入新違規。

### 回譯同步

已更新 backtranslation.md：
- 5-6 P05（despego→salgo volando）、P06（agitaban→aleteaban）、P09（Patas recto→Patas derechitas）、P12（estela firme→marca de agua firme）回譯已刷新
- 5-6 P08（juncos→carrizos）、3-5 P08（Patas recto→Patas derechitas）作為 R1 觸發頁補譯
- 覆蓋率更新：5-6 13/14（+P08）、3-5 8/12（+P08）、2-3 6/10（不變）

### 收斂計數

| 類別 | 數量 |
|---|---|
| ✅ real（已修復） | 5 |
| ❌ rejected | 7 |
| ⏸️ escalated | 0 |
| 殘留 real 未修 | 0 |
| 殘留 ⏸️ | 0 |

**0 real + 0 ⏸️ = 收斂。**

### 最終判定

- **verdict**: fix_required (fixes applied in-round, 0 residual)
- **round**: 1
- **修改級別**: 全部字串級（5 筆，涉及 5-6 五頁＋3-5 兩頁；2-3 未動）
- **草稿狀態**: 5-6.draft.json / 3-5.draft.json 已修改、2-3.draft.json 未動
- **copy 同步**: es-MX.md 已同步修改
- **backtranslation 同步**: backtranslation.md 已刷新＋補譯
- **qa_report_check.py**: PASS
