# 關卡WB整合審閱：小天鵝慢慢長大（E 對位底稿／vi-VN）

- 生成時間：2026-07-22 11:20:12 +0800
- 書目錄：`content/PYO-008_the-little-swan-grows-in-time`
- 產生器：`.claude/skills/piyo-text-qa/scripts/make_review.py --gate WB`（決定性腳本，純解析＋排版）
- locale：vi-VN
- 用途：E 主審與裁決 agent 的單檔輸入 bundle——文字＝QA 對象本體逐字轉錄；可疑頁保留開原檔抽驗權

## 來源檔案

| 來源 | 檔案 | mtime |
|---|---|---|
| storyboard.md | `PYO-008_storyboard.md` | 2026-07-21 17:08:45 |
| copy | `copy/vi-VN.md` | 2026-07-22 11:20:00 |
| text/zh-TW/5-6 | `text/zh-TW/5-6.json` | 2026-07-21 17:08:45 |
| text/vi-VN/5-6 | `text/vi-VN/5-6.draft.json` | 2026-07-21 22:56:20 |
| text/zh-TW/3-5 | `text/zh-TW/3-5.json` | 2026-07-21 17:08:45 |
| text/vi-VN/3-5 | `text/vi-VN/3-5.draft.json` | 2026-07-21 22:56:20 |
| text/zh-TW/2-3 | `text/zh-TW/2-3.json` | 2026-07-21 17:08:45 |
| text/vi-VN/2-3 | `text/vi-VN/2-3.draft.json` | 2026-07-22 11:19:48 |
| qa/vi-VN/backtranslation.md | （缺） | — |

## 檔頭 commitments 逐字轉錄（兌現比對用）

```yaml
schema: piyo_copy/v0.9
slug: the-little-swan-grows-in-time
locale: vi-VN
mode: B
storyboard: content/PYO-008_the-little-swan-grows-in-time/PYO-008_storyboard.md
design: content/PYO-008_the-little-swan-grows-in-time/PYO-008_design.md
image_pool: 14
selection:
  "3-5": [P01, P03, P04, P05, P06, P07, P08, P09, P10, P11, P12, P14]
  "2-3": [P01, P03, P04, P06, P07, P09, P10, P11, P12, P14]
commitments:
  refrain: "Nhanh lên, nhanh lên, mình bay lên nào!"
  ending: "Từ đó về sau… cứ mỗi lần trời vẽ một chữ V, mặt hồ cũng vẽ theo một chữ V."
  onomatopoeia: [phập phập, TÕM, loạt soạt]
characters: [An-An]
```

## 檔位 5-6（14 頁）

### 5-6｜P01（母版 P01）

- 圖說什麼：清晨湖灣的水面中央，小天鵝安安與水面朋友 ×2 緊靠成一組朝翻頁側游；安安披灰褐幼羽、奶油色肚皮、短翅膀與寬腳掌，仰頭露出驚喜嚮往，朋友一淺棕一深灰、身高各約安安的 0.8，神情自在；安安身後有小 V 水紋 ×1，天空水鳥 ×5 排成大 V 掠過，低岸石 ×1、浮葉 ×3 在兩側。水面三鳥組佔畫面下方約四成，輪廓相連且游向清楚；視覺焦點只有水面三鳥組與簡化的天空 V 兩組。構圖裝置：上下雙層三角。
- 文說什麼：旁白：既有朋友關係、天空隊伍出現與水面小 V 的事件建立<br>內心：安安對天空位置的嚮往
- 鉤子：—
- 選圖與提純說明：3-5 compact narration; 2-3 telegraph: action + sky event only (below band lower: telegraph page, 2 beats sufficient for toddler)
- 匹配欄：✓

【zh-TW】
小天鵝安安和朋友們一起游呀游。
天空忽然飛過一排人字隊伍！
安安好想跟上去呀。

【vi-VN】
Thiên nga nhỏ An-An bơi cùng bạn trên mặt hồ.
Bỗng trên trời, một đàn chim xếp thành chữ V bay qua!
An-An ngẩng đầu, lòng thầm ước.

### 5-6｜P02（母版 P02）

- 圖說什麼：低岸石 ×1 佔畫面右下，安安一隻寬腳掌踩穩石面、另一隻腳抬起，短翅膀張到最大，頸部前伸、眉眼急切又期待；天空水鳥 ×5 的 V 從上方掠過，其中兩鳥間露出空隙 ×1；水面朋友 ×2 留在左下水中並肩看著安安，表情關心而不阻止；低視點讓天空隊伍壓在畫面上方，安安與朋友的距離仍清楚。構圖裝置：高低對角分層。
- 文說什麼：旁白：安安暫時離開原本位置並登上低岸石的事件推進<br>內心：立刻追上天空位置的急切
- 鉤子：—
- 選圖與提純說明：3-5/2-3 skip P02: P01->P03 direct to attempt; refrain provides motivation (self-sufficient)
- 匹配欄：✓

【zh-TW】
安安看見隊伍裡好像有個位置。
她離開朋友，爬上岸邊的石頭——
「我馬上就要飛上去了！」

【vi-VN】
An-An thấy đàn chim như có chỗ trống.
An-An rời bạn, leo lên hòn đá bên bờ——
"Mình sắp bay lên rồi!"

### 5-6｜P03（母版 P03）

- 圖說什麼：第一次試飛採固定斜向框架：低岸石 ×1 在左下、翻頁側開放天空在右上；安安佔畫面高度約一半，寬腳掌剛蹬離石面，身體沿左下到右上的短斜線躍起，短翅膀正用力拍動並帶弧形動勢線 ×2，嘴張開、眼睛發亮又緊張；水面朋友 ×2 緊靠成一組在右下抬頭，表情期待；水面小 V 水紋 ×1 留在後方。主體動作輪廓完整，焦點只有安安與朋友組。構圖裝置：斜向起飛軸。
- 文說什麼：台詞：招牌疊句首次；催促自己起飛的功能<br>擬聲：翅膀試飛 motif 首次，動作源為拍動短翅膀
- 鉤子：—
- 選圖與提純說明：3-5 cut result sentence (page turn delivers it); 2-3 telegraph: refrain + SFX only
- 匹配欄：✓

【zh-TW】
「快一點，快一點，我要飛起來！」
安安用力一蹬—— 撲撲！
她在空中停了一下下。

【vi-VN】
"Nhanh lên, nhanh lên, mình bay lên nào!"
An-An đạp thật mạnh—— phập phập!
An-An lơ lửng trên không một chút xíu.

### 5-6｜P04（母版 P04）

- 圖說什麼：俯角近看安安安全落在湖面中央，圓身佔插圖約六成，浮葉 ×1 正停在頭頂，安安瞪圓眼、咧嘴笑；寬腳掌 ×2 在清水中張開托穩身體，腳後划出小 V 水紋 ×1；水面朋友 ×2 緊靠在右側成一組，笑著朝安安游近但沒有嘲笑姿態；其餘浮葉 ×2 疏落在大片留白水面。主體輪廓大而完整，焦點只有安安與朋友組。構圖裝置：中央主體留白。
- 文說什麼：擬聲：安全落水 motif 第一次，動作源為身體落回水面<br>擬聲：游出水紋 motif，動作源為寬腳掌推水<br>內心：辨認腳掌當下用途與重新有勁
- 鉤子：—
- 選圖與提純說明：5-6 full body-awareness beat; 3-5 keep feet + return (below band lower: landing pages are naturally short -- SFX + result); 2-3 telegraph: result + return
- 匹配欄：✓

【zh-TW】
噗通！
寬寬的腳掌穩穩接住安安。
腳掌已經會划水了呢！
安安游回朋友身邊，一起往前游。

【vi-VN】
TÕM!
Bàn chân rộng đỡ An-An thật vững.
Bàn chân biết đạp nước rồi kìa!
An-An bơi về bên bạn, cùng nhau đi tiếp.

### 5-6｜P05（母版 P05）

- 圖說什麼：白日長長水道從畫面左下收窄到右上翻頁側；安安位於水面朋友 ×2 中間並肩游，三鳥表情專心愉快，安安的寬腳掌清楚向後推水；三組水紋在身後拉長，其中安安的 V 水紋 ×1 最清楚，兩岸蘆葦叢 ×2 向遠方縮小，前方水道只露出延續方向、不揭示下一個動作。背景細節層：小青蛙 ×1 從左岸浮葉跳到右岸浮葉，跨頁方向與三鳥同行，但尺寸小且不搶主體。構圖裝置：縱深導流線。
- 文說什麼：旁白：安安以寬腳掌跟上朋友的當下參與<br>內心：由共同游水與長水紋形成下一方法的線索<br>擬聲：游出水紋 motif，動作源為三鳥腳掌推水
- 鉤子：視覺引導型：三鳥身後的長水紋匯入前方水道並伸出畫面
- 選圖與提純說明：3-5 cut reasoning, keep hook atmosphere (below band lower: hook page focused on sound + visual); 2-3 skip P05: P04->P06 try-fail pattern self-evident for toddlers
- 匹配欄：✓

【zh-TW】
安安的寬腳掌跟上朋友了！
沙啦沙啦—— 水紋越拉越長。
如果一直游下去，是不是就能飛起來……

【vi-VN】
Bàn chân rộng của An-An đã theo kịp bạn rồi!
loạt soạt—— vệt nước kéo dài mãi.
Nếu cứ bơi mãi, biết đâu sẽ bay được…

### 5-6｜P06（母版 P06）

- 圖說什麼：第二次試飛沿用固定斜向框架：安安從左下水面朝右上翻頁側加速，身體佔畫面約五成，寬腳掌向後猛推、胸口剛抬離水面，短翅膀快速撲動保持平衡，兩側翼端動勢線 ×2 清楚可見，嘴張開、眉眼快樂又急促；左右水花帶 ×2 比 P03 更長，尾後直水紋 ×1；水面朋友 ×2 緊靠成一組在左後方追隨，表情專注；兩岸蘆葦叢 ×2 模糊後退。主體動作由腳掌、身體前傾與翅膀撲動形成大輪廓，焦點只有安安與朋友組。構圖裝置：斜向起飛軸。
- 文說什麼：台詞：招牌疊句第二次；速度與急促度升級<br>擬聲：翅膀試飛 motif 第二次，動作源為快速撲動的短翅膀與翼端動勢<br>旁白：腳掌加速與水面助跑的事件推進
- 鉤子：—
- 選圖與提純說明：3-5 cut intent clause (below band lower: refrain + action pages are structurally compact); 2-3 telegraph same as P03 (visual difference carried by illustration)
- 匹配欄：✓

【zh-TW】
「快一點，快一點，我要飛起來！」
安安越划越快，想從水面飛起來——
撲撲！

【vi-VN】
"Nhanh lên, nhanh lên, mình bay lên nào!"
An-An đạp nước thật nhanh, muốn bay lên từ mặt nước——
phập phập!

### 5-6｜P07（母版 P07）

- 圖說什麼：俯角近看安安胸口剛貼回水面並轉出小圓圈，圓身佔插圖約六成，兩隻短翅膀一高一低調整方向，眼睛瞪圓、視線落向水紋，表情若有所思；圓形水紋 ×1 與小水花圈 ×1 包住安安，水面朋友 ×2 緊靠在圓圈開口外等她，表情溫和；蘆葦叢 ×1 位於翻頁側。主體輪廓大，轉向由全身弧線可直接指認，焦點只有安安與朋友組。構圖裝置：同心圓旋軸。
- 文說什麼：擬聲：安全落水 motif 第二次，動作源為胸口貼回水面的小水花<br>旁白：短翅膀完成轉向並回到朋友身邊的事件<br>內心：辨認短翅膀當下用途
- 鉤子：—
- 選圖與提純說明：3-5 compact but keep recognition + return; 2-3 telegraph: funny result + short recognition, cut return (below band lower: telegraph landing page)
- 匹配欄：✓

【zh-TW】
噗通！
安安在水面上轉了一個小圓圈。
咦？短翅膀現在可以轉彎了呢。
安安穩穩轉回朋友身邊。

【vi-VN】
TÕM!
An-An xoay tròn một vòng trên mặt nước.
Ơ? Cánh ngắn giờ biết rẽ hướng rồi kìa!
An-An rẽ lại thật vững, bơi về bên bạn.

### 5-6｜P08（母版 P08）

- 圖說什麼：午後風從左下吹向右上，蘆葦叢 ×2 同向彎向翻頁側；安安在水面朋友 ×2 中間並肩游，寬腳掌向後推水、短翅膀一張一收修正方向，神情被陪伴而逐漸篤定；水面前方低圓石 ×3 排出可通行間距，最大圓石 ×1 位於翻頁側；風帶 ×2 與三鳥游向一致。低視點讓迎面風與彎蘆葦形成可見阻力，朋友仍貼近安安。構圖裝置：對角風壓帶。
- 文說什麼：旁白：朋友仍在兩旁並肩前進的成果前歸屬證據<br>內心：腳掌推水、短翅膀轉向與迎面風組成第三方法<br>時間：午後風勢增強
- 鉤子：—
- 選圖與提純說明：3-5 cut scene description, keep buildup; 2-3 skip P08: P07->P09 three-attempt pattern self-evident, no strategy assembly needed
- 匹配欄：✓

【zh-TW】
朋友們還在身邊，一起游過有風的地方。
腳掌會推水、短翅膀會轉彎……
安安想：加上風，這次一定可以！

【vi-VN】
Bạn vẫn ở bên, cùng bơi qua chỗ gió lớn.
Bàn chân đạp nước, cánh ngắn rẽ hướng…
An-An nghĩ: thêm gió nữa, lần này nhất định được!

### 5-6｜P09（母版 P09）

- 圖說什麼：第三次試飛仍用固定斜向框架，但量級最大：圓石 ×3 與淺灘在左下，安安沿左下到右上長斜線躍至全頁最高點，身體仍佔畫面高度約四成，寬腳掌剛離水、短翅膀完全張開迎風，兩側翼端顫動線 ×2 清楚可見，嘴張開、目光全力鎖住前方；腳後水花翼 ×2、長直水痕 ×1、彎曲蘆葦叢 ×2 與風帶 ×3 共同放大速度；水面朋友 ×2 緊靠成一組在左下仰望。畫面凍結在安安是否飛起的單一瞬間，動作剪影清楚，焦點只有安安與朋友組。構圖裝置：斜向起飛軸。
- 文說什麼：台詞：招牌疊句第三次；音量與決心達到三次最大<br>擬聲：翅膀試飛 motif 第三次，動作源為完全張開迎風的短翅膀與翼端顫動<br>旁白：腳掌加速、翅膀迎風與躍至最高點的動作中斷
- 鉤子：動作中斷型：安安躍到最高點，結果尚未發生
- 選圖與提純說明：5-6 three elements listed for maximum scale; 3-5 cut element list, keep height + hook; 2-3 telegraph: exclamatory height for hook
- 匹配欄：✓

【zh-TW】
「快一點，快一點，我要飛起來！」
腳掌推！翅膀張！風來了——
撲撲！
安安跳到了最高最高的地方——

【vi-VN】
"Nhanh lên, nhanh lên, mình bay lên nào!"
Bàn chân đạp! Cánh xòe! Gió tới——
phập phập!
An-An nhảy lên cao nhất, cao nhất——

### 5-6｜P10（母版 P10）

- 圖說什麼：俯角近看安安安全落回淺灘，圓身佔畫面約五成半，最大水花落成水冠弧 ×1 圍在頭頂；安安垂眼停住、嘴角下沉，但寬腳掌 ×2 仍在推水、短翅膀 ×2 仍一高一低掌方向；身後展開本書目前最大的 V 水紋 ×1；水面朋友 ×2 分別貼近左右兩旁，身體朝向安安、表情關心，形成不離開的安全框。主體動作與表情一眼可讀，朋友兩鳥緊靠安安視為同一焦點群。構圖裝置：向心安全框。
- 文說什麼：擬聲：安全落水 motif 第三次，動作源為身體落回水面的大水花<br>內心：失落後辨認腳掌、短翅膀、大 V 水紋與既有位置<br>旁白：朋友仍留在兩旁的成果前歸屬證據
- 鉤子：—
- 選圖與提純說明：3-5 merge recognition + belonging; 2-3 telegraph: fall + friends remain (core belonging; below band lower: emotional pause page, minimal words by design)
- 匹配欄：✓

【zh-TW】
噗通！
安安停了一下下。
可是…… 腳掌還在划，翅膀幫她穩穩的。
身後的水紋好大好大。朋友們就在旁邊。

【vi-VN】
TÕM!
An-An dừng lại một chút.
Nhưng mà… bàn chân vẫn đạp, cánh vẫn giữ thăng bằng.
Vệt nước sau lưng lớn lắm. Bạn vẫn ở ngay bên.

### 5-6｜P11（母版 P11）

- 圖說什麼：金色午後的開闊湖心，安安留在水面朋友 ×2 中間向翻頁側游，三鳥靠得近而沒有排成完整 V；安安寬腳掌穩定推水、短翅膀微張調方向，抬頭嘴微張、露出自在微笑，朋友表情安心；安安身後兩道尚未完成的 V 水紋伸向翻頁側，只畫出靠近安安的前半段，兩個開放端點消失在右頁邊緣，完整隊形尚未出現。三鳥組佔畫面中央約五成，動作同向且輪廓清楚，水紋是方向結構而非新增焦點。構圖裝置：開口 V 引導線。
- 文說什麼：台詞：招牌疊句變奏；由自我催促轉為接納當下並選擇先游<br>內心：辨認已準備好的能力與一直存在的朋友位置<br>擬聲：游出水紋 motif，動作源為寬腳掌穩定推水
- 鉤子：視覺引導型：兩道尚未完成的 V 水紋伸向翻頁側，終點仍在畫外
- 選圖與提純說明：3-5 cut observation triad, straight to smile + variation (below band lower: variation page, refrain is the beat); 2-3 telegraph: cut loạt soạt (swim conveyed by image), keep emotional turn + refrain variation
- 匹配欄：✓

【zh-TW】
安安看看腳掌，看看翅膀，再看看身邊的朋友。
她笑了。
「慢一點，慢一點，我先游起來！」
沙啦——

【vi-VN】
An-An nhìn bàn chân, nhìn đôi cánh, rồi nhìn bạn bên cạnh.
An-An cười rồi.
"Chậm thôi, chậm thôi, mình bơi trước đã!"
loạt soạt——

### 5-6｜P12（母版 P12）

- 圖說什麼：翻頁後直接交付完整雙 V：安安在水面 V 的前端穩定游，水面朋友 ×2 已沿 P11 的兩道水紋分列左右兩臂，三鳥與完整水面 V 水紋 ×1 佔畫面下半約五成；安安用寬腳掌推水、短翅膀微調方向，三鳥都露出驚喜而踏實的笑；天空水鳥 ×5 同時以簡化剪影排成大 V 掠過上方。低水面仰角讓安安成為穩定前進的高光主體；視覺焦點只有水面三鳥 V 與簡化天空 V 兩組。構圖裝置：完整 V 放射。
- 文說什麼：旁白：朋友沿既有水紋完成水面 V 的高潮事件<br>擬聲：游出水紋 motif，動作源為三鳥同步推水<br>內心：以當下能力參與後的驚喜與踏實
- 鉤子：—
- 選圖與提純說明：3-5 cut action description, straight to climax result; 2-3 telegraph: cut loạt soạt, compress to result + double-V declaration
- 匹配欄：✓

【zh-TW】
安安用腳掌帶出水紋，翅膀調好方向。
沙啦—— 朋友們沿著水紋排開了！
天空一個人字，湖面也一個人字。

【vi-VN】
An-An dùng bàn chân vẽ ra vệt nước, cánh chỉnh hướng.
loạt soạt—— bạn bè dọc theo vệt nước dàn ra!
Trời một chữ V, hồ cũng một chữ V.

### 5-6｜P13（母版 P13）

- 圖說什麼：金色湖面上，安安仍披同樣灰褐幼羽、奶油色肚皮、短翅膀與寬腳掌，位於水面朋友 ×2 中間並肩游，三鳥肩線相貼、速度一致；安安笑著轉頭看朋友，朋友回以自在笑容；天空水鳥 ×5 已飛到遠方，只剩小剪影，水面 V 在身後放鬆成三道平行水痕。背景細節層：P05 的小青蛙 ×1 坐在遠處浮葉上，用前腳比出小 V，完成自己的同行副線。構圖裝置：平行雙速帶。
- 文說什麼：旁白：安安未飛起、外觀不變與朋友仍貼近的結果確認<br>時間：天空與水面各以自身速度前進的並行延展
- 鉤子：—
- 選圖與提純說明：3-5/2-3 skip P13: P12->P14 climax to closure direct (self-sufficient: P12 delivers full emotional climax, P14 closes directly)
- 匹配欄：✓

【zh-TW】
安安還是那隻小小的安安。
朋友們笑著貼在她身邊。
天空有天空的快，水面有水面的慢。

【vi-VN】
An-An vẫn là An-An nhỏ xíu ấy thôi.
Bạn bè vẫn cười, vẫn sát bên An-An.
Trời có nhịp của trời, nước có nhịp của nước.

### 5-6｜P14（母版 P14）

- 圖說什麼：黃昏湖心通往晨光湖灣的金橘光路佔畫面中央，安安與水面朋友 ×2 仍以小而清楚的 V 向湖灣游回，水面三鳥組佔畫面下方約四成、安安幼年外觀與寬腳掌輪廓仍可辨，三鳥表情安穩滿足；完整水面 V 水紋 ×1 在背後慢慢拉長，天空水鳥 ×5 的遠方 V 位於上方，低岸 ×1、浮葉 ×3 回收 P01。近處水面三鳥 V 與遠方天空剪影 V 形成前後尺度對比；兩個焦點群游回方向清楚，整體色調由金橘過渡到柔紫，視線最後收回畫面中心。構圖裝置：雙 V 回聲。
- 文說什麼：時間：從午後推進到黃昏的後續時間標記<br>旁白：天空與湖面雙 V 回收、自己的時間表與固定收束功能
- 鉤子：—
- 選圖與提純說明：3-5 cut dusk scene sentence, keep closure only (time conveyed by image palette); 2-3 closure split into two short sentences to fit 2-3 band (max_sentence_len 10, max_page_len 18) while preserving double-V echo
- 匹配欄：✓

【zh-TW】
黃昏了，安安和朋友們慢慢游回湖灣。
後來呀…… 只要天空游出一個人字，湖面也會跟著游出一個人字。

【vi-VN】
Chiều tà, An-An cùng bạn bè bơi về vịnh hồ.
Từ đó về sau… cứ mỗi lần trời vẽ một chữ V, mặt hồ cũng vẽ theo một chữ V.

## 檔位 3-5（12 頁）

### 3-5｜P01（母版 P01）

- 圖說什麼：清晨湖灣的水面中央，小天鵝安安與水面朋友 ×2 緊靠成一組朝翻頁側游；安安披灰褐幼羽、奶油色肚皮、短翅膀與寬腳掌，仰頭露出驚喜嚮往，朋友一淺棕一深灰、身高各約安安的 0.8，神情自在；安安身後有小 V 水紋 ×1，天空水鳥 ×5 排成大 V 掠過，低岸石 ×1、浮葉 ×3 在兩側。水面三鳥組佔畫面下方約四成，輪廓相連且游向清楚；視覺焦點只有水面三鳥組與簡化的天空 V 兩組。構圖裝置：上下雙層三角。
- 文說什麼：旁白：既有朋友關係、天空隊伍出現與水面小 V 的事件建立<br>內心：安安對天空位置的嚮往
- 鉤子：—
- 選圖與提純說明：3-5 compact narration; 2-3 telegraph: action + sky event only (below band lower: telegraph page, 2 beats sufficient for toddler)
- 匹配欄：✓

【zh-TW】
小天鵝安安和朋友一起游。
天空飛過人字隊！
安安好想跟上去。

【vi-VN】
Thiên nga nhỏ An-An bơi cùng bạn.
Trên trời, đàn chim xếp chữ V bay qua!
An-An muốn bay theo quá.

### 3-5｜P02（母版 P03）

- 圖說什麼：第一次試飛採固定斜向框架：低岸石 ×1 在左下、翻頁側開放天空在右上；安安佔畫面高度約一半，寬腳掌剛蹬離石面，身體沿左下到右上的短斜線躍起，短翅膀正用力拍動並帶弧形動勢線 ×2，嘴張開、眼睛發亮又緊張；水面朋友 ×2 緊靠成一組在右下抬頭，表情期待；水面小 V 水紋 ×1 留在後方。主體動作輪廓完整，焦點只有安安與朋友組。構圖裝置：斜向起飛軸。
- 文說什麼：台詞：招牌疊句首次；催促自己起飛的功能<br>擬聲：翅膀試飛 motif 首次，動作源為拍動短翅膀
- 鉤子：—
- 選圖與提純說明：3-5 cut result sentence (page turn delivers it); 2-3 telegraph: refrain + SFX only
- 匹配欄：✓

【zh-TW】
「快一點，快一點，我要飛起來！」
安安用力一跳—— 撲撲！

【vi-VN】
"Nhanh lên, nhanh lên, mình bay lên nào!"
An-An nhảy thật mạnh—— phập phập!

### 3-5｜P03（母版 P04）

- 圖說什麼：俯角近看安安安全落在湖面中央，圓身佔插圖約六成，浮葉 ×1 正停在頭頂，安安瞪圓眼、咧嘴笑；寬腳掌 ×2 在清水中張開托穩身體，腳後划出小 V 水紋 ×1；水面朋友 ×2 緊靠在右側成一組，笑著朝安安游近但沒有嘲笑姿態；其餘浮葉 ×2 疏落在大片留白水面。主體輪廓大而完整，焦點只有安安與朋友組。構圖裝置：中央主體留白。
- 文說什麼：擬聲：安全落水 motif 第一次，動作源為身體落回水面<br>擬聲：游出水紋 motif，動作源為寬腳掌推水<br>內心：辨認腳掌當下用途與重新有勁
- 鉤子：—
- 選圖與提純說明：5-6 full body-awareness beat; 3-5 keep feet + return (below band lower: landing pages are naturally short -- SFX + result); 2-3 telegraph: result + return
- 匹配欄：✓

【zh-TW】
噗通！
寬腳掌穩穩接住安安。
安安游回朋友身邊。

【vi-VN】
TÕM!
Bàn chân rộng đỡ An-An thật vững.
An-An bơi về bên bạn.

### 3-5｜P04（母版 P05）

- 圖說什麼：白日長長水道從畫面左下收窄到右上翻頁側；安安位於水面朋友 ×2 中間並肩游，三鳥表情專心愉快，安安的寬腳掌清楚向後推水；三組水紋在身後拉長，其中安安的 V 水紋 ×1 最清楚，兩岸蘆葦叢 ×2 向遠方縮小，前方水道只露出延續方向、不揭示下一個動作。背景細節層：小青蛙 ×1 從左岸浮葉跳到右岸浮葉，跨頁方向與三鳥同行，但尺寸小且不搶主體。構圖裝置：縱深導流線。
- 文說什麼：旁白：安安以寬腳掌跟上朋友的當下參與<br>內心：由共同游水與長水紋形成下一方法的線索<br>擬聲：游出水紋 motif，動作源為三鳥腳掌推水
- 鉤子：視覺引導型：三鳥身後的長水紋匯入前方水道並伸出畫面
- 選圖與提純說明：3-5 cut reasoning, keep hook atmosphere (below band lower: hook page focused on sound + visual); 2-3 skip P05: P04->P06 try-fail pattern self-evident for toddlers
- 匹配欄：✓

【zh-TW】
安安跟著朋友游進長長的水道。
沙啦沙啦—— 水紋好長好長……

【vi-VN】
An-An bơi cùng bạn vào khúc sông dài.
loạt soạt—— vệt nước dài lắm…

### 3-5｜P05（母版 P06）

- 圖說什麼：第二次試飛沿用固定斜向框架：安安從左下水面朝右上翻頁側加速，身體佔畫面約五成，寬腳掌向後猛推、胸口剛抬離水面，短翅膀快速撲動保持平衡，兩側翼端動勢線 ×2 清楚可見，嘴張開、眉眼快樂又急促；左右水花帶 ×2 比 P03 更長，尾後直水紋 ×1；水面朋友 ×2 緊靠成一組在左後方追隨，表情專注；兩岸蘆葦叢 ×2 模糊後退。主體動作由腳掌、身體前傾與翅膀撲動形成大輪廓，焦點只有安安與朋友組。構圖裝置：斜向起飛軸。
- 文說什麼：台詞：招牌疊句第二次；速度與急促度升級<br>擬聲：翅膀試飛 motif 第二次，動作源為快速撲動的短翅膀與翼端動勢<br>旁白：腳掌加速與水面助跑的事件推進
- 鉤子：—
- 選圖與提純說明：3-5 cut intent clause (below band lower: refrain + action pages are structurally compact); 2-3 telegraph same as P03 (visual difference carried by illustration)
- 匹配欄：✓

【zh-TW】
「快一點，快一點，我要飛起來！」
安安越划越快—— 撲撲！

【vi-VN】
"Nhanh lên, nhanh lên, mình bay lên nào!"
An-An đạp nhanh hơn—— phập phập!

### 3-5｜P06（母版 P07）

- 圖說什麼：俯角近看安安胸口剛貼回水面並轉出小圓圈，圓身佔插圖約六成，兩隻短翅膀一高一低調整方向，眼睛瞪圓、視線落向水紋，表情若有所思；圓形水紋 ×1 與小水花圈 ×1 包住安安，水面朋友 ×2 緊靠在圓圈開口外等她，表情溫和；蘆葦叢 ×1 位於翻頁側。主體輪廓大，轉向由全身弧線可直接指認，焦點只有安安與朋友組。構圖裝置：同心圓旋軸。
- 文說什麼：擬聲：安全落水 motif 第二次，動作源為胸口貼回水面的小水花<br>旁白：短翅膀完成轉向並回到朋友身邊的事件<br>內心：辨認短翅膀當下用途
- 鉤子：—
- 選圖與提純說明：3-5 compact but keep recognition + return; 2-3 telegraph: funny result + short recognition, cut return (below band lower: telegraph landing page)
- 匹配欄：✓

【zh-TW】
噗通！
安安轉了一圈。
咦？翅膀可以轉彎了！安安轉回朋友身邊。

【vi-VN】
TÕM!
An-An xoay một vòng.
Ơ? Cánh biết rẽ rồi! An-An bơi về bên bạn.

### 3-5｜P07（母版 P08）

- 圖說什麼：午後風從左下吹向右上，蘆葦叢 ×2 同向彎向翻頁側；安安在水面朋友 ×2 中間並肩游，寬腳掌向後推水、短翅膀一張一收修正方向，神情被陪伴而逐漸篤定；水面前方低圓石 ×3 排出可通行間距，最大圓石 ×1 位於翻頁側；風帶 ×2 與三鳥游向一致。低視點讓迎面風與彎蘆葦形成可見阻力，朋友仍貼近安安。構圖裝置：對角風壓帶。
- 文說什麼：旁白：朋友仍在兩旁並肩前進的成果前歸屬證據<br>內心：腳掌推水、短翅膀轉向與迎面風組成第三方法<br>時間：午後風勢增強
- 鉤子：—
- 選圖與提純說明：3-5 cut scene description, keep buildup; 2-3 skip P08: P07->P09 three-attempt pattern self-evident, no strategy assembly needed
- 匹配欄：✓

【zh-TW】
朋友們還在身邊。
腳掌推水、翅膀轉彎……
加上風，這次一定可以！

【vi-VN】
Bạn vẫn ở bên.
Bàn chân đạp nước, cánh rẽ hướng…
Thêm gió, lần này nhất định được!

### 3-5｜P08（母版 P09）

- 圖說什麼：第三次試飛仍用固定斜向框架，但量級最大：圓石 ×3 與淺灘在左下，安安沿左下到右上長斜線躍至全頁最高點，身體仍佔畫面高度約四成，寬腳掌剛離水、短翅膀完全張開迎風，兩側翼端顫動線 ×2 清楚可見，嘴張開、目光全力鎖住前方；腳後水花翼 ×2、長直水痕 ×1、彎曲蘆葦叢 ×2 與風帶 ×3 共同放大速度；水面朋友 ×2 緊靠成一組在左下仰望。畫面凍結在安安是否飛起的單一瞬間，動作剪影清楚，焦點只有安安與朋友組。構圖裝置：斜向起飛軸。
- 文說什麼：台詞：招牌疊句第三次；音量與決心達到三次最大<br>擬聲：翅膀試飛 motif 第三次，動作源為完全張開迎風的短翅膀與翼端顫動<br>旁白：腳掌加速、翅膀迎風與躍至最高點的動作中斷
- 鉤子：動作中斷型：安安躍到最高點，結果尚未發生
- 選圖與提純說明：5-6 three elements listed for maximum scale; 3-5 cut element list, keep height + hook; 2-3 telegraph: exclamatory height for hook
- 匹配欄：✓

【zh-TW】
「快一點，快一點，我要飛起來！」
撲撲！
安安跳到最高最高——

【vi-VN】
"Nhanh lên, nhanh lên, mình bay lên nào!"
phập phập!
An-An nhảy lên cao nhất, cao nhất——

### 3-5｜P09（母版 P10）

- 圖說什麼：俯角近看安安安全落回淺灘，圓身佔畫面約五成半，最大水花落成水冠弧 ×1 圍在頭頂；安安垂眼停住、嘴角下沉，但寬腳掌 ×2 仍在推水、短翅膀 ×2 仍一高一低掌方向；身後展開本書目前最大的 V 水紋 ×1；水面朋友 ×2 分別貼近左右兩旁，身體朝向安安、表情關心，形成不離開的安全框。主體動作與表情一眼可讀，朋友兩鳥緊靠安安視為同一焦點群。構圖裝置：向心安全框。
- 文說什麼：擬聲：安全落水 motif 第三次，動作源為身體落回水面的大水花<br>內心：失落後辨認腳掌、短翅膀、大 V 水紋與既有位置<br>旁白：朋友仍留在兩旁的成果前歸屬證據
- 鉤子：—
- 選圖與提純說明：3-5 merge recognition + belonging; 2-3 telegraph: fall + friends remain (core belonging; below band lower: emotional pause page, minimal words by design)
- 匹配欄：✓

【zh-TW】
噗通！
安安停了一下。
可是…… 腳掌還在划，水紋好大。朋友們在旁邊。

【vi-VN】
TÕM!
An-An dừng lại một chút.
Nhưng mà… bàn chân vẫn đạp, vệt nước lớn lắm. Bạn ở ngay bên.

### 3-5｜P10（母版 P11）

- 圖說什麼：金色午後的開闊湖心，安安留在水面朋友 ×2 中間向翻頁側游，三鳥靠得近而沒有排成完整 V；安安寬腳掌穩定推水、短翅膀微張調方向，抬頭嘴微張、露出自在微笑，朋友表情安心；安安身後兩道尚未完成的 V 水紋伸向翻頁側，只畫出靠近安安的前半段，兩個開放端點消失在右頁邊緣，完整隊形尚未出現。三鳥組佔畫面中央約五成，動作同向且輪廓清楚，水紋是方向結構而非新增焦點。構圖裝置：開口 V 引導線。
- 文說什麼：台詞：招牌疊句變奏；由自我催促轉為接納當下並選擇先游<br>內心：辨認已準備好的能力與一直存在的朋友位置<br>擬聲：游出水紋 motif，動作源為寬腳掌穩定推水
- 鉤子：視覺引導型：兩道尚未完成的 V 水紋伸向翻頁側，終點仍在畫外
- 選圖與提純說明：3-5 cut observation triad, straight to smile + variation (below band lower: variation page, refrain is the beat); 2-3 telegraph: cut loạt soạt (swim conveyed by image), keep emotional turn + refrain variation
- 匹配欄：✓

【zh-TW】
安安笑了。
「慢一點，慢一點，我先游起來！」
沙啦——

【vi-VN】
An-An cười rồi.
"Chậm thôi, chậm thôi, mình bơi trước đã!"
loạt soạt——

### 3-5｜P11（母版 P12）

- 圖說什麼：翻頁後直接交付完整雙 V：安安在水面 V 的前端穩定游，水面朋友 ×2 已沿 P11 的兩道水紋分列左右兩臂，三鳥與完整水面 V 水紋 ×1 佔畫面下半約五成；安安用寬腳掌推水、短翅膀微調方向，三鳥都露出驚喜而踏實的笑；天空水鳥 ×5 同時以簡化剪影排成大 V 掠過上方。低水面仰角讓安安成為穩定前進的高光主體；視覺焦點只有水面三鳥 V 與簡化天空 V 兩組。構圖裝置：完整 V 放射。
- 文說什麼：旁白：朋友沿既有水紋完成水面 V 的高潮事件<br>擬聲：游出水紋 motif，動作源為三鳥同步推水<br>內心：以當下能力參與後的驚喜與踏實
- 鉤子：—
- 選圖與提純說明：3-5 cut action description, straight to climax result; 2-3 telegraph: cut loạt soạt, compress to result + double-V declaration
- 匹配欄：✓

【zh-TW】
沙啦—— 朋友們跟著水紋排開了！
天空一個人字，湖面也一個人字。

【vi-VN】
loạt soạt—— bạn bè dàn theo vệt nước rồi!
Trời một chữ V, hồ cũng một chữ V.

### 3-5｜P12（母版 P14）

- 圖說什麼：黃昏湖心通往晨光湖灣的金橘光路佔畫面中央，安安與水面朋友 ×2 仍以小而清楚的 V 向湖灣游回，水面三鳥組佔畫面下方約四成、安安幼年外觀與寬腳掌輪廓仍可辨，三鳥表情安穩滿足；完整水面 V 水紋 ×1 在背後慢慢拉長，天空水鳥 ×5 的遠方 V 位於上方，低岸 ×1、浮葉 ×3 回收 P01。近處水面三鳥 V 與遠方天空剪影 V 形成前後尺度對比；兩個焦點群游回方向清楚，整體色調由金橘過渡到柔紫，視線最後收回畫面中心。構圖裝置：雙 V 回聲。
- 文說什麼：時間：從午後推進到黃昏的後續時間標記<br>旁白：天空與湖面雙 V 回收、自己的時間表與固定收束功能
- 鉤子：—
- 選圖與提純說明：3-5 cut dusk scene sentence, keep closure only (time conveyed by image palette); 2-3 closure split into two short sentences to fit 2-3 band (max_sentence_len 10, max_page_len 18) while preserving double-V echo
- 匹配欄：✓

【zh-TW】
後來呀…… 只要天空游出一個人字，湖面也會跟著游出一個人字。

【vi-VN】
Từ đó về sau… cứ mỗi lần trời vẽ một chữ V, mặt hồ cũng vẽ theo một chữ V.

## 檔位 2-3（10 頁）

### 2-3｜P01（母版 P01）

- 圖說什麼：清晨湖灣的水面中央，小天鵝安安與水面朋友 ×2 緊靠成一組朝翻頁側游；安安披灰褐幼羽、奶油色肚皮、短翅膀與寬腳掌，仰頭露出驚喜嚮往，朋友一淺棕一深灰、身高各約安安的 0.8，神情自在；安安身後有小 V 水紋 ×1，天空水鳥 ×5 排成大 V 掠過，低岸石 ×1、浮葉 ×3 在兩側。水面三鳥組佔畫面下方約四成，輪廓相連且游向清楚；視覺焦點只有水面三鳥組與簡化的天空 V 兩組。構圖裝置：上下雙層三角。
- 文說什麼：旁白：既有朋友關係、天空隊伍出現與水面小 V 的事件建立<br>內心：安安對天空位置的嚮往
- 鉤子：—
- 選圖與提純說明：3-5 compact narration; 2-3 telegraph: action + sky event only (below band lower: telegraph page, 2 beats sufficient for toddler)
- 匹配欄：✓

【zh-TW】
安安和朋友一起游。
天空飛過人字隊！

【vi-VN】
An-An bơi cùng bạn.
Chữ V bay qua trời!

### 2-3｜P02（母版 P03）

- 圖說什麼：第一次試飛採固定斜向框架：低岸石 ×1 在左下、翻頁側開放天空在右上；安安佔畫面高度約一半，寬腳掌剛蹬離石面，身體沿左下到右上的短斜線躍起，短翅膀正用力拍動並帶弧形動勢線 ×2，嘴張開、眼睛發亮又緊張；水面朋友 ×2 緊靠成一組在右下抬頭，表情期待；水面小 V 水紋 ×1 留在後方。主體動作輪廓完整，焦點只有安安與朋友組。構圖裝置：斜向起飛軸。
- 文說什麼：台詞：招牌疊句首次；催促自己起飛的功能<br>擬聲：翅膀試飛 motif 首次，動作源為拍動短翅膀
- 鉤子：—
- 選圖與提純說明：3-5 cut result sentence (page turn delivers it); 2-3 telegraph: refrain + SFX only
- 匹配欄：✓

【zh-TW】
「快一點，快一點，我要飛起來！」
撲撲！

【vi-VN】
"Nhanh lên, nhanh lên, mình bay lên nào!"
phập phập!

### 2-3｜P03（母版 P04）

- 圖說什麼：俯角近看安安安全落在湖面中央，圓身佔插圖約六成，浮葉 ×1 正停在頭頂，安安瞪圓眼、咧嘴笑；寬腳掌 ×2 在清水中張開托穩身體，腳後划出小 V 水紋 ×1；水面朋友 ×2 緊靠在右側成一組，笑著朝安安游近但沒有嘲笑姿態；其餘浮葉 ×2 疏落在大片留白水面。主體輪廓大而完整，焦點只有安安與朋友組。構圖裝置：中央主體留白。
- 文說什麼：擬聲：安全落水 motif 第一次，動作源為身體落回水面<br>擬聲：游出水紋 motif，動作源為寬腳掌推水<br>內心：辨認腳掌當下用途與重新有勁
- 鉤子：—
- 選圖與提純說明：5-6 full body-awareness beat; 3-5 keep feet + return (below band lower: landing pages are naturally short -- SFX + result); 2-3 telegraph: result + return
- 匹配欄：✓

【zh-TW】
噗通！
腳掌接住了。安安游回朋友身邊。

【vi-VN】
TÕM!
Bàn chân đỡ rồi. An-An bơi về bên bạn.

### 2-3｜P04（母版 P06）

- 圖說什麼：第二次試飛沿用固定斜向框架：安安從左下水面朝右上翻頁側加速，身體佔畫面約五成，寬腳掌向後猛推、胸口剛抬離水面，短翅膀快速撲動保持平衡，兩側翼端動勢線 ×2 清楚可見，嘴張開、眉眼快樂又急促；左右水花帶 ×2 比 P03 更長，尾後直水紋 ×1；水面朋友 ×2 緊靠成一組在左後方追隨，表情專注；兩岸蘆葦叢 ×2 模糊後退。主體動作由腳掌、身體前傾與翅膀撲動形成大輪廓，焦點只有安安與朋友組。構圖裝置：斜向起飛軸。
- 文說什麼：台詞：招牌疊句第二次；速度與急促度升級<br>擬聲：翅膀試飛 motif 第二次，動作源為快速撲動的短翅膀與翼端動勢<br>旁白：腳掌加速與水面助跑的事件推進
- 鉤子：—
- 選圖與提純說明：3-5 cut intent clause (below band lower: refrain + action pages are structurally compact); 2-3 telegraph same as P03 (visual difference carried by illustration)
- 匹配欄：✓

【zh-TW】
「快一點，快一點，我要飛起來！」
撲撲！

【vi-VN】
"Nhanh lên, nhanh lên, mình bay lên nào!"
phập phập!

### 2-3｜P05（母版 P07）

- 圖說什麼：俯角近看安安胸口剛貼回水面並轉出小圓圈，圓身佔插圖約六成，兩隻短翅膀一高一低調整方向，眼睛瞪圓、視線落向水紋，表情若有所思；圓形水紋 ×1 與小水花圈 ×1 包住安安，水面朋友 ×2 緊靠在圓圈開口外等她，表情溫和；蘆葦叢 ×1 位於翻頁側。主體輪廓大，轉向由全身弧線可直接指認，焦點只有安安與朋友組。構圖裝置：同心圓旋軸。
- 文說什麼：擬聲：安全落水 motif 第二次，動作源為胸口貼回水面的小水花<br>旁白：短翅膀完成轉向並回到朋友身邊的事件<br>內心：辨認短翅膀當下用途
- 鉤子：—
- 選圖與提純說明：3-5 compact but keep recognition + return; 2-3 telegraph: funny result + short recognition, cut return (below band lower: telegraph landing page)
- 匹配欄：✓

【zh-TW】
噗通！
安安轉了一圈。翅膀會轉彎了！

【vi-VN】
TÕM!
An-An xoay một vòng. Cánh biết rẽ rồi!

### 2-3｜P06（母版 P09）

- 圖說什麼：第三次試飛仍用固定斜向框架，但量級最大：圓石 ×3 與淺灘在左下，安安沿左下到右上長斜線躍至全頁最高點，身體仍佔畫面高度約四成，寬腳掌剛離水、短翅膀完全張開迎風，兩側翼端顫動線 ×2 清楚可見，嘴張開、目光全力鎖住前方；腳後水花翼 ×2、長直水痕 ×1、彎曲蘆葦叢 ×2 與風帶 ×3 共同放大速度；水面朋友 ×2 緊靠成一組在左下仰望。畫面凍結在安安是否飛起的單一瞬間，動作剪影清楚，焦點只有安安與朋友組。構圖裝置：斜向起飛軸。
- 文說什麼：台詞：招牌疊句第三次；音量與決心達到三次最大<br>擬聲：翅膀試飛 motif 第三次，動作源為完全張開迎風的短翅膀與翼端顫動<br>旁白：腳掌加速、翅膀迎風與躍至最高點的動作中斷
- 鉤子：動作中斷型：安安躍到最高點，結果尚未發生
- 選圖與提純說明：5-6 three elements listed for maximum scale; 3-5 cut element list, keep height + hook; 2-3 telegraph: exclamatory height for hook
- 匹配欄：✓

【zh-TW】
「快一點，快一點，我要飛起來！」
撲撲！
好高好高——

【vi-VN】
"Nhanh lên, nhanh lên, mình bay lên nào!"
phập phập!
Cao quá, cao quá——

### 2-3｜P07（母版 P10）

- 圖說什麼：俯角近看安安安全落回淺灘，圓身佔畫面約五成半，最大水花落成水冠弧 ×1 圍在頭頂；安安垂眼停住、嘴角下沉，但寬腳掌 ×2 仍在推水、短翅膀 ×2 仍一高一低掌方向；身後展開本書目前最大的 V 水紋 ×1；水面朋友 ×2 分別貼近左右兩旁，身體朝向安安、表情關心，形成不離開的安全框。主體動作與表情一眼可讀，朋友兩鳥緊靠安安視為同一焦點群。構圖裝置：向心安全框。
- 文說什麼：擬聲：安全落水 motif 第三次，動作源為身體落回水面的大水花<br>內心：失落後辨認腳掌、短翅膀、大 V 水紋與既有位置<br>旁白：朋友仍留在兩旁的成果前歸屬證據
- 鉤子：—
- 選圖與提純說明：3-5 merge recognition + belonging; 2-3 telegraph: fall + friends remain (core belonging; below band lower: emotional pause page, minimal words by design)
- 匹配欄：✓

【zh-TW】
噗通！
安安停了一下。朋友們還在旁邊。

【vi-VN】
TÕM!
An-An dừng lại. Bạn vẫn ở bên.

### 2-3｜P08（母版 P11）

- 圖說什麼：金色午後的開闊湖心，安安留在水面朋友 ×2 中間向翻頁側游，三鳥靠得近而沒有排成完整 V；安安寬腳掌穩定推水、短翅膀微張調方向，抬頭嘴微張、露出自在微笑，朋友表情安心；安安身後兩道尚未完成的 V 水紋伸向翻頁側，只畫出靠近安安的前半段，兩個開放端點消失在右頁邊緣，完整隊形尚未出現。三鳥組佔畫面中央約五成，動作同向且輪廓清楚，水紋是方向結構而非新增焦點。構圖裝置：開口 V 引導線。
- 文說什麼：台詞：招牌疊句變奏；由自我催促轉為接納當下並選擇先游<br>內心：辨認已準備好的能力與一直存在的朋友位置<br>擬聲：游出水紋 motif，動作源為寬腳掌穩定推水
- 鉤子：視覺引導型：兩道尚未完成的 V 水紋伸向翻頁側，終點仍在畫外
- 選圖與提純說明：3-5 cut observation triad, straight to smile + variation (below band lower: variation page, refrain is the beat); 2-3 telegraph: cut loạt soạt (swim conveyed by image), keep emotional turn + refrain variation
- 匹配欄：✓

【zh-TW】
安安笑了。
「慢一點，慢一點，我先游起來！」

【vi-VN】
An-An cười rồi.
"Chậm thôi, chậm thôi, mình bơi trước đã!"

### 2-3｜P09（母版 P12）

- 圖說什麼：翻頁後直接交付完整雙 V：安安在水面 V 的前端穩定游，水面朋友 ×2 已沿 P11 的兩道水紋分列左右兩臂，三鳥與完整水面 V 水紋 ×1 佔畫面下半約五成；安安用寬腳掌推水、短翅膀微調方向，三鳥都露出驚喜而踏實的笑；天空水鳥 ×5 同時以簡化剪影排成大 V 掠過上方。低水面仰角讓安安成為穩定前進的高光主體；視覺焦點只有水面三鳥 V 與簡化天空 V 兩組。構圖裝置：完整 V 放射。
- 文說什麼：旁白：朋友沿既有水紋完成水面 V 的高潮事件<br>擬聲：游出水紋 motif，動作源為三鳥同步推水<br>內心：以當下能力參與後的驚喜與踏實
- 鉤子：—
- 選圖與提純說明：3-5 cut action description, straight to climax result; 2-3 telegraph: cut loạt soạt, compress to result + double-V declaration
- 匹配欄：✓

【zh-TW】
朋友們排好了！
天空一個人字，湖面也一個人字！

【vi-VN】
Bạn bè dàn ra rồi!
Trời một chữ V, hồ cũng một chữ V!

### 2-3｜P10（母版 P14）

- 圖說什麼：黃昏湖心通往晨光湖灣的金橘光路佔畫面中央，安安與水面朋友 ×2 仍以小而清楚的 V 向湖灣游回，水面三鳥組佔畫面下方約四成、安安幼年外觀與寬腳掌輪廓仍可辨，三鳥表情安穩滿足；完整水面 V 水紋 ×1 在背後慢慢拉長，天空水鳥 ×5 的遠方 V 位於上方，低岸 ×1、浮葉 ×3 回收 P01。近處水面三鳥 V 與遠方天空剪影 V 形成前後尺度對比；兩個焦點群游回方向清楚，整體色調由金橘過渡到柔紫，視線最後收回畫面中心。構圖裝置：雙 V 回聲。
- 文說什麼：時間：從午後推進到黃昏的後續時間標記<br>旁白：天空與湖面雙 V 回收、自己的時間表與固定收束功能
- 鉤子：—
- 選圖與提純說明：3-5 cut dusk scene sentence, keep closure only (time conveyed by image palette); 2-3 closure split into two short sentences to fit 2-3 band (max_sentence_len 10, max_page_len 18) while preserving double-V echo
- 匹配欄：✓

【zh-TW】
後來呀…… 只要天空游出一個人字，湖面也會跟著游出一個人字。

【vi-VN】
Từ đó về sau… trời vẽ chữ V. Hồ cũng vẽ chữ V.

