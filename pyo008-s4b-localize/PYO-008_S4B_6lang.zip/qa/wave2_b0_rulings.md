# Wave 2 B0 Rulings — PYO-008 The Little Swan Grows in Time

```yaml
schema: piyo_b0_rulings/v1
book_id: PYO-008
wave: 2
lanes: [th-TH, vi-VN]
date: 2026-07-22
```

## 凍結字串表

| # | 泳道 | 類型 | 凍結字串 | 用法 |
|---|---|---|---|---|
| F1 | th-TH | character-name | `น้องอัน` | 全書 |
| F2 | th-TH | refrain-main | `เร็ว ๆ เร็ว ๆ หนูจะบินให้ได้!` | P03, P06, P09 |
| F3 | th-TH | refrain-variation | `ช้า ๆ ช้า ๆ หนูจะว่ายก่อนนะ!` | P11 |
| F4 | th-TH | sfx-wing-flap | `พับ ๆ ๆ` | P03, P06, P09 |
| F5 | th-TH | sfx-water-landing | `จ๋อม!` | P04, P07, P10 |
| F6 | th-TH | sfx-water-wake | `ซ่า ๆ` | P04, P05, P11, P12 |
| F7 | th-TH | ending-formula | `ต่อจากนั้นนะคะ… ทุกครั้งที่ท้องฟ้ามีตัว V ผิวน้ำก็จะมีตัว V ตามไปด้วยค่ะ` | P14 |
| F8 | vi-VN | character-name | `An-An` | 全書（首次出場 `Thiên nga nhỏ An-An`） |
| F9 | vi-VN | refrain-main | `Nhanh lên, nhanh lên, mình bay lên nào!` | P03, P06, P09 |
| F10 | vi-VN | refrain-variation | `Chậm thôi, chậm thôi, mình bơi trước đã!` | P11 |
| F11 | vi-VN | sfx-wing-flap | `phập phập!` | P03, P06, P09 |
| F12 | vi-VN | sfx-water-landing | `TÕM!` | P04, P07, P10 |
| F13 | vi-VN | sfx-water-wake | `loạt soạt——` | P04, P05, P11, P12 |
| F14 | vi-VN | ending-formula | `Từ đó về sau… cứ mỗi lần trời vẽ một chữ V, mặt hồ cũng vẽ theo một chữ V.` | P14 |

## B0 快審結果

- th-TH：PASS — 泰文 reduplication 語感到位，น้อง 前綴符合兒童書慣例，หนู 自稱溫暖
- vi-VN：PASS — 越南文 từ láy 擬聲詞自然，mình 北方兒童自稱，đã 接納語氣詞恰當

## golden 句式衝突

無。

## ⏸️ 上呈事項

- vi-VN 2-3 收束式 F14（22 tiếng）可能超出單頁上限 18 tiếng——結構性承諾同 zh-TW，QA 確認
