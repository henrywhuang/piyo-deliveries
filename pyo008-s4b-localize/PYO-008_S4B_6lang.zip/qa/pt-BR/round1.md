# QA 報告：the-little-swan-grows-in-time / pt-BR / round 1

```yaml
schema: piyo_text_qa_report/v0.9
slug: the-little-swan-grows-in-time
locale: pt-BR
tiers: ["2-3", "3-5", "5-6"]
round: 1
date: "2026-07-21"
step1_lint: {exit_code: 0, warnings: 16}
step2_checklist: {pass: 28, fail: 0}
step3_personas:
  - id: pt-BR-professora
    scores: {年齡適配度: 8, 巴西語感: 9, 孩子抓得住度: 8}
  - id: pt-BR-mae
    scores: {睡前適讀性: 9, 零說教: 10}
  - id: pt-BR-editora
    scores: {母語自然度: 8, 文字工藝: 8}
step4_triage: {real: 0, rejected: 3, escalated: 0}
verdict: pass
```

## STEP 1 機檢

### 命令與結果

```
python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-008_the-little-swan-grows-in-time/text/pt-BR/5-6.draft.json --locale pt-BR --band 5-6
→ exit 0, warnings 5（全為 repeat_discount 資訊行）

python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-008_the-little-swan-grows-in-time/text/pt-BR/3-5.draft.json --locale pt-BR --band 3-5
→ exit 0, warnings 6（全為 repeat_discount 資訊行）

python3 knowledge_base/tools/locale_lint.py --pages-file content/PYO-008_the-little-swan-grows-in-time/text/pt-BR/2-3.draft.json --locale pt-BR --band 2-3
→ exit 0, warnings 5（全為 repeat_discount 資訊行）
```

三檔位均 exit 0，無違規。16 筆警告全為疊句折計資訊（repeat_discount），屬預期行為：疊句「Mais rápido, mais rápido, eu vou voar!」×3、「plap, plap, plap!」×3、「TCHIBUM!」×3、「xá, xá, xá!」×2-3 等為設計宣告的招牌疊句與擬聲 motif，折計後各檔位總量均在門檻內。

警告判讀：全數保留，不構成任何行動項——疊句重複是 design.md 趣味設計宣告的核心兌現。

### STEP 1 結論
通過。

---

## STEP 2 checklist 自檢

**主題錨復述句**：本書教的是自我接納——小天鵝 Ani 急著要飛上天空的 V 字隊，三次提早起飛都安全落回水面朋友身邊；她最終看見自己的腳掌和翅膀已經能做什麼，選擇以「慢一點，慢一點，我要游了！」留在當下已有的位置，水面也游出了完整的 V 字。賣點是「差異不必消失才有歸屬」與「每個生命有自己的時間表」。

### A）故事結構（5 項）

| 項 | 5-6 | 3-5 | 2-3 | 判定 | 證據 |
|---|---|---|---|---|---|
| A-1 完整弧線 | 通過 | 通過 | 通過 | 通過 | 觸發事件（P01 天空 V 字隊）→ 上升動作（三次嘗試 P03/P06/P09）→ 高潮（P12 雙 V）→ 收束（P14「E desde aquele dia…」）三檔齊備 |
| A-2 衝突有份量 | 通過 | 通過 | 通過 | 通過 | 三次落水跨 P03-P10（5-6）/ P02-P09（3-5）/ P02-P07（2-3），每次 Ani 付出具體行動（蹬石跳、水上助跑、全力迎風跳）|
| A-3 情緒有起伏 | 通過 | 通過 | 通過 | 通過 | 清晰轉折：5-6 P10「Ani parou. Baixou os olhos.」→ P11「Então sorriu de um jeito novo.」 |
| A-4 結尾有回響 | 通過 | 通過 | 通過 | 通過 | 圓滿式呼應開頭（P01 天空 V → P14 天空與湖面雙 V）＋收束式「E desde aquele dia…」；末頁無旁白直述教訓 |
| A-5 開場有鉤子 | 通過 | 通過 | 通過 | 通過 | P01 反常型：Ani 已在水面朋友間游卻只看天空（design 宣告：反常型 P01）；5-6「Ani levantou o biquinho e pensou: — Eu também quero ir lá em cima!」 |

### B）語言文字（5 項）

| 項 | 5-6 | 3-5 | 2-3 | 判定 | 證據 |
|---|---|---|---|---|---|
| B-1 每頁字數 | N/A(量化) | N/A(量化) | N/A(量化) | N/A(量化) | STEP 1 機檢已判 |
| B-2 句長配情緒 | 通過 | 通過 | 通過 | 通過 | 緊張短句：5-6 P10「Ani parou.」(2w)、P04「TCHIBUM!」(1w)；溫暖長句：5-6 P14「sempre que um V voou no céu, um V nadou no lago.」(14w)。2-3 全篇短句為合法電報式（W7） |
| B-3 聲音裝置 | 通過 | 通過 | 通過 | 通過 | 三組擬聲 motif（plap/TCHIBUM/xá）＋疊句韻律（Mais rápido/Devagar）；plap ×3、TCHIBUM ×3、xá ×4（5-6）均不超過 craft C2 配額 |
| B-4 對話比例 | 通過 | 通過 | tier-N/A | 通過 | 5-6/3-5 台詞行（travessão 開頭）與旁白均衡；2-3 以旁白與擬聲為主，低幼檔旁白為主合法 |
| B-5 無百科腔 | 通過 | 通過 | 通過 | 通過 | 全書無知識灌輸句式 |

### C）角色塑造（4 項）

| 項 | 5-6 | 3-5 | 2-3 | 判定 | 證據 |
|---|---|---|---|---|---|
| C-1 主角有辨識度 | 通過 | 通過 | 通過 | 通過 | Ani 的區分性特質（急著飛上天空）透過行為呈現：三次嘗試起飛、每次落水後回到朋友身邊 |
| C-2 成長弧線完整 | 通過 | 通過 | 通過 | 通過 | 缺陷（急著離開水面朋友去飛）→ 觸發事件（三次落水看見腳掌/翅膀的功用）→ 行為轉變（P11「Devagar, devagar, eu vou nadar!」選擇留在當下）|
| C-3 障礙有阻力 | 通過 | 通過 | 通過 | 通過 | 內在障礙（催促自己提早飛）阻擋三次，每次方法不同但都未飛起 |
| C-4 配角有功能 | 通過 | 通過 | 通過 | 通過 | 朋友 ×2 作鏡像者：始終留在旁邊（P10「Os amigos continuavam ali, um de cada lado.」），不說教不阻止 |

### D）圖文配合（4 項）

| 項 | 5-6 | 3-5 | 2-3 | 判定 | 證據 |
|---|---|---|---|---|---|
| D-1 圖文關係多元 | stage-N/A | stage-N/A | stage-N/A | stage-N/A | 待媒體線補檢 |
| D-2 圖畫承載資訊 | stage-N/A | stage-N/A | stage-N/A | stage-N/A | 待媒體線補檢 |
| D-3 視覺風格一致 | stage-N/A | stage-N/A | stage-N/A | stage-N/A | 待媒體線補檢 |
| D-4 翻頁有牽引 | 通過 | 通過 | tier-N/A | 通過 | 5-6 P09 動作中斷型「e saltou — mais alto que todas as outras vezes!」（凍結最高點）；3-5 P08 同形。2-3 翻頁由疊句自然牽引但無文字三型 hook → tier-N/A |

### E）主題思想（4 項）

| 項 | 5-6 | 3-5 | 2-3 | 判定 | 證據 |
|---|---|---|---|---|---|
| E-1 主題由行動呈現 | 通過 | 通過 | 通過 | 通過 | 自我接納由 Ani 選擇不再催促自己飛、改說「Devagar, devagar, eu vou nadar!」自然浮現，零旁白說教 |
| E-2 情感共鳴可達 | 通過 | 通過 | 通過 | 通過 | 5-6 P10「Ani parou. Baixou os olhos.」場景呈現失落；P11「sorriu de um jeito novo」行為呈現發現 |
| E-3 末頁無教訓宣言 | 通過 | 通過 | 通過 | 通過 | P14「E desde aquele dia… Um V voou. Um V nadou.」為收束式，無教訓句 |
| E-4 抽象度匹配年齡 | 通過 | 通過 | 通過 | 通過 | 2-3 無抽象概念詞；5-6 P08「juntou tudo para uma terceira tentativa」由具體行動支撐 |

### 快速掃描清單（9 項文本階段適用）

| # | 判定 | 證據 |
|---|---|---|
| 1 無說教 | 通過 | 全書零旁白教訓句 |
| 2 衝突跨頁 | 通過 | 三次嘗試跨 7+ 頁 |
| 3 情緒轉折 | 通過 | P10→P11 低谷→自在 |
| 4 字數門檻 | N/A(量化) | STEP 1 |
| 5 開場鉤子 | 通過 | P01 反常型 |
| 6 主角行為 | 通過 | 三次起飛行為呈現 |
| 7 圖文關係 | stage-N/A | 待媒體線 |
| 8 翻頁 hook | 通過 | P09 動作中斷型（5-6/3-5） |
| 9 聲音裝置 | 通過 | 三組 motif |
| 10 末頁無教訓 | 通過 | 收束式 |

**文本階段適用項合計**：A-E 19 項適用中 19 項通過（含 2 項 N/A(量化)、1 項 tier-N/A 附依據）＋快速掃描 9 項適用中 9 項通過（含 1 項 N/A(量化)）＝**28 pass, 0 fail**。

### 趣味設計兌現比對

| 宣告 | 兌現 | 判定 |
|---|---|---|
| 開場鉤子：反常型 P01 | P01 Ani 已在朋友間游卻抬頭追天空，切合反常（明明已有位置卻只看上方） | 通過 |
| 疊句：P03/P06/P09 首三次＋P11 變奏 | 5-6 P03/P06/P09「Mais rápido, mais rápido, eu vou voar!」×3；P11「Devagar, devagar, eu vou nadar!」變奏。3-5/2-3 頁位對應一致 | 通過 |
| 翻頁 hook P05 視覺引導型 | stage-N/A（文本階段不判視覺引導型） | stage-N/A |
| 翻頁 hook P09 動作中斷型 | 5-6 P09「e saltou — mais alto que todas as outras vezes!」凍結跳躍最高點 | 通過 |
| 翻頁 hook P11 視覺引導型 | stage-N/A | stage-N/A |
| 擬聲 motif：翅膀試飛→plap | plap, plap, plap! ×3（P03/P06/P09）僅配翅膀拍動，全書一致 | 通過 |
| 擬聲 motif：安全落水→TCHIBUM | TCHIBUM! ×3（P04/P07/P10）僅配落水，全書一致 | 通過 |
| 擬聲 motif：游出水紋→xá | xá, xá, xá! 出現 P04/P05/P11/P12（5-6），配游水推水，≤4 次 | 通過 |
| 高潮 P12 情緒翻轉 | 5-6 P12「Lá no alto, o V do céu passou de novo. E no lago, também havia um V — completo.」雙 V 交付，怕趕不上→願意留在當下 | 通過 |
| 幽默 P04 配件錯位 | 5-6 P04「uma folhinha pousou na cabeça dela!」浮葉停頭頂 | 通過 |
| 幽默 P07 方向反轉 | 5-6 P07「girou no mesmo lugar, fazendo uma rodinha!」原地轉圈 | 通過 |
| 幽默 P10 規模升級 | 5-6 P10「A maior onda de todas caiu sobre a cabeça de Ani, como uma coroinha de água brilhante.」水冠 | 通過 |
| 收束式 | 三檔末頁「E desde aquele dia…」＋「Um V voou. Um V nadou.」 | 通過 |

設計外新增：無。

### 對位逐頁比對

逐頁比對 pt-BR 文字是否重述 storyboard「圖說什麼」已明示的視覺事實。判準＝刪掉這句，閉眼聽的人會不會漏掉情節。

**5-6 檔位**

| 頁 | 判定 | 說明 |
|---|---|---|
| P01 | 通過 | 「Era uma vez uma manhã quietinha no lago」建立時間（文字負載）；「deixando um rastro em V na água」描述水紋是事件建立，聽者需此資訊（V 字隊／V 水紋是全書核心隱喻） |
| P02 | 通過 | 事件推進：登石、張翅、伸頸 |
| P03 | 通過 | 台詞＋擬聲，文字專屬負載 |
| P04 | 通過 | 擬聲＋內心＋事件 |
| P05 | 通過 | 旁白事件＋擬聲 |
| P06 | 通過 | 台詞＋擬聲＋事件推進 |
| P07 | 通過 | 擬聲＋事件＋內心 |
| P08 | 通過 | 旁白事件＋內心＋時間標記 |
| P09 | 通過 | 台詞＋擬聲＋事件 |
| P10 | 通過 | 擬聲＋內心＋旁白 |
| P11 | 通過 | 台詞變奏＋擬聲＋內心 |
| P12 | 通過 | 旁白高潮事件＋擬聲 |
| P13 | 通過 | 旁白結果確認（「ainda tinha as mesmas peninhas cinza, a barriguinha cor de creme」確認外觀未變＝核心主題兌現——閉眼聽者需此確認，非屬性重述） |
| P14 | 通過 | 時間＋收束式 |

**3-5 檔位**：同向，逐頁皆通過。
**2-3 檔位**：同向，逐頁皆通過。全篇電報式負載精確。

對位結論：零違反。

### Concept fidelity 逐檔判定

| 檔位 | 判定 | 說明 |
|---|---|---|
| 5-6 | 通過 | 講完後孩子帶走的是「每個生命有自己的時間表」——Ani 選擇不再催促自己飛、以現在能做到的游水方式留在朋友間，水面 V 自然成形。文字趣味（三次落水的幽默遞進、水紋越來越大的視覺隱喻）全數服務主題 |
| 3-5 | 通過 | 精簡但主題鏈完整：三次嘗試→三次落水→看見腳掌/翅膀→改說慢一點→雙 V |
| 2-3 | 通過 | 電報式但因果完整：疊句×3→TCHIBUM×3→朋友還在→改說慢一點→雙 V |

### 回譯偏移標記

回譯覆蓋策略：結構頁全量＋觸發補譯（S4B）。結構頁集合＝{P01, P03, P05, P06, P09, P11, P12, P14}。

全部結構頁回譯偏移標記＝「無」（21 筆回譯行，三檔合計）。改編在語義層準確還原 zh-TW 母本的 beat 負載，無中度或以上偏移。

### ESL 獵手（pt-BR 雷區）

**主題錨復述句**：本書主題是自我接納——Ani 急著飛上天空，三次落回水面後發現自己的腳掌和翅膀當下已能做什麼，選擇留在朋友間游水。

**獵物①靶區＝pt-BR spec 雷區（歐葡滲漏）**

全文逐頁掃描，對照 spec 第 2-5 段紅線：

| 檢查項 | 結果 |
|---|---|
| R2-1 tu/第二人稱變位 | 零出現。通篇用 você 系（「Eu também quero」「Meus pés já sabem」均第一人稱） |
| R2-2 estar a + infinitivo | 零出現。進行體均用 gerúndio（「nadava」「empurrando」「ajustando」「batendo」「fazendo」「nadando」） |
| R2-3 diminutivos | 自然使用：「quietinha」「juntinhos」「biquinho」「pedrinha」「folhinha」「direitinho」「rodinha」「coroinha」「peninhas」「barriguinha」「asinhas」「juntinho」——分佈自然，未見同句堆疊，BR 兒語溫度到位 |
| R2-4 代詞位置 | 對話 proclisis 自然（「— Eu também quero」「— Meus pés já sabem」），零 ênclise 開場 |
| R2-5 旁白語體 | norma culta 輕量版（「Era uma vez」開場公式）＋自然口語感嘆（「Mas olha só:」P04） |
| P5-1 travessão | 對話全用 em dash「— 」開頭，零引號對話 |
| P5-4 AO1990 | 未見舊拼形 |
| P5-5 變音符號 | 全數書寫完整（ã, é, ê, á, â, ó, í, ú, ç 均出現且正確） |
| P5-6 ¡ ¿ | 零出現 |
| banned_terms | 全書逐頁掃描，零命中（無 rapariga/comboio/autocarro/telemóvel 等歐葡詞） |
| banned_chars | 零命中（無全形空白、CJK 標點、ü、波狀符） |

**結論①**：零歐葡滲漏發現。

**獵物②靶區＝AI 機械句（style_guide §3.4 四型）**

| 型 | 結果 |
|---|---|
| 電報式裸動詞堆疊 | 2-3 檔極簡句（「Os pés seguraram Ani. Ani voltou.」「TCHIBUM! Ani parou. Os amigos ficaram perto.」）為合法電報式（W7 邊界：有收束拍點「Ani voltou」、「Os amigos ficaram perto」設計性片段句） |
| 成分懸空 | 零發現。動詞搭配完整（「empurravam a água」「ajustavam a direção」「bateram com toda a força」） |
| 超規律平行 | 疊句逐字一致為設計；敘事句無模板複製（三次落水段各有不同描寫） |
| 無語氣詞乾句 | BR 語氣標記自然分佈：「Mas olha só:」（P04 驚喜語氣）、感嘆號用於適當位置、diminutivos 本身即溫度標記 |

**結論②**：零 AI 機械句發現。

**en-US 定稿二手錨定檢查**（獵手是唯一拿多語對讀的審者）：pt-BR 文本獨立於 en-US 定稿，未見句句對位的翻譯對齊痕跡。盲稿讀序聲明合理——pt-BR 版的句子結構、diminutivo 用法與行文節奏不像從英文逐句翻譯。

---

## STEP 3 人設 blind QA

### pt-BR-professora（Professora Ana Clara）

**逐句挑錯表**

| 檔位 | 頁 | 原句（節錄） | 問題描述 | 嚴重度 | 建議改法 |
|---|---|---|---|---|---|
| 5-6 | P01 | A pequena cisne Ani | 「cisne」在巴西通用為陽性（o cisne），用 feminine「a cisne」不常見 | 低 | 可保留——作者刻意將 cisne 當陰性使用，配合 Ani 為女性角色；巴西文學允許此用法（動物角色性別化） |
| 5-6 | P08 | Ani juntou tudo para uma terceira tentativa | 「terceira tentativa」稍進階但 5-6 檔合法 | 低 | 可保留 |
| 5-6 | P13 | as ondas se relaxaram em três linhas paralelas | 「se relaxaram」稍文學但 5-6 檔適配 | 低 | 可保留 |

**分檔評分**

| 維度 | 5-6 | 3-5 | 2-3 | 摘要（最弱） |
|---|---|---|---|---|
| 年齡適配度 | 8 | 9 | 8 | 8 |
| 巴西語感 | 9 | 9 | 9 | 9 |
| 孩子抓得住度 | 8 | 9 | 8 | 8 |

年齡適配度 8（5-6/2-3）：5-6 有個別偏成人化表達（「terceira tentativa」P08）但 5-6 允許；2-3 檔精簡到位但 P03「Os pés seguraram Ani」稍抽象（3 歲可能不理解「pés seguraram」＝腳掌穩住了她），品味級。3-5 幾乎完美。

巴西語感 9：通篇聽不出翻譯腔，diminutivos 自然，「Mas olha só:」是典型 BR 說書人口吻。差 1 分只因是機器生成文本的保守扣分。

孩子抓得住度 8（5-6）：三次嘗試的遞進結構勾人，疊句易接。5-6 P08 是全書最平的一頁（過渡蓄勢頁），但有「vento de frente」蓄勢。2-3 的 P07「Ani parou. Os amigos ficaram perto.」很短但情緒轉折到位。

---

### pt-BR-mae（Camila）

**逐句挑錯表**

| 檔位 | 頁 | 原句（節錄） | 問題描述 | 嚴重度 | 建議改法 |
|---|---|---|---|---|---|
|（無發現）| | | | | |

全篇零發現。睡前安全感到位（三次落水都安全、朋友始終在旁）；零說教（Ani 自己選擇「Devagar, devagar」，無旁白教訓）；2-3 檔有搖籃曲式重複（三次疊句＋三次 TCHIBUM）；收尾「Um V voou. Um V nadou.」有餘韻的溫暖。

**分檔評分**

| 維度 | 5-6 | 3-5 | 2-3 | 摘要（最弱） |
|---|---|---|---|---|
| 睡前適讀性 | 9 | 9 | 9 | 9 |
| 零說教 | 10 | 10 | 10 | 10 |

睡前適讀性 9：三檔均收尾回暖，緊張段落（落水）以幽默降壓（浮葉停頭頂、轉小圓圈、水冠），結尾「Um V voou. Um V nadou.」節奏放緩如搖籃。差 1 分是 5-6 P10 的低谷拍（Baixou os olhos）停一拍後立刻由「Mas os pés largos ainda empurravam」接住，處理到位但該頁較長。

零說教 10：全書教訓完全由 Ani 行為承載，旁白層零教訓句。

---

### pt-BR-editora（Editora Beatriz）

**逐句挑錯表**

| 檔位 | 頁 | 原句（節錄） | 問題描述 | 嚴重度 | 建議改法 |
|---|---|---|---|---|---|
| 5-6 | P01 | A pequena cisne Ani | 「a cisne」非標準——cisne 在大多數巴西出版物為陽性 | 低 | 可保留為品牌決策：角色性別化是兒童繪本慣例（A Dona Aranha 蜘蛛也陰性化），且全書統一 |
| 5-6 | P04 | Mas olha só: os pés largos já estavam firmes | 「Mas olha só:」冒號後接子句，正字法嚴格看可用逗號 | 低 | 可保留——童書旁白口吻，冒號作語氣停頓合法 |
| 5-6 | P13 | as ondas se relaxaram em três linhas paralelas | 「ondas se relaxaram」擬人化稍文學 | 低 | 可保留——5-6 檔允許輕度文學表達 |

**分檔評分**

| 維度 | 5-6 | 3-5 | 2-3 | 摘要（最弱） |
|---|---|---|---|---|
| 母語自然度 | 8 | 9 | 8 | 8 |
| 文字工藝 | 9 | 8 | 8 | 8 |

母語自然度 8（5-6/2-3）：5-6 幾乎完全像巴西原創，只有「a cisne」一處可議但可接受；2-3 的極簡風格自然但缺少 BR 語氣詞（低幼檔合法限制）。3-5 是甜蜜點。

文字工藝 9（5-6）：疊句韻律設計出色（「Mais rápido, mais rápido, eu vou voar!」→「Devagar, devagar, eu vou nadar!」完美功能轉折）；三次落水描寫各有變奏避免重複疲勞；收束句「Um V voou. Um V nadou.」結構對仗有力。3-5 精簡得好但少了 5-6 的文學層次；2-3 有效但工藝空間有限。

---

## STEP 4 三分法分診

**主題錨復述句**：本書教的是自我接納——每個生命有自己的時間表。小天鵝 Ani 急著飛進天空 V 字隊，三次落回水面後看見腳掌和翅膀已能做什麼，選擇以「慢一點，慢一點，我要游了！」留在朋友間，水面自然游出完整 V 字。

### 裁決對象

人設發現（3 筆）＋STEP 2 轉入項（0 筆）＋回譯偏移（0 筆）＋獵手發現（0 筆）＝共 3 筆。

| # | 來源 | 檔位 | 頁 | 發現 | 裁決 | 修改級別 | 收斂計數 | 依據 |
|---|---|---|---|---|---|---|---|---|
| 1 | pt-BR-professora＋pt-BR-editora | 5-6 | P01 | 「a cisne」陰性用法非標準 | ❌ | — | 2路 | 角色性別化是兒童繪本慣例（巴西：A Dona Aranha、A Coruja 等動物角色常以冠詞性別化）；全書統一用「a cisne」配合女性角色 Ani，為品牌一致性決策，不構成歐葡滲漏亦非正字法錯誤——拒絕 |
| 2 | pt-BR-editora | 5-6 | P04 | 「Mas olha só:」冒號使用 | ❌ | — | 1路 | 童書旁白口吻允許冒號作語氣停頓，非正字法違規；BR 出版實務可見此用法——拒絕 |
| 3 | pt-BR-professora | 5-6 | P08 | 「terceira tentativa」偏進階 | ❌ | — | 1路 | 5-6 檔位允許進階詞彙（age_calibration E 表：因果複句允許、抽象概念可用但附具體情境），且前文已有兩次嘗試作上下文支撐——拒絕 |

獨有訊源分佈：獵手獨有 real 0｜回譯獨有 real 0｜人設獨有 real 0｜多路收斂 real 0

### STEP 4 結論

✅ real = 0, ❌ rejected = 3, ⏸️ escalated = 0。

本輪 ✅=0，QA 收斂。

---

## 附：copy↔draft 同源確認

copy/pt-BR.md 圖文總表的文本欄與 text/pt-BR/{tier}.draft.json 逐頁比對，三檔位全數一致（逐字匹配）。
